const input = {
  A: (a, b, c) => a + b + c,
  B: (a, b, c) => a * b * c,
  C: {
    D: {
      E: {
        F: (a, b, c) => a + b * c,
      }
    },
  },
}

let obj1 = {
  a: "sdas",
  b: "sds",
  c: {
    d:"sds"
  }
}


const getDupObject = (obj) => {
  return function (param1, param2, param3) {
    let res1 = JSON.parse(JSON.stringify(obj))
    let objDuplication = (obj, res1) => {
      for (let item in obj) {
        if (typeof obj[item] === "object") {
          objDuplication(obj[item], res1[item]);
        } else {
          res1[item] = obj[item](param1, param2, param3);
        }
      }
    };
    objDuplication(obj, res1);
    return res1;
  };
};

let r = getDupObject(input)(1, 2, 3);
console.log(JSON.stringify(r))