class Heap {
  constructor() {
    this.list = [];
  }

  heapify = (large) => {
    let largest = large;
    let left = 2 * large + 1;
    let right = 2 * large + 2;

    if (left < this.list.length && this.list[left] > this.list[largest]) {
      largest = left;
    }

    if (right < this.list.length && this.list[right] > this.list[largest]) {
      largest = right;
    }

    if (largest !== large) {
      let temp = this.list[large];
      this.list[large] = this.list[largest];
      this.list[largest] = temp;
      this.heapify(largest);
    }
  };

  insert = (num) => {
    this.list.push(num);
    if (this.len !== 0) {
      for (let i = Math.floor(this.list.length / 2 - 1); i >= 0; i--) {
        this.heapify(i);
      }
    }
  };
 
  delete = (num) => {
    let i;
    for (i = 0; i < this.list.length; i++) {
      if (this.list[i] === num) {
        break;
      }
    }

    [this.list[i], this.list[this.list.length - 1]] = [
      this.list[this.list.length - 1],
      this.list[i],
    ];
    this.list.splice(this.list.length - 1);
    for (let i = Math.floor(this.list.length / 2 - 1); i >= 0; i--) {
      this.heapify(i);
    }
  };

  getList = () => this.list;
}

const heap = new Heap();
heap.insert(3);
heap.insert(4);
heap.insert(9);
heap.insert(5);
heap.insert(2);
heap.delete(9);

console.log(heap.getList());

class MinHeap {
  constructor() {
      this.heap = []
  }
  
  push(val) {
      this.heap.push(val);
      this.siftUp()
  }
  
     pop() {
      this.swap(0, this.heap.length-1)
      let poppedEle = this.heap.pop();
      this.siftDown(0);
      return poppedEle;
  }
  
  siftDown(parentIdx) {
    let leftChildIdx = parentIdx*2+1;
      while (leftChildIdx < this.heap.length)  {
          let childIdx = leftChildIdx;
          let rightChildIdx =  parentIdx*2+2;
          if (rightChildIdx < this.heap.length && this.heap[rightChildIdx].val < this.heap[leftChildIdx].val)
              childIdx = rightChildIdx;
          if (this.heap[childIdx].val < this.heap[parentIdx].val) {
              this.swap(childIdx, parentIdx);
              parentIdx = childIdx;
              leftChildIdx = parentIdx*2+1;
          } else {
              return
          }
      }
  }
  
  siftUp() {
      let childIdx = this.heap.length-1;
      let parentIdx = Math.floor((childIdx-1)/2)
      while (childIdx > 0) {
          if (this.heap[childIdx].val < this.heap[parentIdx].val) {
                this.swap(childIdx, parentIdx);
  childIdx = parentIdx;
  parentIdx = Math.floor((childIdx-1)/2)
          } else {
          return
          }
      }
  }
  
  swap(i, j) {
      let temp = this.heap[i];
      this.heap[i] = this.heap[j];
      this.heap[j] = temp;
  }
  
  getMin() {
      return this.root[0]
  }
  getSize() {
      return this.heap.length
  }
}