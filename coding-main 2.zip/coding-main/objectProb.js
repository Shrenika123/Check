let obj = {
  address: {
    city: "Bangalore",
    ares: "rajajinagar",
    personalAddress: {
      city: "Bangalore",
      ares: "rajajinagar",
    },
  },
  phoneNumber: "99231232",
};

// let convertedObject = (obj, parent, finalObj) => {
//   for (item in obj) {
//     if (typeof obj[item] === "object") {
//       convertedObject(obj[item], parent + "_" + item, finalObj);
//     } else {
//       finalObj[parent + "_" + item] = obj[item];
//     }
//   }
//   return finalObj;
// };

// let finalObj = {};

// let res = convertedObject(obj, "user", finalObj);
// console.log(res);
// for (let item of Object.entries(obj)) {
//   console.log(item[1]);
// }

// console.log(obj, "user");

// for (let item in obj) {
//   console.log(obj[item]);
// }
// const convertedObjFun = (obj,parent,finalObj) => {
//   for (let key in obj) {
//     if (typeof (obj[key]) === 'object') {
//       convertedObjFun(obj[key],parent+"_"+key,finalObj)
//     }
//     else {
//       finalObj[parent+"_"+key]=obj[key]
//     }
//   }
//   return finalObj
// }

const convertedObjFun = (obj,parent,finalObj) => {
  for (let key in obj) {
    if (typeof (obj[key]) === 'object') {
      convertedObjFun(obj[key],parent+"_"+key,finalObj)
    }
    else {
      finalObj[parent+"_"+key]=obj[key]
    }
  }

  return finalObj
}
console.log(convertedObjFun(obj,'root',{}))