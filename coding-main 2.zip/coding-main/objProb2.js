const obj = {
  a: {
    b: {
      c: 113,
      d: {
        e: 54,
      },
    },
    f: [1331, 97],
  },
  g: 2,
  h: {
    i: 121,
  },
};

let res1 = [];
let i = 0;
let sum = 0;
const getValue = (objValue) => {
  for (let a in objValue) {
    if (typeof objValue[a] === "object") {
       getValue(objValue[a]);
    } else {
      sum = sum + objValue[a];
    }
  }
  return sum;
};

const res = getValue(obj);
console.log(res);
