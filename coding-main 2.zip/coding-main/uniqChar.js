let s1 = "abbcdg";

let checkUniq = (string) => {
  let tempArr = new Array(26).fill(false);
  let a = 97;
  let A = 65;
  for (let i = 0; i < string.length; i++) {
    let char;
    char = string.charCodeAt(i) - a;

    if (tempArr[char] === true) return false;
    else tempArr[char] = true;
  }
  return true;
};

let uniqCharFun = (string) => {
  let set = new Set(string);

  if (set.size === string.length) return true;
  else return false;
};

let res = checkUniq(s1);
let res1 = uniqCharFun(s1);
console.log(res, res1);
