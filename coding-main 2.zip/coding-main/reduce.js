if (!Array.prototype.myReduce) {
  Array.prototype.myReduce = function (callback, initial = null) {
    let acc = initial ?? this[0];
    let i = initial ? 0 : 1;
    for (; i < this.length; i++) {
      acc = callback(acc, this[i], i, this);
    }
    return acc;
  };
}

let arr = [1, 2, 3];
console.log(arr.myReduce((acc, cur) => acc + cur));
