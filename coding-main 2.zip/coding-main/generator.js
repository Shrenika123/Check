function* calculate() {
  let arr = [1, 2, 3, 4];
  for (let i = 0; i < arr.length; i++) {
    yield i;
  }
}

const res = calculate();
console.log(res.next());
console.log(res.next().value);
console.log(res.next().value);
console.log(res.next().value);
console.log(res.next().value);
console.log(res.next().value);
console.log(res.next().value);
console.log(res.next().value);
console.log(res.next().value);
