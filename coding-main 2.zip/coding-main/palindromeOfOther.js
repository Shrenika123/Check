let s1="abc";
let s2="bac";

let palindromeMatch=()=>{
    
}