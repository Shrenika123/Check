let arr = [1, 2, [3, 4, [5, 6, [7, [8, 9, 10]]]]];

// function flattenArray(array) {
//   let acc = [];
//   for (let i = 0; i < array.length; i++) {
//     if (Array.isArray(array[i])) {
//       acc = acc.concat(flattenArray(array[i]));
//     } else {
//       console.log(array[i]);
//       acc = acc.concat(array[i]);
//     }
//   }
//   return acc;
// }

// function flatten(arr) {
//   return arr.reduce((acc, next) => {
//     let isArray = Array.isArray(next);
//     return acc.concat(isArray ? flatten(next) : next);
//   }, []);
// }

// console.log(flatten(arr));

// const obj = {
//   level1: {
//     level2: {
//       level3: {
//         more: "stuff",
//         other: "otherz",
//         level4: {
//           the: "end",
//         },
//       },
//     },
//     level2still: {
//       last: "one",
//     },
//     am: "bored",
//   },
//   more: "what",
//   ipsum: {
//     lorem: "latin",
//   },
// };

// var removeNesting = function (obj, parent) {
//   for (let key in obj) {
//     if (typeof obj[key] === "object") {
//       removeNesting(obj[key], parent + "." + key);
//     } else {
//       flattenedObj[parent + "." + key] = obj[key];
//     }
//   }
// };

// let flattenedObj = {};
// const sample = removeNesting(obj, "");
// console.log(flattenedObj);

Array.prototype.flattenArray = function () {
  function flatten(arr) {
  return arr.reduce((acc, next) => {
    let isArray = Array.isArray(next);
    return acc.concat(isArray ? flatten(next) : next);
  }, []);
}
 return flatten(this)
}

console.log(arr.flattenArray())