//function statements aka function declaration--function statements cannot have annonymous functions
function a() {
  console.log("a", this);
  console.log("hi");
  return function b() {
    console.log("b", this);
  };
}

//function expression
// var store = function () {
//   console.lo0g("hi");
// };

// //named function expression
// var namedFun = function name() {
//   console.log(name);
// };

//name()///will give refrencde erroe
// const val = a();
// val();

// class Hero {
//   constructor(heroName) {
//     this.heroName = heroName;
//   }

//   logName = () => {
//     console.log(this.heroName);
//   };
// }
// const batman = new Hero("Batman");
// batman.logName();

const obj = {
  a: this,
  b: function () {
    return this;
  },
  c: () => {
    return this;
  },
  d() {
    return this;
  },
  e: function () {
    return this.a;
  },
};

console.log(obj.a);
