if (!Array.prototype.myMap) {
  Array.prototype.myMap = function (callback) {
    let res = [];
    for (let i = 0; i < this.length; i++) {
      res.push(callback(this[i]));
    }
    return res;
  };
}

let arr = [1, 2, 3];
console.log(arr.myMap((ele) => ele * 2));

if (!Array.prototype.myFilter) {
  Array.prototype.myFilter = function (callback) {
    let res = [];
    this.forEach((ele) => {
      let curFlag = callback(ele);
      if (curFlag) {
        res.push(ele);
      }
    });
    return res;
  };
}

console.log(arr.myFilter((ele) => ele % 3 !== 0));
