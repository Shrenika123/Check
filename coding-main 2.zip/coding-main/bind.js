let obj = {
  name: "Jack",
};
``;
let myFunc = function (id, city) {
  console.log(`${this.name}, ${id}, ${city}`); // id will be undefined
};

// Accepting any number of arguments passed to myBind
Function.prototype.myBind = function (obj, ...args) {
  let func = this;
  console.log(this);
  // Accepting arguments passed to newFunc
  return function (...newArgs) {
    func.apply(obj, [...args, ...newArgs]);
  };
};

let newFunc = myFunc.myBind(obj, "a_random_id");
newFunc("New York");

// Function.prototype.newBind = function (obj, ...args) {
//   const fun = this;
//   return function (...newArgs) {
//     fun.apply(obj, [...args, ...newArgs]);
//   };
// };


Function.prototype.newBind = function (obj,...args) {
  return (...newArgs) => {
    this.apply(obj,[...args,...newArgs])
  }
}

let newFunc1 = myFunc.newBind(obj, "a_random_id");
newFunc1("New York");

Function.prototype.newBind =function (obj, ...params) {
  const that=this
  return function (...newArgs) {
    that.apply(obj,[...params,newArgs])
  }
}

const fun = myFunc.newBind(obj, 'wow');

fun("place","threes")