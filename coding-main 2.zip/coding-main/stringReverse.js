var reverseWords = function (s) {
  let words = s.split(" ");

  const reverse = (str, i) => {
    console.log(i);
    let strArray = str.split("");
    let low = 0;
    let high = strArray.length - 1;
    while (low < high) {
      [strArray[low], strArray[high]] = [strArray[high], strArray[low]];
      low++;
      high--;
    }
    words[i] = strArray.join("");
  };

  words.forEach((ele, i) => reverse(ele, i));
  return words;
};
reverseWords("Let's take LeetCode contest").join(" ");
