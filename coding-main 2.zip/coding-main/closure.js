// const setTimeoutFun = () => {
//   for (var i = 1; i <= 5; i++) {
//     (() => {
//       let j = i;
//       setTimeout(() => {
//         console.log(j);
//       }, 1000);
//     })();
//   }
// };

// setTimeoutFun();

//or

// const setTimeoutFun = () => {
//   for (var i = 1; i <= 5; i++) {
//     ((i) => {
//       setTimeout(() => {
//         console.log(i);
//       }, 1000);
//     })(i);
//   }
// };

// setTimeoutFun();

//or

// const setTimeoutFun = () => {
//   for (let i = 1; i <= 5; i++) {
//     setTimeout(() => {
//       console.log(i);
//     }, 1000);
//   }
// };

// setTimeoutFun();

//proper use of closure .,can be used s constructor

function counter() {
  let count = 0;
  this.incrementCounter = () => {
    // console.log(count++);
  };

  this.decrementCounter = () => {
    // console.log(count--);
  };
}

let counterInstance = new counter();
counterInstance.incrementCounter();
counterInstance.decrementCounter();

let arr = [1, 2, 3, 4];
const reduceFun = arr.reduce((acc, cur) => {
  return acc + cur;
}, 0);
// console.log(reduceFun);

const maxVal = arr.reduce((acc, cur) => {
  return acc > cur ? acc : cur;
}, 0);

// console.log(maxVal);

let obj = [
  { firstname: "sre", lastname: "na", age: 10 },
  { firstname: "sre1", lastname: "na1", age: 20 },
  { firstname: "sre2", lastname: "na2", age: 23 },
];

let lastFirstFun = obj.map((cur) => {
  return cur.firstname + cur.lastname;
});

console.log(lastFirstFun);

let countAge = obj.reduce((acc, cur) => {
  if (acc[cur.age]) {
    acc[cur.age] += 1;
  } else {
    acc[cur.age] = 1;
  }
  return acc;
}, {});

// console.log(countAge);

let ageLessThan = obj.filter((x) => x.age <= 20).map((x) => x.firstname);

// console.log(ageLessThan);

let ageLess = obj.reduce((acc, cur) => {
  if (cur.age <= 20) {
    acc.push(cur.firstname);
  }
  return acc;
}, []);

// console.log(ageLess);

const sumFun = (x) => (y) => {
  console.log(x,y)
  return y ? sumFun(x + y) : x
}

const res = sumFun(1)(2)(4)(5)(8)();
console.log(res);


function curry(callback) {
  // Write your code here.
  const CurriedFunction=(...args)=>{
    if (args.length === 0) {
      console.log("hey")
     return callback()
    }
    else{
      return (...otherArgs)=>{
        if (otherArgs.length === 0) {
          console.log("hey1")
          return callback(...args)
        }
        else {
          console.log("hey3")

         return CurriedFunction(...args,...otherArgs)
        }
      } 
    }
  }

  return CurriedFunction;
}

const sumFunction = (...numbers) => numbers.reduce((acc, cur) => acc + cur, 0);

const sumVal = curry(sumFunction);
console.log(sumVal(1,4,5)(2)(3)(4)())