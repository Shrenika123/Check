class MethodChaining{
    constructor() {
        this.value=0
    }

    sum(...args) {
        this.value = [...args].reduce((acc, cur) => {
         return acc+cur   
        }, 0)
        return this;
    }

    subtract(value) {
        this.value = this.value - value;
        return this
    }
}

let methodChainingInstance = new MethodChaining();
console.log(methodChainingInstance.sum(1,2,3).subtract(5).value)