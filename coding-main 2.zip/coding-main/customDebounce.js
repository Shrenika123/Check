

const customDebounce = (callback, delay) => {
    let timer
    return function (...args) {
        clearTimeout(timer)
        timer = setTimeout(() => {
            callback.call(this,...args)
        },delay)
    }
}

const btn = document.querySelector("#throttle");
btn.addEventListener('click',customDebounce((arg)=>console.log(arg),3000)('str'))