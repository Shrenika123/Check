import { FC } from 'react';
import UploadSuccessIcon from '../../assets/icons/Upload-Cloud-Check.svg';

const SuccessModalView : FC = () =>{
return (
  <div className="flex align-items-center flex-column modal-success-area">
    <img style={{width:'4rem',height:'4rem'}} src={UploadSuccessIcon} alt=''/>
    <span className="my-2 success-modal-header">Success!</span>
    <span className='success-modal-text '>Your file(s) has been successfully uploaded</span>
  </div>
)
}

export default SuccessModalView;