import { Toast } from 'primereact/toast';
import { FC, Ref, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IAlertState } from '../../common/interfaces';
import { setShowAlert } from '../../redux/reducers/alert.reducer';
import { toast } from "react-toastify";
import './Alert.style.css';

const Alert: FC = () => {

const alert = useSelector((state: IAlertState) => state.alert);

const dispatch = useDispatch();

  useEffect(() => {
   switch(alert.alertType){
      case 'warn':
        toast(`${alert.alertTitle?alert.alertTitle:''}${alert.alertDescription?'.\n'+alert.alertDescription:''}`,
          {type: 'warning',toastId:`${alert.alertTitle?alert.alertTitle:''}${alert.alertDescription?'.\n'+alert.alertDescription:''}`})
        break;
      case 'error':
        toast(`${alert.alertTitle?alert.alertTitle:''}${alert.alertDescription?'.\n'+alert.alertDescription:''}`,
          {type: 'error',toastId:`${alert.alertTitle?alert.alertTitle:''}${alert.alertDescription?'.\n'+alert.alertDescription:''}`})
        break;
      case 'success':
        toast(`${alert.alertTitle?alert.alertTitle:''}${alert.alertDescription?'.\n'+alert.alertDescription:''}`,
          {type: 'success'})
        break;
      case 'info':
        toast(`${alert.alertTitle?alert.alertTitle:''}${alert.alertDescription?'.\n'+alert.alertDescription:''}`,
          {type: 'info',toastId:`${alert.alertTitle?alert.alertTitle:''}${alert.alertDescription?'.\n'+alert.alertDescription:''}`})
        break;
      }
    dispatch(setShowAlert({ showAlert: false, alertType: '', alertTitle: '', alertDescription: '' }));
  }, [alert]);

  return null;
  
};

export default Alert;