import { cleanup, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import Alert from '../Alert.component';

afterEach(cleanup);

describe('Alert Component', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userGroupId: 'powerUserDummyId',
      userGroupName: 'Power User',
      userGroupRoutes: ['/po-management',
        '/po-management/details',
        '/item-management',
        '/vessel-tracking',
        '/vessel-tracking/details',
        '/admin-panel']
    },
    navbar: {
      isExpanded: false
    },
    alert: {
      showAlert: false,
      alertType: '',
      alertTitle: '',
      alertDescription: ''
    }
  };
  const powerUserStore = mockStore(powerUserState);

  test('should render component', () => {
    render(
      <Provider store={powerUserStore}>
        <Alert />
      </Provider>, { wrapper: BrowserRouter }
    );
  });
});