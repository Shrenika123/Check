import classNames from 'classnames';
import React from 'react';
import './NavigationBackButton.style.css';
import { IoMdArrowDropdown } from 'react-icons/io';
import { Button } from '@mui/material';

interface NavigateBackButtonProps {
  navigate: () => void;
  label: string;
  isExpanded: boolean;
}
//button may be used in future
const NavigateBackButton: React.FC<NavigateBackButtonProps> = ({
  label,
  navigate,
  isExpanded,
}) => {
  const headerClass = classNames('header', {
    'header-shrink': isExpanded,
  });
  return (
    <div id='NavigationBackButtonContainer'>
      <section className={headerClass}>
        <div className={classNames('text-header', 'mainContainer')}>
          <i
            className={classNames('arrowStyle', 'pi pi-arrow-left back-button')}
            onClick={() => navigate()}
            data-testid='backButtonGeneral'
          ></i>
          {/* <Button variant='contained' disabled className='buttonContainer'> */}
          {label}
          {/* </Button> */}
        </div>
      </section>
    </div>
  );
};
export default NavigateBackButton;
