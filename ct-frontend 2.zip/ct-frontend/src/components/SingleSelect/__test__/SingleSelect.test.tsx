import { act, cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {
  checkElementNotPresentInDomByTestId,
  checkElementPresentInDomByTestId,
  clickedSpecificElementInGroup,
  clickElementByTestId,
  elementContainsSpecifiedText,
  setInputValue,
} from '../../../common/helper/testHelper';
import SingleSelectFilter from '../index';

afterEach(cleanup);

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});

const mockData = {
  buttonTittle: 'Select ID',
  dataTestId: 'one',
  onRadioClick: () => {},
  onSearchValue: jest.fn(),
  data: [
    { key: '1', value: 'one' },
    { key: '2', value: 'Two' },
  ],
};

describe('single Select filter component', () => {
  test('should render the singleSelect filter component', async () => {
    render(<SingleSelectFilter {...mockData} />);
    await checkElementPresentInDomByTestId('singleSelectButton-one-testid');
    await checkElementNotPresentInDomByTestId(
      'singleSelectDropdown-one-testid'
    );
  });

  test('on click of button dropdown is displayed and click of radio button changes the button title', async () => {
    render(<SingleSelectFilter {...mockData} />);
    await act(async () => {
      await clickElementByTestId('singleSelectButton-one-testid');
    });
    await checkElementPresentInDomByTestId('singleSelectDropdown-one-testid');
    await checkElementNotPresentInDomByTestId('single-select-input-one');
    await elementContainsSpecifiedText(
      'singleSelectButtonTitle-one-testid',
      'Select ID'
    );
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-one-testid',
      0
    );
    await elementContainsSpecifiedText(
      'singleSelectButtonTitle-one-testid',
      'one'
    );
  });

  test('When No Data present', async () => {
    render(
      <SingleSelectFilter
        {...mockData}
        data={[]}
      />
    );
    await act(async () => {
      await clickElementByTestId('singleSelectButton-one-testid');
    });
    await checkElementPresentInDomByTestId('singleSelect-noData-one-testid');
    await checkElementNotPresentInDomByTestId(
      'singleSelectDropdown-one-testid'
    );
  });

  test('Click outside functionality on Single Select Filter', async () => {
    render(
      <SingleSelectFilter
        {...mockData}
        search
      />
    );
    await act(async () => {
      await clickElementByTestId('singleSelectButton-one-testid');
    });
    await checkElementPresentInDomByTestId('singleSelectDropdown-one-testid');
    userEvent.click(document.body);
    await checkElementNotPresentInDomByTestId(
      'singleSelectDropdown-one-testid'
    );
  });

  test('OnSearch functionality', async () => {
    render(
      <SingleSelectFilter
        {...mockData}
        search
      />
    );
    await act(async () => {
      await clickElementByTestId('singleSelectButton-one-testid');
    });
    await checkElementPresentInDomByTestId('singleSelectDropdown-one-testid');
    await checkElementPresentInDomByTestId('singleSelectButton-one-testid');
    await checkElementPresentInDomByTestId('single-select-input-one');
    await setInputValue('single-select-input-one', '1234');
  });
});
