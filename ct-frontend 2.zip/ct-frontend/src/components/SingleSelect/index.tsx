import { debounce } from '@mui/material';
import classNames from 'classnames';
import React, { useEffect, useRef, useState } from 'react';
import { IoIosArrowDown } from 'react-icons/io';
import { useDebounce } from '../../hooks/useDebounce';
import { useOnClickOutside } from '../../hooks/useOnClickOutside';
import './index.style.css';

export interface ISelectElement {
  key: string;
  value: string;
}

interface ISingleSelectProps {
  buttonTittle: string;
  data: ISelectElement[];
  onRadioClick: (data: ISelectElement, searchStr?: string | null) => void;
  className?: any;
  search?: boolean;
  disabled?: boolean;
  dataTestId: string;
  onSearchValue?: (e: string) => void;
  minLength?: number;
  resetSelectedValue?: boolean;
}

const SingleSelect: React.FC<ISingleSelectProps> = ({
  buttonTittle,
  data,
  onRadioClick,
  className,
  search,
  disabled,
  dataTestId,
  onSearchValue,
  minLength,
  resetSelectedValue,
}) => {
  const [dropDownClicked, setDropDownClicked] = useState<boolean>(false);
  const [selectedValue, setSelectedValue] = useState<string>(buttonTittle);
  const [searchValue, setSearchValue] = useState<string | null>(null);
  const singleSelectRef = useRef(null);
  const [loading, setLoading] = useState<boolean>(false);

  const debounceValue = useDebounce(searchValue!, 500);

  useEffect(() => {
    if (resetSelectedValue) {
      setSearchValue(null);
    }
  }, [resetSelectedValue]);

  useEffect(() => {
    if (!(search && debounceValue !== null && debounce.length >= 0)) {
      setSelectedValue(buttonTittle);
    }
    setLoading(false);
  }, [data, debounceValue]);

  useOnClickOutside(singleSelectRef, () => setDropDownClicked(false));

  useEffect(() => {
    if (debounceValue !== null) {
      setLoading(true);
      if (debounceValue.length >= 0) {
        onSearchValue?.(debounceValue);
      }
    }
  }, [debounceValue]);

  const handleOnClick = (val: ISelectElement) => {
    setSelectedValue(val.value);
    onRadioClick(val, searchValue);
    setDropDownClicked(false);
  };

  const getNoDataCondition = () => {
    if (data.length === 0 && searchValue && searchValue.length < minLength!) {
      return false;
    } else if ((data.length === 0 && search) || data.length === 0) {
      return true;
    }
    return false;
  };

  return (
    <section
      id='single-select-wrapper'
      ref={singleSelectRef}>
      <div className={classNames(className ?? '', 'singleSelector')}>
        <button
          className='dropDownButton'
          onClick={() => setDropDownClicked(!dropDownClicked)}
          disabled={disabled}
          data-testid={`singleSelectButton-${dataTestId}-testid`}>
          <div
            className='dropDownLabel'
            data-testid={`singleSelectButtonLabel-${dataTestId}-testid`}>
            <p data-testid={`singleSelectButtonTitle-${dataTestId}-testid`}>
              {selectedValue}
            </p>
            <p>{<IoIosArrowDown size={'1.2rem'} />}</p>
          </div>
        </button>
        {dropDownClicked && (
          <div className='dropDownElements'>
            {search && (
              <input
                data-testid={`single-select-input-${dataTestId}`}
                type='text'
                placeholder={`Type ${minLength} character for suggestions`}
                className='searchInput'
                onChange={(e) => setSearchValue(e.target.value)}
                value={searchValue ?? ''}
              />
            )}
            {data.length > 0 && (
              <div
                className='radioWrapperContainer'
                data-testid={`singleSelectDropdown-${dataTestId}-testid`}>
                {data.map((item) => (
                  <div onClick={() => handleOnClick(item)}
                    className='radioWrapper'
                    key={item.key}>
                    <input
                      type='radio'
                      name='gender'
                      className='radio'
                      defaultChecked={item.value === selectedValue}
                      data-testid={`singleSelectRadioButton-${dataTestId}-testid`}
                    />
                    <p> {item.value}</p>
                  </div>
                ))}
              </div>
            )}
            {dropDownClicked && getNoDataCondition() && !loading && (
              <div
                className='noData'
                data-testid={`singleSelect-noData-${dataTestId}-testid`}>
                {'No data'}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
export default SingleSelect;
