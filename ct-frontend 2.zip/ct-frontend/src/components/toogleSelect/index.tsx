import classNames from 'classnames';
import React, { useState } from 'react';
import { isStringValid } from '../../common/utils';
import './index.style.css';

interface IToggleButtonProps {
  preSelectedValue: string;
  onClick: (
    e: React.MouseEvent<HTMLButtonElement, MouseEvent>,
    selectedValue: string,
    preSelectedValue: string
  ) => void;
  toggleTitles: string[];
}

const ToggleButton: React.FC<IToggleButtonProps> = ({
  preSelectedValue,
  onClick,
  toggleTitles,
}) => {
  const [toggle, setToggle] = useState<string>('');

  const getStyle = (type: string) => {
    if (
      type === preSelectedValue &&
      (toggle === preSelectedValue || !isStringValid(toggle))
    ) {
      return 'default';
    } else if (type === toggle && type !== preSelectedValue) {
      return 'active';
    }
    return '';
  };

  const handleOnClick = (
    e: React.MouseEvent<HTMLButtonElement, MouseEvent>,
    type: string
  ) => {
    setToggle(type);
    onClick(e, type, preSelectedValue);
  };
  return (
    <>
      <div
        data-testid='toggle'
        id='tri-state-toggle'
        className={
          toggle !== '' && toggle !== preSelectedValue ? 'active' : ''
        }>
        <button
          data-testid='toggleOne'
          className={classNames('tri-state-toggle-button', getStyle('one'))}
          onClick={(e) => handleOnClick(e, 'one')}>
          {toggleTitles[0]}
        </button>
        <button
          data-testid='toggleTwo'
          className={classNames('tri-state-toggle-button', getStyle('two'))}
          onClick={(e) => handleOnClick(e, 'two')}>
          {toggleTitles[1]}
        </button>
        <button
          data-testid='toggleThree'
          className={classNames('tri-state-toggle-button', getStyle('three'))}
          onClick={(e) => handleOnClick(e, 'three')}>
          {toggleTitles[2]}
        </button>
      </div>
    </>
  );
};
export default ToggleButton;
