import { act, render } from '@testing-library/react';
import ToggleButton from '..';
import {
  checkClassNameStyle,
  checkElementPresentInDomByTestId,
  clickElementByTestId,
} from '../../../common/helper/testHelper';

describe('toggle button component', () => {
  test('should render the singleSelect filter component', async () => {
    render(
      <ToggleButton
        toggleTitles={['one', 'two', 'three']}
        preSelectedValue='one'
        onClick={() => {}}
      />
    );
    await checkElementPresentInDomByTestId('toggle');
    await checkClassNameStyle('toggleOne', 'tri-state-toggle-button default');
    await checkClassNameStyle('toggleTwo', 'tri-state-toggle-button');
    await checkClassNameStyle('toggleThree', 'tri-state-toggle-button');
  });
  test('on click of toggleButton', async () => {
    render(
      <ToggleButton
        toggleTitles={['one', 'two', 'three']}
        preSelectedValue='one'
        onClick={() => {}}
      />
    );
    await checkElementPresentInDomByTestId('toggle');
    await act(async () => {
      await clickElementByTestId('toggleTwo');
    });
    await checkClassNameStyle('toggleTwo', 'tri-state-toggle-button active');
    await checkClassNameStyle('toggleOne', 'tri-state-toggle-button');
    await checkClassNameStyle('toggleThree', 'tri-state-toggle-button');
    await act(async () => {
      await clickElementByTestId('toggleOne');
    });
    await checkClassNameStyle('toggleOne', 'tri-state-toggle-button default');
    await checkClassNameStyle('toggleTwo', 'tri-state-toggle-button');
    await checkClassNameStyle('toggleThree', 'tri-state-toggle-button');
    await act(async () => {
      await clickElementByTestId('toggleThree');
    });
    await checkClassNameStyle('toggleThree', 'tri-state-toggle-button active');
    await checkClassNameStyle('toggleTwo', 'tri-state-toggle-button');
    await checkClassNameStyle('toggleOne', 'tri-state-toggle-button');
  });
});
