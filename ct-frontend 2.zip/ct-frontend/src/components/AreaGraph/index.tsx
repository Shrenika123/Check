import classNames from 'classnames';
import React from 'react';
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import { Margin } from 'recharts/types/util/types';
import { numberFormat } from '../../common/utils';
import './index.style.css';
export interface IAreaGraphDataElement {
  name: string;
  value: string | number;
}

interface IAreaGraphProps {
  graphFontSize: string;
  graphStyle?: Margin;
  height?: number;
  data: IAreaGraphDataElement[];
  range: number[];
  strokeWidth: number;
  maxQuantity: number;
  active?: string;
}

const AreaGraph: React.FC<IAreaGraphProps> = ({
  graphStyle,
  graphFontSize,
  height,
  strokeWidth,
  data,
  range,
  maxQuantity,
  active,
}) => {
  const getGraphStyle = (): Margin => {
    if (graphStyle) return graphStyle;
    else {
      return {
        top: 20,
        right: 20,
        left: 20,
        bottom: 15,
      };
    }
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <p
          className={classNames('label', 'customLabelAreGraph')}
        >{`${label} : ${numberFormat(payload[0].value)}`}</p>
      );
    } else {
      return <></>;
    }
  };

  const CustomYAxisTick = (props: any) => {
    const { y, payload } = props;

    return (
      <g transform={`translate(${0},${y})`}>
        <text fontSize={'12px'} x={70} y={3} textAnchor='end' fill='#666'>
          {new Intl.NumberFormat('en-US', {
            notation: 'compact',
            compactDisplay: 'short',
          }).format(payload.value)}
        </text>
      </g>
    );
  };

  return (
    <>
      <div id='areaGraphContainer'>
        <ResponsiveContainer height={height ?? 100} width='99%'>
          <ComposedChart data={data} margin={getGraphStyle()}>
            <defs>
              <linearGradient id='colorUv' x1='0' y1='0' x2='0' y2='1'>
                <stop offset='40%' stopColor='#B6F24D' stopOpacity={0.8} />
                <stop offset='95%' stopColor='black' stopOpacity={0.5} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke='#B3B3B366' />
            <XAxis dataKey='name' tickLine={false} fontSize={graphFontSize} label={{ value: "Last Year's Inventory Plan Trend", dy: 22, fontSize: 13, fill: '#B6F24D' }} />
            <YAxis
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => numberFormat(value)}
              allowDataOverflow={true}
              fontSize={graphFontSize}
              tick={<CustomYAxisTick />}
              ticks={range}
              domain={[0, maxQuantity]}
              label={{ value: 'ITEM QUANTITY', angle: -90, dx: -30, fontSize: 12, fill: '#B6F24D' }}
            />
            <Area
              type='monotone'
              dataKey='value'
              stroke='#B6F24D'
              fill='url(#colorUv)'
              strokeWidth={0}
            />
            <ReferenceLine x={active} stroke='white' strokeWidth={2} />
            <Tooltip
              wrapperStyle={{ outline: 'none' }}
              content={<CustomTooltip />}
            />
            <Line
              type='monotone'
              dataKey='value'
              stroke='#B6F24D'
              strokeWidth={2}
              isAnimationActive={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </>
  );
};
export default AreaGraph;
