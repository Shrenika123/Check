import { FC, ReactElement } from 'react';
import { useSelector } from 'react-redux';
import { ILoadingState } from '../../common/interfaces';
import './Loading.style.css';

const Loading: FC = (): ReactElement => {

  const showLoading = useSelector((state: ILoadingState) => state.loading.isLoading);
  const className = showLoading ? 'showLoading' : 'hideLoading';

  return (
    <div id='screen-loading' className={className}>
      <div id='backdrop-loading'></div>
    </div>
  );
};

export default Loading;