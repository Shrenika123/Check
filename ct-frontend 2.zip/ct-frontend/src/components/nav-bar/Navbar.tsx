import Tooltip from '@mui/material/Tooltip';
import { useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom";
import expandIcon from '../../assets/icons/0.expandIcon.png';
import homeIcon from '../../assets/icons/1.dashboard.icon.png';
import adminPanelIcon from '../../assets/icons/adminPanel.icon.png';
import poManagementIcon from '../../assets/icons/2.po.icon.png';
import poItemManagementIcon from '../../assets/icons/3.itemManage.icon.png';
import tesseractIcon from '../../assets/icons/5.shipManage.icon.png';
import calenderIcon from '../../assets/icons/7.buyPlanManage.icon.png';
import trackerIcon from '../../assets/icons/8.liveTracker.icon.png';
import docIcon from '../../assets/icons/9.docLibrary.icon.png';
import externalizationIcon from '../../assets/icons/Externalization.svg';
import { routes } from '../../common/navigation-utils';
import { labels } from '../../common/constants';
import { IRoutePermission, IUserState } from '../../common/interfaces';
import './Navbar.css';

interface NavBarProps {
  selected: string;
  toggleExpansion: Function;
  isExpanded: boolean;
}

const Navbar: React.FC<NavBarProps> = (props) => {

  const navigate = useNavigate();
  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
console.log(userGroupRoutes);
  const navigationAction = (routeTo: string) => {
    navigate(`/${routeTo}`);
  };

  // checking if the route exists for the loggedin user. if not then it will disable the route
  const routeDisabledClassName = (route: string) => {
    return !userGroupRoutes.some(routePer=> routePer.route === route && routePer.permission !== 'NA') ? 'disabled' : '';
  };

  const isSelectedClassName = (routesVar: string[]) => {
    return routesVar.some(route => route === props.selected) ? 'selected' : '';
  };

  return (
    <section data-testid='navbar' className={props.isExpanded ? "navbar expanded" : "navbar"}>
      <div id='expandIcon'>
        <img data-testid='toggleButton' className={props.isExpanded ? 'expandIcon cursor' : 'cursor'} src={expandIcon} alt='' onClick={() => props.toggleExpansion()} />
      </div>
      <div data-testid='home' id='home' className={`icon ${routeDisabledClassName(routes.home)} ${isSelectedClassName([routes.home])}`} onClick={() => navigationAction(routes.home)}>
        <Tooltip title="Dashboard" placement="right">
          <img src={homeIcon} alt='' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.home}</p> : <></>}
      </div>
      <div data-testid='po' id='po' className={`icon ${routeDisabledClassName(routes.poManagement)} ${isSelectedClassName([routes.poManagement, routes.lineDetails])}`} onClick={() => navigationAction(routes.poManagement)}>
        <Tooltip title="PO Management" placement="right">
          <img src={poManagementIcon} alt='' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.poManagement}</p> : <></>}
      </div>
      <div data-testid='poItem' id='poItem' className={`icon ${routeDisabledClassName(routes.itemManagement)} ${isSelectedClassName([routes.itemManagement])}`} onClick={() => navigationAction(routes.itemManagement)}>
        <Tooltip title="Item Management" placement="right">
          <img src={poItemManagementIcon} alt='' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.itemManagement}</p> : <></>}
      </div>
      <div data-testid='shipAndLoadManagement' id='shipAndLoadManagement' className={`icon ${routeDisabledClassName(routes.shipLoadManagement)} ${isSelectedClassName([routes.shipLoadManagement])}`} onClick={() => navigationAction(routes.shipLoadManagement)}>
        <Tooltip title="Shipment & Load Management" placement="right">
          <img src={tesseractIcon} alt='' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.shipAndLoadManagement}</p> : <></>}
      </div>
      <div data-testid='buyPlan' id='buyPlan' className={`icon ${routeDisabledClassName(routes.eventBuyPlanManagement)} ${isSelectedClassName([routes.eventBuyPlanManagement, routes.eventBuyPlanManagementDetails])}`} onClick={() => navigationAction(routes.eventBuyPlanManagement)}>
        <Tooltip title="Event and Inventory Plan Management" placement="right">
          <img src={calenderIcon} alt='' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.buyPlanEventManagement}</p> : <></>}
      </div>
      <div data-testid='vesselTracker' id='vesselTracker' className={`icon ${routeDisabledClassName(routes.vesselTracking)} ${isSelectedClassName([routes.vesselTracking, routes.vesselTrackingDetails])}`} onClick={() => navigationAction(routes.vesselTracking)}>
        <Tooltip title="Vessel Tracking" placement="right">
          <img src={trackerIcon} alt='' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.vesselTracking}</p> : <></>}
      </div>
      <div data-testid='docLibrary' id='docLibrary' className={`icon ${routeDisabledClassName(routes.documentLibrary)} ${isSelectedClassName([routes.documentLibrary])}`} onClick={() => navigationAction(routes.documentLibrary)}>
        <Tooltip title="Document Library" placement="right">
          <img src={docIcon} alt='' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.docLibrary}</p> : <></>}
      </div>
      <div data-testid='Externalization' id='externalization' className={`icon ${routeDisabledClassName(routes.externalization)} ${isSelectedClassName([routes.externalization])}`} onClick={() => navigationAction(routes.externalization)}>
        <Tooltip title="Externalization" placement="right">
          <img src={externalizationIcon} alt='externalization' />
        </Tooltip>
        {props.isExpanded ? <p className='icon-text'>{labels.externalization}</p> : <></>}
      </div>
      { routeDisabledClassName(routes.adminPanel) !== 'disabled' && <div className='settings-wrap'>
        <div data-testid='settings' id="settings" className={`icon ${routeDisabledClassName(routes.adminPanel)} ${isSelectedClassName([routes.adminPanel])}`} onClick={() => navigationAction(routes.adminPanel)}>
        <Tooltip title="Admin" placement="right">
            <img src={adminPanelIcon} alt='' />
            </Tooltip>
          {props.isExpanded ? <p className='icon-text'>{labels.adminPanel}</p> : <></>}
        </div>
      </div>}
    </section>
  );
};

export default Navbar; 