import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../common/constants';
import { checkClassNameStyle } from '../../common/helper/testHelper';
import HomePage from '../../pages/main-container/home-page/Homepage.component';
import GroupGuard from '../../router/GroupGuard.router';
import Navbar from './Navbar';

afterEach(() => {
  cleanup();
});

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "NA",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
};


const mockStore = configureStore();

test('should render Navigation Bar component', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={'po-management'}
        toggleExpansion={() => {}}
        isExpanded={false}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const navbar = screen.getByTestId('navbar');
  expect(navbar).toBeInTheDocument();
  expect(navbar).toBeVisible();
});

test('should render the expanded view on Navigation Bar component', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={'po-management'}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const toggleButton = screen.getByTestId('toggleButton');
  userEvent.click(toggleButton);
  expect(screen.getByText('Dashboard')).toBeVisible();
  expect(screen.getByText('PO Management')).toBeVisible();
  expect(screen.getByText('Item Management')).toBeVisible();
  //expect(screen.getByText('Vendor Management')).toBeVisible();
  expect(screen.getByText('Shipment & Load Management')).toBeVisible();
  //expect(screen.getByText('Zone & Loc Management')).toBeVisible();
  expect(screen.getByText('Event & Inventory Plan Management')).toBeVisible();
  expect(screen.getByText('Vessel Tracking')).toBeVisible();
  expect(screen.getByText('Document Library')).toBeVisible();
  expect(screen.getByText('Admin Panel')).toBeVisible();
});

test('should navigate to home', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={routes.home}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const dashboard = screen.getByTestId('home');
  expect(dashboard).toBeVisible();
  userEvent.click(dashboard);
  expect(window.location.pathname).toBe(`/${routes.home}`);
  expect(dashboard.className).toBe('icon  selected');
});

test('should highlight item management', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={routes.itemManagement}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const poItem = screen.getByTestId('poItem');
  expect(poItem).toBeVisible();
  expect(poItem.className).toBe('icon disabled selected');
});

test('should highlight vessel tracking', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={routes.vesselTracking}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const vesselTracker = screen.getByTestId('vesselTracker');
  expect(vesselTracker).toBeVisible();
  expect(vesselTracker.className).toBe('icon  selected');
});

test('should naviagate to item management', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={routes.home}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const poItem = screen.getByTestId('poItem');
  userEvent.click(poItem);
  expect(window.location.pathname).toBe(`/${routes.itemManagement}`);
});
test('should naviagate to PO management', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={routes.home}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const poManagement = screen.getByTestId('po');
  userEvent.click(poManagement);
  expect(window.location.pathname).toBe(`/${routes.poManagement}`);
});

test('should navigate to vessel tracking', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={'Vessel Tracking'}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const vesselTracking = screen.getByTestId('vesselTracker');
  expect(vesselTracking).toBeVisible();
  userEvent.click(vesselTracking);
  expect(window.location.pathname).toBe(`/${routes.vesselTracking}`);
});

test('should navigate to ship load page', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={'Vessel Tracking'}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const shipLoad = screen.getByTestId('shipAndLoadManagement');
  expect(shipLoad).toBeVisible();
  userEvent.click(shipLoad);
  expect(window.location.pathname).toBe(`/${routes.shipLoadManagement}`);
});

test('should navigate to buy plan page', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={'buy plan'}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const buyPlan = screen.getByTestId('buyPlan');
  expect(buyPlan).toBeVisible();
  userEvent.click(buyPlan);
  expect(window.location.pathname).toBe(`/${routes.eventBuyPlanManagement}`);
});

test('should navigate to doc library page', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={'doc lib'}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );

  const docLib = screen.getByTestId('docLibrary');
  expect(docLib).toBeVisible();
  userEvent.click(docLib);
  expect(window.location.pathname).toBe(`/${routes.documentLibrary}`);
});

test('should navigate to setings with power user', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <Navbar
        selected={'po-management'}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const settings = screen.getByTestId('settings');
  expect(settings).toBeVisible();
  expect(settings.className).toBe('icon  ');
  userEvent.click(settings);
  expect(window.location.pathname).toBe(`/${routes.adminPanel}`);
});

test('should not navigate to setings with normal user', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <GroupGuard />
      <HomePage isExpanded={false}></HomePage>
      <Navbar
        selected={'po-management'}
        toggleExpansion={() => {}}
        isExpanded={true}
      />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const settings = screen.getByTestId('poItem');
  expect(settings).toBeVisible();
  expect(settings.className).toBe('icon disabled ');
  userEvent.click(settings);
  expect(window.location.pathname).toBe(`/${routes.home}`);
});



