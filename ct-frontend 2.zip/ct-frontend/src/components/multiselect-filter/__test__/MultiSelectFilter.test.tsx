import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import MultiSelectFilter from '../MultiSelectFilter';

afterEach(cleanup);

jest.mock("nanoid", () => {
  return { nanoid: () => Math.random().toString() };
});

describe('multiselect filter component', () => {

  const mockprops = {
    data: ['1', '2', '3', '4', '5'],
    setCheckedData: () => { },
    checkedData: ['1', '2', '3'],
    filterData: ['1', '2', '3', '4'],
    setFilterData: () => { },
    inputValue: '1',
    setInputValue: () => { },
    onlyButtonHandler: () => { }
  };


  test('should render the multiselect filter component', () => {
    render(<MultiSelectFilter {...mockprops} />);
    const wrapper = screen.getByTestId('multiselect-header-wrapper');
    //toggle open
    userEvent.click(wrapper);
    //toggle close
    userEvent.click(wrapper);
  });
  test('should render the multiselect filter component without data', () => {
    render(<MultiSelectFilter {...mockprops} data={[]} />);
  });

  test('should handle top check box change', () => {
    render(<MultiSelectFilter {...mockprops} />);
    const wrapper = screen.getByTestId('multiselect-header-wrapper');
    userEvent.click(wrapper);
    const ele = screen.getByTestId('top-checkbox');
    userEvent.click(ele);
    userEvent.click(ele);
  });

  test('should handle top check box change with no filter', () => {
    render(<MultiSelectFilter {...mockprops} filterData={[]} />);
    const wrapper = screen.getByTestId('multiselect-header-wrapper');
    userEvent.click(wrapper);
    const ele = screen.getByTestId('top-checkbox');
    userEvent.click(ele);
    userEvent.click(ele);
  });

  test('should handle sugestion check box change', () => {
    render(<MultiSelectFilter {...mockprops} inputValue='' />);
    const wrapper = screen.getByTestId('multiselect-header-wrapper');
    userEvent.click(wrapper);
    const ele = screen.getAllByTestId('multiselect-checkbox');
    //checked
    userEvent.click(ele[3]);
    //unchecked
    userEvent.click(ele[2]);
  });

  test('should handle only button click', () => {
    render(<MultiSelectFilter {...mockprops} />);
    const wrapper = screen.getByTestId('multiselect-header-wrapper');
    userEvent.click(wrapper);
    const ele = screen.getAllByTestId('multiselect-only');
    userEvent.click(ele[0]);

  });
  test('should handle input box changes', () => {
    render(<MultiSelectFilter {...mockprops} />);
    const wrapper = screen.getByTestId('multiselect-header-wrapper');
    userEvent.click(wrapper);
    const ele = screen.getByTestId('multiselect-input');
    fireEvent.change(ele, { target: { value: '2' } });
  });

  test('should handle input box change with no data', () => {
    render(<MultiSelectFilter {...mockprops} data={[]} />);
    const wrapper = screen.getByTestId('multiselect-header-wrapper');
    userEvent.click(wrapper);
    const ele = screen.getByTestId('multiselect-input');
    fireEvent.change(ele, { target: { value: '2' } });
  });
});