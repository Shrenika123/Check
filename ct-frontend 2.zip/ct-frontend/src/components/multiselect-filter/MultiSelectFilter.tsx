import { nanoid } from 'nanoid';
import { ChangeEvent, FC, MouseEvent, useEffect, useRef, useState } from 'react';
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io';
import { MdSearch } from 'react-icons/md';
import './MultiSelectFilter.style.css';


interface Props {
  data: string[],
  setCheckedData: Function;
  checkedData: string[];
  filterData: string[];
  setFilterData: Function;
  inputValue: string;
  setInputValue: Function;
  onlyButtonHandler: Function;
}

const MultiSelectFilter: FC<Props> = (props) => {

  const [boxStyle, setBoxStyle] = useState<string>('hidden');
  const multiSelectBoxRef = useRef<HTMLDivElement>(null);
  const headerCheckBoxRef = useRef<HTMLInputElement>(null);
  const multiselectWrapperRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (props && props.data && props.data.length > 0) {
      if (props.inputValue && props.inputValue.length > 0) {
        const newFilterData: string[] = props.data.filter((value: string) => {
          return value.includes(props.inputValue);
        });
        props.setFilterData(newFilterData);
      }
      else
        props.setFilterData(props.data);
    }
  }, [props.data]);

  useEffect(() => {
    if (props.inputValue === '')
      handleAutoComplete('');
  }, [props.inputValue]);


  const toggleSelectBox = (event: MouseEvent<HTMLDivElement>) => {

    if (event.target === headerCheckBoxRef.current) return;

    if (boxStyle === 'hidden') {
      setBoxStyle('multiselect-box');
      (headerCheckBoxRef.current as HTMLInputElement).className = 'mulitselect-checkbox-header';
    }
    else {
      props.setInputValue('');
      setBoxStyle('hidden');
      headerCheckBoxRef.current!.className = 'invisible';
    }
  };

  const handleAutoComplete = (inputValue: string) => {
    props.setInputValue((inputValue));
    const autoCompleteData = props.data.length > 0 ? props.data.filter((option) => {
      return option.toString().includes(inputValue);
    }) : [];
    props.setFilterData(autoCompleteData);
  };

  const checkBoxHandler = (event: ChangeEvent<HTMLInputElement>, query: string) => {

    if (event.target.checked) {
      props.setCheckedData([...props.checkedData, query]);
    }
    else {
      props.setCheckedData(props.checkedData.filter((value) => value !== query));
    }
  };

  const ifChecked = (query: string) => {
    if (props.checkedData.length > 0) {
      return props.checkedData.includes(query);
    }
  };
  const topCheckBoxHandler = (event: ChangeEvent<HTMLInputElement>) => {
    if (props.checkedData && props.filterData && props.filterData.length > 0) {
      if (event.target.checked)
        props.setCheckedData(props.filterData);
      else {
        props.setCheckedData(props.checkedData.filter((value) => !props.filterData.includes(value)));
      }
    }
  };
  const getHeaderText = () => {
    if (props.checkedData.length === 0) return '';
    else {
      return `(${props.checkedData.length})`;
    }
  };

  useEffect(() => {
    // event listeners
    document.addEventListener("click", hideOnClickOutside, true);
  }, []);

  const hideOnClickOutside = (e: any) => {
    if (multiselectWrapperRef.current && !multiselectWrapperRef.current.contains(e.target)) {
      headerCheckBoxRef.current!.className = 'invisible';
      setBoxStyle('hidden');
    }
  };

  return (
    <section className='multiselect-wrapper' ref={multiselectWrapperRef}>

      <div data-testid='multiselect-header-wrapper' className='multiselect-header-wrapper' onClick={(event) => toggleSelectBox(event)}>
        <input data-testid='top-checkbox' ref={headerCheckBoxRef} className='invisible' defaultChecked={false} type='checkbox' onChange={topCheckBoxHandler} />
        <div className='multiselect-header'>All{getHeaderText()}</div>
        <span>{boxStyle === 'hidden' ? <IoMdArrowDropdown /> : <IoMdArrowDropup />}</span>
      </div>
      <div className={boxStyle} ref={multiSelectBoxRef}>
        <div className='multiselect-input-wrapper'> <MdSearch />
          <input data-testid='multiselect-input' className='multiselect-input' value={props.inputValue} type='text' placeholder='Type to search' onChange={(event) => handleAutoComplete(event.target.value)} />
        </div>
        {props.filterData.map((value) => {
          return {
            value: value,
            key: nanoid()
          };
        }).map((value) => {
          return (
            <div className='multiselect-option' key={value.key}>
              <input type='checkbox' data-testid='multiselect-checkbox' className='mulitselect-checkbox' checked={ifChecked(value.value)} onChange={(event) => checkBoxHandler(event, value.value.toString())} />
              <div className='multiselect-option-text'>{value.value.toString()}</div>
              <button data-testid='multiselect-only' className='multiselect-only' onClick={() => props.onlyButtonHandler(value.value.toString())}>ONLY</button>
            </div>
          );
        })
        }
      </div>
    </section>
  );
};

export default MultiSelectFilter;