import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {
  addDays, subDays
} from 'date-fns';
import { Range } from 'react-date-range';
import CustomDateRangePicker, { defineds } from '../CustomDateRangePicker';


afterEach(cleanup);

describe('Date Range Picker Component', () => {

  const range: Range[] = [
    {
      startDate: subDays(new Date(), 15),
      endDate: addDays(new Date(), 45),
      key: 'selection'
    }
  ];

  test('should render date range picker component', () => {
    render(<CustomDateRangePicker range={range} setRange={() => { } } footerLabel={''} />);
  });

  test('should toggle open/close date on click range picker component', () => {
    render(<CustomDateRangePicker range={range} setRange={() => { } } footerLabel={''} />);
    const ele = screen.getByTestId('date-range-picker');
    userEvent.click(ele);
    userEvent.click(ele);
  });

  test('should hide range picker component on escape key press', () => {
    render(<CustomDateRangePicker range={range} setRange={() => { } } footerLabel={''} />);
    userEvent.keyboard('{Escape}');
    userEvent.keyboard('{Shift}');

  });

  test('should select the preset value today', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfToday, endDate: defineds.endOfToday, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Today');
    userEvent.click(ele)

  });
  test('should select the preset value yesterday', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfYesterday, endDate: defineds.endOfYesterday, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Yesterday');
    userEvent.click(ele)
  });
  test('should select the preset value tomorrow', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfTomorrow, endDate: defineds.endOfTomorrow, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Tomorrow');
    userEvent.click(ele)
  });
  test('should select the preset value this week', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfWeek, endDate: defineds.endOfWeek, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('This Week');
    userEvent.click(ele)
  });
  test('should select the preset value last Week', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfLastWeek, endDate: defineds.endOfLastWeek, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Last Week');
    userEvent.click(ele)
  });
  test('should select the preset value next Week', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfNextWeek, endDate: defineds.endOfNextWeek, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Next Week');
    userEvent.click(ele)
  });
  test('should select the preset value this month', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfMonth, endDate: defineds.endOfMonth, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('This Month');
    userEvent.click(ele)
  });
  test('should select the preset value lastMonth', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfLastMonth, endDate: defineds.endOfLastMonth, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Last Month');
    userEvent.click(ele)
  });
  test('should select the preset value next month', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfNextMonth, endDate: defineds.endOfNextMonth, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Next Month');
    userEvent.click(ele)
  });
  test('should select the preset value this quarter', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfQuarter, endDate: defineds.endOfQuarter, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('This Quarter');
    userEvent.click(ele)
  });
  test('should select the preset value last quarter', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfLastQuarter, endDate: defineds.endOfLastQuarter, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Last Quarter');
    userEvent.click(ele)
  });
  test('should select the preset value next quarter', () => {
    render(<CustomDateRangePicker range={[{ startDate: defineds.startOfNextQuarter, endDate: defineds.endOfNextQuarter, key: 'selection' }]} setRange={() => { } } footerLabel={''} />);
    const eleWrap = screen.getByTestId('date-range-picker');
    userEvent.click(eleWrap);
    const ele = screen.getByText('Next Quarter');
    userEvent.click(ele)
  });

});