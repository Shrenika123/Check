import {
  addDays, addMonths, addQuarters, endOfDay, endOfMonth, endOfQuarter, endOfWeek, format, isSameDay, startOfDay,
  startOfMonth, startOfQuarter, startOfWeek
} from 'date-fns';
import { FC, useEffect, useRef, useState } from 'react';
import { createStaticRanges, DateRangePicker, Range, StaticRange } from 'react-date-range';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import './CustomDateRangePicker.style.css';

export const defineds = {
  startOfWeek: startOfWeek(new Date()),
  endOfWeek: endOfWeek(new Date()),
  startOfLastWeek: startOfWeek(addDays(new Date(), -7)),
  endOfLastWeek: endOfWeek(addDays(new Date(), -7)),
  startOfNextWeek: startOfWeek(addDays(new Date(), 7)),
  endOfNextWeek: endOfWeek(addDays(new Date(), 7)),
  startOfToday: startOfDay(new Date()),
  endOfToday: endOfDay(new Date()),
  startOfYesterday: startOfDay(addDays(new Date(), -1)),
  endOfYesterday: endOfDay(addDays(new Date(), -1)),
  startOfTomorrow: startOfDay(addDays(new Date(), 1)),
  endOfTomorrow: endOfDay(addDays(new Date(), 1)),
  startOfMonth: startOfMonth(new Date()),
  endOfMonth: endOfMonth(new Date()),
  startOfLastMonth: startOfMonth(addMonths(new Date(), -1)),
  endOfLastMonth: endOfMonth(addMonths(new Date(), -1)),
  startOfNextMonth: startOfMonth(addMonths(new Date(), 1)),
  endOfNextMonth: endOfMonth(addMonths(new Date(), 1)),
  startOfQuarter: startOfQuarter(new Date()),
  endOfQuarter: endOfQuarter(new Date()),
  startOfLastQuarter: startOfQuarter(addQuarters(new Date(), -1)),
  endOfLastQuarter: endOfQuarter(addQuarters(new Date(), -1)),
  startOfNextQuarter: startOfQuarter(addQuarters(new Date(), 1)),
  endOfNextQuarter: endOfQuarter(addQuarters(new Date(), 1)),

};

interface Props {
  range: Range[],
  setRange: Function,
  footerLabel: string,
  minDate?: Date,
  maxDate?: Date,
  staticRanges?: StaticRange[];
  isDateInputEditable?:boolean;
}

const CustomDateRangePicker: FC<Props> = (props) => {

  const customStaticRange = createStaticRanges([
    {
      label: 'Today',
      range: () => ({
        startDate: defineds.startOfToday,
        endDate: defineds.endOfToday,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }

    },
    {
      label: 'Yesterday',
      range: () => ({
        startDate: defineds.startOfYesterday,
        endDate: defineds.endOfYesterday,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Tomorrow',
      range: () => ({
        startDate: defineds.startOfTomorrow,
        endDate: defineds.endOfTomorrow,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },

    {
      label: 'This Week',
      range: () => ({
        startDate: defineds.startOfWeek,
        endDate: defineds.endOfWeek,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Last Week',
      range: () => ({
        startDate: defineds.startOfLastWeek,
        endDate: defineds.endOfLastWeek,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Next Week',
      range: () => ({
        startDate: defineds.startOfNextWeek,
        endDate: defineds.endOfNextWeek,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'This Month',
      range: () => ({
        startDate: defineds.startOfMonth,
        endDate: defineds.endOfMonth,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Last Month',
      range: () => ({
        startDate: defineds.startOfLastMonth,
        endDate: defineds.endOfLastMonth,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Next Month',
      range: () => ({
        startDate: defineds.startOfNextMonth,
        endDate: defineds.endOfNextMonth,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'This Quarter',
      range: () => ({
        startDate: defineds.startOfQuarter,
        endDate: defineds.endOfQuarter,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Last Quarter',
      range: () => ({
        startDate: defineds.startOfLastQuarter,
        endDate: defineds.endOfLastQuarter,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Next Quarter',
      range: () => ({
        startDate: defineds.startOfNextQuarter,
        endDate: defineds.endOfNextQuarter,
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
    {
      label: 'Default',
      range: () => ({
        startDate: addDays(new Date(), -15),
        endDate: addDays(new Date(), 45),
      }),
      isSelected(range) {
        const definedRange = this.range();
        return (
          isSameDay(range.startDate!, definedRange.startDate!) &&
          isSameDay(range.endDate!, definedRange.endDate!)
        );
      }
    },
  ]);

  const [open, setOpen] = useState<boolean>(false);

  const refOne = useRef<HTMLDivElement>(null);
  const refTwo = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // event listeners
    document.addEventListener("keydown", hideOnEscape, true);
    document.addEventListener("click", hideOnClickOutside, true);
  }, []);

  const handleDateRangeChange = (item: any) => {
    props.setRange([item.selection]);
  };

  //hide dropdown on ESC press
  const hideOnEscape = (e: { key: string; }) => {

    if (e.key === "Escape") {
      setOpen(false);
    }
  };

  // Hide dropdown on outside click
  const hideOnClickOutside = (e: any) => {

    if (refOne.current && !refOne.current.contains(e.target) && e.target !== refTwo.current?.children[0]) {
      setOpen(false);
    }
  };

  const toggleCalenderOpen = () => {
    if (open) setOpen(false);
    else setOpen(true);
  };

  return (
    <div className="calendarWrap">
      <div className='input-wrap' ref={refTwo}>
        <input
          value={`${format(props.range[0].startDate!, "MMM dd, yyyy")} to ${format(props.range[0].endDate!, "MMM dd, yyyy")}`}
          readOnly
          className="inputBox"
          onClick={toggleCalenderOpen}
          data-testid='date-range-picker'
        />
      </div>
      <div ref={refOne}>
        {open &&
          <DateRangePicker
            onChange={item => handleDateRangeChange(item)}
            editableDateInputs={props.isDateInputEditable ?? true}
            moveRangeOnFirstSelection={false}
            ranges={props.range}
            months={2}
            direction="horizontal"
            className="calendarElement"
            rangeColors={['#3B3A39']}
            inputRanges={[]}
            staticRanges= {props.staticRanges ? props.staticRanges : customStaticRange}
            minDate={props.minDate}
            maxDate={props.maxDate}
          />
        }
      </div>
      <span className='date-range-helper-text'>* {props.footerLabel}</span>
    </div>
  );
};

export default CustomDateRangePicker;