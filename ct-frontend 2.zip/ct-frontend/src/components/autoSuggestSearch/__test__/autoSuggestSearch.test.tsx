import { act, render, screen } from '@testing-library/react';
import AutoSuggestSearch from '..';
import { setInputValue } from '../../../common/helper/testHelper';
import { ISelectElement } from '../../SingleSelect';

const RenderAutoSuggest = ({ data }: { data: ISelectElement[] }) => {
  return (
    <AutoSuggestSearch
      data={data}
      onSearch={() => {}}
      onRadioClick={() => {}}
      searchLength={0}
      dataTestId={'test'}
    />
  );
};

describe('toggle button component', () => {
  test('should render the singleSelect filter component', async () => {
    render(
      <RenderAutoSuggest
        data={[
          { key: '1', value: 'one' },
          { key: '2', value: 'two' },
        ]}
      />
    );
    await setInputValue('searchInput-test-testid', 'one');
  });
});
