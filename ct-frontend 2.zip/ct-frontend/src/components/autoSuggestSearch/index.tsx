import React, { useEffect, useRef, useState } from 'react';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import './index.style.css';
import { useDebounce } from '../../hooks/useDebounce';
import { ISelectElement } from '../SingleSelect';
import { useOnClickOutside } from '../../hooks/useOnClickOutside';

interface IAutoSuggestSearchProps {
  onSearch: (search: string) => void;
  onRadioClick: (search: string) => void;
  searchLength: number;
  data: ISelectElement[];
  dataTestId: string;
  reset?: boolean;
}

const AutoSuggestSearch: React.FC<IAutoSuggestSearchProps> = ({
  onSearch,
  searchLength,
  data,
  dataTestId,
  onRadioClick,
  reset,
}) => {
  const [searchValue, setSearchValue] = useState<string>('');
  const [selectedValue, setSelectedValue] = useState<string>('');
  const [dropDownOpen, setDropDownOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const debounceValue = useDebounce(searchValue!, 500);
  const searchRef = useRef(null);

  useEffect(() => {
    if (debounceValue !== null && debounceValue.length >= 0) {
      onSearch(debounceValue);
      setLoading(true);
    }
  }, [debounceValue]);

  useEffect(() => {
    if (selectedValue.length > 0) {
      setSearchValue(selectedValue);
    }
  }, [selectedValue]);

  useEffect(() => {
    setDropDownOpen(true);
    setLoading(false);
  }, [data, debounceValue]);

  useEffect(() => {
    if (reset) {
      setSearchValue('');
      setSelectedValue('');
    }
  }, [reset]);

  useEffect(() => {
    if (
      selectedValue.length > 0 &&
      data.length === 1 &&
      selectedValue === data[0].value &&
      searchValue === selectedValue
    ) {
      setDropDownOpen(false);
    }
  }, [data, searchValue, selectedValue]);

  useOnClickOutside(searchRef, () => setDropDownOpen(false));

  const handleOnClick = (val: ISelectElement) => {
    setSelectedValue(val.value);
    onRadioClick(val.value);
  };

  const checkIfNoData = () => {
    if (
      data.length === 0 &&
      debounceValue &&
      debounceValue.length >= searchLength &&
      !loading &&
      dropDownOpen
    ) {
      return true;
    }
    return false;
  };

  return (
    <div
      id='autoSuggestSearchWrapper'
      ref={searchRef}>
      <div
        className='autoSuggestSearch'
        data-testid={`autoSuggestSearch-${dataTestId}-testid`}>
        <input
          className='searchInput'
          data-testid={`searchInput-${dataTestId}-testid`}
          placeholder={`Type ${searchLength} character for suggestions`}
          onChange={(e) => setSearchValue(e.target.value)}
          value={searchValue}
          onFocus={() => setDropDownOpen(true)}
        />
        <SearchOutlinedIcon
          className='searchIcon'
          fontSize='large'
        />
      </div>
      {dropDownOpen &&
        data.length > 0 &&
        debounceValue &&
        debounceValue.length >= searchLength && (
          <div className='dropDownElements'>
            <div
              className='radioWrapperContainer'
              data-testid={`searchDropdown-${dataTestId}-testid`}>
              {data.map((item) => (
                <div
                  onClick={() => handleOnClick(item)}
                  className='radioWrapper'
                  key={item.key}>
                  <input
                    type='radio'
                    name='gender'
                    className='radio'
                    defaultChecked={item.value === selectedValue}
                    data-testid={`singleSelectRadioButton-${dataTestId}-testid`}
                  />
                  <p> {item.value}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      {checkIfNoData() && (
        <div
          className='noData'
          data-testid={`singleSelect-noData-${dataTestId}-testid`}>
          {'No data'}
        </div>
      )}
    </div>
  );
};
export default AutoSuggestSearch;
