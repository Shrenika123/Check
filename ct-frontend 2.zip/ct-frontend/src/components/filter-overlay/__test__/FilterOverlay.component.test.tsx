import '@testing-library/jest-dom';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import FilterOverlay from '../FilterOverlay.component';

afterEach(cleanup);

describe('Filter Overlay Component', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userGroupId: 'powerUserDummyId',
      userGroupName: 'Power User',
      userGroupRoutes: ['/po-management',
        '/po-management/details',
        '/item-management',
        '/vessel-tracking',
        '/vessel-tracking/details',
        '/admin-panel']
    },
    navbar: {
      isExpanded: false
    }
  };
  const mockProps = {
    selectedFilter: { name: 'demo', code: 'demo' },
    setSelectedFilter: jest.fn(),
    inputFilterData: '',
    setInputFilterData: jest.fn(),
    setShouldFetchFilter: jest.fn(),
    setAllVesselsPageNumber: jest.fn(),
    isFilterApplied: false,
    setIsFilterApplied: jest.fn(),
    searchParam: ['']
  };

  test('should render component', () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <FilterOverlay {...mockProps} />
      </Provider>, { wrapper: BrowserRouter }
    );
  });

  test('should check filter dropdown change', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <FilterOverlay {...mockProps} />
      </Provider>, { wrapper: BrowserRouter }
    );

    const filterBtn = screen.getByTestId('tracking-filter-button');
    userEvent.click(filterBtn);

    await waitFor(async () => {
      const filterInput = screen.getByTestId('tracking-filter-dropdown');
      await fireEvent.change(filterInput, { value: { name: 'Container ID', code: 'containerId' } });
    });

  });

  test('should check filter input change', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <FilterOverlay {...mockProps} />
      </Provider>, { wrapper: BrowserRouter }
    );

    const filterBtn = screen.getByTestId('tracking-filter-button');
    userEvent.click(filterBtn);

    await waitFor(async () => {
      const filterInput = screen.getByTestId('tracking-filter-input');
      await fireEvent.change(filterInput, { target: { value: '123' } });
    });
  });

  test('should check apply button click', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <FilterOverlay {...mockProps} />
      </Provider>, { wrapper: BrowserRouter }
    );

    const filterBtn = screen.getByTestId('tracking-filter-button');
    userEvent.click(filterBtn);

    await waitFor(async () => {
      const filterInput = screen.getByTestId('tracking-filter-input');
      await fireEvent.change(filterInput, { target: { value: '123' } });

      const filterApplyBtn = screen.getByTestId('filter-apply-btn');
      await userEvent.click(filterApplyBtn);

    });
  });
});