import classNames from 'classnames';
import { Button } from "primereact/button";
import { Dropdown } from 'primereact/dropdown';
import { InputTextarea } from 'primereact/inputtextarea';
import { OverlayPanel } from "primereact/overlaypanel";
import { useRef } from 'react';
import { trackingFilterTypes } from '../../common/constants';
import { IFilterOverlayProps } from '../../common/interfaces';
import './FilterOverlay.style.css';

export default function FilterOverlay(props: IFilterOverlayProps) {

  const opRef = useRef<any>(null);

  const handleApplyClick = () => {
    props.setIsFilterApplied(true);
    props.setShouldFetchFilter((prevState: boolean) => !prevState);
    props.setAllVesselsPageNumber(1);
    opRef.current.hide();
  };
  const handleOverlayHide = () => {
    // if filter is applied and user manually removes the input filter data then reset should be done and refetch should happen
    if (props.isFilterApplied && props.inputFilterData === '') {
      props.setSelectedFilter({ name: 'Container ID', code: 'containerId' });
      props.setShouldFetchFilter((prevState: boolean) => !prevState);
      props.setAllVesselsPageNumber(1);
      props.setIsFilterApplied(false);
    }
  };

  const handleSelectFilterChange = (e: any) => {
    props.setSelectedFilter(e.value);
    props.setInputFilterData('');
  }

  const filterInputGroupClass = classNames('filter-input-group');
  const applyButtonClass = classNames('tracking-filter-apply-button', {
    'disable': props.inputFilterData === ''
  });

  return (
    <section className='filter-overlay-container'>
      <Button
        type="button"
        icon="pi pi-filter"
        label={"Filter"}
        onClick={(e) => opRef.current.toggle(e)}
        aria-haspopup
        aria-controls="overlay_panel"
        className="tracking-filter-button"
        data-testid='tracking-filter-button'
      />
      <OverlayPanel
        ref={opRef}
        style={{ width: "25rem" }}
        className="tracking-filter-overlay"
        onHide={handleOverlayHide}
      >
        <section className="filter-dropdown-group">
          <label htmlFor="tracking-filter-dropdown">Select Filter</label>
          <Dropdown data-testid='tracking-filter-dropdown' inputId='tracking-filter-dropdown' value={props.selectedFilter} options={trackingFilterTypes} onChange={(e) => handleSelectFilterChange(e)} optionLabel="name" />
        </section>
        <section className={filterInputGroupClass}>
          <label htmlFor="tracking-filter-input">Input Data</label>
          <InputTextarea
            data-testid='tracking-filter-input'
            id='tracking-filter-input'
            value={props.inputFilterData}
            onChange={(e) => props.setInputFilterData(e.target.value.toUpperCase())}
            rows={5}
            cols={5}
          />
          <span className='filter-input-helper-text'>For multiple queries use comma (,) eg: 790341, 790341</span>
        </section>
        <section className='filter-overlay-bottom'>
          <Button data-testid='filter-apply-btn' label="Apply" aria-label="Apply" className={applyButtonClass} onClick={handleApplyClick} />
        </section>
      </OverlayPanel>
    </section>
  );

}
