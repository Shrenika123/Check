import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ConfirmationBox from '../ConfirmationBox.component';

afterEach(cleanup);

const mockProps = {
  title: '',
  content: '',
  image: <></>,
  onClose: () => { },
  confirmAction: () => { },
  cancelAction: () => { },
};

test('should render the confirmation box component when open is false', () => {
  render(<ConfirmationBox {...mockProps} open={false} />);
});

test('should render the confirmation box component when open is true', () => {
  render(<ConfirmationBox {...mockProps} open={true} />);
});

test('should handle onClose event', () => {
  render(<ConfirmationBox {...mockProps} open={true} />);
  expect(screen.getByTestId('CloseRoundedIcon')).toBeInTheDocument();
  userEvent.click(screen.getByTestId('CloseRoundedIcon'));
});

test('should handle confirm action event', () => {
  render(<ConfirmationBox {...mockProps} open={true} />);
  expect(screen.getByTestId('confirm-action-button')).toBeInTheDocument();
  userEvent.click(screen.getByTestId('confirm-action-button'));
});

test('should handle cancel action event', () => {
  render(<ConfirmationBox {...mockProps} open={true} />);
  expect(screen.getByTestId('cancel-action-button')).toBeInTheDocument();
  userEvent.click(screen.getByTestId('cancel-action-button'));
});