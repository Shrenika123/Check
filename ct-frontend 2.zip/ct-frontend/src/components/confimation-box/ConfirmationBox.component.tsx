import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { FC, ReactElement } from 'react';
import './ConfirmationBox.style.css';

interface Props {
  title: string;
  content: string;
  open: boolean;
  onClose: Function;
  confirmAction: Function;
  cancelAction: Function;
  image: ReactElement;
}
const ConfirmationBox: FC<Props> = (props) => {

  return (
    <Dialog
      id='confirm-box'
      open={props.open}
      onClose={() => props.onClose()}
      onBackdropClick={() => {}}
      data-testid='confirm-box'>
      <DialogTitle>
        <div>
          <div className='icon-content'>{props.image}</div>
          <CloseRoundedIcon
            fontSize='medium'
            className='cross-icon'
            onClick={() => props.onClose()}
          />
        </div>
        <div className=''>{props.title}</div>
      </DialogTitle>
      <DialogContent>
        <DialogContentText>{props.content}</DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button data-testid='cancel-action-button' id='cancel' size='large' variant="contained" onClick={() => props.cancelAction()}>
          Cancel
        </Button>
        <Button data-testid='confirm-action-button' id='confirm' size='large' variant="contained" onClick={() => props.confirmAction()}>
          Confirm
        </Button>
      </DialogActions>
    </Dialog>
  );
};


export default ConfirmationBox;;