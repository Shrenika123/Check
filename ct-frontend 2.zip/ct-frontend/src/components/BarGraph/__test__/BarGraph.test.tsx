import { cleanup, render } from '@testing-library/react';
import { promotionProcurementGraphData } from '../../../common/mocks/promotionAndProcurement';
import BarGraph, { IBarGraphDataElement } from '../index';
afterEach(() => {
  cleanup();
});

const mockDataGraph: IBarGraphDataElement[] =
  promotionProcurementGraphData.data;
const mockRange = [0, 200, 400, 600, 800, 1000, 1200, 1400];
jest.mock('recharts', () => {
  const OriginalModule = jest.requireActual('recharts');
  return {
    ...OriginalModule,
    ResponsiveContainer: ({ children }: { children: any }) => (
      <OriginalModule.ResponsiveContainer width={350} height={350}>
        {children}
      </OriginalModule.ResponsiveContainer>
    ),
  };
});
describe('BarGraph', () => {
  test('should render date range picker component', () => {
  render(
    <BarGraph
      data={mockDataGraph}
      graphFontSize='12px'
      xAxisLegend
      yAxisLabel='QUANTITY'
      range={mockRange}
    />
  );
  });
});
