import React, { useEffect, useState } from 'react';
import {
  Bar, BarChart, CartesianGrid, Cell, Label, LabelList, ResponsiveContainer,
  Text, Tooltip, XAxis,
  YAxis
} from 'recharts';
import { Margin } from 'recharts/types/util/types';
import './index.style.css';
export interface IBarGraphDataElement {
  name?: string;
  value: string | number;
  percentage: string;
  maxQuantity: string | number;
}

interface IBarGraphProps {
  click?: (selectedElement: IBarGraphDataElement, index: number) => void;
  graphFontSize: string;
  xAxisLegend: boolean;
  yAxisLabel: string;
  graphStyle?: Margin;
  height?: number;
  data: IBarGraphDataElement[];
  range: number[];
  percentageLabelSize?: string;
}

const BarGraph: React.FC<IBarGraphProps> = ({
  click,
  graphFontSize,
  graphStyle,
  yAxisLabel,
  xAxisLegend,
  height,
  data,
  range,
  percentageLabelSize,
}) => {
  const [active, setActive] = useState<number | null>(null);
  const handleClick = (data: any, index: number) => {
    if (click) {
      setActive(index);
    }
  };

  useEffect(() => {
    if (click && (active || active === 0)) {
      click(data[active], active);
    }
  }, [active]);
  const getGraphStyle = (): Margin => {
    if (graphStyle) return graphStyle;
    else {
      return {
        top: 30,
        right: 20,
        left: 20,
        bottom: 5,
      };
    }
  };

  const getColorForBar = (index: Number) => {
    if (active || active === 0) {
      return active === index ? '#b6f24d' : '#666666';
    }
    return '#b6f24d';
  };

  const getColorForLabel = (
    value: string,
    fieldName: Partial<keyof IBarGraphDataElement>
  ) => {
    if (active || active === 0) {
      if (data[active][fieldName] === value) return 'white';
      else return '#B3B3B3';
    } else return '#ffffff';
  };

  const changeTickColor = (e: any) => {
    const {
      payload: { value, index },
    } = e;
    e['fill'] = getColorForLabel(value, 'name');

    return xAxisLegend ? (
      <Text
        {...e}
        onClick={() => handleClick(value, index)}
        style={{
          cursor: `${click ? 'pointer' : ''}`,
        }}
      >
        {value}
      </Text>
    ) : (
      <></>
    );
  };

  return (
    <div id='barMainGraphContainer' data-testid='BarGraphMainContainer'>
      <ResponsiveContainer height={height ?? 400}>
        <BarChart
          data={data}
          margin={getGraphStyle()}
          barCategoryGap={'30%'}
          data-testid='BarGraphContainer'
        >
          <CartesianGrid vertical={false} stroke='#B3B3B366' />
          <XAxis
            dataKey='name'
            fontSize={graphFontSize}
            tick={(e) => changeTickColor(e)}
            tickLine={{ stroke: 'transparent' }}
            data-testid='XAxisBarGraph'
          />
          <YAxis
            axisLine={false}
            tickFormatter={(value) =>
              new Intl.NumberFormat('en-US', {
                notation: 'compact',
                compactDisplay: 'short',
              }).format(value)
            }
            ticks={range}
            tick={{ fill: '#ffffff' }}
            tickLine={false}
            allowDataOverflow={true}
            fontSize={graphFontSize}
            offset={-10}
            domain={[0, Number(data[0].maxQuantity)]}
            data-testid='YAxisBarGraph'
          >
            <Label
              value={yAxisLabel}
              position='insideLeft'
              angle={-90}
              fill={'#b6f24d'}
              dx={-15}
              style={{
                textAnchor: 'middle',
                fontSize: `${graphFontSize}`,
              }}
              data-testid='LabelYAxis'
            />
          </YAxis>
          <Tooltip
            cursor={false}
            isAnimationActive={false}
            content={(data) => <div className='custom-tooltip'>{data.label === 'VP' ? 'Vendor Pending' : data.label}</div>}
          />
          <Bar dataKey='value' fill='#8884d8' onClick={handleClick}>
            {data.map((entry, index) => (
              <Cell
                cursor={click ? 'pointer' : ''}
                key={`cell-${index}`}
                fill={getColorForBar(index)}
                data-testid='cellBarGraph'
              />
            ))}
            <LabelList
              dataKey='percentage'
              position='top'
              fontSize={percentageLabelSize ?? graphFontSize}
              fontWeight={700}
              fill={'#ffffff'}
              data-testid='percentageLabelList'
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
export default BarGraph;
