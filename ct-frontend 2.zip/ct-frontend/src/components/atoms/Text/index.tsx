import React from "react";
import cn from "classnames";
import "./index.css";

type LabelPosition = "left" | "right" | "top";

interface ITextProps {
  label: string | React.ReactNode;
  labelPosition?: LabelPosition;
  size?: string;
  bold?: string;
  color?: string;
  className?: string;
  classNameText?: string;
}

const Text: React.FC<React.PropsWithChildren<ITextProps>> = ({
  children,
  label,
  labelPosition,
  size,
  bold,
  color,
  className,
  classNameText,
}) => {
  const getStyles = () => {
    switch (labelPosition) {
      case 'left':
        return 'left';
      case 'right':
        return 'labelRight';
      case 'top':
      default:
        return 'labelTop';
    }
  };

  const getFontSize = () => {
    switch (size) {
      case 'smallest':
        return 'smallest';
      case 'small':
        return 'small';
      case 'large':
        return 'large';
      case 'medium':
      default:
        return 'medium';
    }
  };
  const getFontWeight = () => {
    switch (bold) {
      case 'bold':
        return 'bold';
      case 'bolder':
        return 'bolder';
      case 'normal':
      default:
        return 'normal';
    }
  };

  return (
    <div className={cn('titleWrapper', getStyles(), classNameText)}>
      <p
        className={cn(getFontSize(), getFontWeight(), className ?? null)}
        style={{ color: color }}
      >
        {label}
      </p>
      {children}
    </div>
  );
};
export default Text;
