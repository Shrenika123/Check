import * as React from 'react';
import { styled } from '@mui/material/styles';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import StepConnector, {
  stepConnectorClasses,
} from '@mui/material/StepConnector';
import { StepIconProps } from '@mui/material/StepIcon';
import './milestone.style.css';
import classNames from 'classnames';

const StepperConnector = styled(StepConnector)(() => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 44,
    left: 'calc(-50% + 10px)',
    right: 'calc(50% + 10px)',
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 5,
    border: 0,
    backgroundColor: '#B3B3B366',
    borderRadius: 1,
    width: '100%',
  },
}));

const StepperIconRoot = styled('div')<{
  ownerState: { completed?: boolean; active?: boolean };
}>(({ ownerState }) => ({
  zIndex: 1,
  color: '#fff',
  width: 10,
  height: 10,
  display: 'flex',
  borderRadius: '50%',
  marginTop: '1rem',
  ...(ownerState.active && {
    backgroundColor: 'black',
    height: '10px',
    width: '10px',
    boxShadow: '0 0 0 5px #B3B3B366',
  }),
  ...(ownerState.completed && {
    backgroundColor: 'black',
    height: '10px',
    width: '10px',
    boxShadow: '0 0 0 5px #B6F24D',
  }),
}));

interface IMilestoneProps {
  data: string[];
  active: number;
}

function StepperElement(props: StepIconProps) {
  const { active, completed } = props;
  return <StepperIconRoot ownerState={{ completed, active }} />;
}

const Milestone: React.FC<IMilestoneProps> = ({ data, active }) => {
  return (
    <div id='milestoneContainer'>
      <Stepper alternativeLabel connector={<StepperConnector />}>
        {data.map((item, i) => (
          <Step key={i} active={i !== active} completed={i === active}>
            <p
              className={classNames(
                'stepperLabel',
                i === active ? 'completedLabel' : 'activeLabel'
              )}
            >
              {item}
            </p>
            <StepLabel StepIconComponent={StepperElement}></StepLabel>
          </Step>
        ))}
      </Stepper>
    </div>
  );
};

export default Milestone;
