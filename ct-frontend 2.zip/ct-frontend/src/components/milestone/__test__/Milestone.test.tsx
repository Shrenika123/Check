import { cleanup, render } from '@testing-library/react';
import Milestone from '../Milestone.component';
afterEach(() => {
  cleanup();
});

describe('BarGraph', () => {
  test('should render date range picker component', () => {
    render(
      <Milestone
        data={['abc', '123', 'deg']}
        active={2}
      />
    );
  });
});
