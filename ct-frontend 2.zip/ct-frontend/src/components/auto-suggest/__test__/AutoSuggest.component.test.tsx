import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import AutoSugggest from '../AutoSuggest.component';


afterEach(cleanup);

jest.mock("nanoid", () => {
  return { nanoid: () => Math.random().toString() };
});

describe('Auto Suggestion component', () => {

  const mockProps = {
    inputData: 'abcd',
    onSuggestionClickHandler: (e: any, v: string) => { },
    handleInputChange: (e: any) => { },
    name: 'poNumber',
    isClosed: false,
    setClose: () => { },
    inputLengthToShowSuggestion: 4
  };
  const inputSuggestionData = ['abcd1234', 'cdef2345', 'efgh3456', 'ghjk4567'];

  test('should render when no suggestion data', () => {
    render(<AutoSugggest inputSuggestionData={[]} isLoading={false} {...mockProps} />);
  });

  test('should render the auto suggestion component with loading', () => {
    render(<AutoSugggest inputSuggestionData={inputSuggestionData} isLoading={true} {...mockProps} />);
    const autoSuggest = screen.getByTestId('auto-suggest');
    expect(autoSuggest).toBeInTheDocument();
    expect(autoSuggest).toBeVisible();
  });

  test('should render the auto suggestion component without loading', () => {
    render(<AutoSugggest inputSuggestionData={inputSuggestionData} isLoading={false} {...mockProps} />);
    const autoSuggest = screen.getByTestId('auto-suggest');
    expect(autoSuggest).toBeInTheDocument();
    expect(autoSuggest).toBeVisible();
  });

  test('should click on auto suggestion options', () => {
    render(<AutoSugggest inputSuggestionData={inputSuggestionData} isLoading={false} {...mockProps} />);
    const suggestion = screen.getAllByTestId('suggest-option');
    expect(suggestion[0]).toBeInTheDocument();
    expect(suggestion[0]).toBeVisible();
    userEvent.click(suggestion[0]);
  });

  test('should handle on focus on input box', () => {
    render(<AutoSugggest inputSuggestionData={inputSuggestionData} isLoading={false} {...mockProps} />);
    const inputBox = screen.getByTestId('input-auto-suggest');
    expect(inputBox).toBeInTheDocument();
    expect(inputBox).toBeVisible();
    inputBox.focus();
  });

  test('should handle input box on change', () => {
    render(<AutoSugggest inputSuggestionData={inputSuggestionData} isLoading={false} {...mockProps} />);
    const inputBox = screen.getByTestId('input-auto-suggest');
    expect(inputBox).toBeInTheDocument();
    expect(inputBox).toBeVisible();
    fireEvent.change(screen.getByTestId('input-auto-suggest'), { target: { value: 'abcd123' } });
  });

  test('should handle Enter key press', () => {
    render(<AutoSugggest inputSuggestionData={inputSuggestionData} isLoading={false} {...mockProps} />);
    userEvent.keyboard('{Enter}');
    userEvent.keyboard('{NumpadEnter}');
  });

});