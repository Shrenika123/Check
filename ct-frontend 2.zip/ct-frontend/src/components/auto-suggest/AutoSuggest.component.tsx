import { nanoid } from 'nanoid';
import { FC, useEffect, useRef, useState } from 'react';
import './AutoSuggest.style.css';


interface Props {
  inputSuggestionData: string[];
  inputData: string;
  onSuggestionClickHandler: Function;
  handleInputChange: Function;
  name: string;
  isClosed: boolean;
  setClose: Function;
  isLoading: boolean;
  inputLengthToShowSuggestion: number;
}

const AutoSuggest: FC<Props> = (props) => {

  const [boxStyle, setBoxStyle] = useState<string>('auto-suggest-options-wrapper');

  const [messageStyle, setMessageStyle] = useState<string>('auto-suggest-options-message');

  const autoSuggestRef = useRef<HTMLDivElement>(null);

  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    // event listeners
    document.addEventListener("click", hideComponent, true);
  }, []);

  const hideComponent = (e: any) => {
    if (autoSuggestRef.current && !autoSuggestRef.current.contains(e.target)) {
      setBoxStyle('hidden');
      setMessageStyle('hidden');
    }
  };

  useEffect(() => {
    if (props.isLoading || props.inputSuggestionData.length <= 0) {
      setMessageStyle('auto-suggest-options-message');
      setBoxStyle('hidden');
    }
    else {
      setBoxStyle('auto-suggest-options-wrapper');
      setMessageStyle('hidden');
    }
  }, [props.inputData, props.isLoading]);

  const onSuggestionClickHandler = (e: any, value: string) => {
    props.onSuggestionClickHandler(e, value);
    props.setClose(true);
  };

  const onFocusHandler = () => {
    setBoxStyle('auto-suggest-options-wrapper');
    props.setClose(false);
  };


  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.code === "Enter" || event.code === "NumpadEnter") {
        event.preventDefault();
        props.setClose(true);
        inputRef.current?.blur();
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
    };
  }, []);

  return (
    <section data-testid='auto-suggest' className='auto-suggest' ref={autoSuggestRef}>
      <textarea placeholder= {`Type ${props.inputLengthToShowSuggestion} characters for suggestion` } data-testid='input-auto-suggest' ref={inputRef} rows={1} value={props.inputData} name={props.name} className='input-textarea' onChange={(event) => props.handleInputChange(event)} onFocus={onFocusHandler} />
      {
        props.inputData.length >= props.inputLengthToShowSuggestion && !props.isClosed ?
          !props.isLoading ?
            props.inputSuggestionData.length <= 0 ?
              <div className={messageStyle}>No Data Found</div>
              :
              <div className={boxStyle} >
                {props.inputSuggestionData.map((value) => {
                  return {
                    value: value,
                    key: nanoid()
                  };
                }).map((value, index) => {
                  return <div data-testid='suggest-option' className='suggest-option' key={value.key} onClick={(e) => onSuggestionClickHandler(e, value.value)}>{value.value}</div>;
                })}
              </div>
            : <div className={messageStyle}>Loading...</div>
          : <></>
      }
    </section>
  );

};

export default AutoSuggest;