import classNames from "classnames";
import { Timeline } from "primereact/timeline";
import React from "react";
import "./Tracker.css";

export interface ITracker {
  data: ITrackerData[];
}

export interface ITrackerData {
  icon: React.ReactNode;
  content: React.ReactNode;
  className?: string;
}

const Tracker: React.FC<ITracker> = ({ data }) => {
  const customizedMarker = (item: {
    color: string;
    icon: string | React.ReactNode;
    className: any;
  }) => {
    return (
      <span data-testid='tracker-icon'
        className={classNames( item.className ?? "inActive")}
      >
        {item.icon}
      </span>
    );
  };
  return (
    <Timeline
      value={data}
      layout="horizontal"
      marker={customizedMarker}
      content={(item) => item.content}
      id={"mainTrackerContainer"}
      data-testid="tracker-test-id"
    />
  );
};
export default Tracker;
