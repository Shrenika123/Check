import { cleanup, render } from '@testing-library/react'
import { checkElementPresentInDomByTestId } from '../../../common/helper/testHelper'
import Tracker from '../Tracker.component'

afterEach(() => {
  cleanup()
})

const mockData = [
  {
    icon: <p>icon</p>,
    content: <p>Tracker</p>,
  },
  {
    icon: <p>icon</p>,
    content: <p>Tracker</p>,
  },
]
describe('Tracker', () => {
  render(<Tracker data={mockData} />)
  test('Check Tracker Element', () => {
    checkElementPresentInDomByTestId('tracker-test-id')
  })
})
