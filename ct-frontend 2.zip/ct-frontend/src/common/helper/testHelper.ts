import { fireEvent, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

export const checkElementPresentInDomByTestId = async (testId: string) => {
  const element = await screen.findByTestId(testId);
  expect(element).toBeInTheDocument();
};

export const textNotPresentInDOM = async (text: string) => {
  const elementText = screen.queryByText(text);
  expect(elementText).not.toBeInTheDocument();
};

export const textPresentInDOM = async (text: string) => {
  const element = screen.queryByText(text);
  expect(element).toBeInTheDocument();
};

export const checkCountOfElementsPresent = async (
  testId: string,
  count: number
) => {
  const elementCount = await screen.findAllByTestId(testId);
  expect(elementCount).toHaveLength(count);
};

export const checkElementNotPresentInDomByTestId = async (testId: string) => {
  const element = screen.queryByTestId(testId);
  expect(element).toBeNull();
};

export const clickElementByTestId = async (testId: string) => {
  const element = screen.findByTestId(testId);
  (await element).click();
};

export const elementContainsSpecifiedText = async (
  testId: string,
  val: string
) => {
  expect(screen.getByTestId(testId)).toHaveTextContent(val);
};

export const clickedSpecificElementInGroup = async (
  testId: string,
  element: number
) => {
  userEvent.click(screen.getAllByTestId(testId)[element]);
};

export const setInputValue = async (testId: string, val: string) => {
  const input = screen.getByTestId(testId);
  fireEvent.change(input, { target: { value: val } });
};

export const checkIfElementIsDisabled = async (testId: string) => {
  const element = screen.getByTestId(testId);
  expect(element).toHaveAttribute('disabled');
};

export const checkIfElementNotDisabled = async (testId: string) => {
  const element = screen.getByTestId(testId);
  expect(element).not.toHaveAttribute('disabled');
};

export const setInputValueFromGroup = async (
  testId: string,
  element: number,
  value: string | number
) => {
  fireEvent.change(screen.getAllByTestId(testId)[element], {
    target: { value: value },
  });
};

export const checkIfElementNotDisabledFromGroup = async (
  testId: string,
  element: number
) => {
  expect(screen.getAllByTestId(testId)[element]).not.toHaveAttribute(
    'disabled'
  );
};

export const checkIfElementIfDisabledFromGroup = async (
  testId: string,
  element: number
) => {
  expect(screen.getAllByTestId(testId)[element]).toHaveAttribute('disabled');
};

export const elementContainsSpecifiedTextFromGroup = async (
  testId: string,
  element: number,
  value: string
) => {
  expect(screen.getAllByTestId(testId)[element]).toHaveTextContent(value);
};

export const checkClassNameStyle = async (testID: string, className: string) => {
  const element = screen.getByTestId(testID);
  expect(element.className).toBe(className);
};