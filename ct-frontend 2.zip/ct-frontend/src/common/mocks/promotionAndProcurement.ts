import {
  IRoleEntity,
  IRoleScreenTableResponse,
  IScreenAssignResponse,
} from '../interfaces';

export const promotionProcurementGraphData = {
  data: [
    {
      name: 'Vendor Pending',
      value: 340,
      percentage: '28%',
      maxQuantity: 2000,
    },
    {
      name: 'VDC',
      value: 200,
      percentage: '13%',
      maxQuantity: 2000,
    },
    {
      name: 'POL',
      value: 800,
      percentage: '98%',
      maxQuantity: 2000,
    },
    {
      name: 'OCEAN',
      value: 1000,
      percentage: '39%',
      maxQuantity: 2000,
    },
    {
      name: 'POE',
      value: 1600,
      percentage: '39%',
      maxQuantity: 2000,
    },
    {
      name: 'DRAY',
      value: 1780,
      percentage: '40%',
      maxQuantity: 2000,
    },
    {
      name: 'IDC',
      value: '1700',
      percentage: '20%',
      maxQuantity: 2000,
    },
  ],
};

export const procurementPromotionPlanMonthly = {
  data: [
    {
      monthName: 'January',
      totalTargetAmount: '21195000000',
      plans: [
        {
          planName: 'Winter',
          planTotalTargetAmount: '21195000000',
        },
      ],
    },
    {
      monthName: 'March',
      totalTargetAmount: '16409840300',
      plans: [
        {
          planName: 'Cosmetics',
          planTotalTargetAmount: '16409840300',
        },
      ],
    },
    {
      monthName: 'April',
      totalTargetAmount: '18854530200',
      plans: [
        {
          planName: 'Gaming',
          planTotalTargetAmount: '18854530200',
        },
      ],
    },
    {
      monthName: 'May',
      totalTargetAmount: '20101500000',
      plans: [
        {
          planName: 'Summer',
          planTotalTargetAmount: '20101500000',
        },
      ],
    },
    {
      monthName: 'August',
      totalTargetAmount: '18069504350',
      plans: [
        {
          planName: 'Fall',
          planTotalTargetAmount: '18069504350',
        },
      ],
    },
  ],
};

export const favouritesResponse = {
  data: [
    {
      eventId: 'ThanksGiving',
      eventName: 'ThanksGiving',
      targetAmount: '2593993',
      targetDate: '2022-11-20',
    },
  ],
};

export const favouritesEmptyResponse = {
  data: null,
};

export const statusResponse = {
  data: {
    data: ['Accepted', 'Partially Shipped'],
  },
};

export const poManagement = [
  {
    poNumber: 'abc',
    mabd: '2-12-2024',
    maap: '12-12-2023',
    idcdate: '2-11-2023',
    vendorId: '1234',
    vendorDescription: 'landed',
    businessUnit: 'One',
    status: 'Partially Delivered',
    eventId: '1467',
  },
  {
    poNumber: 'abc1',
    mabd: '2-11-2024',
    maap: '12-11-2023',
    idcdate: '3-11-2023',
    vendorId: '12345',
    vendorDescription: 'lande1d',
    businessUnit: 'Two',
    status: 'Accepted',
    eventId: '1468',
  },
];

export const itemManagementData = [
  {
    buyPlanId: '104',
    eventId: "President's Day",
    itemDescription: 'abc',
    itemNumber: '5816',
    eventName: "President's Day",
    buyPlanName: 'NA',
    targetDate: '2023-02-14',
    itemStatus: 'Accepted',
    locationType: 'VDC',
    poNumber: '24681755',
    quantity: '255',
    shipmentId: '1234',
    snapshotDate: '2023-02-17',
    upc: 'MPTH7203',
    mabd: '2023-02-06',
  },
  {
    buyPlanId: null,
    eventId: 'NA',
    itemDescription: 'Vampire Costumes',
    itemNumber: '9733',
    buyPlanName: 'NA',
    targetDate: '2023-02-14',
    itemStatus: 'Committed',
    locationType: 'VDC',
    poNumber: '24681375',
    quantity: '202',
    shipmentId: null,
    snapshotDate: '2023-02-18',
    upc: 'MJRF9542',
    mabd: '2023-02-06',
  },
];

export const SupplierCrmData = [
  {
    capacityDate: '2023-01-01',
    supplierCapacity: '20',
    committedCount: 4,
    unCommittedCount: 5,
  },
  {
    capacityDate: '2023-02-01',
    supplierCapacity: '30',
    committedCount: 1,
    unCommittedCount: 2,
  },
];

export const SupplierCrmAll = {
  '1505VDC': {
    EXPRESS: ['EXPRESS'],
  },
  '1969VDC': {
    MAIL: ['Hot equipment'],
    SECURE: ['Inflammable', 'Hot equipment'],
  },
  '8274VDC': {
    MAIL: ['Inflammable'],
  },
  '2924VDC': {
    MAIL: ['Hot equipment'],
  },
  '5562VDC': {
    MAIL: ['Hot equipment'],
  },
  '4775VDC': {
    SECURE: ['Hot equipment', 'Refridgerator -5 degree c'],
  },
  '9617VDC': {
    SECURE: ['Refridgerator -5 degree c'],
  },
  '9364VDC': {
    MAIL: ['Refridgerator -5 degree c', 'Refridgerator -15 degree c'],
    SECURE: ['Refridgerator -15 degree c'],
  },
  '7383VDC': {
    EXPRESS: ['Refridgerator -15 degree c'],
  },
};

export const SupplierCrmDetails = [
  {
    capacityDate: '2023-03-13',
    supplierCapacity: 10,
    commitedCount: 2,
    uncommitedCount: 8,
    lastModifiedDatetime: '2023-04-03 14:30:07.075443+00',
  },
  {
    capacityDate: '2023-03-14',
    supplierCapacity: null,
    commitedCount: null,
    uncommitedCount: null,
    lastModifiedDatetime: 'NA',
  },
  {
    capacityDate: '2023-03-15',
    supplierCapacity: null,
    commitedCount: null,
    uncommitedCount: null,
    lastModifiedDatetime: 'NA',
  },
  {
    capacityDate: '2023-03-16',
    supplierCapacity: null,
    commitedCount: null,
    uncommitedCount: null,
    lastModifiedDatetime: 'NA',
  },
  {
    capacityDate: '2023-03-17',
    supplierCapacity: null,
    commitedCount: null,
    uncommitedCount: null,
    lastModifiedDatetime: 'NA',
  },
];

export const CarrierCrmDetails = [
  {
    capacityDate: '2023-03-13',
    count: 10,
    lastModifiedDateTime: '2023-03-31 06:03:48+00',
  },
  {
    capacityDate: '2023-03-14',
    count: null,
    lastModifiedDateTime: 'NA',
  },
  {
    capacityDate: '2023-03-15',
    count: null,
    lastModifiedDateTime: 'NA',
  },
  {
    capacityDate: '2023-03-16',
    count: null,
    lastModifiedDateTime: 'NA',
  },
  {
    capacityDate: '2023-03-17',
    count: null,
    lastModifiedDateTime: 'NA',
  },
];

export const userRole = [
  [
    {
      emailId: 'adam@deloitte.com',
      role: 'Supplier',
      externalId: 'abcd',
    },
    {
      emailId: 'allyadams@deloitte.com',
      role: 'Supplier',
      externalId: '12345',
    },
  ],
];

export const RoleScreenData: IRoleScreenTableResponse = {
  screens: [
    'PO Management',
    'PO Item Management',
    'Shipment & Load Management',
  ],
  roles: [
    'Power User',
    'Supply ChainOps',
    'Supplier',
    'Carrier',
    'Custom Ops',
    'Admin',
    'Super User',
  ],
  screensRolesPermissionMappings: [
    {
      role: 'Power User',
      screens: [
        {
          screen: 'PO Management',
          permission: 'READ',
        },
        {
          screen: 'PO Item Management',
          permission: 'WRITE',
        },
        {
          screen: 'Externalization',
          permission: 'NA',
        },
        {
          screen: 'Supplier',
          permission: 'WRITE',
        },
      ],
    },
    {
      role: 'Supply ChainOps',
      screens: [
        {
          screen: 'PO Management',
          permission: 'NA',
        },
        {
          screen: 'PO Item Management',
          permission: 'WRITE',
        },
      ],
    },
    {
      role: 'Supplier',
      screens: [
        {
          screen: 'PO Management',
          permission: 'NA',
        },
        {
          screen: 'PO Item Management',
          permission: 'READ',
        },
        {
          screen: 'Externalization',
          permission: 'READ',
        },
      ],
    },
    {
      role: 'Carrier',
      screens: [
        {
          screen: 'PO Management',
          permission: 'NA',
        },
        {
          screen: 'PO Item Management',
          permission: 'READ',
        },
        {
          screen: 'Externalization',
          permission: 'READ',
        },
      ],
    },
    {
      role: 'Custom Ops',
      screens: [
        {
          screen: 'PO Management',
          permission: 'NA',
        },
        {
          screen: 'PO Item Management',
          permission: 'READ',
        },
        {
          screen: 'Externalization',
          permission: 'READ',
        },
      ],
    },
    {
      role: 'Admin',
      screens: [
        {
          screen: 'PO Management',
          permission: 'NA',
        },
        {
          screen: 'PO Item Management',
          permission: 'READ',
        },
        {
          screen: 'Externalization',
          permission: 'READ',
        },
      ],
    },
    {
      role: 'Super User',
      screens: [
        {
          screen: 'PO Management',
          permission: 'NA',
        },
        {
          screen: 'PO Item Management',
          permission: 'READ',
        },
        {
          screen: 'Externalization',
          permission: 'WRITE',
        },
      ],
    },
  ],
};

export const ScreenData: IScreenAssignResponse[] = [
  {
    screens: [
      'PO Management',
      'PO Item Management',
      'Shipment & Load Management',
      'Parceling',
    ],
    roles: [
      { role: 'Power User', isExternalRole: false },
      { role: 'Supplier', isExternalRole: true },
      { role: 'Supply Chain Ops', isExternalRole: false },
    ],
    screensRolesPermissionMappings: [
      {
        screen: 'PO Management',
        roles: [
          {
            role: 'Power User',
            permission: 'READ',
            isExternalRole: false,
          },
          {
            role: 'Supplier',
            permission: 'WRITE',
            isExternalRole: true,
          },
          {
            role: 'Supply Chain Ops',
            permission: 'READ',
            isExternalRole: false,
          },
        ],
      },
      {
        screen: 'PO Item Management',
        roles: [
          {
            role: 'Supplier',
            permission: 'READ',
            isExternalRole: true,
          },
          {
            role: 'Supply Chain Ops',
            permission: 'NA',
            isExternalRole: false,
          },
          {
            role: 'Power User',
            permission: 'WRITE',
            isExternalRole: false,
          },
        ],
      },
      {
        screen: 'Shipment & Load Management',
        roles: [
          {
            role: 'Supplier',
            permission: 'READ',
            isExternalRole: true,
          },
          {
            role: 'Supply Chain Ops',
            permission: 'WRITE',
            isExternalRole: false,
          },
          {
            role: 'Power User',
            permission: 'WRITE',
            isExternalRole: false,
          },
        ],
      },
      {
        screen: 'Parceling',
        roles: [],
      },
    ],
  },
];

export const UserAccessRoles: IRoleEntity[] = [
  { role: 'Power User', is_external_user: true },
  { role: 'Supplier', is_external_user: false },
  { role: 'Supply Chain Ops', is_external_user: false },
];

export const inboundGraphData = [
  {
    capacityDate: '2023-05-19',
    supplierCapacity: 30,
    assignedLoads: 15,
    unAssignedLoads: 57,
    pendingLoads: 0,
    carrierCapacity: 20,
  },
  {
    capacityDate: '2023-05-20',
    supplierCapacity: 40,
    assignedLoads: 9,
    unAssignedLoads: 20,
    pendingLoads: 0,
    carrierCapacity: 20,
  },
  {
    capacityDate: '2023-05-21',
    supplierCapacity: 24,
    assignedLoads: 19,
    unAssignedLoads: 56,
    pendingLoads: 0,
    carrierCapacity: 20,
  },
  {
    capacityDate: '2023-05-22',
    supplierCapacity: 26,
    assignedLoads: 13,
    unAssignedLoads: 36,
    pendingLoads: 0,
    carrierCapacity: 20,
  },
  {
    capacityDate: '2023-05-23',
    supplierCapacity: 57,
    assignedLoads: 9,
    unAssignedLoads: 36,
    pendingLoads: 0,
    carrierCapacity: 20,
  },
  {
    capacityDate: '2023-05-24',
    supplierCapacity: 9,
    assignedLoads: 9,
    unAssignedLoads: 26,
    pendingLoads: 0,
    carrierCapacity: 20,
  },
  {
    capacityDate: '2023-05-25',
    supplierCapacity: 73,
    assignedLoads: 15,
    unAssignedLoads: 38,
    pendingLoads: 1,
    carrierCapacity: 20,
  },
];
