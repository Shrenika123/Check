export const POLineTableResponseData = {
  data: [
    {
      poNumber: "24681952",
      mabd: "2023-01-11",
      maap: "2022-12-23",
      itemNumber: "6464",
      lineNumber: "24681952/11",
      department: "Technology",
      itemDescription: "abc",
      orderedQuantity: "118",
      shippedQuantity: "7",
      pendingQuantity: "96",
      shipmentId: "GW8SLBLDAVCQEQT"
    },
    {
      poNumber: "24681952",
      mabd: "2023-01-11",
      maap: "2022-12-23",
      itemNumber: "5351",
      lineNumber: "24681952/16",
      department: "Technology",
      itemDescription: "KeyBoard",
      orderedQuantity: "263",
      shippedQuantity: "85",
      pendingQuantity: "148",
      shipmentId: "Z5ZSFDX54NSQJZC"
    },
    {
      poNumber: "24681952",
      mabd: "2023-01-11",
      maap: "2022-12-23",
      itemNumber: "8179",
      lineNumber: "24681952/20",
      department: "Technology",
      itemDescription: "Tablet",
      orderedQuantity: "324",
      shippedQuantity: "117",
      pendingQuantity: "140",
      shipmentId: null
    },
  ]
};