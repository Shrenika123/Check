import { IRoutePermission } from "./interfaces";

export const routes = {
    root: '/',
    login: '/login',
    logout: '/logout',
    unAuthenticated: '/unAuthenticate',
    unAuthorized: '/unauthorized',
    adminPanel: 'admin-panel',
    home: 'home',
    poManagement: 'po-management',
    lineDetails: 'po-management/details',
    itemManagement: 'item-management',
    vesselTracking: 'vessel-tracking',
    vesselTrackingDetails: 'vessel-tracking/details',
    vendorManagement: 'vendor-management',
    shipLoadManagement: 'ship-load-management',
    shipLoadManagementMulti: 'ship-load-management-multi',
    zoneManagement: 'zone-management',
    eventBuyPlanManagement: 'event-inventory-plan',
    eventBuyPlanManagementDetails: 'event-inventory-plan/details',
    documentLibrary: 'document-library',
    externalization: 'externalization',
};

export const routeDBMapping =
    [
        {
            screen: 'PO_Management',
            route: routes.poManagement
        },
        {
            screen: 'PO_Line_Management',
            route: routes.lineDetails
        },
        {
            screen: 'PO_Item_Management',
            route: routes.itemManagement
        },
        {
            screen: 'Shipment_And_Load_Management',
            route: routes.shipLoadManagement
        },
        {
            screen: 'Event_Plan',
            route: routes.eventBuyPlanManagement
        },
        {
            screen: 'Inventory_Plan',
            route: routes.eventBuyPlanManagement
        },
        {
            screen: 'Event_And_Inventory_Plan_Details',
            route: routes.eventBuyPlanManagementDetails
        },
        {
            screen: 'Vessel_Tracking',
            route: routes.vesselTracking
        },
        {
            screen: 'Container_Tracking',
            route: routes.vesselTrackingDetails
        },
        {
            screen: 'Inbound_optimization',
            route: routes.externalization,
        },
        {
            screen: 'Supplier_CRM',
            route: routes.externalization
        },
        {
            screen: 'Carrier_CRM',
            route: routes.externalization
        },
        {
            screen: 'Port_Document_Library',
            route: routes.documentLibrary,
        },
        {
            screen: 'Load_Document_Library',
            route: routes.documentLibrary,
        },
        {
            screen: 'Container_Document_Library',
            route: routes.documentLibrary,
        },
        {
            screen: 'Admin',
            route: routes.adminPanel
        },
        {
            screen: 'RECENT_PO_DASHBOARD_TILE',
            route: routes.home,
        },
        {
            screen: 'RECENT_SHIPMENT_DASHBOARD_TILE',
            route: routes.home,
        },
        {
            screen: 'RECENT_CONTAINER_DASHBOARD_TILE',
            route: routes.home,
        },
        {
            screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
            route: routes.home,
        },
        {
            screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
            route: routes.home,
        }
    ]


export const getPermissionsFromResponse = (allRoutePermString: string) => {

    const routePermStringList: string[] = allRoutePermString.split(',');

    const routePermList: IRoutePermission[] = routePermStringList.map((routePermString) => {

        const screen = routePermString.toUpperCase().trim().substring(0, routePermString.lastIndexOf('_'));
        const permission = routePermString.toUpperCase().trim().substring(routePermString.lastIndexOf('_') + 1, routePermString.length);

        const route = routeDBMapping.find((value) => value.screen.toUpperCase() === screen.toUpperCase())?.route;

        return { screen: screen, permission:permission, route:route };
    })

    return routePermList;

}

export const calculateDefaultRoute = (routePermList: IRoutePermission[]) => {

  if(routePermList.some(route=> route.route === routes.home && route.permission !== 'NA')){
    return routes.home
  }
  else{
    return routePermList.find(route=> route.permission !== 'NA')?.route;
  }
}