import axios from 'axios';
import {
  addDays,
  eachDayOfInterval,
  intervalToDuration,
  subDays,
} from 'date-fns';
import moment from 'moment';
import { nanoid } from 'nanoid';
import { Range } from 'react-date-range';
import {
  carrierCRMCSVHeaders,
  externalizationSchema,
  google,
  serviceApi,
  supplierCRMCSVHeaders,
  systemSettingNames,
} from './constants';
import {
  ActivityComponentTypes,
  ActivityTypes,
  ColumnType,
  DocumentTabs,
  IAddRole,
  IAdminPanelUserRolesParams,
  IAllDetailsCountParams,
  IAllDetailsParams,
  ICarrierCrmDetailsParam,
  ICarrierCrmParam,
  IDocumentLibraryTableRequest,
  IDocumentLibraryTotalCountRequest,
  IInboundOptimizationCommonParams,
  IInboundOptimizationFilterParams,
  IInboundOptimizationTableParams,
  IItemManagementFilterRequest,
  IItemManagementRequest,
  IListRolesParams,
  IListScreensParams,
  IPOLineFilterRequest,
  IPOLineTableRequest,
  IPoManagementFilterRequest,
  IPoManagementRequest,
  IPostCarrierCrmDetails,
  IPostSupplierCrmDetails,
  IProcurementMilestoneParams,
  IPromotionProcurementFilterRequest,
  IPromotionProcurementPORequest,
  IPromotionProcurementRequest,
  IRoleAccessEntity,
  ISaveAssignScreenParams,
  ISaveTableEntityRequest,
  IScreenAccessEntity,
  IShipmentFilterRequest,
  IShipmentRequest,
  ISupplierCrmDetailsParam,
  ISupplierCrmFilter,
  ITransShipmentPoDetailsParams,
  IUserDetails,
  IUserDetailsCountParam,
  IUserDetailsParam,
  IVesselCountParams,
  IVesselParams,
} from './interfaces';
import {
  axiosDelete,
  axiosGetAuth,
  axiosGetUnAuth,
  axiosPost,
  axiosPut,
} from './service';
import { store } from '../redux/store'

export const getShortenMonthFormat = (month: string) => {
  return moment().month(month).format('MMM');
};

export const getRangeForGraph = (
  maxValue: number,
  splitCount = 8
): number[] => {
  let graphRangeBuffer = [0];
  let minVal = Math.ceil(maxValue / splitCount);
  for (let i = 1; i <= splitCount; i++) {
    if (i === splitCount) {
      graphRangeBuffer.push(Number(maxValue));
    } else graphRangeBuffer.push(i * minVal);
  }
  return graphRangeBuffer;
};

export const isDigit = (value: string) => {
  const re = /^[1-9][0-9]*$/;
  return value === '' || re.test(value);
};

export const numberFormat = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    compactDisplay: 'short',
  }).format(value);
};

export const getMapTypeToToggle = (permission: string) => {
  switch (permission) {
    case 'READ':
      return 'one';
    case 'WRITE':
      return 'two';
    case 'NA':
      return 'three';
    default:
      return '';
  }
};

export const getMapToggleToType = (permission: string) => {
  switch (permission) {
    case 'one':
      return 'READ';
    case 'two':
      return 'WRITE';
    case 'three':
      return 'NA';
    default:
      return '';
  }
};

export const sortByString = <K extends string, T extends Record<K, string>>(
  items: T[],
  dateFieldName: K
) =>
  items.sort((a: T, b: T) => a[dateFieldName].localeCompare(b[dateFieldName]));

export const groupBy = <T>(
  array: T[],
  predicate: (value: T, index: number, array: T[]) => string
) =>
  array.reduce((acc, value, index, array) => {
    (acc[predicate(value, index, array)] ||= []).push(value);
    return acc;
  }, {} as { [key: string]: T[] });

export const sortForRoleScreen = (
  data: IRoleAccessEntity[] | IScreenAccessEntity[],
  isRole: boolean
) => {
  let groupedData: { [x: string]: any[] };
  let res: any[] = [];
  if (isRole) {
    groupedData = groupBy(data as IScreenAccessEntity[], (v) => v.permission);
  } else {
    groupedData = groupBy(data as IRoleAccessEntity[], (v) => v.permission);
  }
  const sortVal = (isRole: boolean, type: string) => {
    if (isRole) {
      let data = groupedData[type] as IScreenAccessEntity[];
      res = res.concat(...sortByString(data, 'screen'));
    } else {
      let data = groupedData[type] as IRoleAccessEntity[];
      res = res.concat(...sortByString(data, 'role'));
    }
  };

  if (groupedData && groupedData['WRITE']) {
    sortVal(isRole, 'WRITE');
  }
  if (groupedData && groupedData['READ']) {
    sortVal(isRole, 'READ');
  }
  if (groupedData && groupedData['NA']) {
    sortVal(isRole, 'NA');
  }
  if (groupedData && groupedData['']) {
    sortVal(isRole, '');
  }

  return res;
};

export const getNPercentOfValue = (val: number, nPercent: number) => {
  return Math.ceil((nPercent / 100) * val);
};

export const getFormattedDate = (date: string) => {
  return moment(new Date(date + ' 00:00:00')).format('MM/DD/YYYY');
};

export function sortDate(dateA: string, dateB: string, direction = 'asc') {
  const formats = ['YYYY-MM-DD'];
  return (
    (moment(dateA, formats).isBefore(moment(dateB, formats))
      ? -1
      : moment(dateA, formats).isAfter(moment(dateB, formats))
      ? 1
      : 0) * (direction === 'asc' ? 1 : -1)
  );
}

export const getFormattedApiDate = (date: string) => {
  return moment(new Date(date)).format('YYYY-MM-DD');
};

export const getFormattedNumber = (number: string) => {
  return new Intl.NumberFormat().format(Number(number));
};

export const getGMTTimeStamp = (date?: string) => {
  if (date) {
    return new Date(new Date(date + ' 00:00:00'));
  }
  return new Date(
    new Date().getTime() + new Date().getTimezoneOffset() * 60 * 1000
  );
};

export const isStringValid = (str: string | undefined): boolean => {
  if (!str) return false;
  else if (str === '') return false;
  else if (str === null) return false;
  else return true;
};

export const capitaliseFirstletterOfAllWordsInSentence = (
  value: string
): string => {
  let words = value.trim().split(' ');
  words = words.map((value, index) => {
    if (value.trim().length === 0) return '';
    return value[0].toUpperCase() + value.substring(1).toLocaleLowerCase();
  });
  return words.join(' ');
};

export const fetchUserRole = (userGroupId: string | null): string => {
  if (userGroupId !== null) {
    if (process.env.REACT_APP_GROUP_ID_SUPPLY_CHAINOPS === userGroupId)
      return 'SUPPLY CHAINOPS';
    if (process.env.REACT_APP_GROUP_ID_POWER_USER === userGroupId)
      return 'POWER USER';
    if (process.env.REACT_APP_GROUP_ID_SUPPLIER === userGroupId)
      return 'SUPPLIER';
    if (process.env.REACT_APP_GROUP_ID_CUSTOM_OPS === userGroupId)
      return 'CUSTOM OPS';
    if (process.env.REACT_APP_GROUP_ID_CARRIER === userGroupId)
      return 'CARRIER';
  }
  return '';
};

export const isAlphanumericWithSpace = (val: string) => {
  const regex = /^[a-zA-Z ]*$/;

  if (regex.test(val)) {
    return true;
  }
  return false;
};

export const isAlphaNumericString = (input: string) => {
  const regex = /^[a-zA-Z0-9]*$/;
  if (regex.test(input)) {
    return true;
  }
  return false;
};

export const removeExtraSpaces = (input: string) => {
  return input.replace(/\s+/g, ' ');
};

export const formatFileSize = (bytes: number, decimalPoint?: number) => {
  if (bytes === 0) return '0';
  var k = 1000,
    dm = decimalPoint || 2,
    sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
    i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

export const getPercentage = (
  currentValue: number,
  totalValue: number
): string => {
  if (currentValue === 0 && totalValue === 0) {
    return '0%';
  } else {
    let num = ((currentValue / totalValue) * 100).toFixed(2);
    if (currentValue > 0 && Number(num) === 0) {
      return '< 0.01%';
    } else {
      if (Number(num) % 1 !== 0) {
        return `${num}%`;
      } else {
        return Math.round(Number(num)) + '%';
      }
    }
  }
};

export const validEntityString = (value: string) => {
  return value.length > 0;
};

export const getSettingModifiedData = (
  settings: any,
  start: number,
  end: number
): Range[] => {
  let fixedSettingDate: undefined | string;
  let enableFixedDate: undefined | string;

  if (settings && settings.length > 0) {
    settings.forEach((setting: any) => {
      if (!enableFixedDate)
        enableFixedDate =
          setting.name === systemSettingNames.enableFixedDate
            ? setting.value
            : undefined;
      if (!fixedSettingDate)
        fixedSettingDate =
          setting.name === systemSettingNames.fixedDate
            ? setting.value
            : undefined;
    });
  }

  return [
    {
      startDate: subDays(
        getGMTTimeStamp(
          enableFixedDate === 'true' ? fixedSettingDate : undefined
        ),
        start
      ),
      endDate: addDays(
        getGMTTimeStamp(
          enableFixedDate === 'true' ? fixedSettingDate : undefined
        ),
        end
      ),
      key: 'selection',
    },
  ];
};

/**
 * Get user information
 * @param {string} access_token
 * @return {any} axios response
 */
export const getUserInfo = (access_token: string) => {
  return axiosGetAuth(google.user_info_api, access_token);
};

/**
 * Get user group
 */
export const getUserGroup = async () => {
  // create array of group url of each group_id
  const userGroupUrls: string[] = google.group_ids.map((group_id) => {
    return `${
      google.user_group_api
    }/${group_id}/memberships/${store.getState().user.userId}`;
  });
  let errorResponseStatus;
  // invoking each url to check if user exist in a certain group.
  for (const url of userGroupUrls) {
    try {
      const response = await axiosGetAuth(url);
      // returning group_id
      return response.data.name.split('/')[1];
    } catch (error: any) {
      errorResponseStatus = error.response?.data.error.status;
      // when token is expired, it will return 'UNAUTHENTICATED'
      if (errorResponseStatus === 'UNAUTHENTICATED') return errorResponseStatus;
    }
  }
  // when all api calls are finished and user doesnt belongs to any group then it will return 'PERMISSION_DENIED'
  return errorResponseStatus;
};

/**
 * Get user email IDs
 * @param {string} string on which to search for emailId
 * @return {any} axios response
 */
export const getUserEmailIds = async (emailParam: string) => {
  return axiosGetAuth(
    google.user_email_id_api +
      `?projection=custom&domain=deloitte.com&viewType=domain_public&query=email%3A` +
      emailParam +
      `*`
  );
};

/**
 * Get all vessels
 * @param {IVesselParams} fetchParams
 * @return {any} axios response
 */
export const getAllVessels = (fetchParams: IVesselParams) => {
  return axiosGetUnAuth(serviceApi.getVesselDetails, {
    ...fetchParams,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get all vessels total count of records
 * @param {IVesselCountParams} fetchParams
 * @return {any} axios response
 */
export const getAllVesselsCount = (fetchParams: IVesselCountParams) => {
  return axiosGetUnAuth(serviceApi.getVesselDetailsCount, {
    ...fetchParams,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get vessel details like containerId, mabd, shipmentStatus, poNumber, loadId
 * @param {IAllDetailsParams} fetchParams
 * @return {any} axios response
 */
export const getAllDetails = (fetchParams: IAllDetailsParams) => {
  return axiosGetUnAuth(serviceApi.getAllDetails, {
    ...fetchParams,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get vessel details total count of records
 * @param {IAllDetailsCountParams} fetchParams
 * @return {any} axios response
 */
export const getAllDetailsCount = (fetchParams: IAllDetailsCountParams) => {
  return axiosGetUnAuth(serviceApi.getAllDetailsCount, {
    ...fetchParams,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get tracking details of shipAndLoad to display on vessel tracking screen 2 table
 * @param {ITransShipmentPoDetailsParams} fetchParams
 * @return {any} axios response
 */
export const getTransShipmentPoDetails = (
  fetchParams: ITransShipmentPoDetailsParams
) => {
  return axiosGetUnAuth(serviceApi.getTransShipmentPoDetails, {
    ...fetchParams,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get Count of all tracking details of shipAndLoad
 * @param {ITransShipmentPoDetailsParams} fetchParams
 * @return {any} axios response
 */
export const getTransShipmentPoDetailsCount = (
  fetchParams: ITransShipmentPoDetailsParams
) => {
  return axiosGetUnAuth(serviceApi.getTransShipmentPoDetailsCount, {
    ...fetchParams,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get transshipment tracking details
 * @param {string} containerId
 * @return {any} axios response
 */
export const getTransShipmentDetails = (containerId: string, mabd: string) => {
  return axiosGetUnAuth(serviceApi.getTransShipmentDetails, {
    containerId,
    mabd,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get a single vessel's history coordinates
 * @param {string} vesselId
 * @param {string} containerId
 * @param {string} mabd
 * @return {any} axios response
 */
export const getVesselHistoryCoordinates = (
  vesselId: string,
  containerId: string,
  mabd: string
) => {
  return axiosGetUnAuth(serviceApi.getVesselHistoryCoordinates, {
    vesselId,
    containerId,
    mabd,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get recent PO,Shipment,tracking details for displaying in Dashboard page
 * @param {string} activityType
 * @param {string} activityComponent
 * @return {any} axios response
 */
export const getActivityTrackingDetails = (
  activityType: ActivityTypes,
  activityComponent: ActivityComponentTypes,
  activityDaysLimit?: number,
  activityLimit?: number
) => {
  return axiosGetUnAuth(serviceApi.activityTrackingDetails, {
    activityType,
    activityComponent,
    activityLimit,
    activityDaysLimit,
    userId: store.getState().user.userId,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const postActivityTrackerDetails = (
  activityId: string,
  activityType: ActivityTypes,
  activityComponent: ActivityComponentTypes,
  activityDaysLimit?: number,
  activityLimit?: number,
  fetchActivities?: boolean,
  partitionValue?: string
) => {
  let config = {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  };
  return axiosPost(
    serviceApi.activityTrackingDetails,
    {
      activityId,
      activityType,
      activityComponent,
      userId: store.getState().user.userId,
      activityDaysLimit,
      activityLimit,
      fetchActivities,
      partitionValue,
    },
    config
  );
};

/**
 * Get list of Document titles for Upload Modal
 * @param {string} documentComponent
 * @param {string} selectColumn
 * @param {string} selectValue
 * @return {any} axios response
 */
export const getUploadOptions = (
  documentComponent: string,
  selectColumn: ColumnType,
  selectValue = ''
) => {
  return axiosGetUnAuth(serviceApi.getUploadOptions, {
    documentComponent,
    selectColumn,
    selectValue,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getUploadOptionsPoNumber = (
  documentComponent: string,
  selectValue = ''
) => {
  return axiosGetUnAuth(serviceApi.documentLibraryPONumSuggestion, {
    documentComponent,
    selectValue,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const deleteActivityTrackerDetails = (
  activityId: string,
  activityType: ActivityTypes,
  activityComponent: ActivityComponentTypes,
  activityDaysLimit: number,
  activityLimit: number,
  fetchActivities: boolean
) => {
  return axiosDelete(
    serviceApi.activityTrackingDetails +
      '?key=' +
      process.env.REACT_APP_GCLOUD_TOKEN_KEY,
    {
      activityId,
      activityType,
      activityComponent,
      userId: store.getState().user.userId,
      activityDaysLimit,
      activityLimit,
      fetchActivities,
    }
  );
};

/**
 * Get Shipment and Load details
 * @param {IShipmentRequest} params
 * @return {any} axios response
 */
export const getShipAndLoadData = (params: IShipmentRequest) => {
  return axiosGetUnAuth(serviceApi.shipAndLoad_url, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getShipAndLoadDataCount = (params: IShipmentRequest) => {
  return axiosGetUnAuth(serviceApi.shipAndLoadCount_url, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get Shipment and Load Auto Suggest details
 * @param {IshipmentFilterRequest} data
 * @return {any} axios response
 */
export const getShipAndLoadAutoSuggestData = (data: IShipmentFilterRequest) => {
  return axiosGetUnAuth(serviceApi.shipAndLoadFilter_url, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getMultiSelectFilterData = (filterType: string) => {
  return axiosGetUnAuth(serviceApi.multiselectFilters, {
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
    filterType,
  });
};

/**
 * Get Promotion and Procurement Plan details
 * @param {IPromotionProcurementRequest} data
 * @return {any} axios response
 */
export const getEventAndBuyPlanTableData = (
  data: IPromotionProcurementRequest
) => {
  return axiosGetUnAuth(serviceApi.promotionProcurementTable_url, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getEventAndBuyPlanTableCount = (
  data: IPromotionProcurementRequest
) => {
  return axiosGetUnAuth(serviceApi.promotionProcurementTableCount, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getPromotionProcurementPlan = (
  param: IProcurementMilestoneParams
) => {
  return axiosGetUnAuth(serviceApi.promotionProcurementDetails_url, {
    ...param,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get Promotion and Procurement Plan  filters
 * @param {IPromotionProcurementFilterRequest} data
 * @return {any} axios response
 */
export const getEventAndBuyPlanFilterData = (
  data: IPromotionProcurementFilterRequest
) => {
  return axiosGetUnAuth(serviceApi.promotionProcurementFilter_url, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get Promotion and Procurement Plan  filters
 * @param {IPromotionProcurementPORequest} data
 * @return {any} axios response
 */
export const getPromotionProcurementPlanPOData = (
  data: IPromotionProcurementPORequest
) => {
  return axiosGetUnAuth(serviceApi.promotionProcurementDetailsTable_url, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getPromotionProcurementPlanPOTableCount = (
  data: IPromotionProcurementPORequest
) => {
  return axiosGetUnAuth(serviceApi.promotionProcurementDetailsTableCount, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get Document Library filters
 * @param {DocumentTypes} documentComponent
 * @return {any} axios response
 */
export const getDocumentLibraryFilterData = (
  documentComponent: DocumentTabs
) => {
  const refineApiUrl =
    documentComponent === 'LOAD'
      ? serviceApi.documentLibraryRefineSearchVendor
      : serviceApi.documentLibraryRefineSearchCarrier;
  return axiosGetUnAuth(refineApiUrl, {
    documentComponent,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getDocumentLibraryTableData = (
  data: IDocumentLibraryTableRequest
) => {
  const documentDetailsURl =
    data.documentComponent === 'LOAD'
      ? serviceApi.vendorDocumentDetails
      : serviceApi.carrierDocumentDetails;

  return axiosGetUnAuth(documentDetailsURl, {
    currentUserId: store.getState().user.userId,
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getDocumentLibraryTotalCount = (
  data: IDocumentLibraryTotalCountRequest
) => {
  const documentDetailsCountURl =
    data.documentComponent === 'LOAD'
      ? serviceApi.documentLibraryVendorTotalCount
      : serviceApi.documentLibraryCarrierTotalCount;
  return axiosGetUnAuth(documentDetailsCountURl, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getPromotionCommitmentPlan = () => {
  return axiosGetUnAuth(serviceApi.promotionCommitment_url, {
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const downloadDocumentLibraryFiles = (
  fileIds: string[],
  type: DocumentTabs
) => {
  const downloadAPIUrl =
    type === 'LOAD'
      ? serviceApi.documentLibraryDownloadVendorFiles
      : serviceApi.documentLibraryDownloadCarrierFiles;
  return axiosGetUnAuth(downloadAPIUrl, {
    listOfDocId: fileIds.join(','),
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const uploadDocumentLibraryFiles = (
  data: FormData,
  onUploadProgress: Function
) => {
  //To retrieve type of document from formData and map to url
  const uploadAPIUrl =
    data
      .get('request')
      ?.toString()
      .split(',')[0]
      .split(':')[1]
      .split('"')
      .join('') === 'LOAD'
      ? serviceApi.documentLibraryVendorUploadFiles
      : serviceApi.documentLibraryCarrierUploadFiles;
  let config = {
    onUploadProgress,
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
    headers: { 'Content-Type': 'multipart/form-data' },
  };
  return axiosPost(uploadAPIUrl, data, config);
};

export const updateDocumentLibraryFile = (
  data: FormData,
  onUploadProgress: Function,
  type: DocumentTabs
) => {
  let config = {
    onUploadProgress,
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
    headers: { 'Content-Type': 'multipart/form-data' },
  };
  const updateDocumentAPIUrl =
    type === 'LOAD'
      ? serviceApi.documentLibraryUpdateVendorFile
      : serviceApi.documentLibraryUpdateCarrierFile;
  return axiosPut(updateDocumentAPIUrl, data, config);
};

export const getSystemSetting = (data?: string[]) => {
  return axiosGetUnAuth(serviceApi.systemSettings_url, {
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
    names: data ? data.join(',') : '',
  });
};

export const getPOLineManagementTableData = (
  request: IPOLineTableRequest,
  cancelToken?: any
) => {
  return axiosGetUnAuth(
    serviceApi.poLineMangementTable_url,
    { ...request, key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
    cancelToken
  );
};

export const getPOLineManagementTableCount = (
  request: IPOLineTableRequest,
  cancelToken?: any
) => {
  return axiosGetUnAuth(
    serviceApi.poLineMangementTableCount,
    { ...request, key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
    cancelToken
  );
};

export const getPOLineManagementFilter = (
  request: IPOLineFilterRequest,
  cancelToken?: any
) => {
  return axiosGetUnAuth(
    serviceApi.poLineMangementFilter,
    { ...request, key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
    cancelToken
  );
};
/**
 * Get Shipment and Load details
 * @param {IPoManagementRequest} params
 * @return {any} axios response
 */
export const getPoManagementDetails = (params: IPoManagementRequest) => {
  return axiosGetUnAuth(serviceApi.getPoManagementDetails, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getPoManagementDataCount = (params: IPoManagementRequest) => {
  return axiosGetUnAuth(serviceApi.getPoManagementDetailsCount, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get Shipment and Load Auto Suggest details
 * @param {IPoManagementRequest} data
 * @return {any} axios response
 */
export const getPoManagementAutoSuggestData = (
  data: IPoManagementFilterRequest
) => {
  return axiosGetUnAuth(serviceApi.getPoManagementFilter, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get ItemManagement details
 * @param {IPoManagementRequest} params
 * @return {any} axios response
 */
export const getItemManagementDetails = (params: IItemManagementRequest) => {
  return axiosGetUnAuth(serviceApi.getItemManagementDetails, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getItemManagementDataCount = (params: IPoManagementRequest) => {
  return axiosGetUnAuth(serviceApi.getItemManagementDetailsCount, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

/**
 * Get Item Management Auto Suggest details
 * @param {IPoManagementRequest} data
 * @return {any} axios response
 */
export const getItemManagementAutoSuggestData = (
  data: IItemManagementFilterRequest
) => {
  return axiosGetUnAuth(serviceApi.getItemManagementFilter, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const uploadSupplierCrmCSVFile = (
  data: FormData,
  onUploadProgress: Function
) => {
  let config = {
    onUploadProgress,
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
    headers: { 'Content-Type': 'multipart/form-data' },
  };
  return axiosPost(serviceApi.supplierCrmCSVUpload, data, config);
};
export const getSupplierCrmFIlter = (data: ISupplierCrmFilter) => {
  return axiosGetUnAuth(serviceApi.getSupplierCrmFilter, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getSupplierCrmDetails = (data: ISupplierCrmDetailsParam) => {
  return axiosGetUnAuth(serviceApi.getSupplierCrmDetails, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const postSupplierCrmDetail = (data: IPostSupplierCrmDetails) => {
  return axiosPost(serviceApi.getSupplierCrmDetails, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const supplierCRMBulkUpdatePost = (data: IPostSupplierCrmDetails[]) => {
  return axiosPost(serviceApi.supplierCrmBulkUpdate, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const paginationCount = (totalElements: number, pageSize: number) => {
  return Math.ceil(totalElements / pageSize);
};

export const getFillerLength = (totalTableData: any[], minLength?: number) => {
  if (totalTableData) {
    return totalTableData.length < (minLength ?? 8) ? (minLength ?? 8) - totalTableData.length : 0;
  }
  return 0;
};

export const getDatesInRange = (startDate: string, endDate: string) => {
  return eachDayOfInterval({
    start: new Date(startDate),
    end: new Date(endDate),
  });
};

export const removeTimeZone = (date: string) => {
  return new Date(Date.parse(date));
};

export const formatSupplierCRMResponseForCSV = (
  data: any,
  tableParam: ISupplierCrmDetailsParam
) => {
  data = data.map((row: any) => {
    return [
      tableParam.vendorId,
      tableParam.shipPointId,
      tableParam.facility,
      tableParam.protectionType,
      row.capacityDate,
      row.supplierCapacity ?? '',
    ];
  });
  return data;
};

export const schemaValidationForCSVUpload = (
  file: File,
  schema: string,
  callBack: any
) => {
  const reader = new FileReader();

  reader.onload = (e: any) => {
    const errors: string[] = [];
    const schemaToValidate =
      schema === externalizationSchema.SUPPLIER
        ? supplierCRMCSVHeaders
        : carrierCRMCSVHeaders;

    if (e && e.target && e.target.result) {
      const text = e.target.result;
      // if there is no new line that means the file is invalid
      if (text.indexOf('\n') === -1) {
        callBack([
          externalizationSchema.inValidHeader,
          externalizationSchema.noData,
        ]);
        return;
      }
      //get the headers from file
      const headers = text.slice(0, text.indexOf('\n')).split(',');
      // get the rows from file
      let rows = text.slice(text.indexOf('\n') + 1).split('\n');
      // get the non empty rows
      rows = rows.filter(
        (row: string) =>
          !row
            .replaceAll('/r', '')
            .split(',')
            .every(
              (value) => value.replace(/^"(.*)"$/, '$1').trim().length === 0
            )
      );
      //validation checks missing column headers length, order
      if (
        schemaToValidate.length !== headers.length ||
        !schemaToValidate.every(
          (value, index) =>
            //remove white spaces and unnecessary double quotes
            value.trim() === headers[index].replace(/^"(.*)"$/, '$1').trim()
        )
      ) {
        errors.push(externalizationSchema.inValidHeader);
      }
      //validation check empty file/no data
      if (rows.length <= 0) {
        errors.push(externalizationSchema.noData);
      }
      callBack(errors);
    } else {
      callBack([
        externalizationSchema.inValidHeader,
        externalizationSchema.noData,
      ]);
    }
  };
  reader.readAsText(file);
};

export const uploadCarrierCrmCSVFile = (
  data: FormData,
  onUploadProgress: Function
) => {
  let config = {
    onUploadProgress,
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
    headers: { 'Content-Type': 'multipart/form-data' },
  };
  return axiosPost(serviceApi.carrierCrmCSVUpload, data, config);
};

export const getCarrierCrmDetails = (data: ICarrierCrmDetailsParam) => {
  return axiosGetUnAuth(serviceApi.getCarrierCrmDetails, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getCarrierCrmFIlter = (data: ICarrierCrmParam) => {
  return axiosGetUnAuth(serviceApi.getCarrierCrmFilter, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const postCarrierCrmDetail = (data: IPostCarrierCrmDetails) => {
  return axiosPost(serviceApi.getCarrierCrmDetails, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const formatCarrierCRMResponseForCSV = (
  data: any,
  tableParam: ICarrierCrmDetailsParam
) => {
  data = data.map((row: any) => {
    return [
      tableParam.carrierUserId,
      tableParam.carrierId,
      tableParam.origin,
      tableParam.destination,
      tableParam.facility,
      tableParam.protectionType,
      tableParam.mode,
      row.capacityDate,
      row.count ?? '',
    ];
  });
  return data;
};

export const carrierCRMBulkUpdatePost = (data: IPostCarrierCrmDetails[]) => {
  return axiosPost(serviceApi.carrierCrmBulkUpdate, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const getInboundGraph = (data: IInboundOptimizationCommonParams) => {
  return axiosGetUnAuth(serviceApi.getInboundGraph, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getLastUpdatedDateTImeString = (dateString: string) => {
  const duration: Duration = intervalToDuration({
    start: new Date(dateString.split('.')[0]),
    end: getGMTTimeStamp(),
  });
  const getPlural = (value: number) => {
    return value > 1 ? 's' : '';
  };
  switch (true) {
    case duration.years && duration.years > 0:
      return duration.years + ' year' + getPlural(duration.years!);
    case duration.months && duration.months > 0:
      return duration.months + ' month' + getPlural(duration.months!);
    case duration.days && duration.days > 0:
      return duration.days + ' day' + getPlural(duration.days!);
    case duration.hours && duration.hours > 0:
      return duration.hours + ' hour' + getPlural(duration.hours!);
    case duration.minutes && duration.minutes > 0:
      return duration.minutes + ' minute' + getPlural(duration.minutes!);
    case duration.seconds && duration.seconds > 0:
      return duration.seconds + ' second' + getPlural(duration.seconds!);
    default:
      return '1 second';
  }
};

export const formatToSelectFilterType = (rawArray: string[]) => {
  return rawArray.map((item) => {
    return {
      key: nanoid(),
      value: item,
    };
  });
};

export const getInboundOptimizationFilter = (
  params: IInboundOptimizationFilterParams
) => {
  return axiosGetUnAuth(serviceApi.getInboundOptimizationFilter, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getInboundOptimizationTable = (
  params: IInboundOptimizationTableParams
) => {
  return axiosGetUnAuth(serviceApi.getInboundOptimizationTableDetails, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getInboundOptimizationTableCount = (
  params: IInboundOptimizationTableParams
) => {
  return axiosGetUnAuth(serviceApi.getInboundOptimizationTableCount, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getAdminPanelUserRoles = (data: IAdminPanelUserRolesParams) => {
  return axiosGetUnAuth(serviceApi.getAdminPanelUserRoles, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const deleteUser = (emailId: string) => {
  return axiosDelete(
    serviceApi.addUser + '?key=' + process.env.REACT_APP_GCLOUD_TOKEN_KEY,
    {
      emailId: emailId,
    }
  );
};

export const getUsers = (data: IUserDetailsParam) => {
  return axiosGetUnAuth(serviceApi.getUsers, {
    ...data,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getUsersCount = (params: IUserDetailsCountParam) => {
  return axiosGetUnAuth(serviceApi.getUsersCount, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const postUser = (data: IUserDetails) => {
  return axiosPost(serviceApi.addUser, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const getListRoles = (params: IListRolesParams) => {
  return axiosGetUnAuth(serviceApi.getRoles, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const getListRolesCount = () => {
  return axiosGetUnAuth(serviceApi.getRolesCount, {
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const postSaveTable = (data: ISaveTableEntityRequest[]) => {
  return axiosPut(serviceApi.postRole, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const getListScreens = (params: IListScreensParams) => {
  return axiosGetUnAuth(serviceApi.getListScreens, {
    ...params,
    key: process.env.REACT_APP_GCLOUD_TOKEN_KEY,
  });
};

export const saveScreenPermission = (data: ISaveAssignScreenParams[]) => {
  return axiosPost(serviceApi.saveAssignScreen, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const addRole = (data: IAddRole[]) => {
  return axiosPost(serviceApi.postRole, data, {
    params: { key: process.env.REACT_APP_GCLOUD_TOKEN_KEY },
  });
};

export const getUserPermissions = (authToken:string) =>{
  return axios.get(serviceApi.getUserPsermissions,{
    headers: {'auth-token':authToken},
    params:{ key: process.env.REACT_APP_GCLOUD_TOKEN_KEY},
    timeout: 20000
  })
}