import { addDays, addMonths, endOfDay, endOfMonth, endOfWeek, isSameDay, startOfDay, startOfMonth, startOfWeek } from 'date-fns';
import { createStaticRanges } from 'react-date-range';
import { getGMTTimeStamp } from './utils';

// live tracking filter overlay component
export const trackingFilterTypes = [
  { name: 'Container ID', code: 'containerId' },
  { name: 'Vessel ID', code: 'vesselId' },
  { name: 'Shipment ID', code: 'shipmentId' },
  { name: 'Load ID', code: 'loadId' },
  { name: 'PO Number', code: 'poNumber' },
  { name: 'Supplier Name', code: 'supplierName' }
];

// list of file type for upload modal component
export const typeOfFiles = [{ label: 'Load Document(s)', value: 'LOAD' },
{ label: 'Port Document(s)', value: 'PORT' },
{ label: 'Container Document(s)', value: 'CONTAINER' }
];
export const typeOfFilesCustomOps =
  [{ label: 'Port Document(s)', value: 'PORT' }];

export const labels = {
  appTitle: 'Trellis Control Tower',
  signInButtonText: 'Sign in with Google',
  home: 'Dashboard',
  homeNav: 'Dashboard',
  poManagement: 'PO Management',
  poLineManagement: 'PO Line Management',
  poLineNav: 'PO Line Item Details',
  itemManagement: 'Item Management',
  vendorManagement: 'Vendor Management',
  shipAndLoadManagement: 'Shipment & Load Management',
  zoneAndLocManagement: 'Zone & Loc Management',
  buyPlanEventManagement: 'Event & Inventory Plan Management',
  vesselTracking: 'Vessel Tracking',
  vesselTrackingDetails: 'Vessel Tracking Details',
  liveTracking: 'Live Tracking',
  poItemManagement: 'PO Item Management',
  poNumber: 'PO Number',
  shipmentId: 'Shipment ID',
  loadId: 'Load ID',
  carrierSCAC: 'Carrier SCAC',
  mode: 'Mode',
  shipmentDocId: 'Shipment Doc ID',
  containerId: 'Container ID',
  maap: 'MAAP',
  mabd: 'MABD',
  equipmentId: 'Equipment ID',
  equipmentDesc: 'Equipment Description',
  weight: 'Weight(Lbs)',
  cube: 'Cube(Ft)',
  shipUnitCount: 'Shipping Unit Count',
  dataRange: 'Date Range(UTC)',
  tooTip: '* By Default date range of MABD will be T-15 to T+45',
  imo: 'IMO',
  mmsi: 'MMSI',
  VesselId: 'Vessel ID',
  Arrival: 'Arrival',
  Departure: 'Departure',
  promotionProcurementTitle: 'Event & Inventory Plans',
  promotionTab: 'Event Plans',
  procurementTab: 'Inventory Plans',
  ProcurementPlan: 'Inventory Plan',
  PromotionPlan: 'Event Plan',
  MilestoneLabel: 'MILESTONE MANAGEMENT',
  docLibrary: 'Document Library',
  loadDoc: 'Load Document',
  portDoc: 'Port Document',
  containerDoc: 'Container Document',
  ItemQuantity: 'ITEM QUANTITY',
  SupplyChain: 'SUPPLY CHAIN SEGMENT',
  PromotionCommitment: 'Inventory Plan / Commitment',
  TargetDate: 'Target Date',
  TargetQuantity: 'Target Quantity',
  VendorId: 'Vendor ID',
  VendorDes: 'Vendor Description',
  BusinessUnit: 'Business Unit',
  Status: 'Status',
  EventId: 'Event',
  UPC: 'UPC',
  ItemNumber: 'Item Number',
  BuyPlanID: 'Inventory',
  ItemStatus: 'Item Status',
  shippedQuantity: 'Quantity Shipped',
  department: 'Department',
  orderedQuantity: 'Quantity Ordered',
  pendingQuantity: 'Quantity Pending',
  itemDescription: 'Item Description',
  lineNumber: 'Line Number',
  itemNumber: 'Item Number',
  externalization: 'Externalization',
  carrierCrm: 'Carrier CRM',
  supplierCrm: 'Supplier CRM',
  inboundOptimization: 'Inbound Optimization',
  shipPointId: 'Ship Point ID',
  facilityName: 'Facility Name',
  protectionType: 'Protection Type',
  supplierId: 'Supplier ID',
  somethingWentWrong: 'Something Went Wrong',
  recordSaved: 'Record saved!!',
  bulkUpdateStarted:
    'Bulk update has been initialized. Check after sometime for updated records',
  dataNotSaved: 'Data was not Saved',
  bulkUpdateFailed: 'Bulk update failed to initialize',
  capacityWarn:
    'Shipping capacity should be greater than or equal to the Committed capacity!!',
  capacityEmpty: 'Shipping capacity can not be empty for update',
  carrierCountWarn: ' cannot be empty!',
  carrierId: 'Carrier ID',
  carrierUserId: 'Carrier User ID',
  origin: 'Origin',
  destination: 'Destination',
  dcId: 'DC ID',
  filterFetchFail: 'Failed to fetch filter values',
  assignedLoads: 'Assigned Loads',
  unAssignedLoads: 'Unassigned Loads',
  pendingLoads: 'Pending Loads',
  supplierShippingCapacity: 'Supplier Shipping',
  supplierCapacity: 'Supplier Capacity',
  carrierCapacity: 'Carrier Capacity',
  inboundLoadWarning: 'The loads are exceeding the shipping capacity',
  adminPanel: 'Admin Panel',
  userAccess: 'User Access',
  roleAccess: 'Role Access',
  emailId: 'Email ID',
  userRole: 'User Role',
  externalId: 'External ID',
  userAccessDetails: 'User Access Details',
  roleAccessDetails: 'Role Access Details',
  role: 'Role',
  screen: 'Screen',
  permission: 'Permissions',
  modifiedRole: 'The role has been modified successfully',
  Error: 'Error',
  RoleNPermission: 'Role and Permission',
  Assign: 'Assign',
  AssignScreenSuccess: 'The screen has been assigned to roles successfully',
  AssignScreenTitle: 'Assign Screen to Role(s)',
  AssignScreenError: 'Failed to assigne the screen to role/s',
  selectScreenToProceed: 'Please select the screen to proceed further',
  selectRolesNPermission:
    'Select role(s) and permission(s) type for the above selected screen',
  roleAddedSuccess: 'New role has been added successfully',
  addRole: 'Add a Role',
  externalRole: 'External Role',
  selectExternalRole: 'Please Select If External Role',
  screenNPermission: 'Screens and Permissions',
  selectScreensNPermission:
    'Select screen(s) and permission type for the above mentioned user',
  AddRole: 'Add Role',
  selectScreen: 'Select Screen',
};

const dataStudioBaseUrl = process.env.REACT_APP_DATA_STUDIO_URL; //data studio report url
const dataStudioPOUri = process.env.REACT_APP_DATA_STUDIO_PO_URI;
const dataStudioLineUri = process.env.REACT_APP_DATA_STUDIO_LINE_URI;
const dataStudioItemUrl = process.env.REACT_APP_DATA_STUDIO_ITEM_URI;

export const dataStudioUrls = {
  po_url: (dataStudioBaseUrl ?? '') + dataStudioPOUri ?? '',
  poline_url: (dataStudioBaseUrl ?? '') + dataStudioLineUri ?? '',
  itemManage_url: (dataStudioBaseUrl ?? '') + dataStudioItemUrl ?? '',
  iFrameWidth: '1350px',
  iFrameWidth_short: '1200px',
  iFrameHeight: '720px',
};

export const tableConfig = {
  pageSize: 25,
  vesselTrackingMapPageSize: 100,
};

export const milestoneStatus = [
  'PO placed',
  'PO ready to ship',
  'Transportation plan in place',
  'PO in transit',
  'Cleared customs',
  'Domestic transit',
  'Available in stores',
];

export const shipmentColumn = {
  mustArriveByDate: 'mabd',
  poNumber: 'poNumber',
  shipmentId: 'shipmentId',
  loadId: 'loadId',
  transportDocId: 'transportDocId',
  carrierSCAC: 'carrierSCAC',
  mode: 'mode',
  equipmentId: 'equipmentId',
  equipmentDesc: 'equipmentDesc',
  cube: 'cube',
  weight: 'weight',
  shippingUnitCount: 'shippingUnitCount',
  containerId: 'containerId',
  scac: 'scac',
};

export const polineColumn = {
  poNumber: 'poNumber',
  mabd: 'mabd',
  maap: 'maap',
  itemNumber: 'itemNumber',
  lineNumber: 'lineNumber',
  department: 'department',
  itemDescription: 'itemDescription',
  orderedQuantity: 'orderedQuantity',
  shippedQuantity: 'shippedQuantity',
  pendingQuantity: 'pendingQuantity',
  shipmentId: 'shipmentId',
};

export const eventColumns = [
  'Event',
  'Target Date',
  'Target Quantity',
  'At Risk Quantity',
  'At Risk Percentage',
];
export const buyPlanColumns = [
  'Inventory',
  'Target Date',
  'Target Quantity',
  'At Risk Quantity',
  'At Risk Percentage',
];

export const routes = {
  root: '/',
  login: '/login',
  logout: '/logout',
  unAuthenticated: '/unAuthenticate',
  unAuthorized: '/unauthorized',
  adminPanel: 'admin-panel',
  home: 'home',
  poManagement: 'po-management',
  lineDetails: 'po-management/details',
  itemManagement: 'item-management',
  vesselTracking: 'vessel-tracking',
  vesselTrackingDetails: 'vessel-tracking/details',
  vendorManagement: 'vendor-management',
  shipLoadManagement: 'ship-load-management',
  shipLoadManagementMulti: 'ship-load-management-multi',
  zoneManagement: 'zone-management',
  eventBuyPlanManagement: 'event-inventory-plan',
  promotionProcurementDetails: 'event-inventory-plan/details',
  documentLibrary: 'document-library',
  externalization: 'externalization',
};
export const monthNames = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

export const allowedFileType = ['pdf', 'doc', 'docx'];

export const allowedFileTypeSupplierCRM = ['csv'];

export const externalizationSchema = {
  SUPPLIER: 'supplierCRM',
  CARRIER: 'carrierCRM',
  noData: " doesn't contain any data",
  inValidHeader: " does't have correct column headers"
};

export const google = {
  client_id: process.env.REACT_APP_GOOGLE_OAUTH_CLIENT_ID,
  scope:
    'email profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/cloud-identity.devices.lookup https://www.googleapis.com/auth/cloud-identity.groups https://www.googleapis.com/auth/cloud-identity.groups.readonly https://www.googleapis.com/auth/admin.directory.user.readonly',
  group_ids: [
    process.env.REACT_APP_GROUP_ID_POWER_USER,
    process.env.REACT_APP_GROUP_ID_SUPPLY_CHAINOPS,
    process.env.REACT_APP_GROUP_ID_CUSTOM_OPS,
    process.env.REACT_APP_GROUP_ID_SUPPLIER,
    process.env.REACT_APP_GROUP_ID_CARRIER,
  ],
  user_info_api: 'https://www.googleapis.com/oauth2/v3/userinfo?alt=json',
  user_group_api: 'https://content-cloudidentity.googleapis.com/v1/groups',
  user_email_id_api: 'https://content-admin.googleapis.com/admin/directory/v1/users',
};

const baseUrl = process.env.REACT_APP_BACKEND_API_BASE_URL; //api gateway
// const baseUrl = 'http://localhost:8080'
export const serviceApi = {
  getVesselDetails: `${baseUrl}/live-tracking/vessel-details`,
  getVesselDetailsCount: `${baseUrl}/live-tracking/vessel-details/count`,
  getAllDetails: `${baseUrl}/live-tracking/vessel-containers`,
  getAllDetailsCount: `${baseUrl}/live-tracking/vessel-containers/count`,
  getTransShipmentDetails: `${baseUrl}/live-tracking/container-ships`,
  getTransShipmentPoDetails: `${baseUrl}/live-tracking/container-po-details`,
  getTransShipmentPoDetailsCount: `${baseUrl}/live-tracking/container-po-details/count`,
  getVesselHistoryCoordinates: `${baseUrl}/live-tracking/vessel-history`,
  activityTrackingDetails: `${baseUrl}/activity-tracking`,
  getUploadOptions: `${baseUrl}/document-library/upload-options`,
  shipAndLoad_v2_url: `${baseUrl}/shipment-load/v2/details`,
  shipAndLoad_url: `${baseUrl}/shipment-load/details`,
  shipAndLoadCount_url: `${baseUrl}/shipment-load/details/count`,
  shipAndLoadFilter_url: `${baseUrl}/shipment-load/filter`,
  multiselectFilters: `${baseUrl}/filters`,
  promotionProcurementTable_url: `${baseUrl}/event-inventory-plan/details`,
  promotionProcurementTableCount: `${baseUrl}/event-inventory-plan/details/count`,
  promotionProcurementFilter_url: `${baseUrl}/event-inventory-plan/filters`,
  promotionProcurementDetails_url: `${baseUrl}/event-inventory-plan/milestone`,
  promotionProcurementDetailsTable_url: `${baseUrl}/event-inventory-plan/location-type-po`,
  promotionProcurementDetailsTableCount: `${baseUrl}/event-inventory-plan/location-type-po/count`,
  promotionCommitment_url: `${baseUrl}/event-inventory-plan/plan-trend`,
  documentLibraryRefineSearchVendor: `${baseUrl}/vendor-document-library/refine-search`,
  documentLibraryRefineSearchCarrier: `${baseUrl}/carrier-document-library/refine-search`,
  vendorDocumentDetails: `${baseUrl}/vendor-document-library/list-documents`,
  carrierDocumentDetails: `${baseUrl}/carrier-document-library/list-documents`,
  documentLibraryDownloadVendorFiles: `${baseUrl}/vendor-document-library/file`,
  documentLibraryDownloadCarrierFiles: `${baseUrl}/carrier-document-library/file`,
  documentLibraryVendorUploadFiles: `${baseUrl}/vendor-document-library/upload`,
  documentLibraryCarrierUploadFiles: `${baseUrl}/carrier-document-library/upload`,
  documentLibraryUpdateVendorFile: `${baseUrl}/vendor-document-library/update`,
  documentLibraryUpdateCarrierFile: `${baseUrl}/carrier-document-library/update`,
  documentLibraryVendorTotalCount: `${baseUrl}/vendor-document-library/list-documents-count`,
  documentLibraryCarrierTotalCount: `${baseUrl}/carrier-document-library/list-documents-count`,
  documentLibraryPONumSuggestion: `${baseUrl}/purchase-order/po-document-ids`,
  systemSettings_url: `${baseUrl}/system-settings`,
  getPoManagementDetails: `${baseUrl}/purchase-order/details`,
  getPoManagementDetailsCount: `${baseUrl}/purchase-order/details/count`,
  getPoManagementFilter: `${baseUrl}/purchase-order/filter`,
  poLineMangementTable_url: `${baseUrl}/purchase-order/line-items-details`,
  poLineMangementTableCount: `${baseUrl}/purchase-order/line-items-details/count`,
  poLineMangementFilter: `${baseUrl}/purchase-order/line-items-filter`,
  getItemManagementDetails: `${baseUrl}/item-management/details`,
  getItemManagementDetailsCount: `${baseUrl}/item-management/details/count`,
  getItemManagementFilter: `${baseUrl}/item-management/filter`,
  getSupplierCrmFilter: `${baseUrl}/supplier-crm/filter`,
  supplierCrmCSVUpload: `${baseUrl}/supplier-crm/upload`,
  supplierCrmBulkUpdate: `${baseUrl}/supplier-crm/bulk-update`,
  getSupplierCrmDetails: `${baseUrl}/supplier-crm/details`,
  carrierCrmBulkUpdate: `${baseUrl}/carrier-crm/bulk-update`,
  carrierCrmCSVUpload: `${baseUrl}/carrier-crm/upload`,
  getCarrierCrmDetails: `${baseUrl}/carrier-crm/details`,
  getCarrierCrmFilter: `${baseUrl}/carrier-crm/filter`,
  getInboundOptimizationFilter: `${baseUrl}/inbound-optimization/filter`,
  getInboundOptimizationTableDetails: `${baseUrl}/inbound-optimization/details`,
  getInboundOptimizationTableCount: `${baseUrl}/inbound-optimization/details/count`,
  getInboundGraph: `${baseUrl}/inbound-optimization/graph`,
  getAdminPanelUserRoles: `${baseUrl}/roles`,
  addUser: `${baseUrl}/users`,
  getUsers: `${baseUrl}/users/list-users`,
  getUsersCount: `${baseUrl}/users/list-users/count`,
  getRoles: `${baseUrl}/roles/list-roles`,
  getRolesCount: `${baseUrl}/roles/list-roles/count`,
  postRole: `${baseUrl}/roles`,
  getListScreens: `${baseUrl}/screens/list-screens`,
  saveAssignScreen: `${baseUrl}/screens/save`,
  getUserPsermissions:`${baseUrl}/user-auth/login-details`
};

//'039kk8xu4jbpycu' - MEMBER
export const userGroupRoutes = [
  {
    group_id: process.env.REACT_APP_GROUP_ID_SUPPLY_CHAINOPS,
    group_name: 'SUPPLY CHAINOPS',
    mappedRoutes: [
      routes.home,
      routes.poManagement,
      routes.lineDetails,
      routes.itemManagement,
      routes.vesselTracking,
      routes.vesselTrackingDetails,
      routes.shipLoadManagement,
      routes.shipLoadManagementMulti,
      routes.eventBuyPlanManagement,
      routes.promotionProcurementDetails,
      routes.documentLibrary,
      routes.externalization,
    ],
    defaultRoute: routes.home,
  },
  {
    group_id: process.env.REACT_APP_GROUP_ID_POWER_USER,
    group_name: 'POWER USER',
    mappedRoutes: [
      routes.home,
      routes.poManagement,
      routes.lineDetails,
      routes.itemManagement,
      routes.vesselTracking,
      routes.vesselTrackingDetails,
      routes.shipLoadManagement,
      routes.shipLoadManagementMulti,
      routes.eventBuyPlanManagement,
      routes.promotionProcurementDetails,
      routes.documentLibrary,
      routes.adminPanel,
      routes.externalization,
    ],
    defaultRoute: routes.home,
  },
  {
    group_id: process.env.REACT_APP_GROUP_ID_SUPPLIER,
    group_name: 'SUPPLIER',
    mappedRoutes: [routes.externalization],
    defaultRoute: routes.externalization,
  },
  {
    group_id: process.env.REACT_APP_GROUP_ID_CARRIER,
    group_name: 'CARRIER',
    mappedRoutes: [routes.externalization],
    defaultRoute: routes.externalization,
  },
  {
    group_id: process.env.REACT_APP_GROUP_ID_CUSTOM_OPS,
    group_name: 'CUSTOM OPS',
    mappedRoutes: [routes.documentLibrary],
    defaultRoute: routes.documentLibrary,
  },
];

export const systemSettingNames = {
  enableFixedDate: 'enable_fixed_date',
  fixedDate: 'fixed_date',
  activityVisitedDaysLimit: 'activity_visited_days_limit',
  activityFavouriteDaysLimit: 'activity_favourite_days_limit',
};

export const allowedMultiSelectFilters = {
  mode: 'mode',
  itemStatus: 'item_status',
  purchaseOrderStatus: 'purchase_order_status',
};

export const PoManagementColumn = {
  PONumber: 'poNumber',
  Maap: 'maap',
  Mabd: 'mabd',
  Idc: 'idc',
  Date: 'Date',
  vendorId: 'vendorId',
  vendorDesc: 'vendorDescription',
  businessUnit: 'businessUnit',
  status: 'status',
  eventId: 'eventId',
};

export const ItemManagementColumn = {
  buyPlanId: 'buyPlanName',
  eventId: 'eventId',
  itemDescription: 'itemDescription',
  itemNumber: 'itemNumber',
  poNumber: 'poNumber',
  upc: 'upc',
  shipmentId: 'shipmentId',
  mabd: 'mabd',
  locationType: 'locationType',
  quantity: 'quantity',
  snapShotDate: 'snapshotDate',
  itemStatus: 'itemStatus',
};

export const ExternalizationSupplierColumn = {
  supplierAvailability: 'supplierAvailability',
  shippingCapacity: 'shippingCapacity',
  committed: 'committed',
  unCommitted: 'unCommitted',
  Action: 'Action',
};

export const ExternalizationCarrierColumn = {
  loadCapacityDate: 'Load Capacity Availability by Date',
  NoOfModes: 'No. of ',
  Action: 'Action',
};

export const supplierCRMDateStaticRanges = createStaticRanges([
  {
    label: 'Tomorrow',
    range: () => ({
      startDate: startOfDay(addDays(new Date(), 1)),
      endDate: endOfDay(addDays(new Date(), 1)),
    }),
    isSelected(range) {
      const definedRange = this.range();
      return (
        isSameDay(range.startDate!, definedRange.startDate!) &&
        isSameDay(range.endDate!, definedRange.endDate!)
      );
    }
  },


  {
    label: 'Next Week',
    range: () => ({
      startDate: startOfWeek(addDays(new Date(), 7)),
      endDate: endOfWeek(addDays(new Date(), 7)),
    }),
    isSelected(range) {
      const definedRange = this.range();
      return (
        isSameDay(range.startDate!, definedRange.startDate!) &&
        isSameDay(range.endDate!, definedRange.endDate!)
      );
    }
  },
  {
    label: 'Next Month',
    range: () => ({
      startDate: startOfMonth(addMonths(new Date(), 1)),
      endDate: endOfMonth(addMonths(new Date(), 1)),
    }),
    isSelected(range) {
      const definedRange = this.range();
      return (
        isSameDay(range.startDate!, definedRange.startDate!) &&
        isSameDay(range.endDate!, definedRange.endDate!)
      );
    }
  },
  {
    label: 'Next 3 Months',
    range: () => ({
      startDate: startOfMonth(addMonths(new Date(), 1)),
      endDate: endOfMonth(addMonths(new Date(), 3)),
    }),
    isSelected(range) {
      const definedRange = this.range();
      return (
        isSameDay(range.startDate!, definedRange.startDate!) &&
        isSameDay(range.endDate!, definedRange.endDate!)
      );
    }
  },
  {
    label: 'Default',
    range: () => ({
      startDate: getGMTTimeStamp(),
      endDate: addDays(new Date(), 29),
    }),
    isSelected(range) {
      const definedRange = this.range();
      return (
        isSameDay(range.startDate!, definedRange.startDate!) &&
        isSameDay(range.endDate!, definedRange.endDate!)
      );
    }
  },
]);

export const supplierCRMCSVHeaders = ['Supplier ID', 'Ship Point ID', 'Facility Name', 'Protection Type', 'Supplier Availability By Date', 'Shipping Capacity'];
export const carrierCRMCSVHeaders = ['Carrier User ID', 'Carrier ID', 'Origin', 'Destination', 'Facility Name', 'Protection Type', 'Mode', 'Load Capacity Availability by Date',  'No. of Modes'];

export const enum inboundOptimizationFilters { dcId, facility, protection, supplier,carrier};
