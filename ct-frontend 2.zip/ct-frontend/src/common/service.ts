import axios from 'axios';
import { store } from '../redux/store' 


/**
 * Function to fetch auth details with header token
 *
 * @param {string} url
 * @param {string} [access_token]
 * @return {*} 
 */
export function axiosGetAuth(url: string, access_token?: string) {
  return axios.get(url, {
    headers: { 'Authorization': `Bearer ${access_token ?? localStorage.getItem('auth_token')}` },
    timeout: 20000
  });
}

/**
 * Function to fetch data without header token
 *
 * @param {string} url
 * @param {*} params
 * @return {*} 
 */
export function axiosGetUnAuth(url: string, params?: any,cancelToken?:any) {
  return axios.get(url, { 
  params, timeout: 20000, 
  cancelToken,
  headers : { 'Authorization': `Bearer ${store.getState().user.idToken}`, 'app-token': store.getState().user.appToken }
});

}

export function axiosPost(url: string, data: any, config?: any) {
  return axios.post(url, data, {
    ...config,
    headers : { 'Authorization': `Bearer ${store.getState().user.idToken}`, 'app-token': store.getState().user.appToken }
  });
}

export function axiosDelete(url: string, data: any) {
  return axios.delete(url, { 
    data, 
    timeout: 20000, 
    headers : { 'Authorization': `Bearer ${store.getState().user.idToken}`, 'app-token': store.getState().user.appToken }
  });
}

export function axiosPut(url:string,data:any,config?:any){
  return axios.put(url, data,{ 
    ...config,
    headers : { 'Authorization': `Bearer ${store.getState().user.idToken}`, 'app-token': store.getState().user.appToken }
  });
}

