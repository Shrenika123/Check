import leaflet from 'leaflet';

export const shipIcon = leaflet.icon({
  iconUrl: '/markers/ship.svg',
  iconAnchor: [6, 5],
  iconSize: [16, 8],
});

export const portAnchorIcon = leaflet.icon({
  iconUrl: '/markers/port.svg',
  iconAnchor: [7, 17],
  iconSize: [15, 15],
});

export const importContainerIcon = leaflet.icon({
  iconUrl: '/markers/import.svg',
  iconAnchor: [7, 17],
  iconSize: [15, 15],
});

export const sourceIcon = leaflet.icon({
  iconUrl: '/markers/port.svg',
  iconAnchor: [7, 17],
  iconSize: [15, 15],
});

export const destinationIcon = leaflet.icon({
  iconUrl: '/markers/import.svg',
  iconAnchor: [7, 17],
  iconSize: [15, 15],
});