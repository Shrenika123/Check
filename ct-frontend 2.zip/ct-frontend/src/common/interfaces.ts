import { Dispatch } from 'react';
import { Range } from 'react-date-range';

// redux interfaces
export interface IUserState {
  user: IUserPermissions;
}

export interface IMapState {
  map: {
    showVesselPathById: number;
    showSingleVessel: any;
  };
}

export interface IAlertState {
  alert: {
    showAlert: boolean;
    alertType?: string;
    alertTitle?: string;
    alertDescription?: string;
  };
}
export interface ILiveTrackingState {
  liveTracking: {
    containerId: string;
  };
}
export interface ILoadingState {
  loading: {
    isLoading: boolean;
  };
}
export interface INavbarState {
  navbar: {
    isExpanded: boolean;
  };
}

export interface IRoutePermission {
  screen:string;
  route:string|undefined;
  permission:string;
}

export interface ISystemSetting {
  name: string,
  value: string;
}

export interface ISystemSettingState {
  systemSetting: ISystemSetting[];
}

// react interfaces
export interface IUserGroupDeprecated {
  userGroupId: string;
  userGroupName: string;
  userGroupRoutes: string[];
  userDefaultRoute: string;
}

export interface IUserPermissions {
  userRole: string;
  routePermissions: IRoutePermission[];
  userDefaultRoute: string;
  userExternalId: string;
  appToken: string;
  idToken: string;
  appTokenExpiration: number;
  userId: string;
  refreshTokenId:number
}

export enum alertStates {
  ERROR = 'error',
  INFO = 'info',
  SUCCESS = 'success',
  WARN = 'warn'
}

export enum sortOrder {
  ASC = 'ASC',
  DESC = 'DESC',
}

// live tracking page - start
export interface IVessel {
  key?: string;
  fromLocationId: string;
  toLocationId: string;
  fromLocation: string;
  toLocation: string;
  fromLocationLatitude: number;
  fromLocationLongitude: number;
  toLocationLatitude: number;
  toLocationLongitude: number;
  vesselName: string;
  vesselId: string;
  tracker_geo_latitude: number;
  tracker_geo_longitude: number;
  imo: string;
  mmsi: string;
  idc_id: string;
  idc_name: string;
  idc_latitude: number;
  idc_longitude: number;
}

export interface IAllDetails {
  key?: string;
  mabd: string;
  shipmentStatus: string;
  fromLocation: string;
  toLocation: string;
  vesselId: string;
  idcDate: string;
  containerId: string;
  loadId: string;
  shipmentId: string;
  supplierName: string;
  poNumber: string;
  eta: string;
}

export interface IMapProps {
  allVessels: IVessel[] | null;
  selectedVessel: IVessel | null;
  setSelectedVessel?: Dispatch<any>;
  selectedVesselsPortsImports: string[];
  vesselHistoryCoordinates: IVesselHistoryCoordinate[] | null;
}

export interface IMapMarkersProps {
  key?: string;
  selectedVessel?: IVessel;
  handleTrackerClick: (vessel: IVessel) => void;
  vessel: IVessel;
  selectedVesselsPortsImports: string[];
  vesselHistoryCoordinates?: IVesselHistoryCoordinate[] | null;
}

export interface IVesselParams {
  fromDate: string;
  toDate: string;
  pageNumber: number;
  pageSize: number;
  searchKey?: string;
  searchValue?: string;
}

export interface IVesselCountParams {
  fromDate: string;
  toDate: string;
  searchKey?: string;
  searchValue?: string;
}

export interface IAllDetailsParams extends IVesselParams {
  vesselId: string;
}
export interface IAllDetailsCountParams extends IVesselCountParams {
  vesselId: string;
}

export interface ITransShipmentPoDetailsParams {
  pageNumber?: number;
  pageSize?: number;
  containerId: string;
  vesselId: string;
  mabd: string;
}

export interface IFilterOverlayProps {
  selectedFilter: { name: string, code: string; };
  setSelectedFilter: Function;
  inputFilterData: string;
  setInputFilterData: Function;
  setShouldFetchFilter: Function;
  setAllVesselsPageNumber: Function;
  setIsFilterApplied: Function;
  isFilterApplied: boolean;
}

export interface IVesselTrackingTableProps {
  isExpanded: boolean;
  allDetails: IAllDetails[];
  setAllDetails: Dispatch<any>;
  setAllDetailsTotalRecords: Dispatch<any>;
  range: Range[];
  vesselId: string;
  selectedTableFilter: { name: string; value: string; };
  setSelectedTableFilter: Dispatch<any>;
  shouldResetTable: boolean;
  setShouldResetTable: Dispatch<any>;
}

export interface IVesselTrackingDetailsTableProps {
  isExpanded: boolean;
  tableShipmentData: ITrackingDetailsShipmentTable[];
}

export interface ITransShipmentTrackingDetails {
  key?: string;
  createdDateTime: string;
  carrierId: string;
  carrierName: string;
  fromLocationId: string;
  fromLocation: string;
  toLocationId: string;
  toLocation: string;
  locationId: string;
  locationName: string;
  startDateTime: string;
  endDateTime: string;
  locationType: string;
  containerId: string;
  shipmentStatus: string;
  imo: string;
  mmsi: string;
  eventType: string;
  locationLatitude: string;
  locationLongitude: string;
  fromLocationLatitude: string;
  fromLocationLongitude: string;
  toLocationLatitude: string;
  toLocationLongitude: string;
  delayInDays: number;
  arrivalEventTime: null | string;
  arrivalEstimatedTime: null | string;
  departureEventTime: null | string;
  departureEstimatedTime: null | string;
  fromPort: boolean;
  toPort: boolean;
  intermediatePort: boolean;
  isShipment?: boolean;
  upcomingPort: boolean;
  mabd: string;
}

export interface ITransShipmentTracking {
  activeVesselId: string;
  vesselIds: string[];
  vesselDetailsMap: {
    [key: string]: ITransShipmentTrackingDetails[];
  };
}

export interface ITransShipmentMapProps {
  singleVesselData: ITransShipmentTrackingDetails[];
  activeVesselId: string | null;
  currentVesselTab: string | null;
  vesselHistoryCoordinates: IVesselHistoryCoordinate[] | null;
}

export interface ITransShipmentMapMarkersProps {
  data: ITransShipmentTrackingDetails[];
  activeVesselId: string | null;
  currentVesselTab: string | null;
  vesselHistoryCoordinates: IVesselHistoryCoordinate[] | null;
}

export interface IVesselDetails {
  carrierName: string;
  carrierId: string;
  imo: string;
  mmsi: string;
  latitude: number;
  longitude: number;
}

export enum TrackerState {
  DEPARTED = 'DEPARTED',
  DELAYED = 'Delayed',
  STOP = 'PORT',
  DESTINATION = 'EXPECTED ETA',
  SHIPMENT = 'SHIPMENT',
}

export interface ITrackingDetailsShipmentTable {
  key?: string;
  mabd: string;
  shipmentId: string;
  loadid: string;
  poNumber: string;
  vendorName: string;
  noOfItems: string;
  fromLocation: string;
  toLocation: string;
  shipmentStatus: string;
  eta: string;
}

export interface IVesselHistoryCoordinate {
  key?: string;
  trackerGeoLatitude: number;
  trackerGeoLongitude: number;
}

// live tracking page - end

// Home page - start
export interface IHomepageProps {
  isExpanded: boolean;
}

export interface IRecentPo {
  key?: string;
  status: string;
  ponumber: string;
  mabd: string;
}

export interface IRecentShipment {
  key?: string;
  shipmentId: string;
  transportModeType: string;
  mabd: string;
}

export interface IRecentContainer {
  key?: string;
  containerId: string;
  endDateTime: string;
  shipmentStatus: string;
  fromLocation: string;
  toLocation: string;
  fromLocationLatitude: number;
  fromLocationLongitude: number;
  toLocationLatitude: number;
  toLocationLongitude: number;
  fromLocationId: string;
  toLocationId: string;
  mabd: string;
  carrierName: string;
  carrierId: string;
  imo: string;
  mmsi: string;
  trackerGeoLatitude: number;
  trackerGeoLongitude: number;
}

export interface IRecentPoTable {
  recentPos: IRecentPo[] | null;
}

export interface IRecentShipmentTable {
  recentShipments: IRecentShipment[] | null;
}

export interface IRecentContainerTable {
  recentContainers: IRecentContainer[] | null;
  setSingleTrackingData: Dispatch<any>;
  singleTrackingData: IRecentContainer | null;
}

export interface IDashboardMapProps {
  recentContainers: IRecentContainer[] | null;
  singleTrackingData: IRecentContainer | null;
  setSingleTrackingData?: Dispatch<any>;
  dashboardVesselHistoryCoordinates: IVesselHistoryCoordinate[] | null;
}

export interface IDashboardMapMarkersProps {
  key?: string;
  handleTrackerClick: (container: IRecentContainer) => void;
  data: IRecentContainer;
  dashboardVesselHistoryCoordinates?: IVesselHistoryCoordinate[] | null;
}

export interface IFavCardProps {
  key: string;
  item: {
    eventId: string;
    buyPlanId?: string;
    buyPlanName?: string;
    eventName: string;
    targetAmount: string;
    targetDate: string;
    tagType: TagType;
    key: string;
  };
  handleFetchGraphData: Function;
}
// Home page - end

// ship and load management page - start
export interface IShipmentResponseData {
  poNumber: string;
  shipmentId: string;
  loadId: string;
  transportDocId: string;
  carrierSCAC: string;
  mode: string;
  equipmentId: number;
  equipmentDesc: string;
  cube: string;
  weight: number;
  shippingUnitCount: number;
  mabd: string;
  containerId: string;
  orderedQuantity: number;
  vendorId: string;
  idcId: string;
  locationType: string;
}

export interface IShipmentResponseDataPage {
  totalRecords: number;
  actualPageSize: number;
  responses: IShipmentResponseData[];
}

export interface IShipmentRequest {
  startDate?: string;
  endDate?: string;
  pageSize: number;
  pageNumber: number;
  sortColumn?: string;
  sortOrder?: string;
  poNumber?: string;
  shipmentId?: string;
  loadId?: string;
  transportDocId?: string;
  carrierSCAC?: string;
  mode?: string;
  containerId?: string;
}

export interface IShipmentFilterRequest {
  selectField: string,
  fromDate: string,
  toDate: string,
  transportDocId?: string[],
  mode?: string[],
  scac?: string[],
  poNumber?: string[],
  loadId?: string[],
  shipmentId?: string[],
  sortColumn: string,
  sortOrder: string;
}

export interface ISort {
  sortOrder: 'Desc' | '' | 'desc' | 'DESC';
  sortColumn: string;
}

export interface ISortAndPage extends ISort {
  pageNumber: number;
}
export interface ISortAndPagePOLine {
  sortColumn: string;
  sortingInDesc: boolean;
  pageNumber: number;
}
export interface ISortAndPagePOLine {
  sortColumn: string;
  sortingInDesc: boolean;
  pageNumber: number;
}

export interface IShipmentFilter {
  poNumber: string,
  shipmentId: string,
  loadId: string,
  transportDocumentId: string,
  scac: string,
  mode: string;
}
// ship and load management page - end

// promotion and procurement plan page - start 

export interface IPromotionProcurement {
  key?: string,
  promotionOrProcurementPlanId: string,
  promotionOrProcurementPlanName: string,
  targetDate: string,
  targetAmount: string,
  atRiskAmount: string,
}

export interface IEventBuyPlanResponse {
  tagType: 'INVENTORY_PLAN' | 'EVENT_PLAN',
  totalRecords: number,
  promotionProcurementPlanResponseList: IPromotionProcurement[],
}

export interface IPromotionProcurementRequest {
  tagType: 'INVENTORY_PLAN' | 'EVENT_PLAN',
  pageSize?: number,
  pageNumber?: number,
  sortColumnName?: string,
  sortOrder?: 'DESC' | '';
  startDate?: string,
  endDate?: string,
  tagIds: string,
}

export interface IPromotionProcurementFilterRequest {
  tagType: 'INVENTORY_PLAN' | 'EVENT_PLAN',
  eventOrBuyPlanList: string;
}


export interface IProcurementMilestoneParams {
  tagId: string;
  tagType: string;
  targetDate: string;
}

export interface IProcurementMilestoneResponse {
  data: IProcurementMilestoneResponseElement[];
}
export interface IProcurementMilestoneResponseElement {
  name: string;
  value: number;
  maxQuantity: number;
}

export type ActivityTypes = 'FAVOURITE' | 'VISITED';

export type ActivityComponentTypes = 'PURCHASE_ORDER' | 'SHIPMENT' | 'CONTAINER' | 'EVENT_PLAN' | 'INVENTORY_PLAN';


export enum TagType {
  PROMOTION_PLAN = 'EVENT_PLAN',
  PROCUREMENT_PLAN = 'INVENTORY_PLAN'
}

export interface IPromotionProcurementPORequest {
  tagType: TagType;
  tagId: string;
  locationType: string;
  sortColumn?: string;
  sortOrder?: "desc" | "" | 'DESC' | 'Desc';
  pageSize?: number;
  pageNumber?: number;
  targetDate: string;
}

export interface IPromotionProcurementPOResponse {
  poNumber: string;
  mabd: string;
  targetDate: string;
  targetAmount: string;
  supplyChainSegment: string;
  quantity: string;
  department: string;
}

export interface IPromotionProcurementPOPageResponse {
  totalRecords: number;
  data: IPromotionProcurementPOResponse[];
}
//promotion and procurement pla ends

// doc lib upload modal - start
export interface IFileType {
  name: string;
  keyword: string;
  code: string;
}

export type ColumnType = 'DOCUMENT_TYPE' | 'PO_NUMBER';

export interface IUploadModalProps {
  open: boolean;
  setOpen: Dispatch<any>;
  handleClose: Function;
  realodTable: Function;
}

export interface IUploadCommentData {
  time: string;
  message: string;
  userId: string | null;
  userName: string | null;
}

export interface IUploadFormData {
  documentComponent: string;
  documentType: string;
  poNumber: string;
  documentId: string;
  userId?: string | null;
  userName?: string | null;
  comments?: IUploadCommentData[];
  vendorId?: string;
  vendorName?: string;
  carrierId?: string;
  carrierName?: string;
}

export interface IUpdateFileFormData {
  id: string;
  modifyUserId?: string;
  modifyUserName?: string;
  comments?: IUploadCommentData[];
}

export interface IModalView1Props {
  uploadFormData: IUploadFormData;
  setUploadFormData: Function;
  setDocumentTitles: Function;
  setPoNumbers: Function;
  setPoDocIds: Function;
  poDocIds: IDocumentLibraryPos;
  poNumbers: any[] | undefined;
  documentTitles: string[] | [];
  isPoNumSelected: boolean;
  setPoNumSelected: Function;
}
// doc lib upload modal - end

//document library start

export interface IDocumentLibraryTableRow {
  documentId: string;
  poNumber: string;
  documentComponent: string;
  documentType: string;
  createdUserId: string;
  createdUserName: string;
  createdDate: string;
  lastModifiedUserId: string;
  lastModifiedUserName: string;
  lastModifiedDate: string;
  sequence: string;
  canEdit: boolean;
  id: string;
  comments: IUploadCommentData[];
}

export interface IDocumentLibraryTablePage {
  data: IDocumentLibraryTableRow[];
  totalRecords?: number;
}

export type DocumentTabs = 'LOAD' | 'PORT' | 'CONTAINER' | 'NONE';

export type allowedFileType = 'pdf' | 'doc' | 'docx';

//export type UserRole  = 'SUPPLY CHAINOPS' | 'POWER USER' |'CUSTOMS USER'

export interface IDocumentLibraryTableRequest {
  documentComponent: DocumentTabs;
  currentUserRole: string;
  selectedUserIds?: string;
  selectedDocumentTypes?: string;
  pageNo: number;
  pageSize: number;
  documentIdPattern?: string;
}
export interface IDocumentLibraryTotalCountRequest {
  documentComponent: DocumentTabs;
  selectedUserIds?: string;
  selectedDocumentTypes?: string;
  documentIdPattern?: string;
}

export interface IDocumentLibraryFilterResponse {
  createdUsers: { userId: string; userName: string }[];
  documentTypes: string[];
}

export interface IIPromotionCommitmentEntityPlan {
  planName: string;
  planTotalTargetAmount: string;
}
export interface IPromotionCommitmentEntity {
  monthName: string;
  totalTargetAmount: string;
  plans: IIPromotionCommitmentEntityPlan[];
  key?: string;
}
export interface IPromotionCommitmentResponse {
  data: IPromotionCommitmentEntity[];
}

export interface IFavouriteActivityTrackerEntity {
  eventId: string;
  buyPlanId?: string;
  buyPlanName?: string;
  eventName: string;
  targetAmount: string;
  targetDate: string;
}
export interface IFavouriteActivityTracker {
  data: IFavouriteActivityTrackerEntity[];
}

export interface IPoManagementTableResponse {
  poNumber: string;
  mabd: string;
  maap: string;
  idcdate: string;
  vendorId: string;
  vendorDescription: string;
  businessUnit: string;
  status: string;
  eventId: string;
}

export interface IPoManagementRequest {
  startDate?: string;
  endDate?: string;
  pageSize: number;
  pageNumber: number;
  sortColumn?: string;
  sortOrder?: string;
  businessUnit?: string;
  eventId?: string;
  poNumber?: string;
  status?: string;
  vendorId?: string;
  vendorDescription?: string;
}

export interface IPoManagementResponseDataPage {
  totalRecords: number;
  actualPageSize: number;
  responses: IPoManagementTableResponse[];
}

export interface IPoManagementFilterRequest {
  selectField: string;
  startDate: string;
  endDate: string;
  status?: string[];
  vendorId?: string[];
  businessUnit?: string[];
  vendorDescription?: string[];
  poNumber?: string[];
  eventId?: string[];
}

//PO Line Management

export interface IPOLineTableRequest {
  poNumber: string;
  mabd: string;
  itemNumber: string;
  shipmentId: string;
  sortColumn?: string;
  sortingInDesc?: boolean;
  pageNumber?: number;
  pageSize?: number;
  itemDescription?: string;
}

export interface IPOLineTableRow {
  poNumber: string;
  mabd: string;
  maap: string;
  itemNumber: string;
  lineNumber: string;
  department: string;
  itemDescription: string;
  orderedQuantity: string;
  shippedQuantity: string;
  pendingQuantity: string;
  shipmentId: string;
  itemStatus: string;
}

export interface IPOLineFilterRequest {
  poNumber: string;
  mabd: string;
  selectField: 'shipmentId' | 'itemNumber' | 'itemDescription';
  itemNumber?: string;
  itemDescription?: string;
  shipmentId?: string;
}

//Item Management

export interface IItemManagementResponse {
  buyPlanId: string;
  eventId: string;
  eventName: string;
  buyPlanName: string;
  targetDate: string;
  itemDescription: string;
  itemNumber: string;
  itemStatus: string;
  locationType: string;
  poNumber: string;
  quantity: string;
  shipmentId: string;
  snapshotDate: string;
  upc: string;
  mabd: string;
}

export interface IItemManagementRequest {
  pageNumber: number;
  pageSize: number;
  endDate: string;
  startDate: string;
  sortColumn: string;
  sortOrder: string;
  buyPlanName: string;
  eventId: string;
  itemNumber: string;
  itemStatus: string;
  poNumber: string;
  upc: string;
  shipmentId: string;
}

export interface IItemManagementFilterRequest {
  selectField: string;
  startDate: string;
  endDate: string;
  buyPlanName?: string[];
  eventId?: string[];
  shipmentId?: string[];
  itemNumber?: string[];
  itemStatus?: string[];
  poNumber?: string[];
  upc?: string[];
}

export interface ITableData {
  label: string;
  value: string;
}
export interface ISupplierCrmEntity {
  key?: string;
  capacityDate: string;
  commitedCount: number | null;
  uncommitedCount: number | null;
  supplierCapacity: number | string;
  lastModifiedDatetime: string;
}
export interface ISupplierCrmAllDetails {
  [key: string]: {
    [key: string]: string[];
  };
}

export interface ISupplierCrmCommonParam {
  pageSize: number;
  sortColumn: string;
  sortOrderDesc: boolean;
  vendorId: string;
  shipPointId: string;
  protectionType: string;
  facility: string;
}

export interface ISupplierCrmDetailsParam extends ISupplierCrmCommonParam {
  startDate: string;
  endDate: string;
  pageNumber: number;
}

export interface IPostSupplierCrmDetails {
  vendorId: string;
  facility: string;
  shipPointId: string;
  protectionType: string;
  capacityDate: string;
  committedCount: number;
  uncommittedCount: number;
  supplierCapacity: number;
  lastModifiedDatetime: string;
}

export interface ISupplierCrmFilter {
  vendorId?: string;
  shipPointId?: string;
  protectionType?: string;
  facility?: string;
  selectField?: string;
}

export interface ICarrierCrmEntity {
  key?: string;
  capacityDate: string;
  count: number | string;
  lastModifiedDateTime: string;
}

export interface ICarrierCrmParam {
  selectField: string;
  carrierUserId?: string;
  carrierId?: string;
  origin?: string;
  destination?: string;
  facility?: string;
  protectionType?: string;
  mode?: string;
}

export interface ICarrierCrmAllDetails {
  [key: string]: {
    [key: string]: {
      [key: string]: {
        [key: string]: string[];
      };
    };
  };
}

export interface ICarrierCrmCommonParam {
  pageSize: number;
  sortColumn: string;
  sortOrderDesc: boolean;
  carrierUserId: string;
  carrierId: string;
  origin: string;
  destination: string;
  facility: string;
  protectionType: string;
  mode: string;
}

export interface ICarrierCrmDetailsParam extends ICarrierCrmCommonParam {
  startDate: string;
  endDate: string;
  pageNumber: number;
}

export interface IPostCarrierCrmDetails {
  carrierId: string;
  origin: string;
  destination: string;
  facility: string;
  protectionType: string;
  mode: string;
  capacityDate: string;
  count: number;
  lastModifiedDatetime: string;
  carrierUserId: string;
}

export interface IInboundGraphAPI {
  capacityDate: string;
  assignedLoads: number | string;
  unAssignedLoads: number | string;
  pendingLoads: number | string;
  carrierCapacity: number | string | null;
  supplierCapacity: number | string | null;
  hasWarning?: boolean;
}

export interface IInboundOptimizationCommonParams {
  startDate: string;
  endDate: string;
  supplierId?: string;
  carrierId?: string;
  facility?: string;
  protectionType?: string;
  shipPointId?: string;
  dcId?: string;
}

export interface IInboundOptimizationFilterParams
  extends IInboundOptimizationCommonParams {
  selectField:
    | 'shipPointId'
    | 'facility'
    | 'protectionType'
    | 'supplierId'
    | 'carrierId';
}

export interface IInboundOptimizationTableParams
  extends IInboundOptimizationCommonParams {
  loadType?: string;
  pageNumber?: number;
  pageSize?: number;
  poNumberSearch?: string;
  shipmentIdSearch?: string;
  loadIdSearch?: string;
  selectField?: 'poNumber' | 'shipmentId' | 'loadId' | 'all';
}

export interface IGraphClickEvent {
  capacityDate: string;
  loadType: string;
}

export interface IInboundOptimizationTable {
  poNumber: string;
  origin: string;
  destination: string;
  shipmentId: string;
  loadId: string;
  plannedPickupDate: string;
  scheduledDelivery: string;
  laneId: string;
  schedulerAppointmentDate: string;
  mabd: string;
  carrierId: string;
  key?: string;
}

export interface ISelectElement {
  key: string;
  value: string;
}

export interface IAdminPanelUserRolesParams {
  includeScreenPermissions: boolean;
  includeUniqueScreen: boolean;
  pageNumber: number;
  pageSize: number;
  sortColumn?: string;
  sortOrder?: string;
}

export interface IUserDetails {
  emailId: string;
  role: string;
  externalId: string;
  key?: string;
}

export interface IUserDetailsParam {
  selectField: string;
  emailId?: string;
  externalId?: string;
  pageNumber: number;
  pageSize: number;
  sortColumn?: string;
  sortOrder?: string;
}

export interface IUserDetailsCountParam {
  selectField: string;
  emailId?: string;
  externalId?: string;
}

export interface IRoleAccessEntity {
  role: string;
  permission: string;
  isExternalRole: boolean;
  action?: string;
}

export interface IScreenAccessEntity {
  screen: string;
  permission: string;
}
export interface IScreenToRolePermissionEntity {
  screen: string;
  roles: IRoleAccessEntity[];
}

export interface IRoleToScreenPermissionEntity {
  role: string;
  screens: IScreenAccessEntity[];
}

export interface IRoleScreenTableResponse {
  screens?: string[];
  roles?: string[];
  screensRolesPermissionMappings?: IRoleToScreenPermissionEntity[];
}

export interface IScreenRoleEntity {
  role: string;
  isExternalRole: boolean;
}

export interface IScreenAssignResponse {
  screens?: string[];
  roles?: IScreenRoleEntity[];
  screensRolesPermissionMappings?: IScreenToRolePermissionEntity[];
}

export enum addRoleType {
  ADD_ROLE = 'ADD_ROLE',
  MODIFY = 'MODIFY',
  ADD_SCREEN = 'ADD_SCREEN',
  NONE = 'NONE',
}

export interface ICommonSortParams {
  sortColumn?: string;
  sortOrder?: string;
}
export interface IListRolesParams extends ICommonSortParams {
  includeScreenPermissions: boolean;
  includeUniqueScreen: boolean;
  pageNumber: number;
  pageSize: number;
}

export interface IListScreensParams extends ICommonSortParams {
  includeRolePermissions: boolean;
  includeUniqueRoles: boolean;
}

export interface ISaveTableEntityRequest {
  role: string;
  screen: string;
  permission: string;
}

export interface ISaveAssignScreenParams extends IRoleAccessEntity {
  screen: string;
}

export interface IAddRole extends ISaveTableEntityRequest {
  isExternalRole: boolean;
}

export interface IDocumentLibraryPoEntity {
  id: string;
  name: string;
}

export interface IDocumentLibraryPos {
  [key: string]: IDocumentLibraryPoEntity;
}


export interface IRoleEntity {
  role: string;
  is_external_user: boolean;
}