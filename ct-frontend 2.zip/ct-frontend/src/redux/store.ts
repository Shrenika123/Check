import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { persistReducer, persistStore } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import thunk from 'redux-thunk';
import alertReducer from './reducers/alert.reducer';
import liveTrackingReducer from './reducers/liveTracking.reducer';
import loadingReducer from './reducers/loading.reducer';
import navbarReducer from './reducers/navbar.reducer';
import systemSettingReducer from './reducers/systemSetting.reducer';
import userPermissionReducer from './reducers/userPermissions.reducer';

const persistConfig = {
  timeout: 5000,
  key: 'settings',
  storage,
  whitelist: ['systemSetting']
};



const rootReducer = combineReducers({
  user: userPermissionReducer,
  loading: loadingReducer,
  alert: alertReducer,
  navbar: navbarReducer,
  liveTracking: liveTrackingReducer,
  systemSetting: systemSettingReducer

});

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,
  middleware: [thunk]
});

export const persistor = persistStore(store);