import { createSlice } from '@reduxjs/toolkit';
import { IUserPermissions } from '../../common/interfaces';

const userSlice = createSlice({
  name: 'user',
  initialState: {
    userRole: '',
    routePermissions: [],
    userDefaultRoute: '',
    userExternalId: '',
    appToken: '',
    idToken: '',
    appTokenExpiration: 0,
    userId: '',
    refreshTokenId: 0
  },
  reducers: {
    setUserRolePermissions: (state: IUserPermissions, action) => {
      state.userRole = action.payload.user_role;
      state.routePermissions = [...action.payload.user_routes];
      state.userDefaultRoute = action.payload.default_route;
      state.userExternalId = action.payload.external_id;
      state.appToken = action.payload.app_token;
      state.idToken = action.payload.id_token;
      state.appTokenExpiration = action.payload.expiration;
      state.userId = action.payload.user_id;
      state.refreshTokenId = action.payload.refresh_token_id;
    },
  }
});

// this is for dispatch()
export const { setUserRolePermissions } = userSlice.actions;

// this is for configureStore()
export default userSlice.reducer;