import { createSlice } from '@reduxjs/toolkit';

const loadingSlice = createSlice({
  name: 'loading',
  initialState: {
    isLoading: false
  },
  reducers: {
    setLoading: (state, action) => {
      state.isLoading = action.payload;
    },
  }
});

// this is for dispatch()
export const { setLoading } = loadingSlice.actions;

// this is for configureStore()
export default loadingSlice.reducer;