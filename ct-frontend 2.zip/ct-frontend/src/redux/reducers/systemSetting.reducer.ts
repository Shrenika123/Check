import { createSlice } from '@reduxjs/toolkit';
import { ISystemSetting } from '../../common/interfaces';

const systemSettingSlice = createSlice({
  name: 'systemSetting',
  initialState: [],

  reducers: {
    setSystemSetting: (state: ISystemSetting[], action) => {
      state.length = 0;
      state.push(...action.payload);
    }
  }
});

export const { setSystemSetting } = systemSettingSlice.actions;

export default systemSettingSlice.reducer;