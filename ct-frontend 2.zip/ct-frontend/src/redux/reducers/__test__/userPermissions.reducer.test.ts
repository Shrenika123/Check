import { cleanup } from '@testing-library/react';
import reducer, { setUserRolePermissions } from '../userPermissions.reducer';

afterEach(cleanup);

describe('User reducer', () => {
  test('should render reducer', () => {
    const previousState = {
    userRole: '',
    routePermissions: [],
    userDefaultRoute: '',
    userExternalId: '',
    appToken: '',
    idToken: '',
    appTokenExpiration: 0,
    userId: '',
    refreshTokenId: 0
    };

    expect(reducer(previousState, setUserRolePermissions({
      user_role: 'role',
      user_routes: [],
      default_route:'/path',
      external_id:'',
      app_token:'appToken',
      id_token:'idToken',
      expiration:0,
      user_id:'1',
      refresh_token_id:0
    }))).toEqual({
      userRole: 'role',
      routePermissions: [],
      userDefaultRoute:'/path',
      userExternalId:'',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:0,
      userId:'1',
      refreshTokenId:0
    });
  });
});