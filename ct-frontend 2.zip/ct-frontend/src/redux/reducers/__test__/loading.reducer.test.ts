import { cleanup } from '@testing-library/react';
import reducer, { setLoading } from '../loading.reducer';

afterEach(cleanup);

describe('Loading reducer', () => {
  test('should render reducer', () => {
    const previousState = {
      isLoading: false,
    };

    expect(reducer(previousState, setLoading(true))).toEqual({
      isLoading: true,
    });
  });
});