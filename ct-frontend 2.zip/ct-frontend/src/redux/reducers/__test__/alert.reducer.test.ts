import { cleanup } from '@testing-library/react';
import reducer, { setShowAlert } from '../../../redux/reducers/alert.reducer';

afterEach(cleanup);

describe('Alert reducer', () => {
  test('should render reducer', () => {
    const previousState = {
      showAlert: false,
      alertType: '',
      alertTitle: '',
      alertDescription: ''
    };

    expect(reducer(previousState, setShowAlert({
      showAlert: true, alertType: '',
      alertTitle: '',
      alertDescription: ''
    }))).toEqual({
      showAlert: true,
      alertType: '',
      alertTitle: '',
      alertDescription: ''
    });
  });
});