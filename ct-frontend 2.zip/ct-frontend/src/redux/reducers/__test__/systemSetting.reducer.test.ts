import { cleanup } from '@testing-library/react';
import reducer, { setSystemSetting } from '../systemSetting.reducer';

afterEach(cleanup);

describe('User reducer', () => {
  test('should render reducer', () => {
    const previousState: never[] | undefined = [];

    expect(reducer(previousState, setSystemSetting(
      [{ name: 'abc', value: 'abc' }]
    ))).toEqual([{ name: 'abc', value: 'abc' }]);
  });
});