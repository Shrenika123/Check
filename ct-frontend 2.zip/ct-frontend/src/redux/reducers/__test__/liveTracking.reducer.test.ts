import { cleanup } from '@testing-library/react';
import reducer, { setContainerId } from '../liveTracking.reducer';

afterEach(cleanup);

describe('Live Tracking reducer', () => {
  test('should render reducer', () => {
    const previousState = {
      containerId: '',
    };

    expect(reducer(previousState, setContainerId('CNT1234'))).toEqual({
      containerId: 'CNT1234',
    });
  });
});