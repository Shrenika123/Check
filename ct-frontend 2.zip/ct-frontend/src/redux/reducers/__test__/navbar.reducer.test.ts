import { cleanup } from '@testing-library/react';
import reducer, { setExpanded } from '../navbar.reducer';

afterEach(cleanup);

describe('Navbar reducer', () => {
  test('should render reducer', () => {
    const previousState = {
      isExpanded: false,
    };

    expect(reducer(previousState, setExpanded(true))).toEqual({
      isExpanded: true,
    });
  });
});