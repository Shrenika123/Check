import { createSlice } from '@reduxjs/toolkit';

const liveTracking = createSlice({
  name: 'liveTracking',
  initialState: {
    containerId: '',
  },
  reducers: {
    setContainerId: (state, action) => {
      state.containerId = action.payload;
    },
  }
});

// this is for dispatch()
export const { setContainerId } = liveTracking.actions;

// this is for configureStore()
export default liveTracking.reducer;