import { createSlice } from '@reduxjs/toolkit';

const alertSlice = createSlice({
  name: 'alert',
  initialState: {
    showAlert: false,
    alertType: '',
    alertTitle: '',
    alertDescription: ''
  },
  reducers: {
    setShowAlert: (state, action) => {
      state.showAlert = action.payload.showAlert;
      state.alertType = action.payload.alertType;
      state.alertTitle = action.payload.alertTitle;
      state.alertDescription = action.payload.alertDescription;
    },
  }
});

// this is for dispatch()
export const { setShowAlert } = alertSlice.actions;

// this is for configureStore()
export default alertSlice.reducer;