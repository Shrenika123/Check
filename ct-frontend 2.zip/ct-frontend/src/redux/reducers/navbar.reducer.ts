import { createSlice } from '@reduxjs/toolkit';

const navbarSlice = createSlice({
  name: 'navbar',
  initialState: {
    isExpanded: false
  },
  reducers: {
    setExpanded: (state, action) => {
      state.isExpanded = action.payload;
    },
  }
});

// this is for dispatch()
export const { setExpanded } = navbarSlice.actions;

// this is for configureStore()
export default navbarSlice.reducer;