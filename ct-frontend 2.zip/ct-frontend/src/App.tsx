import { FC, ReactElement } from 'react';
import { RouterProvider } from 'react-router-dom';
import './App.css';
import Alert from './components/alert/Alert.component';
import Loading from './components/loading/Loading.component';
import router from './router';
import { Slide, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import useAxiosInterceptor from './hooks/useAxiosInterceptor';

const App: FC = (): ReactElement => {

  useAxiosInterceptor();

  return (
    <>
      <ToastContainer position='top-right' 
        autoClose={3000} 
        hideProgressBar={true} 
        transition={Slide} 
        theme='colored'
        limit={3}
        pauseOnFocusLoss={false}
      />
      <Alert />
      <Loading />
      <RouterProvider router={router} />
    </>
  );
};

export default App;
