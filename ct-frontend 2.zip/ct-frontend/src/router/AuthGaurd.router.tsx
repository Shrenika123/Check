import { FC, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { getSystemSetting, getUserPermissions, isStringValid } from '../common/utils';
import { setShowAlert } from '../redux/reducers/alert.reducer';
import { setLoading } from '../redux/reducers/loading.reducer';
import { setSystemSetting } from '../redux/reducers/systemSetting.reducer';
import { setUserRolePermissions } from '../redux/reducers/userPermissions.reducer';
import { IUserState } from '../common/interfaces';
import { calculateDefaultRoute, getPermissionsFromResponse } from '../common/navigation-utils';

const AuthGuard: FC = () => {
  const userGroupRoutes = useSelector((state: IUserState) => state.user);

  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();

  let refreshTokenId: any;

  const refreshToken = () => {
    getUserPermissions(localStorage.getItem('auth_token')!).then((userInfoResponse: any) => {
      const appToken = userInfoResponse.headers.get('app-token')?.toString()!;
      const idToken = userInfoResponse.headers.get('id-token')?.toString()!;
      const expirationTime = userInfoResponse.headers.get('app-token-expiration')?.toString()!;

      const userPermList = getPermissionsFromResponse(userInfoResponse.data.data.permissions)
      const defaultRouteVar = calculateDefaultRoute(userPermList)

      dispatch(setUserRolePermissions({
        user_role: userInfoResponse.data.data.role,
        user_routes: userPermList,
        default_route: defaultRouteVar,
        external_id: userInfoResponse.data.data.externalId,
        app_token: appToken,
        id_token: idToken,
        expiration: expirationTime,
        user_id: userInfoResponse.data.data.userId,
        refresh_token_id: refreshTokenId
      }));

    }).catch((err) => {
      clearInterval(refreshTokenId);
      dispatch(setShowAlert({
        showAlert: true,
        alertType: 'error',
        alertTitle: 'User session expired, Please login again',
        alertDescription: ''
      }));   
      navigate('/logout');
    })
  }

  useEffect(() => {
    (async function () {
     
      if (localStorage.getItem('auth_token') !== null) {
        console.log('1')
        if (userGroupRoutes.userRole === '') {
          console.log('2')
          dispatch(setLoading(true));
          getUserPermissions(localStorage.getItem('auth_token')!).then((userInfoResponse: any) => {
            console.log('3')

            const appToken = userInfoResponse.headers.get('app-token')?.toString()!;
            const idToken = userInfoResponse.headers.get('id-token')?.toString()!;
            const expirationTime: number = userInfoResponse.headers.get('app-token-expiration')!;
            localStorage.setItem('tokenExpiration', expirationTime.toString()!)


            const userPermList = getPermissionsFromResponse(userInfoResponse.data.data.permissions)
            const defaultRouteVar = calculateDefaultRoute(userPermList)

            refreshTokenId = setInterval(()=>{
              refreshToken();
            },expirationTime)

            dispatch(setUserRolePermissions({
              user_role: userInfoResponse.data.data.role,
              user_routes: userPermList,
              default_route: defaultRouteVar,
              external_id: userInfoResponse.data.data.externalId,
              app_token: appToken,
              id_token: idToken,
              expiration: expirationTime,
              user_id: userInfoResponse.data.data.userId,
              refresh_token_id: refreshTokenId
            }));

            if (!localStorage.getItem('persist:settings') || localStorage.getItem('persist:settings') === null || JSON.parse(localStorage.getItem('persist:settings')!).systemSetting.length <= 2) {
              console.log(4)
              dispatch(setLoading(true));
              getSystemSetting().then((res) => {

                dispatch(setSystemSetting(res.data.data));
                if (userPermList.some(routePer => (routePer.route === location.pathname.substring(1) && isStringValid(routePer.permission) && routePer.permission !== 'NA'))) {
                  console.log(5)
                  navigate(location.pathname + location.search, { state: location.state });
                }
                else
                  console.log(6)
                navigate(`/${defaultRouteVar}`);
              }).catch((res) => {
                clearInterval(refreshTokenId)
                dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to fetch system settings', alertDescription: '' }));
                navigate('/logout')
              }).finally(() => {
                dispatch(setLoading(false));
              })
            }
            else {
              console.log(7)
              if (userPermList.some(routePer => (routePer.route === location.pathname.substring(1) && isStringValid(routePer.permission) && routePer.permission !== 'NA'))) {
                console.log(8)
                navigate(location.pathname + location.search, { state: location.state });
              }
              else
                console.log(9)
              navigate(`/${defaultRouteVar}`);
            }
          }).catch((err) => {
            clearInterval(refreshTokenId)
            dispatch(setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: err && err.response && err.response.data && err.response.data.errorMessage ? err.response.data.errorMessage : 'Login failed',
              alertDescription: ''
            }));
            dispatch(setLoading(false));
            navigate('/logout');
          }).finally(() => {
            if (!(!localStorage.getItem('persist:settings') || localStorage.getItem('persist:settings') === null || JSON.parse(localStorage.getItem('persist:settings')!).systemSetting.length <= 2)) {
              dispatch(setLoading(false));
            }
          })
        }
        else {
          console.log(10)
          if (userGroupRoutes.routePermissions.some(routePer => (routePer.route === location.pathname.substring(1) && isStringValid(routePer.permission) && routePer.permission !== 'NA'))) {
            console.log(11)
            navigate(location.pathname + location.search, { state: location.state });
          }
          else
            console.log(12)
          navigate(`/${userGroupRoutes.userDefaultRoute}`);
        }
      }
      else {
        console.log(13)
        navigate('/logout');
      }

      return clearInterval(refreshTokenId)
    })()
  }, [])

  return (
    <Outlet></Outlet>
  );
};

export default AuthGuard;