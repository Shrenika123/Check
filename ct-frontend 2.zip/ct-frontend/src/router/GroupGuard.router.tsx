import { FC, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { userGroupRoutes } from '../common/constants';
import { IRoutePermission, IUserState } from '../common/interfaces';
import { isStringValid } from '../common/utils';

const GroupGuard: FC = () => {

  const location = useLocation();
  const navigate = useNavigate();
  const userGroupRoutes = useSelector((state: IUserState) => state.user);

  useEffect(() => {
    // check if the user has access to that route. if false then navigate to default route
    console.log(13)
    if (userGroupRoutes.routePermissions.length > 0 && userGroupRoutes.routePermissions.some(routeVar => (routeVar.route === location.pathname.substring(1) && isStringValid(routeVar.permission) && routeVar.permission !=='NA' ))) {
      console.log(14)
      navigate(location.pathname + location.search, { state: location.state } );
    }
    else{
      console.log(15)
      navigate(`/${userGroupRoutes.userDefaultRoute}`);
    }
  }, [location.pathname]);

  return (
    // if user exists in one of the group and mappedRoutes matches then allow to access the child routes
    <Outlet />
  );
};

export default GroupGuard;