import { createBrowserRouter, Navigate } from "react-router-dom";
import { routes } from "../common/constants";
import Login from '../pages/login/Login.page';
import Logout from '../pages/logout/Logout.page';
import MainContainer from "../pages/main-container/MainContainer";
import AuthGuard from './AuthGaurd.router';
import GroupGuard from './GroupGuard.router';


const router = createBrowserRouter(
  [
    {
      path: routes.root,
      element: <AuthGuard />,
      errorElement: <Navigate to={routes.logout} />,
      children: [
        {
          element: <GroupGuard />,
          children: [
            {
              path: routes.home,
              element: <MainContainer route={routes.home} />,
            },
            {
              path: routes.poManagement,
              element: <MainContainer route={routes.poManagement} />,
            },
            {
              path: routes.lineDetails,
              element: <MainContainer route={routes.lineDetails} />,
            },
            {
              path: routes.itemManagement,
              element: <MainContainer route={routes.itemManagement} />
            },
            {
              path: routes.shipLoadManagement,
              element: <MainContainer route={routes.shipLoadManagement} />
            },
            {
              path: routes.vesselTracking,
              element: <MainContainer route={routes.vesselTracking} />
            },
            {
              path: routes.vesselTrackingDetails,
              element: <MainContainer route={routes.vesselTrackingDetails} />
            },
            {
              path: routes.shipLoadManagement,
              element: <MainContainer route={routes.shipLoadManagement} />,
            },
            {
              path: routes.eventBuyPlanManagement,
              element: <MainContainer route={routes.eventBuyPlanManagement} />
            },
            {
              path: routes.promotionProcurementDetails,
              element: <MainContainer route={routes.promotionProcurementDetails} />
            },
            {
              path: routes.documentLibrary,
              element: <MainContainer route={routes.documentLibrary} />
            },
            {
              path: routes.adminPanel,
              element: <MainContainer route={routes.adminPanel} />,
            },
            {
              path: routes.externalization,
              element: <MainContainer route={routes.externalization} />,
            },
          ]
        }
      ]
    },
    {
      path: routes.login,
      element: <Login />
    },
    {
      path: routes.logout,
      element: <Logout />
    },
    // {
    //   path: '*',
    //   element: <Navigate to={routes.home} />
    // }
  ]
);
export default router;