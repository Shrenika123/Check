import { useGoogleLogin } from '@react-oauth/google';
import { FC, ReactElement } from "react";
import { useDispatch } from 'react-redux';
import { useNavigate } from "react-router-dom";
import backImg from '../../assets/images/background.png';
import { google, labels } from '../../common/constants';
import { getUserInfo } from '../../common/utils';
import { setLoading } from '../../redux/reducers/loading.reducer';
import './Login.style.css';

const Login: FC = (): ReactElement => {

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleGoogleLogin = useGoogleLogin({
    scope: google.scope,
    onSuccess: async (response) => {
      dispatch(setLoading(true));
      localStorage.setItem('auth_token', response.access_token);
      const userInfoResponse: any = await getUserInfo(response.access_token);
      dispatch(setLoading(false));
      if (userInfoResponse.status === 200) {
        localStorage.setItem('user_name', userInfoResponse.data.name);
        localStorage.setItem('user_email', userInfoResponse.data.email);
        
        navigate(`/home`);
      } else {
        navigate('/logout');
      }
    },
    onError: (response) => {
      console.log('login error', response);
    }
  });

  return (
    <section className='login-container'>
      <img className="img" src={backImg} alt="" />
      <div className="signin-div">
        <div className="signin-button-div">
          <div className="app-logo">
            <div className="logo-1">{labels.appTitle}</div>

          </div>
          <div className="signin-button">
            <button data-testid='login-btn' id='button' className="sign-in-btn" onClick={() => handleGoogleLogin()}>{labels.signInButtonText}</button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;