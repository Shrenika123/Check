import Tooltip from '@mui/material/Tooltip';
import { ReactElement } from 'react';
import Dropzone from 'react-dropzone';
import { useDispatch } from 'react-redux';
import UploadIcon from '../../../../../../assets/icons/Upload-Cloud.svg';
import { allowedFileType } from '../../../../../../common/constants';
import { formatFileSize } from '../../../../../../common/utils';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';

interface Props {
  selectedFiles: File[];
  setSelectedFiles: Function;
  comment: string;
  setComment: Function;
  multiple: boolean;
  progress: number;
  isUploading: boolean;
}

export default function ModalView2(props: Props): ReactElement {

  const dispatch = useDispatch();

  const addToSelectedFiles = (filesToSelect: File[]) => {
    if (filesToSelect.length > 5) {
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Maximum 5 files are allowed to upload together', alertDescription: "You are trying to add more than 5 files" }));
      return;
    }
    if (props.selectedFiles.length >= 5) {
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Maximum 5 files are allowed to upload together', alertDescription: 'You have already selected 5 files, Please remove from them to add other files' }));
      return;
    }
    if ((props.selectedFiles.length + filesToSelect.length )> 5) {
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Maximum 5 files are allowed to upload together', alertDescription: `You can only add ${5-props.selectedFiles.length} more files` }));
      return;
    }
    const filesVar: File[] = [];
    const rejectedFilesOnSize: string[] = [];
    const rejectedFilesOnType: string[] = [];
    const alreadyAddedFiles: string[] = [];
    filesToSelect.forEach(fileToInclude => {

      props.selectedFiles.forEach((fileAdded: File) => {
        fileAdded.name === fileToInclude.name && alreadyAddedFiles.push(fileToInclude.name);
        return;
      });

      const fileType = fileToInclude.name.split('.').pop()?.trim();
      if (!fileType || !allowedFileType.includes(fileType?.toLowerCase())) {
        rejectedFilesOnType.push(fileToInclude.name);
        return;
      }

      if (fileToInclude.size > 5000000) {
        rejectedFilesOnSize.push(fileToInclude.name);
        return;
      }
      if (!props.selectedFiles.map((file: File) => file.name).includes(fileToInclude.name))
        filesVar.push(fileToInclude);
    });
    if (props.multiple)
      props.setSelectedFiles([...props.selectedFiles, ...filesVar]);
    else
      props.setSelectedFiles(filesVar);

    if (alreadyAddedFiles.length > 0)
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Duplicate Files selected', alertDescription: 'File(s) ' + alreadyAddedFiles.join(" ,") + ' has been already  selected to upload' }));
    if (rejectedFilesOnSize.length > 0)
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'File size of more than 5MB is not allowed', alertDescription: 'File(s) ' + rejectedFilesOnSize.join(" ,") + ' has more than 5MB of size.' }));
    if (rejectedFilesOnType.length > 0)
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Only pdf, Doc & Docx files are allowed', alertDescription: 'File(s) ' + rejectedFilesOnType.join(" ,") + ' has unsupported file format.' }));

  };

  const removeSelectedFile = (fileNameToRemove: string) => {
    props.setSelectedFiles(
      props.selectedFiles.filter((file: File) => file.name !== fileNameToRemove)
    );
  };

  return (
    <>
      <Dropzone  multiple={props.multiple} accept={{ 'application/pdf': ['.pdf', '.doc', '.docx'] }} onDrop={acceptedFiles => addToSelectedFiles(acceptedFiles)}>
        {({ getRootProps, getInputProps }) => (
          <section>
            <div {...getRootProps()}>
              <input data-testid='drop-zone' {...getInputProps()} />
              <div  className="flex align-items-center flex-column modal-view2-dragdrop-area">
                <img className='uploadicon' src={UploadIcon} alt='' />
                <span className="my-2 uploadtext1">Drag & Drop files or <span className='uploadtext3'>Browse</span></span>
                <span className='uploadtext2'>Supported formats: .doc, .pdf, .docx upto{props.multiple ? ' 5 files and 5MB per file' : ' 5MB'}</span>
              </div>
            </div>
          </section>
        )}
      </Dropzone>
      {props.selectedFiles.length > 0 && !props.isUploading &&
        <>
          <div className='uploaded-files-area-wrapper'>
            <div id='uploaded-text'>Uploaded</div>
            <div className='uploaded-files-area'>
              {props.selectedFiles.map((file: File) => {
                return (
                  <div key={file.name} className='uploaded-file-info'>
                    <Tooltip id='doc-library-upload-tooltip' title={file.name} placement='bottom-start'><div id='uploaded-file-name'>{file.name}</div></Tooltip>
                    <div>{formatFileSize(file.size)}</div>
                    <i data-testid='remove-file-icon' onClick={() => removeSelectedFile(file.name)} className='pi pi-times-circle pointer-cursor'></i>
                  </div>
                );
              })}
            </div>
          </div>
          <>
            <div id='add-comments-text'>Add Comments*</div>
          <textarea placeholder='Type to add comments' name='comment-textarea' id='comment-textarea' data-testid='comment-textarea' value={props.comment} onChange={(e) => props.setComment(e.target.value)} />
          </>
        </>
      }
      {
        props.isUploading &&
        <>
          <div id='uploaded-text'>Uploading File(s)</div>
          <div className='progress-bar-outer'>
            <div style={{ width: `${props.progress * 100}%` }} className='progress-bar-inner'>
            </div>
          </div>
        </>
      }
    </>
  );
}