import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../../../../common/constants';
import ModalView2 from '../ModalView2.component';

afterEach(cleanup);
const mockStore = configureStore();

const mockPdfFile = new File( ['pdf'] ,'mockpdf.pdf')
const mockPdfFileDup = new File(['pdf'], 'mockpdfDup.pdf');
const mockPdfFile2 = new File(['pdf'], 'mockpdf2.pdf');
const mockPdfFile3 = new File(['pdf'], 'mockpdf3.pdf');
const mockPdfFile4 = new File(['pdf'], 'mockpdf4.pdf');
const mockPdfFile5 = new File(['pdf'], 'mockpdf5.pdf');
const mockDocxFile = new File(['docx'], 'mockdocx.docx');
const mockJpgFile = new File(['jpg'], 'mockjpg.jpg');

const initMockProps={
  selectedFiles: [],
  setSelectedFiles: jest.fn(),
  comment: '',
  setComment: jest.fn(),
  multiple: false,
  progress: 0,
  isUploading: false,
}

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

test('should render modal view 2 component',()=>{
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} />
  </Provider>
  );
})

test('should add pdf file to upload', async () =>  {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} selectedFiles={[mockPdfFile]} comment='pdf file'/>
  </Provider>
  );

  expect(screen.getByTestId('drop-zone')).toBeInTheDocument()
  fireEvent.drop(screen.getByTestId('drop-zone'),mockPdfFile)
  await waitFor(()=>{
    expect(screen.getByText('mockpdf.pdf')).toBeInTheDocument()
  })
});

test('should add docx file to upload', async () => {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} selectedFiles={[mockDocxFile]} comment='docx file' />
  </Provider>
  );

  expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
  fireEvent.drop(screen.getByTestId('drop-zone'), mockDocxFile);
  await waitFor(() => {
    expect(screen.getByText('mockdocx.docx')).toBeInTheDocument();
  });
});

test('should not add jpg file to upload', async () => {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} />
  </Provider>
  );

  expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
  fireEvent.drop(screen.getByTestId('drop-zone'), mockJpgFile);
  await waitFor(() => {
    expect(screen.queryByText('mockdocx.docx')).not.toBeInTheDocument();
  });
});
test('should not add more than 5 file to upload', async() => {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} selectedFiles={[mockDocxFile, mockPdfFile, mockPdfFile2, mockPdfFile3, mockPdfFile4]} />
  </Provider>
  );

  expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
  fireEvent.drop(screen.getByTestId('drop-zone'), mockPdfFile5);
  await waitFor(() => {
    expect(screen.queryByText('mockPdf5.pdf')).not.toBeInTheDocument();
  });
});

test('should add upto5 file to upload in multiple',async () => {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} multiple={true} selectedFiles={[mockDocxFile, mockPdfFile, mockPdfFile2]} />
  </Provider>
  );

  expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
  fireEvent.drop(screen.getByTestId('drop-zone'), [mockPdfFile5, mockPdfFile4]);
  await waitFor(() => {
    expect(screen.getByText('Add Comments*')).toBeInTheDocument();
  });
});

test('should not add more than 5 file to upload in multiple',async () => {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} multiple={true} selectedFiles={[mockDocxFile, mockPdfFile, mockPdfFile2, mockPdfFile3]} />
  </Provider>
  );

  expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
  fireEvent.drop(screen.getByTestId('drop-zone'), [mockPdfFile5, mockPdfFile4]);
  await waitFor(() => {
    expect(screen.getByText('Add Comments*')).toBeInTheDocument();
  });
});

test('should not add duplicate file to upload', async () => {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} selectedFiles={[mockDocxFile, mockPdfFile, mockPdfFile2, mockPdfFile3, mockPdfFile4]} />
  </Provider>
  );

  expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
  fireEvent.drop(screen.getByTestId('drop-zone'), mockPdfFileDup);
  await waitFor(() => {
    expect(screen.getByText('Add Comments*')).toBeInTheDocument();
  });
});

test('should not add more than 5MB file to upload', async () => {
  const powerUserStore = mockStore(powerUserState);

  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} />
  </Provider>
  );
  Object.defineProperty(mockPdfFile, 'size', { value: 6000000 })
  expect(screen.getByTestId('drop-zone')).toBeInTheDocument();
  fireEvent.drop(screen.getByTestId('drop-zone'), mockPdfFile);
  await waitFor(() => {
    expect(screen.queryByText('Add Comments*')).not.toBeInTheDocument();
  });
});

test('should remove added files when clicked on cross icon  ', async () => {
  const powerUserStore = mockStore(powerUserState);
 
  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} selectedFiles={[mockPdfFile2]} />
  </Provider>
  );
  await waitFor(()=>{
    expect(screen.getByTestId('remove-file-icon')).toBeInTheDocument();
  })
  
  userEvent.click(screen.getByTestId('remove-file-icon'));
});

test('should add comments', async ()=>{
  const powerUserStore = mockStore(powerUserState);
  
  render(<Provider store={powerUserStore}>
    <ModalView2 {...initMockProps} comment='comment' selectedFiles={[mockDocxFile, mockPdfFile2]} />
  </Provider>
  );
  expect(screen.getByPlaceholderText('Type to add comments')).toBeInTheDocument();
  userEvent.type(screen.getByPlaceholderText('Type to add comments'),'comment')
  await waitFor(() => {
    expect(screen.getByText('comment')).toBeInTheDocument();
  });
})
