import classNames from 'classnames';
import { Dialog } from 'primereact/dialog';
import { ReactElement, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  IDocumentLibraryPos,
  IUploadCommentData,
  IUploadFormData,
  IUploadModalProps,
  IUserState,
} from '../../../../../common/interfaces';
import { uploadDocumentLibraryFiles } from '../../../../../common/utils';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import ModalView1 from './components/ModalView1.component';
import ModalView2 from './components/ModalView2.component';
import SuccessModalView from './components/SuccessModalView.component';

import './UploadModal.style.css';

export default function UploadModal(props: IUploadModalProps): ReactElement {

  const userId = useSelector((state: IUserState) => state.user.userId);
  
  const [modalView, setModalView] = useState(1);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [documentTitles, setDocumentTitles] = useState<string[] | []>([]);
  const [poNumbers, setPoNumbers] = useState<any[]>();
  const [poDocIds, setPoDocIds] = useState<IDocumentLibraryPos>({});
  const [comment, setComment] = useState<string>('');
  const [uploadFormData, setUploadFormData] = useState<IUploadFormData>({
    documentComponent: '',
    documentType: '',
    poNumber: '',
    documentId: '',
  });
  const [isPoNumSelected, setPoNumSelected] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [isUploading, setUploading] = useState<boolean>(false);
  const dispatch = useDispatch();

  const handleModalClose = () => {
    setSelectedFiles([]);
    setComment('');
    setPoDocIds({});
    setModalView(1);
    setUploadFormData((prevState: any) => ({
      ...prevState,
      documentComponent: '',
      documentType: '',
      poNumber: '',
      documentId: '',
    }));
    props.handleClose();
  };

  const handleSuccessModalClose = () => {
    setModalView(1);
    props.realodTable();
  };

  const nextButtonClass = classNames('next-and-upload-button', {
    disabled: uploadFormData.documentId === '' || !isPoNumSelected,
  });
  const uploadButtonClass = classNames('next-and-upload-button', {
    disabled:
      uploadFormData.documentId === '' ||
      selectedFiles.length === 0 ||
      comment.trim().length === 0,
  });

  const handleFileUpload = () => {
    setUploading(true);
    dispatch(setLoading(true));
    const formData = new FormData();
    selectedFiles.forEach((file) => formData.append('file', file));
    const comments: IUploadCommentData = {
      time: Date.now().toString(),
      message: comment.trim(),
      userId: userId,
      userName: localStorage.getItem('user_name'),
    };
    const request: IUploadFormData = {
      ...uploadFormData,
      comments: [comments],
      userId: userId,
      userName: localStorage.getItem('user_name'),
    };

    formData.append('request', JSON.stringify(request));

    const onUploadProgress = (progressEvent: any) => {
      setProgress(progressEvent.progress);
    };
    uploadDocumentLibraryFiles(formData, onUploadProgress)
      .then((res) => {
        if (res.data.data.message === 'SUCCESS') {
          handleModalClose();
          setModalView(3);
        }
        if (res.data.data.message === 'PARTIAL_SUCCESS') {
          setModalView(1);
          handleModalClose();
          props.realodTable();
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: res.data.data.failedFile.join(', '),
              alertDescription: 'documents were not uploaded',
            })
          );
        }
      })
      .catch((err) => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Error Occurred while Uploading Documents',
            alertDescription: '',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
        setUploading(false);
      });
  };
  return (
    <>
      <Dialog
        id='upload-modal'
        header='Upload Documents'
        visible={props.open}
        onHide={handleModalClose}>
        {modalView === 1 && (
          <>
            <ModalView1
              uploadFormData={uploadFormData}
              setUploadFormData={setUploadFormData}
              documentTitles={documentTitles}
              poNumbers={poNumbers}
              poDocIds={poDocIds}
              setDocumentTitles={setDocumentTitles}
              setPoNumbers={setPoNumbers}
              setPoDocIds={setPoDocIds}
              isPoNumSelected={isPoNumSelected}
              setPoNumSelected={setPoNumSelected}
            />
            <button
              className={nextButtonClass}
              onClick={() => setModalView(2)}>
              Next
            </button>
          </>
        )}
        {modalView === 2 && (
          <>
            <div>
              <i
                className='pi pi-arrow-left modal-back-button'
                data-testid='modal-back-button'
                onClick={() => setModalView(1)}></i>
            </div>
            <ModalView2
              multiple={true}
              selectedFiles={selectedFiles}
              setSelectedFiles={setSelectedFiles}
              comment={comment}
              setComment={setComment}
              progress={progress}
              isUploading={isUploading}
            />
            {
              <button
                onClick={handleFileUpload}
                className={uploadButtonClass}>
                Upload
              </button>
            }
          </>
        )}
      </Dialog>
      {modalView === 3 && (
        <Dialog
          header='Success'
          visible={modalView === 3}
          onHide={handleSuccessModalClose}>
          <SuccessModalView />
        </Dialog>
      )}
    </>
  );
}
