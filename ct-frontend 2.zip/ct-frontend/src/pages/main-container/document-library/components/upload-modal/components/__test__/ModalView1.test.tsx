import { cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../../../../common/constants';
import { IModalView1Props } from '../../../../../../../common/interfaces';
import ModalView1 from '../ModalView1.component';

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

afterEach(cleanup);
const mockStore = configureStore();
const uploadOptionsRes = {
  data: {
    data: [
      "Bill of Lading",
      "Roadway/rail/ air bills",
      "Vehicle load sheet summary"
    ]
  },
  status: 200
};

const uploadOptionsPoRes = {
  data: {
    data: {
      poNumbers: [
        "24681805"
      ],
      poDocumentIdMap: {
        24681805: [
          "113480398",
          "124938265"
        ]
      }
    }
  },
  status: 200
};
const err = {
  status: 500
};

const mockProps: IModalView1Props = {
  setUploadFormData: jest.fn(),
  setDocumentTitles: jest.fn(),
  setPoNumbers: jest.fn(),
  setPoDocIds: jest.fn(),
  poDocIds: { '1234': { id: '', name: '' }, '14': { id: '', name: '' } },
  poNumbers: [],
  documentTitles: [],
  isPoNumSelected: true,
  setPoNumSelected: jest.fn(),
  uploadFormData: {
    documentComponent: 'Port',
    documentType: 'Bill of lading',
    poNumber: '2345678',
    documentId: 'PORT123',
    userId: '1234567890',
    userName: 'John Macclain',
    comments: [],
  },
};

const emptyDocComponent = {
  documentComponent: '',
  documentType: '',
  poNumber: '',
  documentId: 'POT123',
  userId: '123457890',
  userName: '',
  comments: []
}

test('should render modal view 1 component with upload options api', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../../common/utils');
  jest.spyOn(util, 'getUploadOptions').mockResolvedValue(uploadOptionsRes);
  jest.spyOn(util, 'getUploadOptionsPoNumber').mockResolvedValue(uploadOptionsPoRes);

  render(<Provider store={powerUserStore}>
    <ModalView1 {...mockProps} />
  </Provider>
  );
  expect(screen.getByTestId('test-button')).toBeInTheDocument();
  userEvent.click(screen.getByTestId('test-button'));
  await waitFor(() => {
    screen.getByText('Type of File');
  });
});

test('should render modal view 1 component with document component empty', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../../common/utils');
  jest.spyOn(util, 'getUploadOptions').mockResolvedValue(uploadOptionsRes);
  jest.spyOn(util, 'getUploadOptionsPoNumber').mockResolvedValue(uploadOptionsPoRes);

  render(<Provider store={powerUserStore}>
    <ModalView1 {...mockProps} uploadFormData={emptyDocComponent} />
  </Provider>
  );
  expect(screen.getByTestId('test-button')).toBeInTheDocument();
  userEvent.click(screen.getByTestId('test-button'));
  await waitFor(() => {
    screen.getByText('Type of File');
  });
});

test('should handle upload options api fail', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../../common/utils');
  jest.spyOn(util, 'getUploadOptions').mockRejectedValue(err);
  jest.spyOn(util, 'getUploadOptionsPoNumber').mockRejectedValue(err);

  render(<Provider store={powerUserStore}>
    <ModalView1 {...mockProps} />
  </Provider>
  );

  expect(screen.getByTestId('test-button')).toBeInTheDocument();
  userEvent.click(screen.getByTestId('test-button'));
  await waitFor(() => {
    screen.getByText('Type of File');
  });
});