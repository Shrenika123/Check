import { AutoComplete } from 'primereact/autocomplete';
import { Dropdown } from 'primereact/dropdown';
import { ReactElement, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { IModalView1Props, IRoutePermission, IUserState } from '../../../../../../common/interfaces';
import {
  getUploadOptions,
  getUploadOptionsPoNumber,
  isStringValid,
} from '../../../../../../common/utils';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';

export default function ModalView1(props: IModalView1Props): ReactElement {
  
  const dispatch = useDispatch();
  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);

  const portDocPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'PORT_DOCUMENT_LIBRARY' )?.permission;
  const loadDocPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'LOAD_DOCUMENT_LIBRARY' )?.permission;
  const containerDocPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'CONTAINER_DOCUMENT_LIBRARY' )?.permission;

  const poNumMap = useRef();

  const getTypeOfFiles=()=>{
    let fileType = [];
    if(isStringValid(portDocPerm) && portDocPerm?.trim().toUpperCase() === 'WRITE')
      fileType.push({ label: 'Port Document(s)', value: 'PORT' })
    if(isStringValid(loadDocPerm) && loadDocPerm?.trim().toUpperCase() === 'WRITE')
      fileType.push( { label: 'Load Document(s)', value: 'LOAD' })
    if(isStringValid(containerDocPerm) && containerDocPerm?.trim().toUpperCase() === 'WRITE')
      fileType.push( { label: 'Container Document(s)', value: 'CONTAINER' })

    return fileType;
  }
  // handler method for file type change
  const handleTypeOfFileChange = async (e: any) => {
    try {
      dispatch(setLoading(true));
      props.setUploadFormData((prevState: any) => ({
        ...prevState,
        documentType: '',
        poNumber: '',
        documentId: '',
      }));
      props.setPoDocIds({});
      poNumMap.current = undefined;
      const response = await getUploadOptions(
        e.value.split(' ')[0].toUpperCase(),
        'DOCUMENT_TYPE'
      );
      props.setDocumentTitles(response?.data.data);
      props.setUploadFormData((prevState: any) => ({
        ...prevState,
        documentComponent: e.value,
      }));
      dispatch(setLoading(false));
    } catch (error: any) {
      console.log('error - UploadModal Component', error);
      dispatch(setLoading(false));
    }
  };

  // handler method for document title change
  const handleDocumentTitleChange = (e: any) => {
    props.setUploadFormData((prevState: any) => ({
      ...prevState,
      documentType: e.value,
    }));
  };
  // handler method for Po Doc Id change
  const handlePoDocIdChange = (e: any) => {
    if (props.uploadFormData.documentComponent === 'LOAD')
      props.setUploadFormData((prevState: any) => ({
        ...prevState,
        documentId: e.value,
        vendorId: props.poDocIds[e.value].id,
        vendorName: props.poDocIds[e.value].name,
      }));
    else {
      props.setUploadFormData((prevState: any) => ({
        ...prevState,
        documentId: e.value,
        carrierId: props.poDocIds[e.value].id,
        carrierName: props.poDocIds[e.value].name,
      }));
    }
  };

  // handler method for search PO number
  const handleSearchPoNumber = async (event: any) => {
    try {
      if (props.uploadFormData.documentComponent !== '') {
        props.setPoNumSelected(false);
        const response = await getUploadOptionsPoNumber(
          props.uploadFormData.documentComponent.split(' ')[0].toUpperCase(),
          event.query.trim()
        );
        props.setPoNumbers(response?.data.data?.poNumbers ?? []);
        poNumMap.current = response?.data.data?.poDocumentIdMap;
      }
    } catch (error: any) {
      console.log('error - handleSearchPoNumber()', error);
      props.setPoNumbers([]);
    }
  };

  // handler method for fetching Load/Port/Container ID
  const handleFetchDocId = async (poNumber: string) => {
    if (poNumMap.current) {
      props.setPoNumSelected(true);
      props.setPoDocIds(poNumMap.current[poNumber]);
    }
  };

  const handleModal1Methods = () => {
    handleTypeOfFileChange({ value: '' });
    handleDocumentTitleChange({ value: '' });
    handlePoDocIdChange({ value: '' });
    handleSearchPoNumber({ value: '' });
    handleFetchDocId('');
  };

  return (
    <>
      <section className='dropdown-group'>
        <p>Type of File</p>
        <Dropdown
          placeholder='Select Type of File'
          value={props.uploadFormData.documentComponent}
          optionLabel='label'
          optionValue='value'
          options={
            getTypeOfFiles()
          }
          onChange={handleTypeOfFileChange}
        />
      </section>
      <section className='dropdown-group'>
        {props.uploadFormData.documentComponent !== '' && (
          <>
            <p>Select Document Title</p>
            <Dropdown
              value={props.uploadFormData.documentType}
              options={props.documentTitles}
              onChange={handleDocumentTitleChange}
            />
          </>
        )}
      </section>
      <section className='dropdown-group'>
        {props.uploadFormData.documentType !== '' && (
          <>
            <p>Enter PO Number(s)</p>
            <AutoComplete
              minLength={4}
              delay={500}
              value={props.uploadFormData.poNumber}
              suggestions={props.poNumbers}
              completeMethod={handleSearchPoNumber}
              onChange={(e) =>
                props.setUploadFormData((prevState: any) => ({
                  ...prevState,
                  poNumber: e.value,
                }))
              }
              onSelect={(e) => handleFetchDocId(e.value)}
              dropdownAriaLabel='Enter PO Number'
              placeholder='Input minimum 4 numbers'
              showEmptyMessage={true}
            />
          </>
        )}
      </section>
      <section className='dropdown-group'>
        {props.isPoNumSelected && Object.keys(props.poDocIds).length > 0 && (
          <>
            <p>
              Select {props.uploadFormData.documentComponent.split(' ')[0]} ID
            </p>
            <Dropdown
              value={props.uploadFormData.documentId}
              options={Object.keys(props.poDocIds)}
              onChange={handlePoDocIdChange}
            />
          </>
        )}
      </section>
      <button
        data-testid='test-button'
        className='test-button'
        onClick={handleModal1Methods}></button>
    </>
  );
}