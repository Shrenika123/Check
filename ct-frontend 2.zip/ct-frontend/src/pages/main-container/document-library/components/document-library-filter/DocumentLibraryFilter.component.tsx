import Popper, { PopperPlacementType } from '@mui/material/Popper';
import Stack from '@mui/material/Stack';
import { Button } from "primereact/button";
import { MultiSelect } from 'primereact/multiselect';
import { FC, useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { DocumentTabs } from '../../../../../common/interfaces';
import { getDocumentLibraryFilterData } from '../../../../../common/utils';
import { useDidComponentUpdate } from '../../../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import './DocumentLibraryFilter.style.css';

interface Props {
  selectedUsers: { userId: string, userName: string; }[],
  selectedDocNames: string[];
  addToSelectedUsers: Function;
  addToSelectedDocNames: Function;
  onApplyFilter: any;
  onResetFilter: any;
  filterApplied: boolean;
  documentComponent: DocumentTabs;
}

const DocumentLibraryFilter: FC<Props> = (props) => {

  const dispatch = useDispatch();

  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [placement, setPlacement] = useState<PopperPlacementType>();
  const [open, setOpen] = useState(false);
  const [users, setUsers] = useState<{ userId: string, userName: string; }[]>([]);
  const [documentNameTypes, setDocumentNameTypes] = useState<string[]>([]);

  const boxRef = useRef<HTMLDivElement>(null);
  const toggleRef = useRef(null);

  useDidComponentUpdate(() => {
    if (!props.filterApplied && !open) {
      props.addToSelectedUsers([]);
      props.addToSelectedDocNames([]);
    }
  }, [open]);

  const handleClick =
    (newPlacement: PopperPlacementType) =>
      (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(event.currentTarget);
        setOpen((prev) => placement !== newPlacement || !prev);
        setPlacement(newPlacement);
      };

  const onApplyFilter = (e: any) => {
    props.onApplyFilter(e);
    setOpen(false);
  };

  const onResetFilter = (e: any) => {
    props.onResetFilter(e);
    setOpen(false);
  };
  const hideOnClickOutside = (e: any) => {
    const innerFilter = document.querySelector("[class='p-multiselect-panel p-component p-connected-overlay-enter-done']");
    if (boxRef.current && !boxRef.current.contains(e.target)
      && e.target.id !== 'autocomplete-multiselect-toggle-button'
      && e.target.parentNode.id !== 'autocomplete-multiselect-toggle-button'
      && e.target.id !== 'autocomplete-multiselect_list'
      && e.target.parentNode.id !== 'autocomplete-multiselect_list') {
      innerFilter === null && setOpen(false);
      innerFilter !== null && !innerFilter.contains(e.target) && setOpen(false);
    }
  };

  useEffect(() => {
    getDocumentLibraryFilterData(props.documentComponent).then((res) => {
      setUsers(res.data.data.createdUsers);
      setDocumentNameTypes(res.data.data.documentTypes);
    }).catch(() => {
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Error Occurred while fetching filter data', alertDescription: '' }));
    });
  }, []);

  useEffect(() => {
    // event listeners
    document.addEventListener("click", hideOnClickOutside, true);
  }, []);

  const id = open ? 'doc-library-filter-box' : undefined;

  const isApplyButtonDisabled = () => {
    if (props.selectedDocNames && props.selectedDocNames.length > 0)
      return false;
    if (props.selectedUsers && props.selectedUsers.length > 0)
      return false;
    return true;

  };

  return (
    <section className='doc-library-autocomplete-multiselect-filter'>
      <Button
        ref={toggleRef}
        type="button"
        icon="pi pi-filter"
        label={"Filter"}
        onClick={handleClick('bottom-end')}
        aria-haspopup
        aria-controls="overlay_panel"
        className="autocomplete-multiselect-toggle-button"
        id='autocomplete-multiselect-toggle-button'
        data-testid='autocomplete-multiselect-toggle-button'
      />

      <Popper
        ref={boxRef}
        id={id}
        open={open}
        anchorEl={anchorEl}
        placement={placement}
        sx={{ display: 'flex', flexDirection: 'column', position: 'absolute', zIndex: 3 }}
      >
        <Stack spacing={2} sx={{ backgroundColor: '#1e1e1e', width: '23rem' }} p={2} >
          <div className='filter-title'>Created By</div>
          <MultiSelect value={props.selectedUsers}
            options={users}
            optionLabel='userName'
            filterBy='userName'
            onChange={(e) => props.addToSelectedUsers(e.value)}
            placeholder="Created By"
            className='doc-library-multiselect'
            filter
            resetFilterOnHide
            showSelectAll={true}
            filterPlaceholder='Type to Search'
            dataKey='userId'
            display='chip'
            id='doc-library-filter-created-by'
            data-testid='created-by-filter'
            appendTo='self'
          />
          <div className='filter-title'>Type of Documents</div>
          <MultiSelect value={props.selectedDocNames}
            options={documentNameTypes}
            onChange={(e) => props.addToSelectedDocNames(e.value)}
            placeholder="Type of Documents"
            filter
            resetFilterOnHide
            showSelectAll={true}
            filterPlaceholder='Type to Search'
            display='chip'
            id='doc-library-filter-type-of-doc'
            itemID='doc-library-filter-item'
            data-testid='type-of-doc-filter'
            appendTo='self'
          />
          <Stack spacing={2} direction='row'>
            <Button
              type="button"
              label='Apply'
              disabled={isApplyButtonDisabled()}
              onClick={onApplyFilter}
              className='autocomplete-multiselect-apply-button'
              data-testid='autocomplete-multiselect-apply-button'>
            </Button>
            <Button
              type="button"
              label='Reset'
              onClick={onResetFilter}
              disabled={!props.filterApplied}
              className='autocomplete-multiselect-apply-button'
              data-testid='autocomplete-multiselect-reset-button'>
            </Button>
            <button style={{ display: 'none' }} data-testid='dummy-button-for-testing' onClick={() => { props.addToSelectedDocNames(['document']); props.addToSelectedUsers([{ userId: '1', userName: 'name' }]); }}></button>
          </Stack>
        </Stack>
      </Popper>
    </section>

  );
};

export default DocumentLibraryFilter;