import classNames from 'classnames';
import { Dialog } from 'primereact/dialog';
import { FC, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  DocumentTabs,
  IUpdateFileFormData,
  IUploadCommentData,
  IUserState,
} from '../../../../../../common/interfaces';
import { updateDocumentLibraryFile } from '../../../../../../common/utils';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';
import ModalView2 from '../../upload-modal/components/ModalView2.component';
import SuccessModalView from '../../upload-modal/components/SuccessModalView.component';
import '../../upload-modal/UploadModal.style.css';

interface Props {
  type: DocumentTabs;
  isOpen: boolean;
  setOpen: Function;
  fileIdToUpload: string;
  reloadTable: Function;
  prevComments: IUploadCommentData[];
}

const UploadAction: FC<Props> = (props) => {

  const userId = useSelector((state: IUserState) => state.user.userId);

  const [comment, setComment] = useState<string>('');
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [modalView, setModalView] = useState<1 | 2>(1);
  const [progress, setProgress] = useState<number>(0);
  const [isUploading, setUploading] = useState<boolean>(false);

  const dispatch = useDispatch();

  const handleClose = () => {
    setComment('');
    setSelectedFiles([]);
    props.setOpen(false);
  };

  const handleSuccessModalClose = () => {
    setModalView(1);
    props.reloadTable();
  };

  const uploadUpdateDocument = () => {
    setUploading(true);
    dispatch(setLoading(true));
    const formData = new FormData();
    const commentObj: IUploadCommentData = {
      time: Date.now().toString(),
      message: comment.trim(),
      userId: userId,
      userName: localStorage.getItem('user_name')!
    };

    const request: IUpdateFileFormData = {
      id: props.fileIdToUpload,
      modifyUserId: userId,
      modifyUserName: localStorage.getItem('user_name')!,
      comments: [commentObj]
    };

    formData.append('request', JSON.stringify(request));
    formData.append('file', selectedFiles[0]);

    const onUploadProgress = (progressEvent: any) => {
      setProgress(progressEvent.progress);
    };

    updateDocumentLibraryFile(formData, onUploadProgress, props.type)
      .then((res) => {
        props.setOpen(false);
        setModalView(2);
      })
      .catch((err) => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Error Occurred',
            alertDescription: 'Error Occurred while updating the Document',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
        setUploading(false);
      });
  };

  const nextAndUploadButtonClass = classNames('next-and-upload-button', {
    'disabled': selectedFiles.length === 0 || comment.trim().length === 0
  });

  return (
    <>
      <Dialog id='upload-modal' header='Upload Document' visible={props.isOpen} onHide={handleClose}>
        {modalView === 1 &&
          <> <ModalView2 selectedFiles={selectedFiles} setSelectedFiles={setSelectedFiles} comment={comment} setComment={setComment} multiple={false} progress={progress} isUploading={isUploading}></ModalView2>
            {!isUploading &&
              <button data-testid='upload-button' onClick={() => uploadUpdateDocument()} className={nextAndUploadButtonClass}>Upload</button>
            }
          </>}
      </Dialog>
      {modalView === 2 &&
        <Dialog header='Success' visible={modalView === 2} onHide={handleSuccessModalClose}>
          <SuccessModalView />
        </Dialog>
      }
    </>
  );
};

export default UploadAction;;