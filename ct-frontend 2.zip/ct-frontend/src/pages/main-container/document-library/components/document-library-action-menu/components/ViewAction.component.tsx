
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import classNames from 'classnames';
import { Dialog } from 'primereact/dialog';
import { FC, useState } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import { useDispatch } from 'react-redux';
import {
  DocumentTabs,
  IUploadCommentData,
} from '../../../../../../common/interfaces';
import { downloadDocumentLibraryFiles } from '../../../../../../common/utils';
import { useDidComponentUpdate } from '../../../../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';

interface Props {
  type: DocumentTabs;
  isOpen: boolean;
  setOpen: Function;
  fileIdToView: string;
}

const ViewAction: FC<Props> = (props) => {

  pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

  const [fileContent, setFileContent] = useState<any>('');
  const [pageNo, setPageNo] = useState<number>(1);
  const [numPages, setNumPages] = useState<number>(1);
  const [comments, setComments] = useState<IUploadCommentData[]>([]);
  const [fileType, setFileType] = useState<string>('');
  const [isFileLoaded, setFileLoaded] = useState<boolean>(false);

  const dispatch = useDispatch();

  const downloadFile = (fileId: string) => {
    setFileLoaded(false);
    dispatch(setLoading(true));
    downloadDocumentLibraryFiles([fileId], props.type)
      .then((res) => {
        res.data.data.forEach((file: any) => {
          if (file.fileName.split('.').pop().trim() === 'pdf') {
            setFileType('pdf');
            setFileContent('data:application/pdf;base64,' + file.fileContent);
          } else if (file.fileName.split('.').pop().trim() === 'docx') {
            setFileType('docx');
            setFileContent('data:application/pdf;base64,' + file.fileContent);
          } else if (file.fileName.split('.').pop().trim() === 'doc') {
            setFileType('doc');
            setFileContent('data:application/pdf;base64,' + file.fileContent);
          } else {
            setFileType('notSupport');
          }
          setComments(file.comments);
          setFileLoaded(true);
        });
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Error Occurred',
            alertDescription: 'Failed to fetch the file',
          })
        );
        props.setOpen(false);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });

  };

  const onDocumentLoadSuccess = ({ numPages }: { numPages: number; }) => {
    setNumPages(numPages);
  };

  useDidComponentUpdate(() => {
    if (props.isOpen)
      downloadFile(props.fileIdToView);
  }, [props.isOpen]);

  const paginateLeftIcon = classNames("pi pi-chevron-left pointer-cursor doc-paginate-icon", {
    'doc-paginate-icon-disable': pageNo === 1
  });
  const paginateRightIcon = classNames("pi pi-chevron-right pointer-cursor doc-paginate-icon", {
    'doc-paginate-icon-disable': pageNo === numPages
  });

  return (
    <>
      {isFileLoaded &&
        <Dialog visible={props.isOpen} onHide={() => props.setOpen(false)}>
          <section className='flex' >
            <section>
              {fileType === 'pdf' &&
                <Document file={fileContent} onLoadError={console.error} onLoadSuccess={onDocumentLoadSuccess}>
                  <Page pageNumber={pageNo}></Page>
                </Document>
              }
              {(fileType === 'doc' || fileType === 'docx') &&
                <div className='nosupport-error-div'>
                  <div className='flex justify-content-center'> <ErrorOutlineOutlinedIcon className='nosupport-error-icon'></ErrorOutlineOutlinedIcon></div>
                  <div className='nosupport-error-text'>File formats doc/docx are not supported currently, Please download the file from action menu to view.</div>
                </div>
              }
              {(fileType === 'notSupport') &&
                <div className='nosupport-error-div'>
                  <div className='flex justify-content-center'> <ErrorOutlineOutlinedIcon className='nosupport-error-icon'></ErrorOutlineOutlinedIcon></div>
                  <div className='nosupport-error-text'> Unsupported File Format</div>
                </div>
              }
              {fileType === 'pdf' && <span className='doc-view-pagination'>{pageNo} of {numPages} page(s)</span>}
              <div className='flex justify-content-center align'>
                <span data-testid='prev-page-doc' onClick={() => { setPageNo(pageNo - 1); }}>
                  <i className={paginateLeftIcon}></i>
                </span>
                <span data-testid='next-page-doc' onClick={() => { setPageNo(pageNo + 1); }}> &nbsp;
                  <i className={paginateRightIcon}></i>
                </span>
              </div>
            </section>
            <section className='comments-area-wrapper'>
              <span className='header-text-comment'>Comments</span>
              <div className='comments-area'>
                {comments.map((comment, index) => {
                  return (
                    comment.message.length > 0 ?
                      <div key={comment.time + index}>
                        <div className='doc-library-comment'>{comment.message.trim()}</div>
                        <div className='doc-library-comment-ps'>{comment.userName} &ensp;|&ensp;{new Date(Number.parseInt(comment.time)).toUTCString().replace('GMT', 'UTC')}</div>
                        <br />
                      </div>
                      :
                      <></>
                  );
                })}
              </div>
            </section>
          </section>
        </Dialog>
      }
    </>
  );
};

export default ViewAction;