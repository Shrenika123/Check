import CloudDownloadOutlinedIcon from '@mui/icons-material/CloudDownloadOutlined';
import CloudUploadOutlinedIcon from '@mui/icons-material/CloudUploadOutlined';
import { Pagination } from '@mui/material';
import Tooltip from '@mui/material/Tooltip';
import classNames from 'classnames';
import format from 'date-fns/format';
import { Checkbox } from 'primereact/checkbox';
import { FC, useState } from 'react';
import { useDispatch } from 'react-redux';
import { tableConfig } from '../../../../../common/constants';
import {
  DocumentTabs,
  IDocumentLibraryTableRow,
} from '../../../../../common/interfaces';
import { downloadDocumentLibraryFiles, isStringValid } from '../../../../../common/utils';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import DocLibraryActionMenu from '../document-library-action-menu/DocLibraryActionMenu.component';
import UploadModal from '../upload-modal/UploadModal.component';
import './DocumentLibraryTable.style.css';

interface Props {
  columnType: string;
  totalRecords: number;
  tableData: IDocumentLibraryTableRow[];
  pageNumber: number;
  goToPage: Function;
  reloadTable: Function;
  filterInput: string;
  setFilterInput: Function;
  accessLevel: string | undefined
}

const DocumentLibraryTable: FC<Props> = (props) => {
  const [checkedGroup, setCheckedGroup] = useState<string[]>([]);

  const [open, setOpen] = useState<boolean>(false);
  const handleOpen = () => setOpen(true);
  const handleClose = (event: any, reason: string) => {
    setOpen(false);
  };
  const dispatch = useDispatch();

  const handleChecked = (id: string) => {
    if (checkedGroup.includes(id))
      setCheckedGroup(checkedGroup.filter((value) => value !== id));
    else setCheckedGroup([...checkedGroup, id]);
  };

  const setFilterInput = (inputValue: string, callApi: boolean) => {
    const filter = {
      inputValue,
      callApi,
    };
    props.setFilterInput(filter);
  };

  const handleDownloadClick = (
    filesToDownLoad: string[],
    multiple: boolean
  ) => {
    dispatch(setLoading(true));
    const emptyFileIds: string[] = [];
    let docContent = '';
    downloadDocumentLibraryFiles(
      filesToDownLoad,
      props.columnType.split(' ')[0].toUpperCase() as DocumentTabs
    )
      .then((res) => {
        res.data.data.forEach((file: any) => {
          if (
            file.fileContent === undefined ||
            file.fileContent === null ||
            file.fileContent === ''
          ) {
            emptyFileIds.push(file.id);
            return;
          }
          docContent = file.fileContent;
          const binaryString = window.atob(file.fileContent);
          const binaryLen = binaryString.length;
          const bytes = new Uint8Array(binaryLen);
          for (var i = 0; i < binaryLen; i++) {
            var ascii = binaryString.charCodeAt(i);
            bytes[i] = ascii;
          }
          const url = window.URL.createObjectURL(new Blob([bytes]));

          const link = document.createElement('a');
          link.href = url;

          link.setAttribute('download', file.fileName);

          document.body.appendChild(link);
          link.click();

          if (link.parentNode !== null) link.parentNode.removeChild(link);

          if (multiple) {
            setCheckedGroup(emptyFileIds);
            emptyFileIds.length > 0 &&
              dispatch(
                setShowAlert({
                  showAlert: true,
                  alertType: 'error',
                  alertTitle: 'Error Occurred',
                  alertDescription: 'Failed to download some files',
                })
              );
          }
        });
      })
      .catch((err) => {
        console.log(err);
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Error Occurred',
            alertDescription: 'File(s) downloading failed',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
        return docContent;
      });
  };

  const downloadIcon = classNames('global-upload-download-icon', {
    'global-upload-download-icon-disabled': checkedGroup.length === 0,
  });

  const uploadIcon = classNames('global-upload-download-icon', {
    'global-upload-download-icon-disabled': checkedGroup.length > 0,
  });

  return (
    <>
      <section className='doc-library-table-filter-wrapper'>
        <div className='upload-download-button-div'>
          <input
            autoFocus
            data-testid='inplace-filter'
            className='inplace-filter-input'
            placeholder={'Search by ' + props.columnType}
            type='text'
            value={props.filterInput}
            onChange={(e) => setFilterInput(e.target.value, true)}
          />
          { isStringValid(props.accessLevel) && props.accessLevel === 'WRITE' &&
            <Tooltip
            title='Upload Files'
            placement='top'>
            <CloudUploadOutlinedIcon
              data-testid='global-upload-button'
              onClick={handleOpen}
              className={uploadIcon}></CloudUploadOutlinedIcon>
          </Tooltip>}
          <Tooltip
            title='Download Files'
            placement='top'>
            <CloudDownloadOutlinedIcon
              data-testid='global-download-button'
              onClick={() => handleDownloadClick(checkedGroup, true)}
              className={downloadIcon}></CloudDownloadOutlinedIcon>
          </Tooltip>
        </div>
        <section className='doc-library-table-wrapper'>
          <table className='doc-library-table'>
            <thead>
              <tr>
                <th id='checkbox-th'> &emsp;&emsp;</th>
                <th>Created By</th>
                <th>Created Date</th>
                <th>PO Number</th>
                <th>Document Title</th>
                <th>{props.columnType}</th>
                <th>Last Modified By</th>
                <th>Last Modified Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {props.tableData &&
                props.tableData.length > 0 &&
                props.tableData.map((row, index) => {
                  return (
                    <tr
                      key={
                        row.documentId +
                        row.lastModifiedDate +
                        row.sequence +
                        index
                      }>
                      <td
                        data-testid='checkbox-testid'
                        id='checkbox-td'>
                        <Checkbox
                          data-testid='download-checkbox'
                          name={row.id}
                          checked={checkedGroup.includes(row.id)}
                          onChange={() => handleChecked(row.id)}
                        />
                      </td>
                      <td>
                        <Tooltip title={row.createdUserName}>
                          <span>{row.createdUserName}</span>
                        </Tooltip>{' '}
                      </td>
                      <td>
                        <Tooltip
                          title={
                            row.createdDate === 'NA'
                              ? 'NA'
                              : format(
                                  new Date(row.createdDate),
                                  'MM/dd/yyyy hh:mm:ss'
                                )
                          }>
                          <span>
                            {row.createdDate === 'NA'
                              ? 'NA'
                              : format(
                                  new Date(row.createdDate),
                                  'MM/dd/yyyy hh:mm:ss'
                                )}
                          </span>
                        </Tooltip>{' '}
                      </td>
                      <td>
                        <Tooltip title={row.poNumber}>
                          <span>{row.poNumber}</span>
                        </Tooltip>{' '}
                      </td>
                      <td>
                        <Tooltip title={row.documentType}>
                          <span>{row.documentType}</span>
                        </Tooltip>{' '}
                      </td>
                      <td>
                        <Tooltip title={row.documentId}>
                          <span>{row.documentId}</span>
                        </Tooltip>{' '}
                      </td>
                      <td>
                        <Tooltip title={row.lastModifiedUserName}>
                          <span>{row.lastModifiedUserName}</span>
                        </Tooltip>{' '}
                      </td>
                      <td>
                        <Tooltip
                          title={
                            row.lastModifiedDate === 'NA'
                              ? 'NA'
                              : format(
                                  new Date(row.lastModifiedDate),
                                  'MM/dd/yyyy hh:mm:ss'
                                )
                          }>
                          <span>
                            {row.createdDate === 'NA'
                              ? 'NA'
                              : format(
                                  new Date(row.createdDate),
                                  'MM/dd/yyyy hh:mm:ss'
                                )}
                          </span>
                        </Tooltip>{' '}
                      </td>
                      <td>
                        <DocLibraryActionMenu
                          type={
                            props.columnType
                              .split(' ')[0]
                              .toUpperCase() as DocumentTabs
                          }
                          canEdit={row.canEdit && props.accessLevel === 'WRITE'}
                          fileIdToDownload={row.id}
                          handleDownload={handleDownloadClick}
                          reloadTable={props.reloadTable}
                          prevComments={row.comments}
                        />
                      </td>
                    </tr>
                  );
                })}
              {props.tableData &&
                props.tableData.length < 7 &&
                [...Array(7 - props.tableData.length)].map((_, index) => {
                  return (
                    <tr
                      data-testid='filler'
                      className='custom-tr'
                      key={index}>
                      <td
                        className='custom-td'
                        colSpan={9}>
                        <div className='filler'></div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </section>
      </section>
      <section className='paginated'>
        <span className='footer-message'>
          No. of documents selected for download : {checkedGroup.length}{' '}
        </span>
        <Pagination
          count={Math.ceil(props.totalRecords / tableConfig.pageSize)}
          variant='text'
          shape='rounded'
          siblingCount={1}
          color={'standard'}
          showFirstButton
          showLastButton
          size='small'
          page={props.pageNumber}
          onChange={(e, value) => props.goToPage(value)}
        />
      </section>
      <UploadModal
        open={open}
        setOpen={setOpen}
        handleClose={handleClose}
        realodTable={props.reloadTable}
      />
    </>
  );
};

export default DocumentLibraryTable;