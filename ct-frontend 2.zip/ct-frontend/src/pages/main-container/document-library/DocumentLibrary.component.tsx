import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import classNames from 'classnames';
import { FC, useCallback, useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom";
import { labels, routes, tableConfig } from '../../../common/constants';
import { debounce } from '../../../common/debounce';
import { DocumentTabs, IDocumentLibraryTableRequest, IDocumentLibraryTableRow, IDocumentLibraryTotalCountRequest, IRoutePermission, IUserState } from '../../../common/interfaces';
import { getDocumentLibraryTableData, getDocumentLibraryTotalCount, isStringValid } from '../../../common/utils';
import { useDidComponentUpdate } from '../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import DocumentLibraryFilter from './components/document-library-filter/DocumentLibraryFilter.component';
import DocumentLibraryTable from './components/document-library-table/DocumentLibraryTable.component';
import './DocumentLibrary.style.css';

interface Props {
  isExpanded: boolean;
}

const DocumentLibrary: FC<Props> = (props) => {

  const initFilter: { inputValue: string, callApi: boolean; } = {
    inputValue: '',
    callApi: false
  };

  const user = useSelector((state: IUserState) => state.user);
  const userGroupRoutes: IRoutePermission[] = user.routePermissions
  const portDocPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'PORT_DOCUMENT_LIBRARY' )?.permission;
  const loadDocPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'LOAD_DOCUMENT_LIBRARY' )?.permission;
  const containerDocPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'CONTAINER_DOCUMENT_LIBRARY' )?.permission;

  const [selectedUsers, setSelectedUsers] = useState<{ userId: string, userName: string; }[]>([]);
  const [selectedDocNames, setSelectedDocNames] = useState<string[]>([]);
  const [activeTabIndex, setActiveTabIndex] = useState<number>(0);
  const [tableData, setTableData] = useState<IDocumentLibraryTableRow[]>([]);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [filterInput, setFilterInput] = useState<{ inputValue: string, callApi: boolean; }>(initFilter);
  const [tabScreenMapping, setTabScreenMapping] = useState<string[]>(()=>{
    let tabScreenMappingVar:string[] = [];
    if(isStringValid(loadDocPerm) && loadDocPerm !== 'NA'){
      tabScreenMappingVar.push('LOAD')
    }
    if(isStringValid(portDocPerm) && portDocPerm !== 'NA'){
      tabScreenMappingVar.push('PORT')
    }
    if(isStringValid(containerDocPerm) && containerDocPerm !== 'NA'){
      tabScreenMappingVar.push('CONT')
    }
    return tabScreenMappingVar;
  });

  const isFilterApplied = useRef<boolean>(false);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const currentUserRole = user.userRole;

  const routeToHome = () => {
    navigate(`/${routes.home}`);
  };

  const loadAndPopulateTableData = (
    documentComponent: DocumentTabs,
    pageNo: number,
    selectedDocNamesVar?: string[],
    selectedUserIdVar?: string[],
    filterInputVar?: string
  ) => {
    dispatch(setLoading(true));
    const params: IDocumentLibraryTableRequest = {
      currentUserRole,
      documentComponent,
      selectedDocumentTypes: selectedDocNamesVar?.join(','),
      selectedUserIds: selectedUserIdVar?.join(','),
      pageNo,
      pageSize: tableConfig.pageSize,
      documentIdPattern: filterInputVar,
    };
    getDocumentLibraryTableData(params)
      .then((res) => {
        setTableData(res.data.data);
        if (res.data.data.length === 0)
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: 'No Data Found',
              alertDescription: '',
            })
          );
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Error Occurred while Fetching Document table',
            alertDescription: '',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getTotalCount = (
    documentComponent: DocumentTabs,
    selectedDocNamesVar?: string[],
    selectedUserIdVar?: string[],
    filterInputVar?: string
  ) => {
    const request: IDocumentLibraryTotalCountRequest = {
      documentComponent: documentComponent,
      selectedDocumentTypes: selectedDocNamesVar?.join(','),
      selectedUserIds: selectedUserIdVar?.join(','),
      documentIdPattern: filterInputVar,
    };
    getDocumentLibraryTotalCount(request)
      .then((res) => {
        setTotalRecords(res.data.totalRecords);
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Error Occurred while fetching total pages',
            alertDescription: '',
          })
        );
      });
  };

  const handleInputFilterChange = (
    documentComponent: DocumentTabs,
    selectedDocNamesVar: string[],
    selectedUsersVar: { userId: string; userName: string }[],
    filterInputVar: { inputValue: string; callApi: boolean }
  ) => {
    if (filterInputVar.callApi) {
      loadAndPopulateTableData(
        documentComponent,
        1,
        selectedDocNamesVar,
        selectedUsersVar.map((user) => user.userId),
        filterInputVar.inputValue
      );
      getTotalCount(
        documentComponent,
        selectedDocNames,
        selectedUsers.map((user) => user.userId),
        filterInputVar.inputValue
      );
    }
  };

  const setInputFilter_debounced = useCallback(
    debounce(handleInputFilterChange, 500),
    []
  );

  useDidComponentUpdate(() => {
    switch (activeTabIndex) {
      case 0:
        if(tabScreenMapping[0]==='LOAD'){
          setInputFilter_debounced(
            'LOAD',
            selectedDocNames,
            selectedUsers,
            filterInput
          );
        }
        else if(tabScreenMapping[0]==='PORT'){
          setInputFilter_debounced(
            'PORT',
            selectedDocNames,
            selectedUsers,
            filterInput
          );
        }
        else if(tabScreenMapping[0]==='CONT'){
          setInputFilter_debounced(
            'CONTAINER',
            selectedDocNames,
            selectedUsers,
            filterInput
          );
        }
        break;
      case 1:
        if(tabScreenMapping[1]==='PORT'){
          setInputFilter_debounced(
            'PORT',
            selectedDocNames,
            selectedUsers,
            filterInput
          );
        }
        else if(tabScreenMapping[1]==='CONT'){
          setInputFilter_debounced(
            'CONTAINER',
            selectedDocNames,
            selectedUsers,
            filterInput
          );
        }
        break;
      case 2:
        if(tabScreenMapping[2]==='CONT'){
          setInputFilter_debounced(
            'CONTAINER',
            selectedDocNames,
            selectedUsers,
            filterInput
          );
        }
        break;
    }
  }, [filterInput.inputValue]);

  const handleApplyFilter = () => {
    isFilterApplied.current = true;
    setFilterInput(initFilter);
    switch (activeTabIndex) {
      case 0:
        if(tabScreenMapping[0]==='LOAD'){
          loadAndPopulateTableData(
            'LOAD',
            1,
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
          getTotalCount(
            'LOAD',
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
        }
        else if(tabScreenMapping[0]==='PORT'){
          loadAndPopulateTableData(
            'PORT',
            1,
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
          getTotalCount(
            'PORT',
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
        }
        else if(tabScreenMapping[0]==='CONT'){
          loadAndPopulateTableData(
            'CONTAINER',
            1,
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
          getTotalCount(
            'CONTAINER',
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
        }
        break;
      case 1:
        if(tabScreenMapping[1]==='PORT'){
          loadAndPopulateTableData(
            'PORT',
            1,
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
          getTotalCount(
            'PORT',
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
        }
        else if(tabScreenMapping[1]==='CONT'){
          loadAndPopulateTableData(
            'CONTAINER',
            1,
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
          getTotalCount(
            'CONTAINER',
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
        }
        break;
      case 2:
        if(tabScreenMapping[2]==='CONT'){
          loadAndPopulateTableData(
            'CONTAINER',
            1,
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
          getTotalCount(
            'CONTAINER',
            selectedDocNames,
            selectedUsers.map((user) => user.userId)
          );
        }
        break;
    }
  };

  const handleResetFilter = () => {
    setFilterInput(initFilter);
    setSelectedDocNames([]);
    setSelectedUsers([]);
    setTableData([]);
    setTotalRecords(0);
    setPageNumber(1);
    isFilterApplied.current = false;
    switch (activeTabIndex) {
      case 0:
        if(tabScreenMapping[0]==='LOAD'){
          loadAndPopulateTableData('LOAD', 1);
          getTotalCount('LOAD');
        }
        else if(tabScreenMapping[0]==='PORT'){
          loadAndPopulateTableData('PORT', 1);
          getTotalCount('PORT');
        }
        else if(tabScreenMapping[0]==='CONT'){
          loadAndPopulateTableData('CONTAINER', 1);
          getTotalCount('CONTAINER');
        }
        break;
      case 1:
        if(tabScreenMapping[1]==='PORT'){
          loadAndPopulateTableData('PORT', 1);
          getTotalCount('PORT');
        }
        else if(tabScreenMapping[1]==='CONT'){
          loadAndPopulateTableData('CONTAINER', 1);
          getTotalCount('CONTAINER');
        }
        break;
      case 2:
        if(tabScreenMapping[2]==='CONT'){
          loadAndPopulateTableData('CONTAINER', 1);
          getTotalCount('CONTAINER');
        }
        break;
    }
  };

  const reloadTable = () => {
    if (isFilterApplied.current) handleApplyFilter();
    else handleResetFilter();
  };

  useEffect(() => {
    handleResetFilter();
  }, [activeTabIndex]);

  useDidComponentUpdate(() => {
    switch (activeTabIndex) {
      case 0:
        if(tabScreenMapping[0]==='LOAD'){
          loadAndPopulateTableData(
            'LOAD',
            pageNumber,
            selectedDocNames,
            selectedUsers.map((user) => user.userId),
            filterInput.inputValue
          );
        }
        else if(tabScreenMapping[0]==='PORT'){
          loadAndPopulateTableData(
            'PORT',
            pageNumber,
            selectedDocNames,
            selectedUsers.map((user) => user.userId),
            filterInput.inputValue
          );
        }
        else if(tabScreenMapping[0]==='CONT'){
          loadAndPopulateTableData(
            'CONTAINER',
            pageNumber,
            selectedDocNames,
            selectedUsers.map((user) => user.userId),
            filterInput.inputValue
          );
        }
        break;
      case 1:
        if(tabScreenMapping[1]==='PORT'){
          loadAndPopulateTableData(
            'PORT',
            pageNumber,
            selectedDocNames,
            selectedUsers.map((user) => user.userId),
            filterInput.inputValue
          );
        }
        else if(tabScreenMapping[1]==='CONT'){
          loadAndPopulateTableData(
            'CONTAINER',
            pageNumber,
            selectedDocNames,
            selectedUsers.map((user) => user.userId),
            filterInput.inputValue
          );
        }
        break;
      case 2:
        if(tabScreenMapping[2]==='CONT'){
          loadAndPopulateTableData(
            'CONTAINER',
            pageNumber,
            selectedDocNames,
            selectedUsers.map((user) => user.userId),
            filterInput.inputValue
          );
        }
        break;
    }
  }, [pageNumber]);

  const wrapperClass = classNames('doc-library-wrapper', {
    'doc-library-wrapper-shrink': props.isExpanded,
  });

  const TabPanel = (props: any) => {
    const { value, index } = props;
    return (<>
      {
        value === index && index === 0 && tabScreenMapping[0]==='LOAD' &&
        <DocumentLibraryTable
          columnType='Load ID'
          totalRecords={totalRecords}
          tableData={tableData} pageNumber={pageNumber}
          goToPage={(v: number) => setPageNumber(v)}
          reloadTable={reloadTable}
          filterInput={filterInput.inputValue}
          setFilterInput={setFilterInput} accessLevel={loadDocPerm} />
      }
      {
        value === index && index === 0 && tabScreenMapping[0]==='PORT' &&
        <DocumentLibraryTable columnType='Port ID'
        totalRecords={totalRecords}
        tableData={tableData} pageNumber={pageNumber}
        goToPage={(v: number) => setPageNumber(v)}
        reloadTable={reloadTable}
        filterInput={filterInput.inputValue}
        setFilterInput={setFilterInput} accessLevel={portDocPerm} />
      }
      {
        value === index && index === 1 && tabScreenMapping[1]==='PORT' &&
        <DocumentLibraryTable columnType='Port ID'
        totalRecords={totalRecords}
        tableData={tableData} pageNumber={pageNumber}
        goToPage={(v: number) => setPageNumber(v)}
        reloadTable={reloadTable}
        filterInput={filterInput.inputValue}
        setFilterInput={setFilterInput} accessLevel={portDocPerm} />
      }
      {
        value === index && index === 0 && tabScreenMapping[0]==='CONT' &&
        <DocumentLibraryTable columnType='Container ID'
        totalRecords={totalRecords}
        tableData={tableData} pageNumber={pageNumber}
        goToPage={(v: number) => setPageNumber(v)}
        reloadTable={reloadTable}
        filterInput={filterInput.inputValue}
        setFilterInput={setFilterInput} accessLevel={containerDocPerm} />
      }
      {
        value === index && index === 1 && tabScreenMapping[1]==='CONT' &&
        <DocumentLibraryTable columnType='Container ID'
        totalRecords={totalRecords}
        tableData={tableData} pageNumber={pageNumber}
        goToPage={(v: number) => setPageNumber(v)}
        reloadTable={reloadTable}
        filterInput={filterInput.inputValue}
        setFilterInput={setFilterInput} accessLevel={containerDocPerm} />
      }
      {
        value === index && index === 2 && tabScreenMapping[2]==='CONT' &&
        <DocumentLibraryTable columnType='Container ID'
        totalRecords={totalRecords}
        tableData={tableData} pageNumber={pageNumber}
        goToPage={(v: number) => setPageNumber(v)}
        reloadTable={reloadTable}
        filterInput={filterInput.inputValue}
        setFilterInput={setFilterInput} accessLevel={containerDocPerm} />
      }
    </>);
  };

  const filterClass = classNames('doc-library-filter', {
    '': props.isExpanded
  });

  return (
    <section className={wrapperClass}>
      <section className='doc-library-header'>
        <div className='text-header'>{labels.docLibrary}</div>
        <div className='text-menu'>
          <div className="nav" onClick={routeToHome}>{labels.homeNav}</div>&nbsp; &gt; &nbsp;
          <div className="nav">{labels.docLibrary}</div>
        </div>
      </section>
      <div className={filterClass}>
        {activeTabIndex === 0 && tabScreenMapping[0]==='LOAD' &&
          <div>
            <DocumentLibraryFilter
              selectedUsers={selectedUsers}
              selectedDocNames={selectedDocNames}
              onApplyFilter={handleApplyFilter}
              onResetFilter={handleResetFilter}
              filterApplied={isFilterApplied.current}
              documentComponent='LOAD'
              addToSelectedUsers={setSelectedUsers}
              addToSelectedDocNames={setSelectedDocNames} />
          </div>}
          {activeTabIndex === 0 && tabScreenMapping[0]==='PORT' &&
          <div>
            <DocumentLibraryFilter
              selectedUsers={selectedUsers}
              selectedDocNames={selectedDocNames}
              onApplyFilter={handleApplyFilter}
              onResetFilter={handleResetFilter}
              filterApplied={isFilterApplied.current}
              documentComponent='PORT'
              addToSelectedUsers={setSelectedUsers}
              addToSelectedDocNames={setSelectedDocNames} />
          </div>}
          {activeTabIndex === 0 && tabScreenMapping[0]==='CONT' &&
          <div>
            <DocumentLibraryFilter
              selectedUsers={selectedUsers}
              selectedDocNames={selectedDocNames}
              onApplyFilter={handleApplyFilter}
              onResetFilter={handleResetFilter}
              filterApplied={isFilterApplied.current}
              documentComponent='CONTAINER'
              addToSelectedUsers={setSelectedUsers}
              addToSelectedDocNames={setSelectedDocNames} />
          </div>}
        {activeTabIndex === 1 && tabScreenMapping[1]==='PORT' &&
          <div>
            <DocumentLibraryFilter
              selectedUsers={selectedUsers}
              selectedDocNames={selectedDocNames}
              onApplyFilter={handleApplyFilter}
              onResetFilter={handleResetFilter}
              filterApplied={isFilterApplied.current}
              documentComponent='PORT'
              addToSelectedUsers={setSelectedUsers}
              addToSelectedDocNames={setSelectedDocNames} />
          </div>}
          {activeTabIndex === 1 && tabScreenMapping[1]==='CONT' &&
          <div>
            <DocumentLibraryFilter
              selectedUsers={selectedUsers}
              selectedDocNames={selectedDocNames}
              onApplyFilter={handleApplyFilter}
              onResetFilter={handleResetFilter}
              filterApplied={isFilterApplied.current}
              documentComponent='CONTAINER'
              addToSelectedUsers={setSelectedUsers}
              addToSelectedDocNames={setSelectedDocNames} />
          </div>}
          
        {activeTabIndex === 2 && tabScreenMapping[2]==='CONT' &&
          <div>
            <DocumentLibraryFilter
              selectedUsers={selectedUsers}
              selectedDocNames={selectedDocNames}
              onApplyFilter={handleApplyFilter}
              onResetFilter={handleResetFilter}
              filterApplied={isFilterApplied.current}
              documentComponent='CONTAINER'
              addToSelectedUsers={setSelectedUsers}
              addToSelectedDocNames={setSelectedDocNames} />
          </div>}
      </div>
      <section className='doc-library-tabs'>
        <Tabs value={activeTabIndex} onChange={(e, val) => setActiveTabIndex(val)}>
        { loadDocPerm !== 'NA' &&  <Tab data-testid='loadTab' label={labels.loadDoc}></Tab>}
        { portDocPerm !== 'NA' &&   <Tab data-testid='portTab' label={labels.portDoc}></Tab>}
        { containerDocPerm !== 'NA' &&  <Tab data-testid='containerTab' label={labels.containerDoc}></Tab>}
        </Tabs>
       { tabScreenMapping.length > 0 && <TabPanel value={activeTabIndex} index={0} />}
       { tabScreenMapping.length > 1 && <TabPanel value={activeTabIndex} index={1} />}
       { tabScreenMapping.length > 2 && <TabPanel value={activeTabIndex} index={2} />}
      </section>
    </section>
  );
};

export default DocumentLibrary;