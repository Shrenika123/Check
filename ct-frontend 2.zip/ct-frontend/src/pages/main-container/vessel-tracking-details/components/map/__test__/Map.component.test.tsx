import '@testing-library/jest-dom';
import { cleanup, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import Map from '../Map.component';
import { routes } from '../../../../../../common/navigation-utils';

afterEach(cleanup);

describe('Map Component', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };

  const mockLiveTrackingData = [{
    "createdDateTime": "1.671781002718E9",
    "carrierId": "6529355",
    "carrierName": "WAN HAI 326",
    "fromLocationId": "263",
    "fromLocation": "KOBE",
    "toLocationId": "483",
    "toLocation": "PORT KLANG",
    "locationId": "263",
    "locationName": "KOBE",
    "startDateTime": "2022-11-30",
    "endDateTime": "2022-12-10",
    "locationType": "port",
    "containerId": "CNT5187",
    "shipmentStatus": "Underway",
    "imo": "9871488",
    "mmsi": "563124200",
    "eventType": "exit",
    "locationLatitude": "34.68669891357422",
    "locationLongitude": "135.26710510253906",
    "fromLocationLatitude": "34.68669891357422",
    "fromLocationLongitude": "135.26710510253906",
    "toLocationLatitude": "2.984100103378296",
    "toLocationLongitude": "101.35870361328125",
    "delayInDays": 18,
    "arrivalEventTime": null,
    "arrivalEstimatedTime": null,
    "departureEventTime": "2022-11-30",
    "departureEstimatedTime": "2022-11-30",
    "fromPort": true,
    "toPort": false,
    "intermediatePort": false,
    "upcomingPort": false,
    "mabd": "2022-12-23"
  }];
  const mockVesselHistory = [
    {
      "trackerGeoLatitude": -15.633709907531738,
      "trackerGeoLongitude": -148.76220703125
    },
    {
      "trackerGeoLatitude": -15.633709907531738,
      "trackerGeoLongitude": -148.76220703125
    }
  ];

  test('should render component', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <Map
          singleVesselData={mockLiveTrackingData}
          activeVesselId={'6529355'}
          currentVesselTab={'6529355'}
          vesselHistoryCoordinates={mockVesselHistory}
        />
      </Provider>, { wrapper: BrowserRouter }
    );
  });

  test('should render component for previous vessel', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <Map
          singleVesselData={mockLiveTrackingData}
          activeVesselId={'6529355'}
          currentVesselTab={'416446'}
          vesselHistoryCoordinates={mockVesselHistory}
        />
      </Provider>, { wrapper: BrowserRouter }
    );
  });

  test('should render component for previous vessel with no history path', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <Map
          singleVesselData={mockLiveTrackingData}
          activeVesselId={'6529355'}
          currentVesselTab={'416446'}
          vesselHistoryCoordinates={[]}
        />
      </Provider>, { wrapper: BrowserRouter }
    );
  });
});