import { useEffect, useState } from 'react';
import { Marker, Polyline, Tooltip } from "react-leaflet";
import { ITransShipmentMapMarkersProps } from '../../../../../common/interfaces';
import { destinationIcon, shipIcon, sourceIcon } from '../../../../../common/markers';
import RotatedMarker from '../../../../../components/rotated-marker/RotatedMarker.component';

function TrackingDetailsMapMarkers(props: ITransShipmentMapMarkersProps) {

  const [markerAngle, setMarkerAngle] = useState(0);

  useEffect(() => {
    if (props.vesselHistoryCoordinates && props.vesselHistoryCoordinates.length > 0) {
      // calculating rotation angle for the ship marker
      const currentPosition: number[] = [props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLatitude, props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLongitude];
      const finalPosition: number[] = [Number(props.data[props.data.length - 1].locationLatitude), Number(props.data[props.data.length - 1].locationLongitude)];
      let rotationAngle = Math.atan2(finalPosition[0] - currentPosition[0], finalPosition[1] - currentPosition[1]);
      rotationAngle = rotationAngle * (180 / Math.PI);
      rotationAngle = (rotationAngle + 360) % 360;
      rotationAngle = 360 - rotationAngle;
      setMarkerAngle(rotationAngle);
    }
  }, [props.data, props.vesselHistoryCoordinates]);

  return (
    <>
      {
        <>
          {/* intermediate source marker */}
          <Marker position={[Number(props.data[0].locationLatitude), Number(props.data[0].locationLongitude)]} icon={sourceIcon}>
            <Tooltip offset={[0, -17] as any} direction='top'>
              <strong>{props.data[0].locationName}</strong>
              <p>ID: {props.data[0].locationId}</p>
            </Tooltip>
          </Marker>
          {/* intermediate destination marker */}
          <Marker position={[Number(props.data[props.data.length - 1].locationLatitude), Number(props.data[props.data.length - 1].locationLongitude)]} icon={destinationIcon}>
            <Tooltip offset={[0, -17] as any} direction='top'>
              <strong>{props.data[props.data.length - 1].locationName}</strong>
              <p>ID: {props.data[props.data.length - 1].locationId}</p>
            </Tooltip>
          </Marker>
        </>
      }
      {
        // if activeVesselId and currentVesselTab matches then display the ship marker and its track lines
        // else only show track lines between source and destination
        (props.activeVesselId === props.currentVesselTab && props.vesselHistoryCoordinates && props.vesselHistoryCoordinates.length > 0) ? (
          <>
            {/* vessel marker */}
            <RotatedMarker
              alt='vessel-marker'
              position={[props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLatitude, props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLongitude]}
              // eventHandlers={{ click: () => props.handleTrackerClick(props.data) }}
              icon={shipIcon}
              rotationAngle={markerAngle}
              rotationOrigin='center'
            >
              <Tooltip offset={[0, -5] as any} direction='top'>
                <strong>{props.data[0].carrierName}</strong><br />
                <p>Vessel Id: {props.data[0].carrierId}</p>
                <p>IMO: {props.data[0].imo}</p>
                <p>MMSI: {props.data[0].mmsi}</p>
              </Tooltip>
            </RotatedMarker>
            {/* vessel history track lines */}
            {
              (props.vesselHistoryCoordinates && props.vesselHistoryCoordinates.length > 0) && (
                <>
                  <Polyline
                    pathOptions={{ color: '#8791C2', weight: 2 }}
                    positions={[[Number(props.data[0].locationLatitude), Number(props.data[0].locationLongitude)], [props.vesselHistoryCoordinates[0].trackerGeoLatitude, props.vesselHistoryCoordinates[0].trackerGeoLongitude]]}
                  />
                  {
                    props.vesselHistoryCoordinates?.map((coordinate, index, coordinateArray) => {
                      if (index < coordinateArray.length - 1) {
                        return (
                          <Polyline
                            key={coordinate.key}
                            pathOptions={{ color: '#8791C2', weight: 2 }}
                            positions={[[coordinateArray[index].trackerGeoLatitude, coordinateArray[index].trackerGeoLongitude], [coordinateArray[index + 1].trackerGeoLatitude, coordinateArray[index + 1].trackerGeoLongitude]]}
                          />
                        );
                      }
                    })
                  }
                  <Polyline
                    pathOptions={{ color: '#8791C2', weight: 2, dashArray: '4' }}
                    positions={[[props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLatitude, props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLongitude], [Number(props.data[props.data.length - 1].locationLatitude), Number(props.data[props.data.length - 1].locationLongitude)]]}
                  />
                </>
              )
            }
          </>
        ) : (
          <>
            {
              (props.vesselHistoryCoordinates && props.vesselHistoryCoordinates.length > 0) ? (
                <>
                  <Polyline
                    pathOptions={{ color: '#8791C2', weight: 2 }}
                    positions={[[Number(props.data[0].locationLatitude), Number(props.data[0].locationLongitude)], [props.vesselHistoryCoordinates[0].trackerGeoLatitude, props.vesselHistoryCoordinates[0].trackerGeoLongitude]]}
                  />
                  {
                    props.vesselHistoryCoordinates?.map((coordinate, index, coordinateArray) => {
                      if (index < coordinateArray.length - 1) {
                        return (
                          <Polyline
                            key={coordinate.key}
                            pathOptions={{ color: '#8791C2', weight: 2 }}
                            positions={[[coordinateArray[index].trackerGeoLatitude, coordinateArray[index].trackerGeoLongitude], [coordinateArray[index + 1].trackerGeoLatitude, coordinateArray[index + 1].trackerGeoLongitude]]}
                          />
                        );
                      }
                    })
                  }
                  <Polyline
                    pathOptions={{ color: '#8791C2', weight: 2 }}
                    positions={[[props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLatitude, props.vesselHistoryCoordinates[props.vesselHistoryCoordinates.length - 1].trackerGeoLongitude], [Number(props.data[props.data.length - 1].locationLatitude), Number(props.data[props.data.length - 1].locationLongitude)]]}
                  />
                </>
              ) : (
                <>
                  {
                    // for future vessel scenario.
                    // future vessel will always have the first port's departureEventTime as null ('data[0].departureEventTime'). so we need to show dotted line for this scenario.
                    // and non-dotted line for past vessel
                    props.data[0].departureEventTime !== null && (
                      <Polyline
                        pathOptions={{ color: '#8791C2', weight: 2 }}
                        positions={[[Number(props.data[0].locationLatitude), Number(props.data[0].locationLongitude)], [Number(props.data[props.data.length - 1].locationLatitude), Number(props.data[props.data.length - 1].locationLongitude)]]}
                      />
                    )
                  }
                  {
                    props.data[0].departureEventTime === null && (
                      <Polyline
                        pathOptions={{ color: '#8791C2', weight: 2, dashArray: '4' }}
                        positions={[[Number(props.data[0].locationLatitude), Number(props.data[0].locationLongitude)], [Number(props.data[props.data.length - 1].locationLatitude), Number(props.data[props.data.length - 1].locationLongitude)]]}
                      />
                    )
                  }
                </>
              )
            }
          </>
        )
      }
    </>
  );
}

export default TrackingDetailsMapMarkers;