import { ReactElement, useEffect } from 'react';
import { useMap } from 'react-leaflet';
import { ITransShipmentMapProps } from '../../../../../common/interfaces';
import TrackingDetailsMapMarkers from './TrackingDetailsMapMarkers.component';

function Map(props: ITransShipmentMapProps): ReactElement {
  const map = useMap();

  useEffect(() => {
    map.flyToBounds?.([[Number(props.singleVesselData[0].locationLatitude), Number(props.singleVesselData[0].locationLongitude)], [Number(props.singleVesselData[props.singleVesselData.length - 1].locationLatitude), Number(props.singleVesselData[props.singleVesselData.length - 1].locationLongitude)]], { padding: [60, 60] });
  }, [props.singleVesselData]);

  return (
    <>
      {
        <TrackingDetailsMapMarkers
          data={props.singleVesselData}
          activeVesselId={props.activeVesselId}
          currentVesselTab={props.currentVesselTab}
          vesselHistoryCoordinates={props.vesselHistoryCoordinates}
        />
      }
    </>
  );

}

export default Map;