import React, { useCallback, useEffect, useRef, useState } from 'react';
import ShippedIcon from '../../../../../assets/icons/DelayedPending.svg';
import DepartCompleted from '../../../../../assets/icons/DepartedCompleted.svg';
import DepartedPending from '../../../../../assets/icons/DepartedPending.svg';
import ArrivalCompleted from '../../../../../assets/icons/ArrivedCompleted.svg';
import ArrivalPending from '../../../../../assets/icons/ArrivedPending.svg';
import PortCompleted from '../../../../../assets/icons/PortCompleted.svg';
import PortPending from '../../../../../assets/icons/PortPending.svg';
import VesselPort from '../../../../../assets/icons/VesselPort.svg';
import TrackerShip from '../../../../../assets/images/TrackerShip.png';
import { labels } from '../../../../../common/constants';
import {
  ITransShipmentTrackingDetails,
  TrackerState,
} from '../../../../../common/interfaces';
import Text from '../../../../../components/atoms/Text';
import Tracker from '../../../../../components/Tracker/Tracker.component';
import './ContainerTracker.style.css';
import classNames from 'classnames';
import { getFormattedDate } from '../../../../../common/utils';

interface ContainerTrackerProps {
  data: ITransShipmentTrackingDetails[];
}

const ContainerTracker: React.FC<ContainerTrackerProps> = ({ data }) => {
  const iconRefs = useRef<HTMLElement[]>([]);
  const [vesselTrackerInfo, setVesselTrackerInfo] = useState<
    ITransShipmentTrackingDetails[]
  >([]);
  const [currentActivePort, setCurrentActivePort] = useState<number | null>(
    null
  );

useEffect(() => {
  let activePort = data.findIndex(
    (item, i) => item.upcomingPort === true && i > 0
  );
  if (activePort === 1 && !data[0].departureEventTime) {
    setCurrentActivePort(-1);
  } else {
    setCurrentActivePort(activePort);
  }

  return () => {
    setVesselTrackerInfo([]);
    iconRefs.current = [];
  };
}, [data]);

  //This function adds an element to the vesselInfo:the ship is in aport which is arrived but yet to be departed else add the api response to vesselInfo
  const insertShipOrAddVesselElement = useCallback(() => {
    if (currentActivePort && vesselTrackerInfo.length === 0) {
      if (
        (currentActivePort > 0 &&
          currentActivePort !== data.length - 1 &&
          !data[currentActivePort].arrivalEventTime &&
          !data[currentActivePort].departureEventTime) ||
        (currentActivePort === data.length - 1 &&
          !data[currentActivePort].arrivalEventTime)
      ) {
        let obj = { ...data[0] };
        obj.isShipment = true;
        obj.upcomingPort = true;
        obj.fromPort = obj.toPort = false;
        const dataVessel = [...data];
        setVesselTrackerInfo([
          ...dataVessel.slice(0, currentActivePort),
          obj,
          ...dataVessel.slice(currentActivePort),
        ]);
      } else setVesselTrackerInfo(data);
    }
  }, [currentActivePort, data, vesselTrackerInfo]);

  useEffect(() => {
    insertShipOrAddVesselElement();
  }, [insertShipOrAddVesselElement]);

  useEffect(() => {
    if (vesselTrackerInfo.length > 0 && currentActivePort) {
      if (currentActivePort && currentActivePort > 0) {
        iconRefs.current[currentActivePort]?.scrollIntoView?.({
          behavior: 'smooth',
          inline: 'center',
        });
      }
    }
  }, [vesselTrackerInfo, currentActivePort]);

  const getDelayedComponent = (): React.ReactNode => {
    return (
      <button
        data-testid='delayedButton-testid'
        className='delayedButton'
        disabled
      >
        {TrackerState.DELAYED}
      </button>
    );
  };

  const getTrackerIcon = (
    state: TrackerState,
    item: ITransShipmentTrackingDetails,
    element: number,
    active = false
  ) => {
    switch (state) {
      case TrackerState.SHIPMENT:
        return ShippedIcon;
      case TrackerState.DEPARTED:
        return !item.departureEventTime ? DepartedPending : DepartCompleted;
      case TrackerState.DESTINATION:
        return !item.arrivalEventTime ? ArrivalPending : ArrivalCompleted;
      case TrackerState.STOP:
        if (currentActivePort === element) {
          if (item.arrivalEventTime && !item.departureEventTime) {
            return VesselPort;
          }
          return active ? PortPending : PortCompleted;
        }
        return active ? PortPending : PortCompleted;
    }
  };

  const getLabelType = (item: ITransShipmentTrackingDetails): TrackerState => {
    if (item?.isShipment) {
      return TrackerState.SHIPMENT;
    } else if (item.fromPort) {
      return TrackerState.DEPARTED;
    } else if (item.toPort) {
      return TrackerState.DESTINATION;
    } else return TrackerState.STOP;
  };

  const getTrackerDate = (item: ITransShipmentTrackingDetails) => {
    if (item.isShipment) {
      if (item.delayInDays > 0)
        return (
          <div className='delayByDays'>
            {`By ${item.delayInDays} ${item.delayInDays > 1 ? 'Days' : 'Day'}`}
          </div>
        );
      else return <></>;
    } else if (item.fromPort) {
      return (
        <Text label={labels.Departure} classNameText='arrivalDepartureText'>
          <p
            className={
              item.departureEventTime
                ? 'dateActiveFormat'
                : 'dateInActiveFormat'
            }
          >
            {getFormattedDate(
              item.departureEventTime ?? item.departureEstimatedTime!
            )}
          </p>
        </Text>
      );
    } else if (item.toPort) {
      return (
        <Text label={labels.Arrival} classNameText='arrivalDepartureText'>
          <p
            className={classNames(
              'dateInActiveFormat',
              item.delayInDays > 0
                ? 'DestinationPortDelay'
                : 'DestinationPortNoDelay'
            )}
          >
            {`${!item.arrivalEventTime ? 'ETA' : ''} ${getFormattedDate(
              item.arrivalEventTime ?? item.arrivalEstimatedTime!
            )}`}
          </p>
        </Text>
      );
    } else {
      return (
        <div className='departureArrivalContainer'>
          <Text label={labels.Arrival} classNameText='arrivalDepartureText'>
            <p
              className={classNames(
                item.arrivalEventTime
                  ? 'dateActiveFormat'
                  : 'dateInActiveFormat',
                'arrivalDate'
              )}
            >
              {getFormattedDate(
                item.arrivalEventTime ?? item.arrivalEstimatedTime!
              )}
            </p>
          </Text>
          <Text label={labels.Departure} classNameText='arrivalDepartureText'>
            <p
              className={
                item.departureEventTime
                  ? 'dateActiveFormat'
                  : 'dateInActiveFormat'
              }
            >
              {getFormattedDate(
                item.departureEventTime ?? item.departureEstimatedTime!
              )}
            </p>
          </Text>
        </div>
      );
    }
  };

  const getClassName = (item: ITransShipmentTrackingDetails) => {
    if (item.fromPort) {
      if (item.departureEventTime) return 'inActiveTracker';
      else return 'activeTracker';
    } else if (item.toPort) {
      if (item.arrivalEventTime) return 'inActiveTracker';
      else return 'activeTracker';
    } else {
      return item.upcomingPort ? 'activeTracker' : 'inActiveTracker';
    }
  };

  const getPortNameOrPortDelayedItem = (
    item: ITransShipmentTrackingDetails,
    element: number
  ) => {
    let location = item.locationName.toUpperCase();
    if (
      currentActivePort === element &&
      item.arrivalEventTime &&
      !item.departureEventTime &&
      currentActivePort !== data.length - 1
    ) {
      return (
        <>
          <span className='portWithDelay'>{`PORT - ${location}`}</span>
          {item.delayInDays > 0 && getDelayedComponent()}
        </>
      );
    } else {
      return `PORT - ${location}`;
    }
  };

  const getTrackerElements = () => {
    iconRefs.current = [];
    return vesselTrackerInfo.map((item: ITransShipmentTrackingDetails, i) => {
      let label = getLabelType(item);
      return {
        content: (
          <Text
            label={
              label === TrackerState.SHIPMENT
                ? item.delayInDays > 0 && getDelayedComponent()
                : getPortNameOrPortDelayedItem(item, i)
            }
            className='left'
            size='medium'
            bold='bold'
            key={i}
          >
            <div className='dateContainer' data-testid='date-testId'>
              {getTrackerDate(item)}
            </div>
          </Text>
        ),
        icon: (
          <img
            src={getTrackerIcon(label, item, i, item.upcomingPort)}
            alt='icon'
            className={classNames(
              'iconTrackerElement',
              label === TrackerState.DEPARTED ? 'delayedShipIcon' : ''
            )}
            data-testid='icon-testid'
            key={i}
            ref={(element) => (iconRefs.current[i] = element!)}
          />
        ),
        className: getClassName(item),
      };
    });
  };

  const getLeftTrackerCard = (): React.ReactNode => {
    const { imo, mmsi, carrierName, carrierId } = data[0];
    return (
      <div className='mainLeftCardContainer'>
        <img src={TrackerShip} alt='ship' />
        <Text label={carrierName} size='medium' bold='bold' color='#B6F24D'>
          <p
            data-testid='vesselId-testid'
            className='vesselID'
          >{`${labels.VesselId} - ${carrierId}`}</p>
          <div className='mainLeftCardRightContainer'>
            <Text label={labels.imo} size='medium' color='#666666'>
              <p data-testid='imo-testid' className='imoMmsi'>
                {imo}
              </p>
            </Text>
            <Text label={labels.mmsi} size='medium' color='#666666'>
              <p data-testid='mmsi-testid' className='imoMmsi'>
                {mmsi}
              </p>
            </Text>
          </div>
        </Text>
      </div>
    );
  };

  return (
    <div data-testid='trackerContainer-testId' className='trackerContainer'>
      {getLeftTrackerCard()}
      <div data-testid='vl-testId' className='vl' />
      {vesselTrackerInfo.length > 0 && <Tracker data={getTrackerElements()} />}
    </div>
  );
};
export default ContainerTracker;
