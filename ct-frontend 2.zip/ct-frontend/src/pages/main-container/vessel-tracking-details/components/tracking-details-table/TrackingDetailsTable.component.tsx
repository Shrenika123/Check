import classNames from 'classnames';
import { FC, ReactElement, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import backicon from '../../../../../assets/images/backicon.png';
import { routes } from '../../../../../common/constants';
import {
  IRoutePermission,
  ITrackingDetailsShipmentTable,
  IUserState,
  IVesselTrackingDetailsTableProps
} from '../../../../../common/interfaces';
import { getFormattedDate } from '../../../../../common/utils';
import ConfirmationBox from '../../../../../components/confimation-box/ConfirmationBox.component';
import './TrackingDetailsTable.style.css';
import { useSelector } from 'react-redux';

const TrackingDetailsTable: FC<IVesselTrackingDetailsTableProps> = (
  props
): ReactElement => {
  
  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const poLinePerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'PO_LINE_MANAGEMENT')?.permission;
 
  const tableClassname = classNames('table');
  const tableWrapperClassname = classNames({
    'table-wrapper': props.tableShipmentData?.length > 3,
  });

  const [isConfirmBoxOpen, setConfirmBoxOpen] = useState<boolean>(false);
  const clickedPORef = useRef<{ poNumber: string, mabd: string; }>();

  const navigate = useNavigate();

  const handlePOClick = (data: { poNumber: string, mabd: string; }) => {
    clickedPORef.current = data;
    setConfirmBoxOpen(true);
  };

  const navigateToPOLine = () => {
    navigate(`/${routes.lineDetails}`, { state: clickedPORef.current });
  };
  return (
    <section id='vesselTrackingDetails-table'>
      <div className={tableWrapperClassname}>
        <table className={tableClassname}>
          <thead>
            <tr>
              <th>MABD</th>
              <th>Shipment ID</th>
              <th>Load ID</th>
              <th>PO Number</th>
              <th>Vendor Name</th>
              <th>No. of Items</th>
              <th>Origin</th>
              <th>Destination</th>
              <th>Status</th>
              <th>ETA</th>
            </tr>
          </thead>
          <tbody>
            {props.tableShipmentData ?
              props.tableShipmentData.map(
                (data: ITrackingDetailsShipmentTable) => {
                  return (
                    <tr key={data.key}>
                      <td>{getFormattedDate(data.mabd)}</td>
                      <td>{data.shipmentId}</td>
                      <td>{data.loadid}</td>
                      <td>
                        <div 
                          className={ poLinePerm && poLinePerm !== 'NA' ? 'hyperlink' : 'non-hyperlink' }
                          onClick={() => handlePOClick({ poNumber: data.poNumber, mabd: data.mabd })}>{data.poNumber}
                        </div>
                      </td>
                      <td>{data.vendorName.toUpperCase()}</td>
                      <td>{data.noOfItems}</td>
                      <td>{data.fromLocation.toUpperCase()}</td>
                      <td>{data.toLocation.toUpperCase()}</td>
                      <td>{data.shipmentStatus}</td>
                      <td>{getFormattedDate(data.eta)}</td>
                    </tr>
                  );
                }
              ) : (
                <tr>
                  <td colSpan={10}>No data</td>
                </tr>
              )}
          </tbody>
        </table>
      </div>
      <ConfirmationBox title='Leave this page?'
        content='You will be redirected to Line Management page'
        open={isConfirmBoxOpen} onClose={() => setConfirmBoxOpen(false)}
        confirmAction={() => navigateToPOLine()}
        cancelAction={() => setConfirmBoxOpen(false)}
        image={<img src={backicon} alt='' />} />
    </section>
  );
};

export default TrackingDetailsTable;