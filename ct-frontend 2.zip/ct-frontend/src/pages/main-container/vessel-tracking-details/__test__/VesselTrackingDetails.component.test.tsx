import '@testing-library/jest-dom';
import { act, cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import MainContainer from '../../MainContainer';

afterEach(cleanup);

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useLocation: () => ({
    pathname: "/vessel-tracking/details",
    state: {
      containerId: 'CNT6738',
    }
  }),
}));

describe('Vessel Tracking Details', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };
  const mockResponseActiveVesselId = {
    data: {
      'activeVesselId': '4812085',
      "vesselIds": [
        '4812084',
        "4812085"
      ],
      'vesselDetailsMap': {
        '4812084': [
          {
            "createdDateTime": "1.673853737479E9",
            "carrierId": "4812084",
            "carrierName": "EVER GOLDEN",
            "fromLocationId": " PORT699",
            "fromLocation": "Amsterdam",
            "toLocationId": "PORT534 ",
            "toLocation": "Sueze Canal",
            "locationId": " PORT699",
            "locationName": "Amsterdam",
            "startDateTime": "2022-12-25",
            "endDateTime": "2023-01-17",
            "locationType": "Port",
            "containerId": "CNT9642",
            "shipmentStatus": "Underway",
            "imo": "4532966",
            "mmsi": "512903266",
            "eventType": "exit",
            "locationLatitude": "52.36061477661133",
            "locationLongitude": "4.986117839813232",
            "fromLocationLatitude": "52.36061477661133",
            "fromLocationLongitude": "4.986117839813232",
            "toLocationLatitude": "29.955902099609375",
            "toLocationLongitude": "32.526641845703125",
            "delayInDays": 4,
            "arrivalEventTime": "2023-01-03",
            "arrivalEstimatedTime": "2023-01-03",
            "departureEventTime": "2023-01-03",
            "departureEstimatedTime": "2023-01-03",
            "fromPort": true,
            "toPort": false,
            "intermediatePort": false,
            "upcomingPort": false,
            "mabd": "2023-01-13"
          },
          {
            "createdDateTime": "1.673853737479E9",
            "carrierId": "4812084",
            "carrierName": "EVER GOLDEN",
            "fromLocationId": " PORT699",
            "fromLocation": "Amsterdam",
            "toLocationId": "PORT534 ",
            "toLocation": "Sueze Canal",
            "locationId": "PORT534 ",
            "locationName": "Sueze Canal",
            "startDateTime": "2022-12-25",
            "endDateTime": "2023-01-17",
            "locationType": "Port",
            "containerId": "CNT9642",
            "shipmentStatus": "Underway",
            "imo": "4532966",
            "mmsi": "512903266",
            "eventType": "enter",
            "locationLatitude": "29.955902099609375",
            "locationLongitude": "32.526641845703125",
            "fromLocationLatitude": "52.36061477661133",
            "fromLocationLongitude": "4.986117839813232",
            "toLocationLatitude": "29.955902099609375",
            "toLocationLongitude": "32.526641845703125",
            "delayInDays": 4,
            "arrivalEventTime": null,
            "arrivalEstimatedTime": "2023-01-17",
            "departureEventTime": null,
            "departureEstimatedTime": null,
            "fromPort": false,
            "toPort": true,
            "intermediatePort": false,
            "upcomingPort": true,
            "mabd": "2023-01-13"
          }
        ],
        '4812085': [
          {
            "createdDateTime": "1.673853737479E9",
            "carrierId": "4812085",
            "carrierName": "EVER GOLDEN",
            "fromLocationId": " PORT699",
            "fromLocation": "Amsterdam",
            "toLocationId": "PORT534 ",
            "toLocation": "Sueze Canal",
            "locationId": " PORT699",
            "locationName": "Amsterdam",
            "startDateTime": "2022-12-25",
            "endDateTime": "2023-01-17",
            "locationType": "Port",
            "containerId": "CNT9642",
            "shipmentStatus": "Underway",
            "imo": "4532966",
            "mmsi": "512903266",
            "eventType": "exit",
            "locationLatitude": "52.36061477661133",
            "locationLongitude": "4.986117839813232",
            "fromLocationLatitude": "52.36061477661133",
            "fromLocationLongitude": "4.986117839813232",
            "toLocationLatitude": "29.955902099609375",
            "toLocationLongitude": "32.526641845703125",
            "delayInDays": 4,
            "arrivalEventTime": "2023-01-03",
            "arrivalEstimatedTime": "2023-01-03",
            "departureEventTime": "2023-01-03",
            "departureEstimatedTime": "2023-01-03",
            "fromPort": true,
            "toPort": false,
            "intermediatePort": false,
            "upcomingPort": false,
            "mabd": "2023-01-13"
          },
          {
            "createdDateTime": "1.673853737479E9",
            "carrierId": "4812085",
            "carrierName": "EVER GOLDEN",
            "fromLocationId": " PORT699",
            "fromLocation": "Amsterdam",
            "toLocationId": "PORT534 ",
            "toLocation": "Sueze Canal",
            "locationId": "PORT534 ",
            "locationName": "Sueze Canal",
            "startDateTime": "2022-12-25",
            "endDateTime": "2023-01-17",
            "locationType": "Port",
            "containerId": "CNT9642",
            "shipmentStatus": "Underway",
            "imo": "4532966",
            "mmsi": "512903266",
            "eventType": "enter",
            "locationLatitude": "29.955902099609375",
            "locationLongitude": "32.526641845703125",
            "fromLocationLatitude": "52.36061477661133",
            "fromLocationLongitude": "4.986117839813232",
            "toLocationLatitude": "29.955902099609375",
            "toLocationLongitude": "32.526641845703125",
            "delayInDays": 4,
            "arrivalEventTime": null,
            "arrivalEstimatedTime": "2023-01-17",
            "departureEventTime": null,
            "departureEstimatedTime": null,
            "fromPort": false,
            "toPort": true,
            "intermediatePort": false,
            "upcomingPort": true,
            "mabd": "2023-01-13"
          }
        ]
      }
    }
  };
  const mockResponseActiveVesselIdNull = {
    data: {
      'activeVesselId': null,
      "vesselIds": [
        "4812085"
      ],
      'vesselDetailsMap': {
        '4812085': [
          {
            "createdDateTime": "1.673853737479E9",
            "carrierId": "4812085",
            "carrierName": "EVER GOLDEN",
            "fromLocationId": " PORT699",
            "fromLocation": "Amsterdam",
            "toLocationId": "PORT534 ",
            "toLocation": "Sueze Canal",
            "locationId": " PORT699",
            "locationName": "Amsterdam",
            "startDateTime": "2022-12-25",
            "endDateTime": "2023-01-17",
            "locationType": "Port",
            "containerId": "CNT9642",
            "shipmentStatus": "Underway",
            "imo": "4532966",
            "mmsi": "512903266",
            "eventType": "exit",
            "locationLatitude": "52.36061477661133",
            "locationLongitude": "4.986117839813232",
            "fromLocationLatitude": "52.36061477661133",
            "fromLocationLongitude": "4.986117839813232",
            "toLocationLatitude": "29.955902099609375",
            "toLocationLongitude": "32.526641845703125",
            "delayInDays": 4,
            "arrivalEventTime": "2023-01-03",
            "arrivalEstimatedTime": "2023-01-03",
            "departureEventTime": "2023-01-03",
            "departureEstimatedTime": "2023-01-03",
            "fromPort": true,
            "toPort": false,
            "intermediatePort": false,
            "upcomingPort": false,
            "mabd": "2023-01-13"
          },
          {
            "createdDateTime": "1.673853737479E9",
            "carrierId": "4812085",
            "carrierName": "EVER GOLDEN",
            "fromLocationId": " PORT699",
            "fromLocation": "Amsterdam",
            "toLocationId": "PORT534 ",
            "toLocation": "Sueze Canal",
            "locationId": "PORT534 ",
            "locationName": "Sueze Canal",
            "startDateTime": "2022-12-25",
            "endDateTime": "2023-01-17",
            "locationType": "Port",
            "containerId": "CNT9642",
            "shipmentStatus": "Underway",
            "imo": "4532966",
            "mmsi": "512903266",
            "eventType": "enter",
            "locationLatitude": "29.955902099609375",
            "locationLongitude": "32.526641845703125",
            "fromLocationLatitude": "52.36061477661133",
            "fromLocationLongitude": "4.986117839813232",
            "toLocationLatitude": "29.955902099609375",
            "toLocationLongitude": "32.526641845703125",
            "delayInDays": 4,
            "arrivalEventTime": null,
            "arrivalEstimatedTime": "2023-01-17",
            "departureEventTime": null,
            "departureEstimatedTime": null,
            "fromPort": false,
            "toPort": true,
            "intermediatePort": false,
            "upcomingPort": true,
            "mabd": "2023-01-13"
          }
        ]
      }
    }
  };

  test('should render component with getTransShipmentTrackingDetails with activeVesselId', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getTransShipmentDetails').mockResolvedValue(mockResponseActiveVesselId);

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTrackingDetails} />
      </Provider>, { wrapper: BrowserRouter }
    );

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });

  });

  test('should render component with getTransShipmentTrackingDetails with activeVesselId as null', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getTransShipmentDetails').mockResolvedValue(mockResponseActiveVesselIdNull);

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTrackingDetails} />
      </Provider>, { wrapper: BrowserRouter }
    );

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });

  });

  test('should render component with error 404', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getTransShipmentDetails')
      .mockRejectedValueOnce({ code: 'ERR_NETWORK', response: { status: 404, data: {} } });

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTrackingDetails} />
      </Provider>, { wrapper: BrowserRouter }
    );

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });
  });

  test('should render component with error 500', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getTransShipmentDetails')
      .mockRejectedValueOnce({ code: 'ERR_NETWORK', response: { status: 500, data: {} } });

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTrackingDetails} />
      </Provider>, { wrapper: BrowserRouter }
    );

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });
  });

  test('should check back button click', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTrackingDetails} />
      </Provider>, { wrapper: BrowserRouter }
    );

    const backBtn = screen.getByTestId('back-button');
    userEvent.click(backBtn);

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });
  });
});