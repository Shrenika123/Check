import classNames from 'classnames';
import { IVessel } from '../../../common/interfaces';

export const mapSectionClass = (isExpanded: boolean) => classNames('map-section', {
  'map-section-shrink': isExpanded,
});
export const headerClass = (isExpanded: boolean) => classNames('header', {
  'header-shrink': isExpanded,
});
export const subHeaderClass = (isExpanded: boolean) => classNames('subheader', {
  'subheader-shrink': isExpanded,
});
export const rightSubheaderContainerClass = (singleTrackingData?: IVessel | null) => classNames('right-subheader-container', {
  'hide': singleTrackingData !== null,
});
export const resetButtonClass = classNames('reset-button', {
  // 'disable': singleTrackingData === null && inputFilterData === ''
});
export const nextPageButtonClass = (pageNumber: number, totalRecords: number, pageSize: number) => classNames('next-page-button', {
  'disable': pageNumber === Math.ceil(totalRecords! / pageSize)
});
export const previousPageButtonClass = (pageNumber: number) => classNames('previous-page-button', {
  'disable': pageNumber === 1
});
export const cardSectionClass = (isExpanded: boolean) => classNames('card-section', {
  'card-section-shrink': isExpanded,
});
export const vesselTabsClass = (isExpanded: boolean) => classNames('vessel-tabs', {
  'vessel-tabs-shrink': isExpanded
});
export const tablePaginationClass = (isExpanded: boolean) => classNames('table-with-pagination', {
  'table-with-pagination-shrink': isExpanded
});
