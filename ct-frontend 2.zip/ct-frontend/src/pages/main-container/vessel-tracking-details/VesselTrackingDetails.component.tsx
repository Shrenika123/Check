import DirectionsBoatIcon from '@mui/icons-material/DirectionsBoat';
import Pagination from '@mui/material/Pagination';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { nanoid } from 'nanoid';
import { Card } from 'primereact/card';
import { FC, ReactElement, useEffect, useState } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useDispatch } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { routes, tableConfig } from '../../../common/constants';
import { ITrackingDetailsShipmentTable, ITransShipmentTracking, ITransShipmentTrackingDetails, IVesselHistoryCoordinate } from '../../../common/interfaces';
import { getTransShipmentDetails, getTransShipmentPoDetails, getTransShipmentPoDetailsCount, getVesselHistoryCoordinates, postActivityTrackerDetails } from '../../../common/utils';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import ContainerTracker from './components/ContainerTrackerComponent/ContainerTracker.component';
import Map from './components/map/Map.component';
import TrackingDetailsTable from './components/tracking-details-table/TrackingDetailsTable.component';
import { cardSectionClass, headerClass, mapSectionClass, subHeaderClass, tablePaginationClass, vesselTabsClass } from './VesselTrackingDetails.classnames';
import './VesselTrackingDetails.style.css';

const VesselTrackingDetails: FC<{ isExpanded: boolean; }> = (props): ReactElement => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();

  const [transShipmentTracking, setTransShipmentTracking] = useState<ITransShipmentTracking | null>(null);
  const [singleVesselData, setSingleVesselData] = useState<ITransShipmentTrackingDetails[]>([]);
  const [containerId] = useState<string>(location.state?.containerId);
  const [tableShipmentData, setTableShipmentData] = useState<ITrackingDetailsShipmentTable[] | null>(null);
  // for pagination - start
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [totalRecord, setTotalRecord] = useState<number>(0);
  // for pagination - end

  // this is for handling the tab index
  const [activeVesselTabIndex, setActiveVesselTabIndex] = useState(0);
  // this is for handling the current selected tab
  const [currentVesselTab, setCurrentVesselTab] = useState<string | null>(null);
  // this we get from api response
  const [activeVesselId, setActiveVesselId] = useState<string | null>(null);
  // to store single vessel's history of coordinates
  const [vesselHistoryCoordinates, setVesselHistoryCoordinates] = useState<IVesselHistoryCoordinate[] | null>(null);

  // fetching transhipment tracking details of the containerId
  useEffect(() => {
    (async function () {
      try {
        // if containerId is present in location.state.containerId then fetch the data.
        if (location.state !== null) {
          dispatch(setLoading(true));
          const response = await getTransShipmentDetails(location.state?.containerId, location.state?.mabd);
          // const response: any = await new Promise(resolve => setTimeout(() => resolve({ data: sampleTranshipment }), 2000));
          const activeTabIndex = response?.data.vesselIds.indexOf(response?.data.activeVesselId ?? response?.data.vesselIds[response?.data.vesselIds.length - 1]);
          setActiveVesselTabIndex(activeTabIndex);
          setTransShipmentTracking(response?.data);
          setSingleVesselData(response?.data.vesselDetailsMap[response?.data.activeVesselId ?? response?.data.vesselIds[response?.data.vesselIds.length - 1]]);
          setActiveVesselId(response?.data.activeVesselId);
          setCurrentVesselTab(response?.data.activeVesselId ?? response?.data.vesselIds[response?.data.vesselIds.length - 1]);
        } else {
          // else show error message and navigate to vessel tracking page
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: 'Container id required',
              alertDescription: '',
            })
          );
          navigate(`/${routes.vesselTracking}`);
        }
      } catch (error: any) {
        dispatch(setLoading(false));
        switch (error.response?.status) {
          case 404:
            dispatch(
              setShowAlert({
                showAlert: true,
                alertType: 'error',
                alertTitle: `No data found for ${location.state?.containerId}`,
                alertDescription: ``,
              })
            );
            break;
          default:
            dispatch(
              setShowAlert({
                showAlert: true,
                alertType: 'error',
                alertTitle: 'Failed to fetch the container data',
                alertDescription: '',
              })
            );
            break;
        }
        console.log('error', error);
      }
    })();
  }, []);

  // fetching single vessel's table data
  useEffect(() => {
    (async function () {
      try {
        if (singleVesselData?.length > 0) {
          dispatch(setLoading(true));
          const transShipmentPoDetailsFetchParams = {
            pageSize: 25,
            pageNumber,
            containerId: singleVesselData[0].containerId,
            vesselId: singleVesselData[0].carrierId,
            mabd: singleVesselData[0].mabd
          };
          const transShipmentPoDetailsCountFetchParams = {
            containerId: singleVesselData[0].containerId,
            vesselId: singleVesselData[0].carrierId,
            mabd: singleVesselData[0].mabd
          };
          const transShipmentPoDetailsPromise = getTransShipmentPoDetails(transShipmentPoDetailsFetchParams);
          const transShipmentPoDetailsCountPromise = getTransShipmentPoDetailsCount(transShipmentPoDetailsCountFetchParams);
          const response = await Promise.all([transShipmentPoDetailsPromise, transShipmentPoDetailsCountPromise]);

          // if no data then show error alert
          if (response[1]?.data.totalRecords === 0) {
            dispatch(
              setShowAlert({
                showAlert: true,
                alertType: 'warning',
                alertTitle: 'No data found for the selected Vessel Id',
                alertDescription: '',
              })
            );
          }
          setTotalRecord(response[1]?.data.totalRecords);
          setTableShipmentData(response[0]?.data.responses.map((tableData: ITrackingDetailsShipmentTable) => ({ ...tableData, key: nanoid() })));
          dispatch(setLoading(false));
        }
      } catch (error) {
        console.log('error', error);
        dispatch(setLoading(false));
      }
    })();
  }, [pageNumber, singleVesselData]);

  // fetching single vessel's history of coordinates
  useEffect(() => {
    (async function () {
      if (singleVesselData?.length > 0 && singleVesselData[0]?.departureEventTime !== null) {
        dispatch(setLoading(true));
        try {
          const response = await getVesselHistoryCoordinates(singleVesselData[0].carrierId, singleVesselData[0].containerId, singleVesselData[0].mabd);
          setVesselHistoryCoordinates(response?.data.history.map((coordinate: IVesselHistoryCoordinate) => ({ ...coordinate, key: nanoid() })));
        } catch (error: any) {
          console.log(error);
          dispatch(setLoading(false));
        }
      }
    })();
  }, [singleVesselData]);

  // capturing user visited container id to show in Dashboard Recent Vessel table
  useEffect(() => {
    (async function () {
      try {
        if (location.state !== null) {
          await postActivityTrackerDetails(location.state?.containerId, 'VISITED', 'CONTAINER',undefined,undefined,undefined,location.state?.mabd);
        }
      } catch (error) {
        dispatch(setLoading(false));
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to mark the recent container', alertDescription: '', }));
        console.log('error', error);
      }
    })();
  }, []);

  // handler methods -----------------------------

  const handleTabChange = (e: any, index: number) => {
    setVesselHistoryCoordinates(null);
    setActiveVesselTabIndex(index);
    const vesselId = transShipmentTracking?.vesselIds[index];
    setSingleVesselData(
      transShipmentTracking?.vesselDetailsMap[vesselId as string] ?? []
    );
    setCurrentVesselTab(vesselId as string);
  };

  return (
    <section id='vessel-tracking-details'>
      <section className={headerClass(props.isExpanded)}>
        <section className='header-left-container'>
          <div className='text-header'>
            <i
              className='pi pi-arrow-left back-button'
              data-testid='back-button'
              onClick={() =>
                navigate(`/${routes.vesselTracking}`)
              }
            ></i>
            Container ID - {containerId}
          </div>
        </section>
      </section>
      <section className={subHeaderClass(props.isExpanded)}>
        <section className='left-subheader-container'></section>
      </section>
      <section className={vesselTabsClass(props.isExpanded)}>
        <Tabs
          value={activeVesselTabIndex}
          onChange={(e, index) => handleTabChange(e, index)}
          variant='scrollable'
          scrollButtons='auto'
          aria-label='scrollable vessel id tabs'
          data-testid='vessel-tab'
        >
          {transShipmentTracking &&
            transShipmentTracking.vesselIds.map((vesselId) => {
              if (vesselId === activeVesselId)
                return (
                  <Tab
                    key={vesselId}
                    label={`Vessel ${vesselId}`}
                    icon={<DirectionsBoatIcon fontSize='small' />}
                    iconPosition='end'
                  />
                );
              else return <Tab key={vesselId} label={`Vessel ${vesselId}`} />;
            })}
        </Tabs>
      </section>
      <section className={mapSectionClass(props.isExpanded)}>
        <MapContainer center={[30, -80]} zoom={2} className='map-container'>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url='https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png'
          />
          {
            (singleVesselData?.length > 0) && (
              <Map
                singleVesselData={singleVesselData}
                activeVesselId={activeVesselId}
                currentVesselTab={currentVesselTab}
                vesselHistoryCoordinates={vesselHistoryCoordinates}
              />
            )
          }
        </MapContainer>
      </section>
      {singleVesselData?.length > 0 && (
        <section className={cardSectionClass(props.isExpanded)}>
          <Card className='trackerCard'>
            <ContainerTracker data={singleVesselData} />
          </Card>
        </section>
      )}
      <section className={tablePaginationClass(props.isExpanded)}>
        {
          tableShipmentData !== null && (
            <>
              <TrackingDetailsTable
                isExpanded={props.isExpanded}
                tableShipmentData={tableShipmentData}
              />
              <Pagination
                count={Math.ceil(totalRecord / tableConfig.pageSize)}
                variant='text'
                shape='rounded'
                siblingCount={1}
                color={'standard'}
                showFirstButton
                showLastButton
                size='small'
                defaultPage={pageNumber}
                onChange={(e, value) => setPageNumber(value)}
              />
            </>
          )
        }
      </section>
    </section>
  );
};

export default VesselTrackingDetails;