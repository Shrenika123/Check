import { FC, ReactElement, ReactNode, useEffect, useState } from "react";
import { FiLogOut } from 'react-icons/fi';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom";
import { labels, routes } from '../../common/constants';
import { INavbarState, IUserState } from '../../common/interfaces';
import Navbar from '../../components/nav-bar/Navbar';
import { setExpanded } from '../../redux/reducers/navbar.reducer';
import DocumentLibrary from './document-library/DocumentLibrary.component';
import Externalization from './externalization/externalization';
import Homepage from './home-page/Homepage.component';
import ItemManagement from './item-management/ItemManagement';
import './MainContainer.style.css';
import POLineManagement from './po-line-management/POLineManagement.component';
import POManagement from './po-management/POManagement';
import PromotionProcurementDetails from './promotion-procurement-details/PromotionProcurementDetails';
import PromotionAndProcurementComponent from './promotion-procurement/PromotionAndProcurement.component';
import AdminPanel from './admin-panel/AdminPanel';
import ShipAndLoadManagementMulti from './ship-load-management_multiselect/ShipAndLoadManagement';
import VesselTrackingDetails from './vessel-tracking-details/VesselTrackingDetails.component';
import VesselTracking from './vessel-tracking/VesselTracking.component';

interface Props {
  route: string;
}

const MainContainer: FC<Props> = (props): ReactElement => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const userRole = useSelector(
    (state: IUserState) => state.user.userRole
  );
  const isExpanded = useSelector(
    (state: INavbarState) => state.navbar.isExpanded
  );
  const [screen, setScreen] = useState<ReactNode>();
  const user_name = localStorage.getItem('user_name');

  // toggle sidebar
  const toggleExpansion = () => {
    if (isExpanded) dispatch(setExpanded(false));
    else dispatch(setExpanded(true));
  };

  const logout = () => {
    navigate('/logout');
  };

  useEffect(() => {
    switch (props.route) {
      case routes.home:
        setScreen(<Homepage isExpanded={isExpanded} />);
        break;
      case routes.poManagement:
        setScreen(<POManagement isExpanded={isExpanded} />);
        break;
      case routes.lineDetails:
        setScreen(<POLineManagement isExpanded={isExpanded} />);
        break;
      case routes.itemManagement:
        setScreen(<ItemManagement isExpanded={isExpanded} />);
        break;
      case routes.vesselTracking:
        setScreen(<VesselTracking isExpanded={isExpanded} />);
        break;
      case routes.vesselTrackingDetails:
        setScreen(<VesselTrackingDetails isExpanded={isExpanded} />);
        break;
      case routes.adminPanel:
        setScreen(<AdminPanel isExpanded={isExpanded} />);
        break;
      case routes.shipLoadManagement:
        setScreen(<ShipAndLoadManagementMulti isExpanded={isExpanded} />);
        break;
      case routes.eventBuyPlanManagement:
        setScreen(<PromotionAndProcurementComponent isExpanded={isExpanded} />);
        break;
      case routes.promotionProcurementDetails:
        setScreen(<PromotionProcurementDetails isExpanded={isExpanded} />);
        break;
      case routes.documentLibrary:
        setScreen(<DocumentLibrary isExpanded={isExpanded} />);
        break;
      case routes.externalization:
        setScreen(<Externalization isExpanded={isExpanded} />);
        break;
      default:
        setScreen(<Homepage isExpanded={isExpanded} />);
    }
  }, [props.route, isExpanded]);

  return (
    <section
      data-testid='main-container'
      className='main-container'>
      <section className='wrapper'>
        <div className='top-bar'>
          <div
            data-testid='title'
            className={isExpanded ? 'title title-shrink' : 'title'}>
            {labels.appTitle}
          </div>
          <div className='profile'>
            <div className='nav-top-2'>
              <div className='profile-username'>{user_name}</div>
              <div className='profile-role'>{userRole}</div>
            </div>
            <div className='nav-top'>
              <FiLogOut
                data-testid='logoutButton'
                onClick={logout}
                className='sm-icon-color'
              />
            </div>
          </div>
        </div>
        <section className='component-container'>{screen}</section>
      </section>
      <Navbar
        selected={props.route}
        toggleExpansion={toggleExpansion}
        isExpanded={isExpanded}
      />
    </section>
  );
};
export default MainContainer;   
