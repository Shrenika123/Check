import { Pagination } from '@mui/material';
import classNames from 'classnames';
import { addDays, format, subDays } from 'date-fns';
import { nanoid } from 'nanoid';
import { BaseSyntheticEvent, FC, useCallback, useEffect, useRef, useState } from 'react';
import { Range } from 'react-date-range';
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useSearchParams } from "react-router-dom";
import backicon from '../../../assets/images/backicon.png';
import { allowedMultiSelectFilters, labels, routes, shipmentColumn, systemSettingNames, tableConfig } from '../../../common/constants';
import { debounce } from '../../../common/debounce';
import { IRoutePermission, IShipmentFilterRequest, IShipmentRequest, IShipmentResponseData, IShipmentResponseDataPage, ISortAndPage, IUserState } from '../../../common/interfaces';
import { getGMTTimeStamp, getMultiSelectFilterData, getShipAndLoadAutoSuggestData, getShipAndLoadData, getShipAndLoadDataCount, isStringValid, postActivityTrackerDetails } from '../../../common/utils';
import AutoSuggest from '../../../components/auto-suggest/AutoSuggest.component';
import ConfirmationBox from '../../../components/confimation-box/ConfirmationBox.component';
import CustomDateRangePicker from '../../../components/date-range-picker/CustomDateRangePicker';
import MultiSelectFilter from '../../../components/multiselect-filter/MultiSelectFilter';
import { useDidComponentUpdate } from '../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import './ShipAndLoadManagement.style.css';

interface Props {
  isExpanded: boolean;
}
const ShipAndLoadManagement: FC<Props> = (props) => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const poLinePerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'PO_LINE_MANAGEMENT')?.permission;
  const containerPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'CONTAINER_TRACKING')?.permission;

  const initSortPage: ISortAndPage = {
    sortColumn: shipmentColumn.mustArriveByDate,
    sortOrder: '',
    pageNumber: 1
  };

  const settings = useSelector((state: any) => state.systemSetting);
  let fixedSettingDate: undefined | string;
  let enableFixedDate: undefined | string;

  if (settings && settings.length > 0) {
    settings.forEach((setting: any) => {
      if (!enableFixedDate)
        enableFixedDate = setting.name === systemSettingNames.enableFixedDate ? setting.value : undefined;
      if (!fixedSettingDate)
        fixedSettingDate = setting.name === systemSettingNames.fixedDate ? setting.value : undefined;
    });
  }

  const initDateRange: Range[] = [
    {
      startDate: subDays(getGMTTimeStamp(enableFixedDate === 'true' ? fixedSettingDate : undefined), 15),
      endDate: addDays(getGMTTimeStamp(enableFixedDate === 'true' ? fixedSettingDate : undefined), 45),
      key: 'selection'
    }
  ];

  const [searchParams, setSearchParams] = useSearchParams();

  const [tableData, setTableData] = useState<IShipmentResponseDataPage>();
  const [totalCount, setTotalCount] = useState<number>(0);
  const [sortAndPage, setSortAndPage] = useState<ISortAndPage>(initSortPage);

  const [modeData, setModeData] = useState<string[]>([]);
  const [modeFilterData, setModeFilterData] = useState<string[]>([]);
  const [modeCheckedData, setModeCheckedData] = useState<string[]>([]);

  const [poNumberInput, setPoNumberInput] = useState<string>('');
  const [poNumberSuggestData, setPoNumberSuggestData] = useState<string[]>([]);

  const [loadIdInput, setLoadIdInput] = useState<string>('');
  const [loadIdSuggestData, setLoadIdSuggestData] = useState<string[]>([]);

  const [modeInput, setModeInput] = useState<string>('');
  const [shipmentIdSuggestData, setShipmentIdSuggestData] = useState<string[]>([]);

  const [transportDocIdInput, setTransportDocIdInput] = useState<string>('');
  const [transportDocIdSuggestData, setTransportDocIdSuggestData] = useState<string[]>([]);

  const [scacInput, setScacInput] = useState<string>('');
  const [scacSuggestData, setScacSuggestData] = useState<string[]>([]);

  const [showPoInputLoader, setShowPoInoutLoader] = useState<boolean>(false);
  const [showLoadIdInputLoader, setShowLoadIdInoutLoader] = useState<boolean>(false);
  const [showShipmentIdInputLoader, setShowShipmentIdInputLoader] = useState<boolean>(false);
  const [showScacInputLoader, setShowScacInputLoader] = useState<boolean>(false);
  const [showDocIdLoader, setShowDocIdInputLoader] = useState<boolean>(false);

  const [closePoInputAutoSug, setClosePoInoutAutoSug] = useState<boolean>(false);
  const [closeLoadIdInputAutoSug, setCloseLoadIdInoutAutoSug] = useState<boolean>(false);
  const [closeShipmentIdInputAutoSug, setCloseShipmentIdInputAutoSug] = useState<boolean>(false);
  const [closeScacInputAutoSug, setCloseScacInputAutoSug] = useState<boolean>(false);
  const [closeDocIdAutoSug, setCloseDocIdInputAutoSug] = useState<boolean>(false);

  const [isConfirmBoxOpen, setConfirmBoxOpen] = useState<boolean>(false);

  const headerRef = useRef<HTMLDivElement>(null);
  const clickedPORef = useRef<{ poNumber: string, mabd: string; }>();
  const prevInitSortPageObjectRef = useRef<ISortAndPage>(initSortPage);
  //get shipment id from url if naviagte from item management else empty
  const [shipmentIdInput, setShipmentIdInput] = useState<string>(() => {
    if (searchParams.get('params')) {
      const params = searchParams.get('params');
      return JSON.parse(params!).shipment_id;
    }
    else
      return '';
  }
  );
  // get range from url if navigate from item management else initDateRange
  const [range, setRange] = useState<Range[]>(() => {
    if (searchParams.get('params')) {
      const params = searchParams.get('params');
      return [
        {
          startDate: getGMTTimeStamp(JSON.parse(params!).mabd),
          endDate: getGMTTimeStamp(JSON.parse(params!).mabd),
          key: 'selection'
        }
      ];
    }
    else
      return initDateRange;
  });

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const routeToHome = () => {
    navigate(`/${routes.home}`);
  };

  const routeToPoLine = () => {
    navigate(`/${routes.lineDetails}`, { state: clickedPORef.current });
  };

  const handlePOClick = (data: { poNumber: string, mabd: string; }) => {
    clickedPORef.current = data;
    setConfirmBoxOpen(true);
  };

  const navigateToLiveTracking = (containerId: string, mabd: string) => {
    navigate(`/${routes.vesselTrackingDetails}`, { state: { containerId, mabd } });
  };

  // capturing user visited shipment id to show in Dashboard Recent Vessel table
  useEffect(() => {
    (async function () {
      try {
        if (shipmentIdInput !== '' && searchParams.get('params')) {
          await postActivityTrackerDetails(shipmentIdInput, 'VISITED', 'SHIPMENT', undefined, undefined, undefined, JSON.parse(searchParams.get('params')!).mabd);
        }
      } catch (error) {
        dispatch(setLoading(false));
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to mark visited shipment', alertDescription: '', }));
        console.log('shipmentLoadPage - postActivityTrackerDetails - shipmentIdInput - error', error);
      }
    })();
  }, []);

  //initial table and filter render
  useEffect(() => {
    searchParams.delete('params');
    setSearchParams(searchParams);
    loadTableDataAndPopulateView();
    fetchTotalCount();
    fetchModeFilterData();
  }, []);

  const handleSorting = (columnName: string) => {
    if (sortAndPage.sortColumn === columnName)
      setSortAndPage({ sortColumn: sortAndPage.sortColumn, sortOrder: sortAndPage.sortOrder === '' ? 'Desc' : '', pageNumber: 1 });
    else
      setSortAndPage({ sortColumn: columnName, sortOrder: '', pageNumber: 1 });
  };

  const loadTableDataAndPopulateView = (poNumberVar?: string, scacVar?: string, shipMentIdVar?: string, loadIdVar?: string, docId?: string) => {
    dispatch(setLoading(true));
    const actShipmentId = (): string => {
      if (searchParams.get('params'))
        return JSON.parse(searchParams.get('params')!).shipment_id;
      else
        return shipmentIdInput.length ? shipmentIdInput.trim() : '';
    };
    const params: IShipmentRequest = {
      pageSize: tableConfig.pageSize,
      pageNumber: sortAndPage.pageNumber,
      startDate: format(range[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(range[0].endDate!, 'yyyy-MM-dd'),
      sortColumn: sortAndPage.sortColumn,
      sortOrder: sortAndPage.sortOrder,
      poNumber: poNumberVar ? poNumberVar : poNumberInput.length !== 0 ? poNumberInput.trim() : '',
      shipmentId: shipMentIdVar ? shipMentIdVar : actShipmentId(),
      loadId: loadIdVar ? loadIdVar : loadIdInput.length ? loadIdInput.trim() : '',
      mode: modeCheckedData.length === 0 ? modeData.toString() : modeCheckedData.toString(),
      transportDocId: docId ? docId : transportDocIdInput ? transportDocIdInput.trim() : '',
      carrierSCAC: scacVar ? scacVar : scacInput.length ? scacInput.trim() : '',
    };
    getShipAndLoadData(params).then((res) => {
      if (res.status === 200) {
        window.history.pushState({}, document.title, window.location.pathname);
        if (res.data.tatalRecords === 0 || res.data.responses.length === 0)
          dispatch(setShowAlert({ showAlert: true, alertType: 'warning', alertTitle: 'No data found for the selected filters', alertDescription: '' }));
        setTableData(res.data);
      }
      else {
        dispatch(setLoading(false));
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to fetch shipment table data', alertDescription: '' }));
      }
    }).catch((err) => {
      setTableData(undefined);
      dispatch(setLoading(false));
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to fetch shipment table data', alertDescription: '' }));
      console.log("shipment api failed with status" + err);
    }).finally(() => {
      dispatch(setLoading(false));
    });
  };
  const fetchTotalCount = (poNumberVar?: string, scacVar?: string, shipMentIdVar?: string, loadIdVar?: string, docId?: string) => {
    const actShipmentId = (): string => {
      if (searchParams.get('params'))
        return JSON.parse(searchParams.get('params')!).shipment_id;
      else
        return shipmentIdInput.length ? shipmentIdInput.trim() : '';
    };
    const params: IShipmentRequest = {
      pageSize: tableConfig.pageSize,
      pageNumber: sortAndPage.pageNumber,
      startDate: format(range[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(range[0].endDate!, 'yyyy-MM-dd'),
      sortColumn: sortAndPage.sortColumn,
      sortOrder: sortAndPage.sortOrder,
      poNumber: poNumberVar ? poNumberVar : poNumberInput.length !== 0 ? poNumberInput.trim() : '',
      shipmentId: shipMentIdVar ? shipMentIdVar : actShipmentId(),
      loadId: loadIdVar ? loadIdVar : loadIdInput.length ? loadIdInput.trim() : '',
      mode: modeCheckedData.length === 0 ? modeData.toString() : modeCheckedData.toString(),
      transportDocId: docId ? docId : transportDocIdInput ? transportDocIdInput.trim() : '',
      carrierSCAC: scacVar ? scacVar : scacInput.length ? scacInput.trim() : '',
    };
    getShipAndLoadDataCount(params).then(res => {
      setTotalCount(res.data);
    }).catch(err => {
      console.log("shipment count api failed with status" + err);
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to load total pages', alertDescription: '' }));
    });
  };

  const fetchModeFilterData = () => {
    getMultiSelectFilterData(allowedMultiSelectFilters.mode).then(res => {
      setModeData(res.data.data);
    }).catch(err => {
      console.log(err);
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to fetch mode filter data', alertDescription: '' }));
    });
  };

  const fetchSuggestData = (poNumVar: string, rangeVar: Range[], selectField: string) => {
    if (poNumVar.length >= 4) {
      const params: IShipmentFilterRequest = {
        selectField: selectField,
        fromDate: format(rangeVar[0].startDate!, 'yyyy-MM-dd'),
        toDate: format(rangeVar[0].endDate!, 'yyyy-MM-dd'),
        sortColumn: selectField,
        sortOrder: '',
      };
      switch (selectField) {
        case shipmentColumn.poNumber:
          setShowPoInoutLoader(true);
          params.poNumber = [poNumVar];
          break;
        case shipmentColumn.scac:
          params.scac = [poNumVar];
          setShowScacInputLoader(true);
          break;
        case shipmentColumn.transportDocId:
          setShowDocIdInputLoader(true);
          params.transportDocId = [poNumVar];
          break;
        case shipmentColumn.shipmentId:
          setShowShipmentIdInputLoader(true);
          params.shipmentId = [poNumVar];
          break;
        case shipmentColumn.loadId:
          setShowLoadIdInoutLoader(true);
          params.loadId = [poNumVar];
          break;
      }
      getShipAndLoadAutoSuggestData(params).then((res) => {
        if (res.status === 200) {
          switch (selectField) {
            case shipmentColumn.poNumber:
              setPoNumberSuggestData(res.data);
              break;
            case shipmentColumn.scac:
              setScacSuggestData(res.data);
              break;
            case shipmentColumn.transportDocId:
              setTransportDocIdSuggestData(res.data);
              break;
            case shipmentColumn.shipmentId:
              setShipmentIdSuggestData(res.data);
              break;
            case shipmentColumn.loadId:
              setLoadIdSuggestData(res.data);
              break;
          }
        }
      }).finally(() => {
        switch (selectField) {
          case shipmentColumn.poNumber:
            setShowPoInoutLoader(false);
            break;
          case shipmentColumn.scac:
            setShowScacInputLoader(false);
            break;
          case shipmentColumn.transportDocId:
            setShowDocIdInputLoader(false);
            break;
          case shipmentColumn.shipmentId:
            setShowShipmentIdInputLoader(false);
            break;
          case shipmentColumn.loadId:
            setShowLoadIdInoutLoader(false);
            break;
        }
      });
    }
  };

  const fetchSuggestData_debounced = useCallback(debounce(fetchSuggestData, 500), []);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(poNumberInput, range, shipmentColumn.poNumber);
  }, [poNumberInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(loadIdInput, range, shipmentColumn.loadId);
  }, [loadIdInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(shipmentIdInput, range, shipmentColumn.shipmentId);
  }, [shipmentIdInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(scacInput, range, shipmentColumn.scac);
  }, [scacInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(transportDocIdInput, range, shipmentColumn.transportDocId);
  }, [transportDocIdInput]);

  useDidComponentUpdate(() => {
    dispatch(setLoading(false));
  }, [tableData]);

  useDidComponentUpdate(() => {
    searchParams.delete('params');
    setSearchParams(searchParams);
    setPoNumberInput('');
    setLoadIdInput('');
    setModeInput('');
    setShipmentIdInput('');
    setTransportDocIdInput('');
    setScacInput('');
    setModeCheckedData([]);
  }, [range]);

  useDidComponentUpdate(() => {
    loadTableDataAndPopulateView();
  }, [sortAndPage]);

  useDidComponentUpdate(() => {
    setSortAndPage(initSortPage);
    fetchTotalCount();
  }, [modeCheckedData]);

  const getSortIcon = (columnName: string) => {

    if (sortAndPage.sortColumn === columnName) {
      if (sortAndPage.sortOrder === 'Desc') {
        return <IoMdArrowDropdown />;
      }
      else {
        return <IoMdArrowDropup />;
      }
    }
    else
      return <></>;
  };

  // classnames ------------------
  const headerClass = classNames({
    'header-shrink': props.isExpanded,
    'header': !props.isExpanded,
  });

  const tableReportClass = classNames('table-report', {
    'table-report-shrink': props.isExpanded,
  });

  const paginatedClass = classNames('paginated', {
    'paginated-shrink': props.isExpanded
  });


  const handleInputChange = (e: BaseSyntheticEvent) => {

    switch (e.target.name) {
      case labels.loadId:
        setLoadIdInput(e.target.value);
        break;
      case labels.poNumber:
        setPoNumberInput(e.target.value);
        break;
      case labels.shipmentId:
        setShipmentIdInput(e.target.value);
        break;
      case labels.shipmentDocId:
        setTransportDocIdInput(e.target.value);
        break;
      case labels.mode:
        setModeInput(e.target.value);
        break;
      case labels.carrierSCAC:
        setScacInput(e.target.value);
        break;

    }
  };

  const handlePoNumberSuggestionClick = (value: string) => {
    setClosePoInoutAutoSug(true);
    setPoNumberInput(value);
    loadTableDataAndPopulateView(value);
    fetchTotalCount(value);
  };
  const handleScacSuggestionClick = (value: string) => {
    setCloseScacInputAutoSug(true);
    setScacInput(value);
    loadTableDataAndPopulateView(undefined, value);
    fetchTotalCount(undefined, value);
  };
  const handleShipmentIdSuggestionClick = (value: string) => {
    setCloseShipmentIdInputAutoSug(true);
    setShipmentIdInput(value);
    loadTableDataAndPopulateView(undefined, undefined, value);
    fetchTotalCount(undefined, undefined, value);
  };
  const handleLoadIdSuggestionClick = (value: string) => {
    setCloseLoadIdInoutAutoSug(true);
    setLoadIdInput(value);
    loadTableDataAndPopulateView(undefined, undefined, undefined, value);
    fetchTotalCount(undefined, undefined, undefined, value);
  };
  const handleDocIdSuggestionClick = (value: string) => {
    setCloseDocIdInputAutoSug(true);
    setTransportDocIdInput(value);
    loadTableDataAndPopulateView(undefined, undefined, undefined, undefined, value);
    fetchTotalCount(undefined, undefined, undefined, undefined, value);
  };

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.code === "Enter" || event.code === "NumpadEnter") {
        event.preventDefault();
        headerRef.current?.click();
        setSortAndPage(initSortPage);
        prevInitSortPageObjectRef.current !== initSortPage && fetchTotalCount();
        prevInitSortPageObjectRef.current = initSortPage;
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
    };
  }, [poNumberInput, modeCheckedData, scacInput, shipmentIdInput, transportDocIdInput, loadIdInput]);

  const onlyModeClickHandler = (query: string) => {
    if (modeFilterData && query) {
      setModeCheckedData(modeFilterData.filter((value) => value.toString() === query));
    }
  };

  useEffect(() => {
    headerRef.current?.click();
  }, []);

  return (
    <section id='ship-management-multi'>
      <section className={headerClass}>
        <div ref={headerRef} className='text-header'>{labels.shipAndLoadManagement}</div>
        <div className='text-menu'>
          <div className="nav" onClick={routeToHome}>{labels.homeNav}</div> &nbsp; &gt; &nbsp;
          <div className="nav">{labels.shipAndLoadManagement}</div>
        </div>
      </section>
      <div className='datepicker-wrap'>
        <p className='datepicker-header'>{labels.dataRange}</p>
        <CustomDateRangePicker range={range} setRange={setRange} footerLabel='By default date range of MABD will be T-15 to T+45' />

      </div>
      <div className={props.isExpanded ? 'shrink-query-wrapper' : 'query-wrapper'}>


        <div className='query-box-wrapper'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.loadId}</p>

          <AutoSuggest inputSuggestionData={loadIdSuggestData}
            onSuggestionClickHandler={(e: any, value: any) => handleLoadIdSuggestionClick(value)} inputData={loadIdInput} handleInputChange={handleInputChange}
            name={labels.loadId} isClosed={closeLoadIdInputAutoSug} inputLengthToShowSuggestion={4} isLoading={showLoadIdInputLoader} setClose={setCloseLoadIdInoutAutoSug} />


        </div>
        <div className='query-box-wrapper'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.shipmentId}</p>

          <AutoSuggest inputSuggestionData={shipmentIdSuggestData}
            onSuggestionClickHandler={(e: any, value: any) => handleShipmentIdSuggestionClick(value)} inputData={shipmentIdInput} handleInputChange={handleInputChange}
            name={labels.shipmentId} isClosed={closeShipmentIdInputAutoSug} inputLengthToShowSuggestion={4} isLoading={showShipmentIdInputLoader} setClose={setCloseShipmentIdInputAutoSug} />


        </div>
        <div className='query-box-wrapper'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.poNumber}</p>

          <AutoSuggest inputSuggestionData={poNumberSuggestData}
            onSuggestionClickHandler={(e: any, value: any) => handlePoNumberSuggestionClick(value)} inputData={poNumberInput} handleInputChange={handleInputChange}
            name={labels.poNumber} isClosed={closePoInputAutoSug} inputLengthToShowSuggestion={4} isLoading={showPoInputLoader} setClose={setClosePoInoutAutoSug} />


        </div>
        <div className='query-box-wrapper'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.carrierSCAC}</p>

          <AutoSuggest inputSuggestionData={scacSuggestData}
            onSuggestionClickHandler={(e: any, value: any) => handleScacSuggestionClick(value)} inputData={scacInput} handleInputChange={handleInputChange}
            name={labels.carrierSCAC} isClosed={closeScacInputAutoSug} inputLengthToShowSuggestion={4} isLoading={showScacInputLoader} setClose={setCloseScacInputAutoSug} />

        </div>
        <div className='query-box-wrapper'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.mode}</p>
          <MultiSelectFilter data={modeData} setCheckedData={setModeCheckedData} checkedData={modeCheckedData}
            filterData={modeFilterData} setFilterData={setModeFilterData} inputValue={modeInput} setInputValue={setModeInput}
            onlyButtonHandler={onlyModeClickHandler} />
        </div>

        <div className='query-box-wrapper'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.shipmentDocId}</p>
          <AutoSuggest inputSuggestionData={transportDocIdSuggestData}
            onSuggestionClickHandler={(e: any, value: any) => handleDocIdSuggestionClick(value)} inputData={transportDocIdInput} handleInputChange={handleInputChange}
            name={labels.shipmentDocId} isClosed={closeDocIdAutoSug} inputLengthToShowSuggestion={4} isLoading={showDocIdLoader} setClose={setCloseDocIdInputAutoSug} />

        </div>
      </div>
      <div className={tableReportClass}>
        <table className='table'>
          <thead className={props.isExpanded ? 'custom-thead shrink-font' : 'custom-thead'}>
            <tr className='custom-tr'>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.poNumber)} data-testid='shipment-poNum'>
                <div className='th-wrapper'>
                  {labels.poNumber}
                  {getSortIcon(shipmentColumn.poNumber)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.shipmentId)} data-testid='shipment-shipmentId'>
                <div className='th-wrapper'>
                  {labels.shipmentId}
                  {getSortIcon(shipmentColumn.shipmentId)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.loadId)} data-testid='shipment-loadId'>
                <div className='th-wrapper'>
                  {labels.loadId}
                  {getSortIcon(shipmentColumn.loadId)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.containerId)} data-testid='shipment-containerId'>
                <div className='th-wrapper'>
                  {labels.containerId}
                  {getSortIcon(shipmentColumn.containerId)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.mustArriveByDate)} data-testid='shipment-mabd'>
                <div className='th-wrapper'>
                  {labels.mabd}
                  {getSortIcon(shipmentColumn.mustArriveByDate)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.equipmentId)} data-testid='shipment-equipId'>
                <div className='th-wrapper'>
                  {labels.equipmentId}
                  {getSortIcon(shipmentColumn.equipmentId)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.equipmentDesc)} data-testid='shipment-equipDesc'>
                <div className='th-wrapper'>
                  {labels.equipmentDesc}
                  <span id='eqipment-desc-icon'>{getSortIcon(shipmentColumn.equipmentDesc)}</span>
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.transportDocId)} data-testid='shipment-docId'>
                <div className='th-wrapper'>
                  {labels.shipmentDocId}
                  {getSortIcon(shipmentColumn.transportDocId)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.mode)} data-testid='shipment-mode'>
                <div className='th-wrapper'>
                  {labels.mode}
                  {getSortIcon(shipmentColumn.mode)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.carrierSCAC)} data-testid='shipment-scac'>
                <div className='th-wrapper'>
                  {labels.carrierSCAC}
                  {getSortIcon(shipmentColumn.carrierSCAC)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.cube)} data-testid='shipment-cube'>
                <div className='th-wrapper'>
                  {labels.cube}
                  {getSortIcon(shipmentColumn.cube)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(shipmentColumn.weight)} data-testid='shipment-weight'>
                <div className='th-wrapper'>
                  {labels.weight}
                  {getSortIcon(shipmentColumn.weight)}
                </div>
              </th>
              <th className='custom-th'>{labels.shipUnitCount}</th>
              <th className='custom-th'>Origin</th>
              <th className='custom-th'>Destination</th>
              <th className='custom-th'>Location Type</th>
            </tr>
          </thead>
          <tbody className={props.isExpanded ? 'custom-tbody shrink-font' : 'custom-tbody'}>
            {tableData && tableData.actualPageSize > 0 ? tableData.responses.map((row: IShipmentResponseData, index) => {
              return (
                <tr className='custom-tr' key={row.shipmentId + index}>
                  <td
                    className={ isStringValid(poLinePerm) && poLinePerm !== 'NA' ? 'custom-td hyperlink' : 'custom-td non-hyperlink'}
                    id='shipPoNum'
                    onClick={() => handlePOClick({ poNumber: row.poNumber, mabd: row.mabd })}>
                    {row.poNumber}
                  </td>
                  <td className='custom-td'>{isStringValid(row.shipmentId) ? row.shipmentId : 'NA'}</td>
                  <td className='custom-td'>{row.loadId}</td>
                  <td 
                    className={ isStringValid(containerPerm) && containerPerm !== 'NA' ? 'custom-td hyperlink' : 'custom-td non-hyperlink'}
                    id={row.mode.toLowerCase() === 'ocean' ? 'shipPoNum' : ''} 
                    onClick={() => row.mode.toLowerCase() === 'ocean' && navigateToLiveTracking(row.containerId, row.mabd)}>{row.containerId}
                  </td>
                  <td className='custom-td'>{format(getGMTTimeStamp(row.mabd), 'MM/dd/yyyy')}</td>
                  <td className='custom-td'>{row.equipmentId}</td>
                  <td className='custom-td'>{row.equipmentDesc}</td>
                  <td className='custom-td'>{row.transportDocId}</td>
                  <td className='custom-td'>{row.mode}</td>
                  <td className='custom-td'>{row.carrierSCAC}</td>
                  <td className='custom-td'>{row.cube}</td>
                  <td className='custom-td'>{row.weight}</td>
                  <td className='custom-td'>{row.shippingUnitCount}</td>
                  <td className='custom-td'>{row.vendorId}</td>
                  <td className='custom-td'>{row.idcId}</td>
                  <td className='custom-td'>{row.locationType}</td>
                </tr>);
            }) :
              [...Array(8)].map(() => { return { key: nanoid() }; }).map((_, index) => {
                return (
                  <tr data-testid='filler' className='custom-tr' key={_.key}>
                    <td className='custom-td' colSpan={16}><div className='filler' ></div></td>
                  </tr>);
              })
            }
            {
              [...Array(tableData ? (tableData.actualPageSize < 8 && tableData.actualPageSize > 0 ? 8 - tableData.actualPageSize : 0) : 0)].map(() => { return { key: nanoid() }; }).map((_, index) => {
                return (
                  <tr data-testid='filler' className='custom-tr' key={_.key}>
                    <td className='custom-td' colSpan={16}><div className='filler' ></div></td>
                  </tr>
                );
              })
            }
          </tbody>
        </table>
        <ConfirmationBox title='Leave this page?'
          content='You will be redirected to Line Management page'
          open={isConfirmBoxOpen} onClose={() => setConfirmBoxOpen(false)}
          confirmAction={() => routeToPoLine()}
          cancelAction={() => setConfirmBoxOpen(false)}
          image={<img src={backicon} alt='' />} />

      </div>
      <div>
        <div className={paginatedClass}>
          <Pagination count={Math.ceil(totalCount / tableConfig.pageSize)} variant='text' shape='rounded' siblingCount={1} color={'standard'} showFirstButton showLastButton size="small"
            page={sortAndPage.pageNumber}
            onChange={(e, value) => setSortAndPage({ pageNumber: value, sortColumn: sortAndPage.sortColumn, sortOrder: sortAndPage.sortOrder })}
          />
          {/* </>
            : <></>
          } */}
        </div>
      </div>
    </section>
  );

};
export default ShipAndLoadManagement;
