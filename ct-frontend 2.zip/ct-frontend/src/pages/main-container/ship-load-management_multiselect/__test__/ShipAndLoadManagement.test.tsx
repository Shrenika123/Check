import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
//import userEvent from '@testing-library/user-event';
//import axios from 'axios';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import ShipAndLoadManagement from '../ShipAndLoadManagement';


afterEach(() => {
  cleanup();
  jest.resetAllMocks();
});

jest.mock("nanoid", () => {
  return { nanoid: () => Math.random().toString() };
});

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const res = {
  status: 200,
  data:
  {
    totalRecords: 169618,
    actualPageSize: 1,
    responses: [
      {
        poNumber: "70331316",
        shipmentId: "NQWV5163",
        loadId: "343989811",
        transportDocId: "5163NQWV",
        carrierSCAC: "OSAB",
        mode: "Truckload",
        equipmentId: "84LIP",
        equipmentDesc: "Truck",
        cube: "14",
        weight: 43,
        shippingUnitCount: "1/2",
        mabd: "2022-11-27",
        containerId: "CNT8481"
      }
    ],
  }
};
const zeroRes = {
  status: 200,
  data:
  {
    totalRecords: 0,
    actualPageSize: 0,
    responses: [],
  }
};

const errorRes = {
  status: 500,
  data:
  {
    totalRecords: 0,
    actualPageSize: 0,
    responses: [],
  }
};

const suggestionRes = {
  data: ['abcde', 'bcdef', 'cdefg', 'defgh', 'efghi'],
  status: 200
};

const countRes = {
  data: 100
};

const modeResponse = {
  data:{
    data: ['Drayage', 'Ocean', 'Truckload']
  }
}

const mockStore = configureStore();

test('should render Ship And Load Management component', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  const getShipAndLoadData = jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util,'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
}
);

test('should render Ship And Load Management component with zero response', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(zeroRes);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
  });
}
);

test('should render Ship And Load Management component with non 200 status', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(errorRes);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
  });
}
);

test('should render Ship And Load Management component with api fail', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockRejectedValue("network error");
  jest.spyOn(util, 'getShipAndLoadDataCount').mockRejectedValue({ status: 500 });
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
  });
}
);

test('should render Ship And Load Management component with expanded navbar', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={true} />
    </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
}
);

test('should route to home', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={true} />
    </Provider >, { wrapper: BrowserRouter });
  const homeNav = screen.getByText('Dashboard');
  userEvent.click(homeNav);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on mabd', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });
  const elem = screen.getByTestId('shipment-mabd');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on mabd toggle sort', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-mabd');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  //toggle sort
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });

});

test('should sort based on po no', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-poNum');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on load id', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-loadId');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on shipment id', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-shipmentId');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on containerId', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-containerId');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on equipId', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-equipId');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on equip Desc', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-equipDesc');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });

});
test('should sort based on doc Id', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-docId');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});
test('should sort based on mode', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-mode');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});
test('should sort based on scac', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-scac');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});
test('should sort based on cube', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-cube');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should sort based on weight', async () => {
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  const elem = screen.getByTestId('shipment-weight');
  userEvent.click(elem);
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
});

test('should handle load id auto suggest input box changes', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  const getShipAndLoadData = jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)
  const getShipAndLoadAutoSuggestData = jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  //load id auto suggestion test
  fireEvent.change(screen.getAllByTestId('input-auto-suggest')[0], { target: { value: 'abcd123' } });
  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
  });
  await waitFor(() => {
    expect(getShipAndLoadAutoSuggestData).toBeCalled();
  });
  await waitFor(() => {
    screen.getAllByTestId('suggest-option');
  });
  userEvent.click(screen.getAllByTestId('suggest-option')[0]);
  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });
});

test('should handle shipment id auto suggest input box changes', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  const getShipAndLoadData = jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  const getShipAndLoadAutoSuggestData = jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  fireEvent.change(screen.getAllByTestId('input-auto-suggest')[1], { target: { value: 'abcd123' } });
  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
  });
  await waitFor(() => {
    expect(getShipAndLoadAutoSuggestData).toBeCalled();
  });
  await waitFor(() => {
    screen.getAllByTestId('suggest-option');
  });
  userEvent.click(screen.getAllByTestId('suggest-option')[0]);
  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });
});
test('should handle po number auto suggest input box changes', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  const getShipAndLoadData = jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  const getShipAndLoadAutoSuggestData = jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  fireEvent.change(screen.getAllByTestId('input-auto-suggest')[2], { target: { value: 'abcd123' } });
  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
  });
  await waitFor(() => {
    expect(getShipAndLoadAutoSuggestData).toBeCalled();
  });
  await waitFor(() => {
    screen.getAllByTestId('suggest-option');
  });
  userEvent.click(screen.getAllByTestId('suggest-option')[0]);
  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });
});
test('should handle scac auto suggest input box changes', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  const getShipAndLoadData = jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  const getShipAndLoadAutoSuggestData = jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  fireEvent.change(screen.getAllByTestId('input-auto-suggest')[3], { target: { value: 'abcd123' } });
  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
  });
  await waitFor(() => {
    expect(getShipAndLoadAutoSuggestData).toBeCalled();
  });
  await waitFor(() => {
    screen.getAllByTestId('suggest-option');
  });
  userEvent.click(screen.getAllByTestId('suggest-option')[0]);
  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });
});
test('should handle transport doc id auto suggest input box changes', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  const getShipAndLoadData = jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  const getShipAndLoadAutoSuggestData = jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  fireEvent.change(screen.getAllByTestId('input-auto-suggest')[4], { target: { value: 'abcd123' } });
  await waitFor(() => {
    expect(screen.getAllByTestId('filler')[4]).toBeInTheDocument();
  });
  await waitFor(() => {
    expect(getShipAndLoadAutoSuggestData).toBeCalled();
  });

  await waitFor(() => {
    screen.getAllByTestId('suggest-option');
  });
  userEvent.click(screen.getAllByTestId('suggest-option')[0]);
  await waitFor(() => {
    expect(getShipAndLoadData).toBeCalled();
  });
});

test('should paginate Ship And Load Management component', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });

  userEvent.click(screen.getByTestId('NavigateNextIcon'));
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
}
);

test('should handle mode check box changes', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByTestId('multiselect-header-wrapper')).toBeInTheDocument();
  });
  //open mode filter
  userEvent.click(screen.getByTestId('multiselect-header-wrapper'));

  //checked
  userEvent.click(screen.getAllByTestId('multiselect-checkbox')[0]);

  //unchecked
  userEvent.click(screen.getAllByTestId('multiselect-checkbox')[1]);

  const ele = screen.getAllByTestId('multiselect-only');
  userEvent.click(ele[0]);

}
);

test('should change the range of mabd', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  userEvent.click(screen.getByTestId('date-range-picker'));
  userEvent.click(screen.getByText('Yesterday'));
  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
}
);
test('should handle enter key input', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  userEvent.keyboard('{Enter}');
  userEvent.keyboard('{NumpadEnter}');
}
);

test('should naviagate to  live tracking component', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('CNT8481')).toBeInTheDocument();
  });
  userEvent.click(screen.getByText('CNT8481'));
}
);

test('should naviagate to  PO line management component', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util, 'getShipAndLoadAutoSuggestData').mockResolvedValue(suggestionRes);
  jest.spyOn(util, 'getShipAndLoadDataCount').mockResolvedValue(countRes);
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue(modeResponse)

  render(
    <Provider store={powerUserStore}>
      <ShipAndLoadManagement isExpanded={false} />
    </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('70331316')).toBeInTheDocument();
  });
  userEvent.click(screen.getByText('70331316'));
}
);
