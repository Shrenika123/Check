import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import classNames from 'classnames';
import { FC, useCallback, useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useSearchParams } from "react-router-dom";
import favStar from '../../../assets/images/favStar.png';
import { toast } from "react-toastify";
import { buyPlanColumns, eventColumns, labels, routes, systemSettingNames, tableConfig } from '../../../common/constants';
import { debounce } from '../../../common/debounce';
import { IEventBuyPlanResponse, IPromotionProcurementFilterRequest, IPromotionProcurementRequest, IRoutePermission, IUserState } from '../../../common/interfaces';
import { deleteActivityTrackerDetails, getActivityTrackingDetails, getEventAndBuyPlanFilterData, getEventAndBuyPlanTableCount, getEventAndBuyPlanTableData, postActivityTrackerDetails } from '../../../common/utils';
import ConfirmationBox from '../../../components/confimation-box/ConfirmationBox.component';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import PromotionAndProcurementFilter from './components/promotion-procurement-filter/PromotionAndProcurementFilter.component';
import PromotionAndProcurementTable from './components/promotion-procurement-table/PromotionAndProcurementTable.component';
import './PromotionAndProcurement.style.css';


interface Props {
  isExpanded: boolean;
}

const PromotionAndProcurementComponent: FC<Props> = (props) => {

  const settings = useSelector((state: any) => state.systemSetting);
  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const eventTabPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'EVENT_PLAN')?.permission;
  const inventoryTabPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'INVENTORY_PLAN' )?.permission;

  const calculateInitActiveTab = () =>{
    if(eventTabPerm && eventTabPerm !== 'NA'){
      const url = new URL(window.location.toString());
      url.searchParams.set('tag', 'EVENT_PLAN');
      window.history.pushState({}, '', url);
    }
    else {
      const url = new URL(window.location.toString());
      url.searchParams.set('tag', 'INVENTORY_PLAN');
      window.history.pushState({}, '', url);
    }
  }

  calculateInitActiveTab();

  let activityFavouriteDaysLimit: string;

  settings.forEach((setting: any) => {
    if (!activityFavouriteDaysLimit)
      activityFavouriteDaysLimit = setting.name === systemSettingNames.activityFavouriteDaysLimit ? setting.value : undefined;
  });

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const initData: IEventBuyPlanResponse = { totalRecords: 0, promotionProcurementPlanResponseList: [], tagType: 'EVENT_PLAN' };

  const [eventBuyPlanData, setEventBuyPlanData] = useState<IEventBuyPlanResponse>(initData);
  const [totalRecord, setTotalRecord] = useState<number>(0);
  const [activeTabIndex, setActiveTabIndex] = useState<number|undefined>(() => {
    if (searchParams.get('tag') === 'EVENT_PLAN' && eventTabPerm !== 'NA')
      return 0;
    if (searchParams.get('tag') === 'INVENTORY_PLAN' && inventoryTabPerm !== 'NA')
      return 1;
    if (eventTabPerm !== 'NA')
      return 0;
    if (inventoryTabPerm !== 'NA')
      return 1;
  });

  const [eventAutoSuggestData, setEventAutoSuggestData] = useState<string[]>([]);
  const [eventAutoSuggestionSelected, setEventAutoSuggestionSelected] = useState<string[]>([]);
  const [eventFavouritelist, setEventFavouriteList] = useState<string[]>([]);
  const eventToOverride = useRef<string>();

  const [buyPlanAutoSuggestData, setBuyPlanAutoSuggestData] = useState<string[]>([]);
  const [buyPlanAutoSuggestionSelected, setbuyPlanAutoSuggestionSelected] = useState<string[]>([]);
  const [buyPlanFavouritelist, setBuyPlanFavouriteList] = useState<string[]>([]);
  const buyPlanToOverride = useRef<string>();

  const [isConfirmBoxOpen, setConfirmBoxOpen] = useState<boolean>(false);
  const favClicked = useRef<any>();


  const filterApplied = useRef<boolean>(false);
  const defaultSortOrder = useRef<'DESC' | ''>('');
  const defaultPageNumber = useRef<number>(1);



  const routeToHome = () => {
    navigate(`/${routes.home}`);
  };

  useEffect(() => {
    setEventBuyPlanData(initData);
    setEventAutoSuggestionSelected([]);
    setbuyPlanAutoSuggestionSelected([]);
    filterApplied.current = false;
    defaultSortOrder.current = '';
    defaultPageNumber.current = 1;
    if (activeTabIndex === 0) {
      //  setSearchParams({ 'tag': 'EVENT_PLAN' })
      const url = new URL(window.location.toString());
      url.searchParams.set('tag', 'EVENT_PLAN');
      window.history.pushState({}, '', url);
      loadEventBuyPlanData('EVENT_PLAN', [], '', 1);
      loadEventBuyPlanTableCount('EVENT_PLAN', []);
      fetchPromotionFavourites();
    }
    else {
      //  setSearchParams({ 'tag': 'INVENTORY_PLAN' })
      const url = new URL(window.location.toString());
      url.searchParams.set('tag', 'INVENTORY_PLAN');
      window.history.pushState({}, '', url);
      loadEventBuyPlanData('INVENTORY_PLAN', [], '', 1);
      loadEventBuyPlanTableCount('INVENTORY_PLAN', []);
      fetchProcurementFavourites();
    }
  }, [activeTabIndex]);

  const toggleSortOrderAndPage = (pageNumber: number, sortOrder: '' | 'DESC') => {
    defaultPageNumber.current = pageNumber;
    defaultSortOrder.current = sortOrder;
    if (activeTabIndex === 0)
      loadEventBuyPlanData('EVENT_PLAN', eventAutoSuggestionSelected, sortOrder, pageNumber);
    else
      loadEventBuyPlanData('INVENTORY_PLAN', buyPlanAutoSuggestionSelected, sortOrder, pageNumber);
  };

  const fetchPromotionFavourites = () => {
    getActivityTrackingDetails('FAVOURITE', 'EVENT_PLAN', Number.parseInt(activityFavouriteDaysLimit), 2)
      .then((res) => {
        if (res.data.data !== null && res.data.data.length > 0) {
          const favPromotionIdList: string[] = res.data.data.map((value: any) => value.eventId);
          setEventFavouriteList(favPromotionIdList);
          if (res.data.activities.length >= 2)
            eventToOverride.current = res.data.activities.sort((v1: any, v2: any) => v1.createdAtEpochMilli - v2.createdAtEpochMilli)[0].activityId;
        }
        else {
          setEventFavouriteList([]);
        }
      }).catch(() => {
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Error Occurred while Fetching Favorites', alertDescription: '' }));
      });
  };
  const fetchProcurementFavourites = () => {
    getActivityTrackingDetails('FAVOURITE', 'INVENTORY_PLAN', Number.parseInt(activityFavouriteDaysLimit), 2)
      .then((res) => {
        if (res.data.data !== null && res.data.data.length > 0) {
          const favPromotionIdList: string[] = res.data.data.map((value: any) => value.buyPlanId);
          setBuyPlanFavouriteList(favPromotionIdList);
          if (res.data.activities.length >= 2)
            buyPlanToOverride.current = res.data.activities.sort((v1: any, v2: any) => v1.createdAtEpochMilli - v2.createdAtEpochMilli)[0].activityId;
        }
        else {
          setBuyPlanFavouriteList([]);
        }
      }).catch(() => {
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Error Occurred while Fetching Favorites', alertDescription: '' }));
      });
  };

  const handleFavClick = (activityId: string, tagType: 'EVENT_PLAN' | 'INVENTORY_PLAN') => {
    if ((activeTabIndex === 0 && eventFavouritelist.length >= 2) || (activeTabIndex === 1 && buyPlanFavouritelist.length >= 2)) {
      favClicked.current = { activityId, tagType };
      setConfirmBoxOpen(true);
    }
    else
      addToFavourite(activityId, tagType);
  };

  const addToFavourite = (activityId = favClicked.current.activityId, tagType = favClicked.current.tagType) => {
    dispatch(setLoading(true));
    setConfirmBoxOpen(false);
    postActivityTrackerDetails(activityId, 'FAVOURITE', tagType, Number.parseInt(activityFavouriteDaysLimit), 2, true)
      .then(res => {
        if (res.status === 200) {
          if (tagType === 'EVENT_PLAN') {
            const favPromotionIdList: string[] = res.data.data.map((value: any) => value.activityId);
            setEventFavouriteList(favPromotionIdList);
            eventToOverride.current &&
              removeFavourite(eventToOverride.current, 'EVENT_PLAN', false);
            if (res.data.data.length >= 2)
              eventToOverride.current = res.data.data.sort((v1: any, v2: any) => v1.createdAtEpochMilli - v2.createdAtEpochMilli)[0].activityId;
            else
              eventToOverride.current = undefined;
          }
          else {
            const favPromotionIdList: string[] = res.data.data.map((value: any) => value.activityId);
            setBuyPlanFavouriteList(favPromotionIdList);
            buyPlanToOverride.current &&
              removeFavourite(buyPlanToOverride.current, 'INVENTORY_PLAN', false);
            if (res.data.data.length >= 2)
              buyPlanToOverride.current = res.data.data.sort((v1: any, v2: any) => v1.createdAtEpochMilli - v2.createdAtEpochMilli)[0].activityId;
            else
              buyPlanToOverride.current = undefined;
          }
          toast('Favorite Added Successfully',{type:'success'})
        }
        return false;
      }).catch((err) => {
        console.log(err);
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Error Occurred While Adding Favorite', alertDescription: '' }));
      }).finally(() => {
        dispatch(setLoading(false));
      });
  };

  const removeFavourite = (activityId: string, tagType: 'EVENT_PLAN' | 'INVENTORY_PLAN', alert: boolean = true) => {
    alert &&
      dispatch(setLoading(true));
    deleteActivityTrackerDetails(activityId, 'FAVOURITE', tagType, Number.parseInt(activityFavouriteDaysLimit) ,2, true).then((res) => {
      if (res.status === 200) {
        alert &&
        toast('Favorite Removed Successfully',{type:'success'})

        if (tagType === 'EVENT_PLAN') {
          setEventFavouriteList(res.data.data.map((value: any) => value.activityId));
          if (res.data.data.length >= 2)
            eventToOverride.current = res.data.data.sort((v1: any, v2: any) => v1.createdAtEpochMilli - v2.createdAtEpochMilli)[0].activityId;
          else
            eventToOverride.current = undefined;
        }
        else {
          setBuyPlanFavouriteList(res.data.data.map((value: any) => value.activityId));
          if (res.data.data.length >= 2)
            buyPlanToOverride.current = res.data.data.sort((v1: any, v2: any) => v1.createdAtEpochMilli - v2.createdAtEpochMilli)[0].activityId;
          else
            buyPlanToOverride.current = undefined;
        }
      }
    }).catch((err) => {
      console.log(err);
      dispatch(setLoading(false));
      alert &&
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Error Occurred While Removing Favorite', alertDescription: '' }));
    }).finally(() => {
      alert &&
        dispatch(setLoading(false));
    });
  };

  const loadEventBuyPlanData = (tagType: 'INVENTORY_PLAN' | 'EVENT_PLAN', tagIds: string[], sortOrder: 'DESC' | '', pageNumber: number) => {
    dispatch(setLoading(true));
    const params: IPromotionProcurementRequest = {
      tagType: tagType,
      tagIds: tagIds.toString(),
      sortColumnName: 'target_date',
      sortOrder: sortOrder,
      pageSize: tableConfig.pageSize,
      pageNumber: pageNumber
    };
    getEventAndBuyPlanTableData(params).then((res) => {
      setEventBuyPlanData(res.data);
      if (res.data.promotionProcurementPlanResponseList.length === 0)
        dispatch(setShowAlert({ showAlert: true, alertType: 'warning', alertTitle: 'No Data Found', alertDescription: '' }));
    }).catch((err) => {
      console.log(err);
      setEventBuyPlanData(initData);
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to fetch event/inventory table data', alertDescription: '' }));
    }).finally(() => {
      dispatch(setLoading(false));
    });
  };
  const loadEventBuyPlanTableCount = (tagType: 'INVENTORY_PLAN' | 'EVENT_PLAN', tagIds: string[]) => {
    const params: IPromotionProcurementRequest = {
      tagType: tagType,
      tagIds: tagIds.toString(),
    };
    getEventAndBuyPlanTableCount(params).then((res) => {
      setTotalRecord(res.data);
    }).catch((err) => {
      console.log(err);
      setTotalRecord(0);
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Failed to fetch total Pages', alertDescription: '' }));
    });
  };

  const loadEventBuyPlanFilterData = (tagType: 'INVENTORY_PLAN' | 'EVENT_PLAN', filterString: string) => {
    const params: IPromotionProcurementFilterRequest = {
      tagType: tagType,
      eventOrBuyPlanList: filterString
    };
    getEventAndBuyPlanFilterData(params).then((res) => {
      if (tagType === 'EVENT_PLAN')
        setEventAutoSuggestData(res.data);
      else
        setBuyPlanAutoSuggestData(res.data);
    }).finally(() => {
    });
  };

  const loadEventBuyPlanFilterData_debounced = useCallback(debounce(loadEventBuyPlanFilterData, 500), []);

  const handleApplyFilter = () => {
    filterApplied.current = true;
    if (activeTabIndex === 0) {
      loadEventBuyPlanData('EVENT_PLAN', eventAutoSuggestionSelected, 'DESC', 1);
      loadEventBuyPlanTableCount('EVENT_PLAN', eventAutoSuggestionSelected);
    }
    else {
      loadEventBuyPlanData('INVENTORY_PLAN', buyPlanAutoSuggestionSelected, 'DESC', 1);
      loadEventBuyPlanTableCount('INVENTORY_PLAN', buyPlanAutoSuggestionSelected);
    }
  };

  const handleResetFilter = () => {
    filterApplied.current = false;
    setEventAutoSuggestionSelected([]);
    setbuyPlanAutoSuggestionSelected([]);
    if (activeTabIndex === 0) {
      loadEventBuyPlanData('EVENT_PLAN', [], 'DESC', 1);
      loadEventBuyPlanTableCount('EVENT_PLAN', []);
    }
    else {
      loadEventBuyPlanData('INVENTORY_PLAN', [], 'DESC', 1);
      loadEventBuyPlanTableCount('INVENTORY_PLAN', []);
    }
  };

  const TabPanel = (props: any) => {
    const { value, index } = props;
    return (<>
      {
        value === index && index === 0 && eventTabPerm !=='NA' &&
        <PromotionAndProcurementTable
          columns={eventColumns}
          data={eventBuyPlanData.promotionProcurementPlanResponseList}
          sortOrder={defaultSortOrder.current}
          toggleSortOrderAndPage={toggleSortOrderAndPage}
          favouriteList={eventFavouritelist}
          setFavouriteList={setEventFavouriteList}
          addToFavourite={handleFavClick}
          removeFavourite={removeFavourite}
          totalRecord={totalRecord}
          pagenumber={defaultPageNumber.current} />
      }{
        value === index && index === 1 && inventoryTabPerm !=='NA' &&
        <PromotionAndProcurementTable
          columns={buyPlanColumns}
          data={eventBuyPlanData.promotionProcurementPlanResponseList}
          sortOrder={defaultSortOrder.current}
          toggleSortOrderAndPage={toggleSortOrderAndPage}
          favouriteList={buyPlanFavouritelist}
          setFavouriteList={setBuyPlanFavouriteList}
          addToFavourite={handleFavClick}
          removeFavourite={removeFavourite}
          totalRecord={totalRecord}
          pagenumber={defaultPageNumber.current} />
      }
    </>);
  };

  const eventBuyPlanClass = classNames('event-buyplan', {
    'event-buyplan-shrink': props.isExpanded
  });
  const headerClass = classNames({
    'header-shrink': props.isExpanded,
    'header': !props.isExpanded,
  });
  const filterClass = classNames('promotion-procurement-filter', {
    '': props.isExpanded
  });

  return (
    <section className='event-buyplan-wrapper'>
      <section className={headerClass}>
        <div className='text-header'>{labels.promotionProcurementTitle}</div>
        <div className='text-menu'>
          <div className="nav" onClick={routeToHome}>{labels.homeNav}</div>&nbsp; &gt; &nbsp;
          <div className="nav">{labels.promotionProcurementTitle}</div>
        </div>
        <div className={filterClass}>
          {activeTabIndex === 0 && eventTabPerm !== 'NA' &&
            <div>
              <PromotionAndProcurementFilter
                title='Event'
                selectedValues={eventAutoSuggestionSelected}
                suggestionValues={eventAutoSuggestData}
                searchSuggetions={(e: any) => loadEventBuyPlanFilterData_debounced('EVENT_PLAN', e.originalEvent.target.value)}
                addToSelectedValue={(e: any) => setEventAutoSuggestionSelected(e.value)} onApplyFilter={handleApplyFilter} onResetFilter={handleResetFilter} filterApplied={filterApplied.current} />

            </div>}
          {activeTabIndex === 1 && inventoryTabPerm !== 'NA' &&
            <div>
              <PromotionAndProcurementFilter
                title='Inventory'
                selectedValues={buyPlanAutoSuggestionSelected}
                suggestionValues={buyPlanAutoSuggestData}
                searchSuggetions={(e: any) => loadEventBuyPlanFilterData_debounced('INVENTORY_PLAN', e.originalEvent.target.value)}
                addToSelectedValue={(e: any) => setbuyPlanAutoSuggestionSelected(e.value)} onApplyFilter={handleApplyFilter} onResetFilter={handleResetFilter} filterApplied={filterApplied.current} />

            </div>}
        </div>
      </section>
      <ConfirmationBox title='Add a new favorite plan?'
        content='At the moment, you can only select two 
      favorite plans. 
      Choosing another plan will override the last one.'
        open={isConfirmBoxOpen} onClose={() => setConfirmBoxOpen(false)}
        confirmAction={() => addToFavourite()}
        cancelAction={() => setConfirmBoxOpen(false)} image={<img src={favStar} alt='' />} />
      <section className={eventBuyPlanClass}>
        { activeTabIndex !== undefined ? <Tabs value={activeTabIndex} onChange={(e, val) => setActiveTabIndex(val)}>
          {eventTabPerm !=='NA' ? <Tab data-testid='promotionTab' label={labels.promotionTab} ></Tab>:<></>}
         {inventoryTabPerm !=='NA' ? <Tab data-testid='procurementTab' label={labels.procurementTab}></Tab>:<></>}
        </Tabs> :<></>} 
        {eventTabPerm !=='NA' && <TabPanel value={activeTabIndex} index={0} />}
        {inventoryTabPerm !=='NA' && <TabPanel value={activeTabIndex} index={1} />}
      </section>
    </section>
  );
};

export default PromotionAndProcurementComponent;