import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import PromotionAndProcurementComponent from '../PromotionAndProcurement.component';

afterEach(() => {
  cleanup();
  jest.resetAllMocks();
});

jest.mock("nanoid", () => {
  return { nanoid: () => Math.random().toString() };
});

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};
const emptyTableResponse = {
  status: 200,
  data: {
    tagType: "EVENT_PLAN",
    totalRecords: "2",
    promotionProcurementPlanResponseList: []
  }
};
const errorTableResponse = {
  status: 500,
  error: 'network error'
};

const tablePromotionResponse = {
  status: 200,
  data: {
    tagType: "EVENT_PLAN",
    totalRecords: "2",
    promotionProcurementPlanResponseList: [
      {
        promotionOrProcurementPlanId: "ThanksGiving",
        promotionOrProcurementPlanName: "ThanksGiving",
        targetDate: "NA",
        targetAmount: "4100128",
        atRiskAmount: "10871679"
      },
      {
        promotionOrProcurementPlanId: "Christmas",
        promotionOrProcurementPlanName: "Christmas",
        targetDate: "2022-12-20",
        targetAmount: "4699060",
        atRiskAmount: "2419723"
      },
    ]
  }
};
const tableProcurementResponse = {
  status: 200,
  data: {
    tagType: "INVENTORY_PLAN",
    totalRecords: "2",
    promotionProcurementPlanResponseList: [
      {
        promotionOrProcurementPlanId: "Fall",
        promotionOrProcurementPlanName: "Fall",
        targetDate: "2022-11-20",
        targetAmount: "4100128",
        atRiskAmount: "10871679"
      },
      {
        promotionOrProcurementPlanId: "Winter",
        promotionOrProcurementPlanName: "Winter",
        targetDate: "2022-12-20",
        targetAmount: "4699060",
        atRiskAmount: "2419723"
      },
    ]
  }
};

const favResponseProm = {
  status: 200,
  data: {
    data: [
      {
        eventId: "Christmas",
        eventName: "Christmas",
        targetAmount: "4699060",
        targetDate: "2022-12-20"
      }
    ],
    errorMessage: null
  }
};
const emptyFavResponse = {
  status: 200,
  data: {
    data: [],
    errorMessage: null
  }
};
const errorFavResponse = {
  status: 500,
  error: 'network error'
};
const favResponseProc = {
  status: 200,
  data: {
    data: [
      {
        buyPlanId: "Fall",
        buyPlanName: "Fall",
        targetAmount: "4699060",
        targetDate: "2022-12-20"
      }
    ],
    errorMessage: null
  }
};
const addFavResponseProm = {
  status: 200,
  data: {
    data: [
      {
        activityId: "Christmas",
        activityType: "FAVOURITE",
        activityComponent: "EVENT_PLAN",
        userId: "105924561533972237466"
      },
      {
        activityId: "ThanksGiving",
        activityType: "FAVOURITE",
        activityComponent: "EVENT_PLAN",
        userId: "105924561533972237466"
      }
    ],
    errorMessage: null
  }
};
const non200Response = {
  status: 202,
  data: {}
};
const errorResponse = {
  status: 500,
  error: 'network error'
};
const addFavResponseProc = {
  status: 200,
  data: {
    data: [
      {
        activityId: "Fall",
        activityType: "FAVOURITE",
        activityComponent: "INVENTORY_PLAN",
        userId: "105924561533972237466"
      },
      {
        activityId: "Winter",
        activityType: "FAVOURITE",
        activityComponent: "INVENTORY_PLAN",
        userId: "105924561533972237466"
      }
    ],
    errorMessage: null
  }
};

const removeFavResponse = {
  status: 200,
  data: {
    data: [],
    errorMessage: null
  }
};

const filterDataResponseProm = {
  status: 200,
  data: ['Christmas', 'ChristmasEvent']
};
const mockStore = configureStore();

test('should render promotion and procurement component', () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProc);
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
});

test('should render promotion and procurement component and open filter', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProc);
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });

  const filter = screen.getByTestId('autocomplete-multiselect-toggle-button');
  userEvent.click(filter);
  await waitFor(() => {
    expect(screen.getByText('Apply')).toBeInTheDocument();
  });
});

test('should give sugggestion with input value in filter and appy/reset filter', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProc);
  jest.spyOn(util, 'getEventAndBuyPlanFilterData').mockResolvedValue(filterDataResponseProm);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });

  const filter = screen.getByTestId('autocomplete-multiselect-toggle-button');
  userEvent.click(filter);
  await waitFor(() => {
    expect(screen.getByText('Reset')).toBeInTheDocument();
  });

  const inputBox = screen.getByRole('combobox');
  fireEvent.change(inputBox, { target: { value: 'Christmas' } });
  await waitFor(() => {
    expect(screen.getByText('ChristmasEvent')).toBeInTheDocument();
  });
  userEvent.click(screen.getByText('ChristmasEvent'));
  userEvent.click(screen.getByText('Apply'));

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });

  userEvent.click(screen.getByTestId('autocomplete-multiselect-toggle-button'));
  await waitFor(() => {
    expect(screen.getByText('Reset')).toBeInTheDocument();
  });
  userEvent.click(screen.getByText('Reset'));

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
});


test('should sort the table based on target date', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProc);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const sort = screen.getByText('Target Date');
  userEvent.click(sort);
  await waitFor(() => {
    expect(screen.getByTestId('sortUp')).toBeInTheDocument();
  });
});

test('should add to favourite', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProm);
  jest.spyOn(util, 'postActivityTrackerDetails').mockResolvedValue(addFavResponseProm);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByTestId('non-favourite-icon')).toBeInTheDocument();
  });

  const nonFavouriteIcon = screen.getByTestId('non-favourite-icon');
  userEvent.click(nonFavouriteIcon);
  await waitFor(() => {
    expect(screen.queryByTestId('non-favourite-icon')).toBe(null);
  });
});

test('should not add to favourite with non 200 response', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProm);
  jest.spyOn(util, 'postActivityTrackerDetails').mockResolvedValue(non200Response);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByTestId('non-favourite-icon')).toBeInTheDocument();
  });

  const nonFavouriteIcon = screen.getByTestId('non-favourite-icon');
  userEvent.click(nonFavouriteIcon);
  await waitFor(() => {
    expect(screen.getByTestId('non-favourite-icon')).toBeInTheDocument();
  });
});

test('should not add to favourite with error response', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProm);
  jest.spyOn(util, 'postActivityTrackerDetails').mockResolvedValue(errorResponse);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByTestId('non-favourite-icon')).toBeInTheDocument();
  });

  const nonFavouriteIcon = screen.getByTestId('non-favourite-icon');
  userEvent.click(nonFavouriteIcon);
  await waitFor(() => {
    expect(screen.getByTestId('non-favourite-icon')).toBeInTheDocument();
  });
});

test('should remove from favourite', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProm);
  jest.spyOn(util, 'deleteActivityTrackerDetails').mockResolvedValue(removeFavResponse);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByTestId('favourite-icon')).toBeInTheDocument();
  });
  const favouriteIcon = screen.getByTestId('favourite-icon');
  userEvent.click(favouriteIcon);
  await waitFor(() => {
    expect(screen.queryByTestId('favourite-icon')).toBe(null);
  });
});
test('should not remove from favourite with non 200 response', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProm);
  jest.spyOn(util, 'deleteActivityTrackerDetails').mockResolvedValue(non200Response);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByTestId('favourite-icon')).toBeInTheDocument();
  });
  const favouriteIcon = screen.getByTestId('favourite-icon');
  userEvent.click(favouriteIcon);
  await waitFor(() => {
    expect(screen.getByTestId('favourite-icon')).toBeInTheDocument();
  });
});
test('should not remove from favourite with error response', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tablePromotionResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponseProm);
  jest.spyOn(util, 'deleteActivityTrackerDetails').mockResolvedValue(errorResponse);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByTestId('favourite-icon')).toBeInTheDocument();
  });
  const favouriteIcon = screen.getByTestId('favourite-icon');
  userEvent.click(favouriteIcon);
  await waitFor(() => {
    expect(screen.getByTestId('favourite-icon')).toBeInTheDocument();
  });
});

test('should render promotion and procurement component with empty table response', () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(emptyTableResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(emptyFavResponse);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
});

test('should render promotion and procurement component with error API response', () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockRejectedValue({ status: 500 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(errorTableResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(errorFavResponse);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider>, { wrapper: BrowserRouter });
});

test('should render promotion and procurement component with navbar and change tab to procurement tab', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValueOnce(tableProcurementResponse);
  //const getProcurementTableData = jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValueOnce(favResponseProc);
  // const getActivityTrackingDetailsProc = jest.spyOn(util, 'getActivityTrackingDetails');

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={true} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);
  await waitFor(() => {
    expect(screen.getByText('Fall')).toBeInTheDocument();
  });
});

test('should change tab to procurement tab and sort based on target date', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValue(tableProcurementResponse);
  //const getProcurementTableData = jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValue(favResponseProc);
  // const getActivityTrackingDetailsProc = jest.spyOn(util, 'getActivityTrackingDetails');

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={true} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });

  const sort = screen.getByText('Target Date');
  userEvent.click(sort);
  await waitFor(() => {
    expect(screen.getByTestId('sortUp')).toBeInTheDocument();
  });
});

test('should render promotion and procurement component  and change tab to procurement tab with empty response', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValueOnce(emptyTableResponse);
  //const getProcurementTableData = jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValueOnce(emptyFavResponse);
  // const getActivityTrackingDetailsProc = jest.spyOn(util, 'getActivityTrackingDetails');

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);
  // await waitFor(() => {
  //   expect(screen.queryByText('Christmas')).toBe(null);
  // });
});

test('should render promotion and procurement component and change tab to procurement tab with error response', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValueOnce(errorTableResponse);
  //const getProcurementTableData = jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValueOnce(errorFavResponse);
  // const getActivityTrackingDetailsProc = jest.spyOn(util, 'getActivityTrackingDetails');

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);
  // await waitFor(() => {
  //   expect(screen.queryByText('Christmas')).toBe(null);
  // });
});

test('should render promotion and procurement component and change tab to procurement tab and add to favourite', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValueOnce(tableProcurementResponse);
  //const getProcurementTableData = jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValueOnce(favResponseProc);
  // const getActivityTrackingDetailsProc = jest.spyOn(util, 'getActivityTrackingDetails');
  jest.spyOn(util, 'postActivityTrackerDetails').mockResolvedValue(addFavResponseProc);
  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);
  // await waitFor(() => {
  //   expect(screen.getByTestId('non-favourite-icon')).toBeInTheDocument();
  // });

  // const nonFavouriteIcon = screen.getByTestId('non-favourite-icon');
  // userEvent.click(nonFavouriteIcon);
  // await waitFor(() => {
  //   expect(screen.queryByTestId('non-favourite-icon')).toBe(null);
  // });
});

test('should render promotion and procurement component and change tab to procurement tab and remove from favourite', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValue(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValue(favResponseProc);
  jest.spyOn(util, 'deleteActivityTrackerDetails').mockResolvedValue(removeFavResponse);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);
  // await waitFor(() => {
  //  expect(screen.getByTestId('favourite-icon')).toBeInTheDocument();
  // });

  // const nonFavouriteIcon = screen.getByTestId('non-favourite-icon');
  // userEvent.click(nonFavouriteIcon);
  // await waitFor(() => {
  //   expect(screen.queryByTestId('favourite-icon')).toBe(null);
  // });
});

test('should render promotion and procurement component and open filter for procurement tab', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValueOnce(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValueOnce(favResponseProc);
  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });

  const filter = screen.getByTestId('autocomplete-multiselect-toggle-button');
  userEvent.click(filter);
  await waitFor(() => {
    expect(screen.getByText('Apply')).toBeInTheDocument();
  });
});

test('should give sugggestion with input value in filter and appy/reset filter for procurement tab', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../common/utils');
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({ data: 100 });
  jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValueOnce(tablePromotionResponse)
    .mockResolvedValue(tableProcurementResponse);
  jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValueOnce(favResponseProm)
    .mockResolvedValue(favResponseProc);
  jest.spyOn(util, 'getEventAndBuyPlanFilterData').mockResolvedValue(filterDataResponseProm);

  render(<Provider store={powerUserStore}>
    <PromotionAndProcurementComponent isExpanded={false} />
  </Provider >, { wrapper: BrowserRouter });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  const procurementTab = screen.getByTestId('procurementTab');
  userEvent.click(procurementTab);

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });

  const filter = screen.getByTestId('autocomplete-multiselect-toggle-button');
  userEvent.click(filter);
  await waitFor(() => {
    expect(screen.getByText('Reset')).toBeInTheDocument();
  });

  const inputBox = screen.getByRole('combobox');
  fireEvent.change(inputBox, { target: { value: 'ChristmasEvent' } });
  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
  userEvent.click(screen.getByText('Christmas'));
  //userEvent.click(screen.getByText('Apply'));

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });

  userEvent.click(screen.getByTestId('autocomplete-multiselect-toggle-button'));
  await waitFor(() => {
    expect(screen.getByText('Reset')).toBeInTheDocument();
  });
  userEvent.click(screen.getByText('Reset'));

  await waitFor(() => {
    expect(screen.getByText('Christmas')).toBeInTheDocument();
  });
});