import { Pagination } from '@mui/material';
import { format } from 'date-fns';
import { nanoid } from 'nanoid';
import 'primeicons/primeicons.css';
import { FC } from 'react';
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io';
import { useNavigate } from "react-router-dom";
import { routes, tableConfig } from '../../../../../common/constants';
import { IPromotionProcurement, IRoutePermission, IUserState } from '../../../../../common/interfaces';
import { getGMTTimeStamp, isStringValid } from '../../../../../common/utils';
import './PromotionAndProcurementTable.style.css';
import { useSelector } from 'react-redux';
interface Props {
  columns: string[];
  data: IPromotionProcurement[];
  totalRecord: number;
  pagenumber: number;
  sortOrder: 'DESC' | '';
  toggleSortOrderAndPage: Function;
  favouriteList: string[];
  setFavouriteList: Function;
  addToFavourite: Function;
  removeFavourite: Function;
}

const PromotionAndProcurementTable: FC<Props> = (props) => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const eventInventoryDetailsPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'EVENT_AND_INVENTORY_PLAN_DETAILS')?.permission;


  const navigate = useNavigate();

  const navigateToDetails = (tagId: string, tagName: string, targetDate: string) => {
    const tagType = props.columns[0] === 'Event' ? 'EVENT_PLAN' : 'INVENTORY_PLAN';
    navigate(`/${routes.promotionProcurementDetails}`, { state: { tagType, tagId, tagName, targetDate } });
  };

  const getSortIcon = () => {
    if (props.sortOrder === 'DESC')
      return <IoMdArrowDropdown data-testid='sortDown' className='sort-icon' />;
    else
      return <IoMdArrowDropup data-testid='sortUp' className='sort-icon' />;

  };

  const favouriteIcon = (eventOrBuyPlanId: string) => {
    if (props.favouriteList.includes(eventOrBuyPlanId)) {
      return <i data-testid='favourite-icon' onClick={() => props.removeFavourite(eventOrBuyPlanId, props.columns[0] === 'Event' ? 'EVENT_PLAN' : 'INVENTORY_PLAN')}
        className='pi pi-star-fill pointer'></i>;
    }
    else {
      return <i data-testid='non-favourite-icon' onClick={() => props.addToFavourite(eventOrBuyPlanId, props.columns[0] === 'Event' ? 'EVENT_PLAN' : 'INVENTORY_PLAN')} className='pi pi-star pointer'></i>;
    }
  };

  const getAtRistPecentage = (quantity: string, atRisk: string): string => {
    return (quantity === 'NA' || atRisk === 'NA') ? 'NA'
      :
      (Math.floor((Number.parseInt(atRisk) / Number.parseInt(quantity)) * 10000) / 100).toString()+'%';
  };

  return (<>
    <section className='event-buyplan-table-wrapper'>
      <table className='event-buyplan-table'>
        <thead>
          <tr>
            <th className='favourite-head'></th>
            {props.columns && props.columns.length > 0 && props.columns.map((value) => { return { value: value, key: nanoid() }; }).map((value, index) => {
              return (
                <th key={value.key}>
                  <div onClick={value.value === 'Target Date' ?
                    () => props.toggleSortOrderAndPage(props.pagenumber, props.sortOrder === '' ? 'DESC' : '') :
                    () => { }} id={value.value}>
                    {value.value}{value.value === 'Target Date' ? getSortIcon() : ''}
                  </div>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {props.data && props.data.length > 0 && props.data.map((value) => { return { value: value, key: nanoid() }; }).map((value, index) => {
            return (
              <tr key={value.key}>
                <td>{favouriteIcon(value.value.promotionOrProcurementPlanId)}</td>
                <td> 
                  <div 
                    className={
                     isStringValid(eventInventoryDetailsPerm) && eventInventoryDetailsPerm !== 'NA'
                            ? 'hyperlink'
                            : 'non-hyperlink'
                    }
                    onClick={() => navigateToDetails(value.value.promotionOrProcurementPlanId, value.value.promotionOrProcurementPlanName, value.value.targetDate)}> 
                    {value.value.promotionOrProcurementPlanName}  
                  </div>
                </td>
                <td> {value.value.targetDate === 'NA' ? 'NA' : format(getGMTTimeStamp(value.value.targetDate), 'MM/dd/yyyy')}</td>
                <td> {value.value.targetAmount === 'NA' ? 'NA' : Number.parseInt(value.value.targetAmount).toLocaleString('en-US')}</td>
                <td> {value.value.atRiskAmount === 'NA' ? 'NA' : Number.parseInt(value.value.atRiskAmount).toLocaleString('en-US')}</td>
                <td>{getAtRistPecentage(value.value.targetAmount, value.value.atRiskAmount)}</td>
              </tr>
            );
          })}
          {props.data && props.data.length < 8 && [...Array(8 - props.data.length)].map(() => { return { key: nanoid() }; }).map((_, index) => {
            return (
              <tr data-testid='filler' className='custom-tr' key={_.key}>
                <td className='custom-td' colSpan={6}><div className='filler' ></div></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </section>
    <section className='paginated'>
      <Pagination count={Math.ceil(props.totalRecord / tableConfig.pageSize)} variant='text' shape='rounded' siblingCount={1} color={'standard'} showFirstButton showLastButton size="small"
        onChange={(e, value) => props.toggleSortOrderAndPage(value, props.sortOrder)} page={props.pagenumber} />
    </section>
    <div className='range-label'> *By Default range of target date will be T-90 to T+60</div>
  </>
  );

};

export default PromotionAndProcurementTable;