//import Popover from '@mui/material/Popover';
import Popper, { PopperPlacementType } from '@mui/material/Popper';
import Stack from '@mui/material/Stack';
import { AutoComplete } from 'primereact/autocomplete';
import { Button } from "primereact/button";
import { FC, useEffect, useRef, useState } from 'react';
import './PromotionAndProcurementFilter.style.css';

interface Props {
  title: string;
  selectedValues: string[],
  addToSelectedValue: any;
  suggestionValues: string[],
  searchSuggetions: any;
  onApplyFilter: any;
  onResetFilter: any;
  filterApplied:boolean
}
const PromotionAndProcurementFilter: FC<Props> = (props) => {
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [placement, setPlacement] = useState<PopperPlacementType>();
  const [open, setOpen] = useState(false);

  const boxRef = useRef<HTMLDivElement>(null);
  const toggleRef = useRef(null);

  const handleClick =
    (newPlacement: PopperPlacementType) =>
      (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(event.currentTarget);
        setOpen((prev) => placement !== newPlacement || !prev);
        setPlacement(newPlacement);
      };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const onApplyFilter = (e: any) => {
    props.onApplyFilter(e);
    setOpen(false);
  };

  const onResetFilter=(e:any)=>{
    props.onResetFilter(e);
    setOpen(false);
  }
  const hideOnClickOutside = (e: any) => {
    if (boxRef.current && !boxRef.current.contains(e.target)
      && e.target.id !== 'autocomplete-multiselect-toggle-button'
      && e.target.parentNode.id !== 'autocomplete-multiselect-toggle-button'
      && e.target.id !== 'autocomplete-multiselect_list'
      && e.target.parentNode.id !== 'autocomplete-multiselect_list') {
      setOpen(false);
    }
  };
  useEffect(() => {
    // event listeners
    document.addEventListener("click", hideOnClickOutside, true);
  }, []);

  const id = open ? 'promotion-procurement-filter-box' : undefined;

  return (
    <section className='promotion-procurement-autocomplete-multiselect-filter'>
      <Button
        ref={toggleRef}
        type="button"
        icon="pi pi-filter"
        label={"Filter"}
        onClick={handleClick('bottom-end')}
        aria-haspopup
        aria-controls="overlay_panel"
        className="autocomplete-multiselect-toggle-button"
        id='autocomplete-multiselect-toggle-button'
        data-testid='autocomplete-multiselect-toggle-button'
      />

      <Popper
        ref={boxRef}
        id={id}
        open={open}
        anchorEl={anchorEl}
        placement={placement}
        sx={{ display: 'flex', flexDirection: 'column', position: 'absolute' }}
      >
        <Stack spacing={2} sx={{ backgroundColor: '#1e1e1e', width: '23rem' }} p={2} >
          <div className='filter-title'>{props.title}</div>
          <AutoComplete
            multiple
            id='autocomplete-multiselect'
            className='autocomplete-multiselect-input'
            value={props.selectedValues}
            suggestions={props.suggestionValues}
            completeMethod={props.searchSuggetions}
            onChange={props.addToSelectedValue}
            placeholder='Type for suggestions'
          />
          <Stack spacing={2} direction='row'>
          <Button
            type="button"
            label='Apply'
            disabled={props.selectedValues.length === 0}
            onClick={onApplyFilter}
            className='autocomplete-multiselect-apply-button'
            data-testid='autocomplete-multiselect-apply-button'>
          </Button>
          <Button
            type="button"
            label='Reset'
            onClick={onResetFilter}
            disabled={!props.filterApplied}
            className='autocomplete-multiselect-apply-button'
            data-testid='autocomplete-multiselect-apply-button'>
          </Button>
          </Stack>
        </Stack>
      </Popper>
    </section>

  );

};

export default PromotionAndProcurementFilter;