import { Pagination } from '@mui/material';
import classNames from 'classnames';
import {
  BaseSyntheticEvent,
  FC,
  useCallback,
  useEffect,
  useState,
} from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  allowedMultiSelectFilters,
  labels,
  ItemManagementColumn,
  routes,
  tableConfig,
} from '../../../common/constants';
import CustomDateRangePicker from '../../../components/date-range-picker/CustomDateRangePicker';
import ItemManagementTable from './components/item-management-table';
import { Range } from 'react-date-range';
import { format } from 'date-fns';
import {
  getGMTTimeStamp,
  getItemManagementAutoSuggestData,
  getItemManagementDataCount,
  getItemManagementDetails,
  getMultiSelectFilterData,
  getSettingModifiedData,
} from '../../../common/utils';
import './item-management.style.css';
import AutoSuggest from '../../../components/auto-suggest/AutoSuggest.component';
import MultiSelectFilter from '../../../components/multiselect-filter/MultiSelectFilter';
import {
  IItemManagementFilterRequest,
  IItemManagementRequest,
  IItemManagementResponse,
  ISort,
  ISortAndPage,
} from '../../../common/interfaces';
import { useDidComponentUpdate } from '../../../hooks/useDidComponentUpdate';
import { debounce } from '../../../common/debounce';
import { useDispatch, useSelector } from 'react-redux';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';

interface Props {
  isExpanded: boolean;
}

const ItemManagement: FC<Props> = (props) => {
  const initSortPage: ISortAndPage = {
    sortColumn: ItemManagementColumn.mabd,
    sortOrder: '',
    pageNumber: 1,
  };

  const settings = useSelector((state: any) => state.systemSetting);
  const location = useLocation();

  const [mabdInput, setMabdInput] = useState<string>(
    location?.state?.mabd ?? ''
  );

  const [range, setRange] = useState<Range[]>(() =>
    mabdInput ?
      [{
        startDate: getGMTTimeStamp(mabdInput),
        endDate: getGMTTimeStamp(mabdInput),
        key: 'selection'
      }] :
    getSettingModifiedData(settings,15,45)
  );
  const [tableData, setTableData] = useState<IItemManagementResponse[]>();
  const [totalCount, setTotalCount] = useState<number>(0);
  const [sortAndPage, setSortAndPage] = useState<ISortAndPage>(initSortPage);

  const [statusFilterData, setStatusFilterData] = useState<string[]>([]);
  const [statusCheckedData, setStatusCheckedData] = useState<string[]>([]);

  const [poNumberInput, setPoNumberInput] = useState<string>(
    location?.state?.poNumber ?? ''
  );
  const [poNumberSuggestData, setPoNumberSuggestData] = useState<string[]>(
    location?.state ? [location?.state?.poNumber] : []
  );

  const [itemNumberInput, setItemNumberInput] = useState<string>(
    location.state?.itemNumber ?? ''
  );
  const [itemNumberSuggestedData, setItemNumberIdSuggestData] = useState<
    string[]
  >(location?.state ? [location?.state?.itemNumber] : []);

  const [statusInput, setStatusInput] = useState<string>('');
  const [shipmentIdSuggestedData, setShipmentIdSuggestedData] = useState<
    string[]
  >([]);

  const [eventIdInput, setEventIdInput] = useState<string>('');
  const [eventIdSuggestData, setEventIdSuggestData] = useState<string[]>([]);

  const [upcInput, setUpcInput] = useState<string>('');
  const [upcSuggestedData, setUpcSuggestedData] = useState<string[]>([]);

  const [buyPlanIdInput, setBuyPlanIdInput] = useState<string>('');
  const [buyPlanIdSuggestedData, setBuyPlanIdSuggestedData] = useState<
    string[]
  >([]);

  const [showPoInputLoader, setShowPoInputLoader] = useState<boolean>(false);
  const [showItemNumberInputLoader, setShowItemNumberInputLoader] =
    useState<boolean>(false);
  const [shipmentIdInput, setShipmenIdInput] = useState<string>('');
  const [showShipmentIdInputLoader, setShowShipmentIdInputLoader] =
    useState<boolean>(false);
  const [showUpcInputLoader, setShowUpcInputLoader] = useState<boolean>(false);
  const [showEventIdLoader, setShowEventIdInputLoader] =
    useState<boolean>(false);
  const [showBuyPlanIdLoader, setShowBuyPlanIdInputLoader] =
    useState<boolean>(false);
  const [closePoInputAutoSug, setClosePoInputAutoSug] =
    useState<boolean>(false);
  const [closeItemNumberInputAutoSug, setCloseItemNumberAutoSug] =
    useState<boolean>(false);
  const [closeShipmentIdInputAutoSug, setCloseShipmentIdInputAutoSug] =
    useState<boolean>(false);
  const [closeUpcInputAutoSug, setCloseUpcInputAutoSug] =
    useState<boolean>(false);
  const [closeEventIdAutoSug, setCloseEventIdInputAutoSug] =
    useState<boolean>(false);
  const [closeBuyPlanIdAutoSug, setCloseBuyPlanIdInputAutoSug] =
    useState<boolean>(false);
  const [statusData, setStatusData] = useState<string[]>([]);
  const [filterClicked, setFilteredClicked] = useState<boolean>(false);
  const dispatch = useDispatch();

  const errorHandling = (alertTitle: string, alertDescription: string) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: 'error',
        alertTitle: alertTitle,
        alertDescription: alertDescription,
      })
    );
  };

  const fetchStatusFilterData = () => {
    getMultiSelectFilterData(allowedMultiSelectFilters.itemStatus)
      .then((res) => {
        setStatusData(res?.data?.data);
      })
      .catch((err) => {
        console.log(err);
        errorHandling('Failed to fetch status filter data', '');
      });
  };
  //initial table and filter render
  useEffect(() => {
    fetchItemTotalCount();
    fetchStatusFilterData();
  }, []);

  useEffect(() => {
    if (location?.state?.poNumber) {
      setCloseItemNumberAutoSug(true);
      setClosePoInputAutoSug(true);
    }
  }, [location]);

  const handleSorting = (sortdata: ISort) => {
    setSortAndPage({
      sortColumn: sortdata.sortColumn,
      sortOrder: sortdata.sortOrder,
      pageNumber: 1,
    });
  };

  const handleInputChange = (e: BaseSyntheticEvent) => {
    switch (e.target.name) {
      case labels.poNumber:
        setPoNumberInput(e.target.value);
        break;
      case labels.UPC:
        setUpcInput(e.target.value);
        break;
      case labels.itemNumber:
        setItemNumberInput(e.target.value);
        break;
      case labels.shipmentId:
        setShipmenIdInput(e.target.value);
        break;
      case labels.ItemStatus:
        setStatusInput(e.target.value);
        break;
      case labels.EventId:
        setEventIdInput(e.target.value);
        break;
      case labels.BuyPlanID:
        setBuyPlanIdInput(e.target.value);
        break;
      case labels.mabd:
        setMabdInput(e.target.value);
        break;
    }
  };

  const getItemManagementParam = (): IItemManagementRequest => {
    return {
      pageSize: tableConfig.pageSize,
      pageNumber: sortAndPage.pageNumber,
      startDate: mabdInput.trim() !== '' ? mabdInput.trim() : format(range[0].startDate!, 'yyyy-MM-dd'),
      endDate: mabdInput.trim() !== '' ? mabdInput.trim() : format(range[0].endDate!, 'yyyy-MM-dd'),
      sortColumn: sortAndPage.sortColumn,
      sortOrder: sortAndPage.sortOrder,
      poNumber: poNumberInput.trim() ?? '',
      upc: upcInput.trim() ?? '',
      buyPlanName: buyPlanIdInput.trim() ?? '',
      eventId: eventIdInput.trim() ?? '',
      shipmentId: shipmentIdInput.trim() ?? '',
      itemNumber: itemNumberInput.trim() ?? '',
      itemStatus:
        statusCheckedData.length === 0 ? '' : statusCheckedData.toString(),
    };
  };

  const fetchItemTotalCount = () => {
    dispatch(setLoading(true));
    getItemManagementDataCount(getItemManagementParam())
      .then((res) => {
        setTotalCount(res?.data?.totalRecords);
      })
      .catch((err) => {
        console.log('count api failed with status' + err);
        errorHandling('Failed to load total pages', '');
      });
  };

  const loadItemTableDataAndPopulateView = () => {
    dispatch(setLoading(true));
    getItemManagementDetails(getItemManagementParam())
      .then((res) => {
        if (res?.status === 200) {
          if (res?.data?.data?.length === 0)
            errorHandling(
              'No data found for the selected filters',''
            );
          setTableData(res?.data?.data);
        } else {
          dispatch(setLoading(false));
          errorHandling('Failed to fetch item management table data', '');
        }
      })
      .catch((err) => {
        setTableData(undefined);
        dispatch(setLoading(false));
        errorHandling('Failed to fetch item management table data', '');
        console.log('item-management api failed with status' + err);
      })
      .finally(() => {
        dispatch(setLoading(false));
        setFilteredClicked(false);
      });
  };

  const fetchSuggestData = (
    filterData: string,
    rangeVar: Range[],
    selectField: string
  ) => {
    if (
      filterData.length >= 4 ||
      ((selectField === ItemManagementColumn.buyPlanId ||
        ItemManagementColumn.itemNumber) &&
        filterData.length >= 2)
    ) {
      const params: IItemManagementFilterRequest = {
        selectField: selectField,
        startDate: format(rangeVar[0].startDate!, 'yyyy-MM-dd'),
        endDate: format(rangeVar[0].endDate!, 'yyyy-MM-dd'),
      };
      switch (selectField) {
        case ItemManagementColumn.poNumber:
          setShowPoInputLoader(true);
          params.poNumber = [filterData];
          break;
        case ItemManagementColumn.itemNumber:
          params.itemNumber = [filterData];
          setShowItemNumberInputLoader(true);
          break;
        case ItemManagementColumn.shipmentId:
          params.shipmentId = [filterData];
          setShowShipmentIdInputLoader(true);
          break;
        case ItemManagementColumn.upc:
          params.upc = [filterData];
          setShowUpcInputLoader(true);
          break;
        case ItemManagementColumn.eventId:
          params.eventId = [filterData];
          setShowEventIdInputLoader(true);
          break;
        case ItemManagementColumn.buyPlanId:
          params.buyPlanName = [filterData];
          setShowBuyPlanIdInputLoader(true);
          break;
      }

      getItemManagementAutoSuggestData(params)
        .then((res) => {
          if (res.status === 200) {
            switch (selectField) {
              case ItemManagementColumn.poNumber:
                setPoNumberSuggestData(res?.data?.data);
                break;
              case ItemManagementColumn.itemNumber:
                setItemNumberIdSuggestData(res?.data?.data);
                break;
              case ItemManagementColumn.shipmentId:
                setShipmentIdSuggestedData(res?.data?.data);
                break;
              case ItemManagementColumn.upc:
                setUpcSuggestedData(res?.data?.data);
                break;
              case ItemManagementColumn.eventId:
                setEventIdSuggestData(res?.data?.data);
                break;
              case ItemManagementColumn.buyPlanId:
                setBuyPlanIdSuggestedData(res?.data?.data);
                break;
            }
          }
        })
        .finally(() => {
          setShowPoInputLoader(false);
          setShowUpcInputLoader(false);
          setShowEventIdInputLoader(false);
          setShowShipmentIdInputLoader(false);
          setShowItemNumberInputLoader(false);
          setShowBuyPlanIdInputLoader(false);
        });
    }
  };

  const fetchSuggestData_debounced = useCallback(
    debounce(fetchSuggestData, 500),
    []
  );

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      poNumberInput,
      range,
      ItemManagementColumn.poNumber
    );
  }, [poNumberInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      itemNumberInput,
      range,
      ItemManagementColumn.itemNumber
    );
  }, [itemNumberInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      shipmentIdInput,
      range,
      ItemManagementColumn.shipmentId
    );
  }, [shipmentIdInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(upcInput, range, ItemManagementColumn.upc);
  }, [upcInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      eventIdInput,
      range,
      ItemManagementColumn.eventId
    );
  }, [eventIdInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      buyPlanIdInput,
      range,
      ItemManagementColumn.buyPlanId
    );
  }, [buyPlanIdInput]);

  useDidComponentUpdate(() => {
    dispatch(setLoading(false));
  }, [tableData]);

  useDidComponentUpdate(() => {
    setPoNumberInput('');
    setItemNumberInput('');
    setStatusInput('');
    setShipmenIdInput('');
    setEventIdInput('');
    setUpcInput('');
    setMabdInput('');
    setStatusCheckedData([]);
  }, [range]);

  useDidComponentUpdate(() => {
    loadItemTableDataAndPopulateView();
  }, [sortAndPage]);

  useDidComponentUpdate(() => {
    setSortAndPage(initSortPage);
    fetchItemTotalCount();
  }, [statusCheckedData]);

  useEffect(() => {
    if (filterClicked) {
      loadItemTableDataAndPopulateView();
      fetchItemTotalCount();
    }
  }, [filterClicked]);

  const handlePoNumberSuggestionClick = (value: string) => {
    setClosePoInputAutoSug(true);
    setPoNumberInput(value);
    setFilteredClicked(true);
  };
  const handleUpcSuggestionClick = (value: string) => {
    setCloseUpcInputAutoSug(true);
    setUpcInput(value);
    setFilteredClicked(true);
  };
  const handleShipmentIdSuggestionClick = (value: string) => {
    setClosePoInputAutoSug(true);
    setShipmenIdInput(value);
    setFilteredClicked(true);
  };
  const handleItemNumberSuggestionClick = (value: string) => {
    setCloseItemNumberAutoSug(true);
    setItemNumberInput(value);
    setFilteredClicked(true);
  };

  const handleEventIdSuggestionClick = (value: string) => {
    setCloseEventIdInputAutoSug(true);
    setEventIdInput(value);
    setFilteredClicked(true);
  };

  const handleBuyPlanIdSuggestionClick = (value: string) => {
    setCloseBuyPlanIdInputAutoSug(true);
    setBuyPlanIdInput(value);
    setFilteredClicked(true);
  };

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.code === 'Enter' || event.code === 'NumpadEnter') {
        event.preventDefault();
        setSortAndPage(initSortPage);
        fetchItemTotalCount();
      }
    };
    document.addEventListener('keydown', listener);
    return () => {
      document.removeEventListener('keydown', listener);
    };
  }, [
    poNumberInput,
    upcInput,
    shipmentIdInput,
    eventIdInput,
    itemNumberInput,
    buyPlanIdInput,
  ]);

  const onlyStatusClickHandler = (query: string) => {
    if (statusFilterData && query) {
      setStatusCheckedData(
        statusFilterData.filter(
          (value) =>
            value.toString().toLowerCase() === query.toLocaleLowerCase()
        )
      );
    }
  };

  const navigate = useNavigate();

  const routeToHome = () => {
    navigate(`/${routes.home}`);
  };

  // classnames -----------------
  const containerItemClass = classNames({
    'container-shrink': props.isExpanded,
    container: !props.isExpanded,
  });

  const paginationItemClass = classNames('paginated', {
    'paginated-shrink': props.isExpanded,
  });
  return (
    <section id='item-management'>
      <section className={containerItemClass}>
        <section
          className={'item-management-header'}
          data-testid='item-management-header-testId'>
          <section className='header-left-container'>
            <div className='text-header'>{labels.poItemManagement}</div>
            <div
              className='text-menu'
              data-testid='item-route-testId'>
              <div
                data-testid='route-to-home'
                className='navLink'
                onClick={routeToHome}>
                {labels.homeNav}
              </div>
              <div>{labels.poItemManagement}</div>
            </div>
          </section>
          <div
            className='dropdown-group'
            data-testid='item-datepicker-testId'>
            <p>Date Range(UTC)</p>
            <CustomDateRangePicker
              range={range}
              setRange={setRange}
              footerLabel='By default date range of MABD will be T-15 to T+45'
            />
          </div>
        </section>
        <section className='item-filters'>
          <div
            className='item-filter-wrapper'
            data-testid='poNumber-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.UPC}
            </p>
            <AutoSuggest
              inputSuggestionData={upcSuggestedData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleUpcSuggestionClick(value)
              }
              inputData={upcInput}
              handleInputChange={handleInputChange}
              name={labels.UPC}
              isClosed={closeUpcInputAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showUpcInputLoader}
              setClose={setCloseUpcInputAutoSug}
            />
          </div>
          <div
            className='item-filter-wrapper'
            data-testid='itemNumber-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.ItemNumber}
            </p>
            <AutoSuggest
              inputSuggestionData={itemNumberSuggestedData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleItemNumberSuggestionClick(value)
              }
              inputData={itemNumberInput}
              handleInputChange={handleInputChange}
              name={labels.itemNumber}
              isClosed={closeItemNumberInputAutoSug}
              inputLengthToShowSuggestion={2}
              isLoading={showItemNumberInputLoader}
              setClose={setCloseItemNumberAutoSug}
            />
          </div>
          <div
            className='item-filter-wrapper'
            data-testid='shipmentId-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.shipmentId}
            </p>
            <AutoSuggest
              inputSuggestionData={shipmentIdSuggestedData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleShipmentIdSuggestionClick(value)
              }
              inputData={shipmentIdInput}
              handleInputChange={handleInputChange}
              name={labels.shipmentId}
              isClosed={closeShipmentIdInputAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showShipmentIdInputLoader}
              setClose={setCloseShipmentIdInputAutoSug}
            />
          </div>
          <div
            className='item-filter-wrapper'
            data-testid='upc-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.poNumber}
            </p>

            <AutoSuggest
              inputSuggestionData={poNumberSuggestData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handlePoNumberSuggestionClick(value)
              }
              inputData={poNumberInput}
              handleInputChange={handleInputChange}
              name={labels.poNumber}
              isClosed={closePoInputAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showPoInputLoader}
              setClose={setClosePoInputAutoSug}
            />
          </div>
          <div
            className='item-filter-wrapper'
            data-testid='eventId-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.EventId}
            </p>
            <AutoSuggest
              inputSuggestionData={eventIdSuggestData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleEventIdSuggestionClick(value)
              }
              inputData={eventIdInput}
              handleInputChange={handleInputChange}
              name={labels.EventId}
              isClosed={closeEventIdAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showEventIdLoader}
              setClose={setCloseEventIdInputAutoSug}
            />
          </div>
          <div
            className='item-filter-wrapper'
            data-testid='buyPlanId-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.BuyPlanID}
            </p>
            <AutoSuggest
              inputSuggestionData={buyPlanIdSuggestedData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleBuyPlanIdSuggestionClick(value)
              }
              inputData={buyPlanIdInput}
              handleInputChange={handleInputChange}
              name={labels.BuyPlanID}
              isClosed={closeBuyPlanIdAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showBuyPlanIdLoader}
              setClose={setCloseBuyPlanIdInputAutoSug}
            />
          </div>
          <div
            className='item-filter-wrapper'
            data-testid='status-multiSelect-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.ItemStatus}
            </p>
            <MultiSelectFilter
              data={statusData}
              setCheckedData={setStatusCheckedData}
              checkedData={statusCheckedData}
              filterData={statusFilterData}
              setFilterData={setStatusFilterData}
              inputValue={statusInput}
              setInputValue={setStatusInput}
              onlyButtonHandler={onlyStatusClickHandler}
            />
          </div>
        </section>
        <section className='item-management-table-pagination-wrapper'>
          <ItemManagementTable
            data={tableData || []}
            handleClick={(data) => handleSorting(data)}
          />
          <section className={paginationItemClass}>
            <Pagination
              count={Math.ceil(totalCount / tableConfig.pageSize)}
              variant='text'
              shape='rounded'
              siblingCount={1}
              color={'standard'}
              showFirstButton
              showLastButton
              size='small'
              onChange={(e, value) =>
                setSortAndPage({
                  pageNumber: value,
                  sortColumn: sortAndPage.sortColumn,
                  sortOrder: sortAndPage.sortOrder,
                })
              }
              page={sortAndPage.pageNumber}
            />
          </section>
        </section>
        <section />
      </section>
    </section>
  );
};

export default ItemManagement;
