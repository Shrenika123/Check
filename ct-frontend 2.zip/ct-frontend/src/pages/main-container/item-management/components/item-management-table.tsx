import React, { useEffect, useState } from 'react';
import {
  IItemManagementResponse,
  IRoutePermission,
  ISort,
  IUserState,
  TagType,
} from '../../../../common/interfaces';
import './item-management-table.style.css';
import { getFormattedDate, isStringValid } from '../../../../common/utils';
import { nanoid } from '@reduxjs/toolkit';
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io';
import { ItemManagementColumn, routes } from '../../../../common/constants';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

interface IItemManagementProps {
  data: IItemManagementResponse[];
  handleClick: (data: ISort) => void;
}
interface ITableData {
  label: string;
  value: string;
}

const ItemColumnHeaders: ITableData[] = [
  { label: ItemManagementColumn.upc, value: 'UPC' },
  { label: ItemManagementColumn.itemNumber, value: 'Item Number' },
  { label: ItemManagementColumn.itemDescription, value: 'Item Description' },
  { label: ItemManagementColumn.mabd, value: 'MABD' },
  { label: ItemManagementColumn.locationType, value: 'Location Type' },
  { label: ItemManagementColumn.poNumber, value: 'PO Number' },
  { label: ItemManagementColumn.eventId, value: 'Event' },
  { label: ItemManagementColumn.buyPlanId, value: 'Inventory' },
  { label: ItemManagementColumn.shipmentId, value: 'Shipment ID' },
  { label: ItemManagementColumn.quantity, value: 'Quantity Shipped' },
  { label: ItemManagementColumn.snapShotDate, value: 'Snapshot Date' },
  { label: ItemManagementColumn.itemStatus, value: 'Item Status' },
];

const ItemManagementTable: React.FC<IItemManagementProps> = ({
  data,
  handleClick,
}) => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const shipmentLoadPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'SHIPMENT_AND_LOAD_MANAGEMENT')?.permission;
  const eventInventoryPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'EVENT_AND_INVENTORY_PLAN_DETAILS')?.permission;

  const navigate = useNavigate();

  const [sortItem, setSortItem] = useState<ISort>({
    sortColumn: ItemManagementColumn.mabd,
    sortOrder: '',
  });

  const handleOnItemSort = (sortColumn: string) => {
    if (
      !(sortItem.sortColumn.length > 0 && sortItem.sortColumn === sortColumn)
    ) {
      setSortItem({ sortColumn: sortColumn, sortOrder: '' });
    } else {
      setSortItem({
        sortColumn: sortItem.sortColumn,
        sortOrder: sortItem.sortOrder === '' ? 'Desc' : '',
      });
    }
  };

  const getSortIcon = (columnName: string) => {
    if (sortItem.sortColumn === columnName) {
      if (sortItem.sortOrder === 'Desc') {
        return <IoMdArrowDropdown data-testid='dropDown-testId' />;
      } else {
        return <IoMdArrowDropup data-testid='dropUp-testId' />;
      }
    } else return <></>;
  };

  const handleOnShipmentIdClick = (shipmentId: string, mabd: string) => {
    if (shipmentId) {
      navigate(
        `/${routes.shipLoadManagement}?params=%7B%22shipment_id%22:%22${shipmentId}%22,%22mabd%22:%22${mabd}%22%7D`
      );
    }
  };

  const handleOnClickEventOrBuyPlanId = (
    tagType: string,
    tagId: string,
    tagName: string,
    targetDate: string
  ) => {
    if (tagId && tagId !== 'NA') {
      navigate(`/${routes.promotionProcurementDetails}`, {
        state: { tagType, tagId, tagName, targetDate },
      });
    }
  };

  useEffect(() => {
    handleClick({ ...sortItem });
  }, [sortItem]);

  const getFillerLength = (data: IItemManagementResponse[]) => {
    if (data) {
      return data.length < 8 ? 8 - data.length : 0;
    }
    return 0;
  };

  const getFillerTable = (data: IItemManagementResponse[]) => {
    return [...Array(getFillerLength(data))]
      .map(() => {
        return { key: nanoid() };
      })
      .map((_, index) => {
        return (
          <tr
            data-testid='filler'
            key={_.key}>
            <td colSpan={16}>
              <div></div>
            </td>
          </tr>
        );
      });
  };

  return (
    <>
      <section className={'item-management-table-wrapper'}>
        <table
          className='item-management-table'
          data-testid='itemManagementTable-testId'>
          <thead>
            <tr>
              {ItemColumnHeaders.map((item) => {
                return (
                  <th
                    key={item.label}
                    onClick={() => handleOnItemSort(item.label)}
                    data-testid={`item-table-${item.label}`}>
                    <div>
                      {item.value}
                      {getSortIcon(item.label)}
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {data.length > 0 &&
              data.map((value, index) => {
                return (
                  <tr
                    key={value.poNumber + index}
                    data-testid='item-tableData'>
                    <td>{value.upc}</td>
                    <td>{value.itemNumber}</td>
                    <td>{value.itemDescription}</td>
                    <td>
                      {value.mabd === 'NA'
                        ? 'NA'
                        : getFormattedDate(value.mabd)}
                    </td>
                    <td>{value.locationType}</td>
                    <td>{value.poNumber}</td>
                    <td>
                      <div
                        className={
                          eventInventoryPerm && eventInventoryPerm !== 'NA' && value.eventId && value.eventId !== 'NA'
                            ? 'hyperlink'
                            : 'non-hyperlink'
                        }
                        onClick={() =>
                          handleOnClickEventOrBuyPlanId(
                            TagType.PROMOTION_PLAN,
                            value.eventId,
                            value.eventName,
                            value.targetDate
                          )
                        }
                        data-testid='eventId-route'>
                        {value.eventId ?? 'NA'}
                      </div>
                    </td>
                    <td>
                      <div
                        className={
                          eventInventoryPerm && eventInventoryPerm !== 'NA' && value.buyPlanId && value.buyPlanId !== 'NA'
                            ? 'hyperlink'
                            : 'non-hyperlink'
                        }
                        onClick={() =>
                          handleOnClickEventOrBuyPlanId(
                            TagType.PROCUREMENT_PLAN,
                            value.buyPlanId,
                            value.buyPlanName,
                            value.targetDate
                          )
                        }
                        data-testid='buyPlanId-route'>
                        {value.buyPlanName ?? 'NA'}
                      </div>
                    </td>
                    <td>
                      <div
                        className={( isStringValid(shipmentLoadPerm) && shipmentLoadPerm !== 'NA' && value.shipmentId && value.shipmentId !== 'NA')? 'hyperlink' : 'non-hyperlink'}
                        onClick={() =>
                          handleOnShipmentIdClick(value.shipmentId, value.mabd)
                        }
                        data-testid='shipmentId-route'>
                        {value.shipmentId ?? 'NA'}
                      </div>
                    </td>
                    <td>{value.quantity}</td>
                    <td>
                      {value.mabd === 'NA'
                        ? 'NA'
                        : getFormattedDate(value.snapshotDate)}
                    </td>
                    <td className='status-row'>{value.itemStatus}</td>
                  </tr>
                );
              })}
            {getFillerTable(data)}
          </tbody>
        </table>
      </section>
    </>
  );
};
export default ItemManagementTable;
