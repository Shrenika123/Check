import {
  act,
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import router, { BrowserRouter, MemoryRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { ItemManagementColumn, routes } from '../../../../common/constants';
import {
  checkElementPresentInDomByTestId,
  clickElementByTestId,
  textPresentInDOM
} from '../../../../common/helper/testHelper';
import {
  itemManagementData,
  statusResponse
} from '../../../../common/mocks/promotionAndProcurement';
import ItemManagement from '../ItemManagement';

afterEach(() => {
  cleanup();
  jest.resetAllMocks();
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});
const mockedUsedNavigate = jest.fn();
const mockNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

const mockStore = configureStore();

const mockItemManagementResponse = {
  status: 200,
  data: {
    data: itemManagementData,
  },
};

const suggestionRes = {
  data: { data: ['abcde', 'bcdef', 'cdefg', 'defgh', 'efghi'] },
  status: 200,
};

const countRes = {
  data: { totalRecords: 100 },
};
const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};
const powerUserStore = mockStore(powerUserState);

const RenderItemManagement = ({ isExpanded }: { isExpanded?: boolean }) => {
  return (
    <Provider store={powerUserStore}>
      <ItemManagement isExpanded={false ?? isExpanded} />
    </Provider>
  );
};

describe('ItemManagement Page', () => {
  beforeEach(() => {
    jest.spyOn(router, 'useNavigate').mockImplementation(() => mockNavigate);
    jest.clearAllMocks();
  });

  test('should render ItemManagement component on success', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const ItemManagementData = jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });

    await waitFor(() => {
      expect(ItemManagementData).toBeCalled();
    });
    await checkElementPresentInDomByTestId('item-management-header-testId');
    await checkElementPresentInDomByTestId('item-datepicker-testId');
    await checkElementPresentInDomByTestId('buyPlanId-autoSuggest-testId');
    await checkElementPresentInDomByTestId('shipmentId-autoSuggest-testId');
    await checkElementPresentInDomByTestId('upc-autoSuggest-testId');
    await checkElementPresentInDomByTestId('status-multiSelect-testId');
    await checkElementPresentInDomByTestId('poNumber-autoSuggest-testId');
    await checkElementPresentInDomByTestId('eventId-autoSuggest-testId');
    await checkElementPresentInDomByTestId('itemNumber-autoSuggest-testId');
    await checkElementPresentInDomByTestId('itemManagementTable-testId');

    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {});
  });

  test('When Data is empty', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue({ res: { status: 200, data: { data: [] } } });
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });

    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
      expect(screen.queryAllByTestId('item-tableData')[0]).toBeUndefined();
    });
  });

  test('should render Item Management component with api fail and when Dashboard Navigate is clicked', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockRejectedValue('network error');
    jest
      .spyOn(util, 'getItemManagementDataCount')
      .mockRejectedValue({ status: 500 });
    render(
      <MemoryRouter
        initialEntries={[
          {
            pathname: '/item-management',
          },
        ]}>
        <RenderItemManagement />
      </MemoryRouter>
    );

    await act(async () => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
      await clickElementByTestId('route-to-home');
      expect(mockNavigate).toHaveBeenCalledTimes(1);
      expect(mockNavigate).toHaveBeenCalledWith('/home');
    });
  });

  test('when sort and toggle is performed', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    await act(async () => {
      await clickElementByTestId('item-table-shipmentId');
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('on sort of table', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await act(async () => {
      await clickElementByTestId(`item-table-${ItemManagementColumn.poNumber}`);
      await clickElementByTestId(
        `item-table-${ItemManagementColumn.buyPlanId}`
      );
      await clickElementByTestId(`item-table-${ItemManagementColumn.eventId}`);
      await clickElementByTestId(
        `item-table-${ItemManagementColumn.itemDescription}`
      );
      await clickElementByTestId(
        `item-table-${ItemManagementColumn.itemNumber}`
      );
      await clickElementByTestId(
        `item-table-${ItemManagementColumn.locationType}`
      );
      await clickElementByTestId(`item-table-${ItemManagementColumn.mabd}`);
      await clickElementByTestId(
        `item-table-${ItemManagementColumn.shipmentId}`
      );
      await clickElementByTestId(
        `item-table-${ItemManagementColumn.snapShotDate}`
      );
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle  upc auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[0], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle itemNumber auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[1], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle shipmentId auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[2], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle poNumber auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[3], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle eventId auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[4], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle buyPlanId auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[5], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should paginate itemManagement component', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    userEvent.click(screen.getByTestId('NavigateNextIcon'));
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('Navigate on Click of ShipmentId number', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await waitFor(() => {
      expect(screen.getAllByTestId('shipmentId-route')[0]).toBeInTheDocument();
    });
    userEvent.click(screen.getAllByTestId('shipmentId-route')[0]);
    expect(mockNavigate).toHaveBeenCalledWith(
      '/ship-load-management?params=%7B%22shipment_id%22:%221234%22,%22mabd%22:%222023-02-06%22%7D'
    );
  });

  test('Navigate on Click of eventId number', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await waitFor(() => {
      expect(screen.getAllByTestId('eventId-route')[0]).toBeInTheDocument();
    });
    userEvent.click(screen.getAllByTestId('eventId-route')[0]);
    expect(mockNavigate).toHaveBeenCalledWith('/event-inventory-plan/details', {
      state: {
        tagId: "President's Day",
        tagName: "President's Day",
        tagType: 'EVENT_PLAN',
        targetDate: '2023-02-14',
      },
    });
  });

  test('Navigate on Click of buyPlanId number', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await waitFor(() => {
      expect(screen.getAllByTestId('buyPlanId-route')[0]).toBeInTheDocument();
    });
    userEvent.click(screen.getAllByTestId('buyPlanId-route')[0]);
    expect(mockNavigate).toHaveBeenCalledWith('/event-inventory-plan/details', {
      state: {
        tagId: '104',
        tagName: 'NA',
        tagType: 'INVENTORY_PLAN',
        targetDate: '2023-02-14',
      },
    });
  });

  test('Should not Navigate on Click of buyPlanId/eventId & shipmentID when "NA" or null', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await waitFor(() => {
      expect(screen.getAllByTestId('buyPlanId-route')[1]).toBeInTheDocument();
    });
    userEvent.click(screen.getAllByTestId('buyPlanId-route')[1]);
    expect(mockNavigate).not.toBeCalled();
    await waitFor(() => {
      expect(screen.getAllByTestId('eventId-route')[1]).toBeInTheDocument();
    });
    userEvent.click(screen.getAllByTestId('eventId-route')[1]);
    expect(mockNavigate).not.toBeCalled();
    await waitFor(() => {
      expect(screen.getAllByTestId('shipmentId-route')[1]).toBeInTheDocument();
    });
    expect(mockNavigate).not.toBeCalled();
  });

  test('should handle status check box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });
    await waitFor(() => {
      expect(
        screen.getByTestId('multiselect-header-wrapper')
      ).toBeInTheDocument();
    });
    //open mode filter
    userEvent.click(screen.getByTestId('multiselect-header-wrapper'));
    //checked
    userEvent.click(screen.getAllByTestId('multiselect-checkbox')[0]);
    //unchecked
    userEvent.click(screen.getAllByTestId('multiselect-checkbox')[1]);
    const ele = screen.getAllByTestId('multiselect-only');
    userEvent.click(ele[0]);
  });

  test('should change the range of mabd', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });

    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    await clickElementByTestId('date-range-picker');
    userEvent.click(screen.getByText('Yesterday'));
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });
  test('should handle enter key input', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getItemManagementDetails')
      .mockResolvedValue(mockItemManagementResponse);
    jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
    jest
      .spyOn(util, 'getItemManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderItemManagement />, { wrapper: BrowserRouter });

    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    userEvent.keyboard('{Enter}');
    userEvent.keyboard('{NumpadEnter}');
  });
});
