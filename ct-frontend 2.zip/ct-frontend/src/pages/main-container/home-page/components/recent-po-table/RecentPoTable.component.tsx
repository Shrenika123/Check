import classNames from 'classnames';
import { format } from 'date-fns';
import { FC, ReactElement } from 'react';
import { useNavigate } from 'react-router-dom';
import { routes } from '../../../../../common/constants';
import { IRecentPo, IRecentPoTable, IRoutePermission, IUserState } from '../../../../../common/interfaces';
import { getGMTTimeStamp, isStringValid } from '../../../../../common/utils';
import './RecentPoTable.style.css';
import { useSelector } from 'react-redux';

const RecentPoTable: FC<IRecentPoTable> = (props): ReactElement => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const poLinePerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'PO_LINE_MANAGEMENT')?.permission;


  const navitage = useNavigate();
  const tableClassname = classNames('table');
  const tableWrapperClassname = classNames('table-wrapper-nav', 'table-wrapper');

  const navigateToPOLine = (poNumber: string, mabd: string) => {
    navitage(`/${routes.lineDetails}`, { state: { poNumber, mabd } });
  };

  const fillerRows = (row: number, colSpan: number) => {
    return (
      [...Array(row)].map((_, index) => {
        return (<tr key={index} className='filler-row'>
          <td colSpan={colSpan} className='filler-column'></td>
        </tr>);
      })
    );
  };

  return (
    <section id='recent-po-table'>
      <div className={tableWrapperClassname}>
        <table className={tableClassname}>
          <thead>
            <tr>
              <th>PO Number</th>
              <th>MABD</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {
              (props.recentPos === null && (
                <>
                  <tr>
                    <td colSpan={3}>Loading...</td>
                  </tr>
                  {fillerRows(4, 3)}
                </>
              ))
              ||
              ((props.recentPos && props.recentPos.length === 0) && (
                <>
                  <tr>
                    <td colSpan={3}>No Data</td>
                  </tr>
                  {fillerRows(4, 3)}
                </>
              ))
              ||
              ((props.recentPos && props.recentPos.length > 0) && props.recentPos?.map((recentPo: IRecentPo) => (
                <tr key={recentPo.key}>
                  <td 
                    className={ isStringValid(poLinePerm) && poLinePerm !== 'NA' ? 'clickable' : 'non-clickable' } 
                    onClick={() => navigateToPOLine(recentPo.ponumber, recentPo.mabd)}>
                    {recentPo.ponumber}
                  </td>
                  <td> {recentPo.mabd === 'NA' ? 'NA' : format(getGMTTimeStamp(recentPo.mabd), 'MM/dd/yyyy')}</td>
                  <td>{recentPo.status}</td>
                </tr>
              )))
            }
            {
              (props.recentPos && props.recentPos.length > 0) &&
              fillerRows(5 - props.recentPos.length, 3)
            }
          </tbody>
        </table>
      </div>
    </section>
  );
};

export default RecentPoTable;