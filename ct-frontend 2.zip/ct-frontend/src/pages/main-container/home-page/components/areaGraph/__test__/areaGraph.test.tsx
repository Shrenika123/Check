import { cleanup, render } from '@testing-library/react';
import { IPromotionCommitmentEntity } from '../../../../../../common/interfaces';
import RecentBuyPlanGraph from '../areaGraph.component';

afterEach(() => {
  cleanup();
});

jest.mock("nanoid", () => {
  return { nanoid: () => Math.random().toString() };
});

const mockedProps: IPromotionCommitmentEntity []= [{
  monthName: 'January',
  totalTargetAmount: '1000',
  plans: [{planName:'Jeans', planTotalTargetAmount:'1000'}]
}]

test('should render area graph component',()=>{
  render(<RecentBuyPlanGraph data={mockedProps} ></RecentBuyPlanGraph>)
})