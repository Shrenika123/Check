import classNames from 'classnames';
import { nanoid } from 'nanoid';
import React, { useEffect, useState } from 'react';
import { monthNames } from '../../../../../common/constants';
import { IPromotionCommitmentEntity } from '../../../../../common/interfaces';
import {
  getRangeForGraph,
  getShortenMonthFormat,
  numberFormat
} from '../../../../../common/utils';
import AreaGraph, {
  IAreaGraphDataElement
} from '../../../../../components/AreaGraph';
import './index.style.css';

interface IRecentBuyPlanGraphProps {
  data: IPromotionCommitmentEntity[];
}

const RecentBuyPlanGraph: React.FC<IRecentBuyPlanGraphProps> = ({ data }) => {
  const [active, setActive] = useState<{ month: string; activeIndex: number }>({
    month: '',
    activeIndex: -1,
  });
  const [maxQuantity, setMaxQuantity] = useState<number>(-1);

  useEffect(() => {
    setMaxQuantity(
      data.reduce((acc: number, cur: IPromotionCommitmentEntity) => {
        return Math.max(Number(cur.totalTargetAmount), acc);
      }, 0)
    );
  }, [data]);

  const getEventTableData = () => {
    return data
      .map((item) => {
        if (item.plans.length > 0) {
          return item.plans.map((itemPlan) => {
            return {
              ...itemPlan,
              month: item.monthName,
              key: nanoid(),
            };
          });
        } else {
          return [];
        }
      })
      .flat(1);
  };

  function sortByMonth(arr: IAreaGraphDataElement[]) {
    return arr.sort(function (a, b) {
      return monthNames.indexOf(a.name) - monthNames.indexOf(b.name);
    });
  }

  const getRecentBuyPlanData = (): IAreaGraphDataElement[] => {
    let formattedGraphData: IAreaGraphDataElement[] = data.map((item) => {
      return {
        name: getShortenMonthFormat(item.monthName),
        value: item.totalTargetAmount,
      };
    });

    const startingMonth = monthNames.indexOf(formattedGraphData[0].name);
    for (let i = 0; i < monthNames.length; i++) {
      const month = monthNames[(i + startingMonth) % 12];
      const dataOfMonthIndex = formattedGraphData.findIndex(
        (d) => d.name === month
      );

      if (dataOfMonthIndex < 0) {
        formattedGraphData.splice(i, 0, { name: month, value: 0 });
      }
    }
    return sortByMonth(formattedGraphData);
  };

  const getEventBuyPlanElements = () => {
    return getEventTableData().map((item, i) => {
      return (
        <div className='eventElement' key={item.key}>
          <p
            className={classNames(
              'eventElementPlan',
              active.activeIndex === i ? 'activePlan' : ''
            )}
            onClick={(e) => {
              setActive({
                month: getShortenMonthFormat(item.month),
                activeIndex: i,
              });
            }}
          >
            {item.planName}
          </p>
          <p className='eventElementTarget'>
            {numberFormat(Number(item.planTotalTargetAmount))}
          </p>
        </div>
      );
    });
  };

  return (
    <div id='recentBuyPlanContainer'>
      <div className='graph'>
        <AreaGraph
          height={200}
          data={getRecentBuyPlanData()}
          range={getRangeForGraph(maxQuantity, 4)}
          graphFontSize={'12px'}
          strokeWidth={2}
          maxQuantity={maxQuantity}
          active={active.month}
        />
      </div>
      <div className='rightContainer'>{getEventBuyPlanElements()}</div>
    </div>
  );
};
export default RecentBuyPlanGraph;
