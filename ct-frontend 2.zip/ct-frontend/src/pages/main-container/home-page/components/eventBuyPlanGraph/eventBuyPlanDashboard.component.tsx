import { nanoid } from 'nanoid';
import Tooltip from '@mui/material/Tooltip';
import { ProgressSpinner } from 'primereact/progressspinner';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import EmptyStarIcon from '../../../../../assets/icons/empty-fav-star.svg';
import FavStarIcon from '../../../../../assets/icons/fav-star.svg';
import { labels, routes, systemSettingNames } from '../../../../../common/constants';
import {
  IFavouriteActivityTrackerEntity, IRoutePermission, IUserState, TagType
} from '../../../../../common/interfaces';
import {
  getActivityTrackingDetails,
  getFormattedDate,
  getFormattedNumber,
  getPercentage,
  getPromotionProcurementPlan,
  getRangeForGraph,
  isStringValid
} from '../../../../../common/utils';
import Text from '../../../../../components/atoms/Text';
import BarGraph, {
  IBarGraphDataElement
} from '../../../../../components/BarGraph';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import FavCard from './components/FavCard.component';
import './index.style.css';

interface IEventBuyPlanDashboardEntity extends IFavouriteActivityTrackerEntity {
  tagType: TagType;
  key: string;
}

const EventBuyPlanDashboard: React.FC = () => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const eventPlanPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'EVENT_PLAN')?.permission;
  const inventoryPlanPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'INVENTORY_PLAN')?.permission;
  const eventInventoryDetailsPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'EVENT_AND_INVENTORY_PLAN_DETAILS')?.permission;

  

  const settings = useSelector((state: any) => state.systemSetting);
  let activityFavouriteDaysLimit: string;

  settings.forEach((setting: any) => {
    if (!activityFavouriteDaysLimit)
      activityFavouriteDaysLimit = setting.name === systemSettingNames.activityFavouriteDaysLimit ? setting.value : undefined;
  });

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [favourite, setFavourite] = useState<IEventBuyPlanDashboardEntity[]>([]);
  const [graphData, setGraphData] = useState<IBarGraphDataElement[]>([]);
  const [activeCard, setActiveCard] = useState<IEventBuyPlanDashboardEntity>();
  const [range, setRange] = useState<number[]>([]);
  const [showSpinner, setShowSpinner] = useState<boolean>(false);

  const navigateToEventInventoryDetails = (tagType: string, tagId: string, tagName: string, targetDate: string) => {
    navigate(`/${routes.promotionProcurementDetails}`, { state: { tagType, tagId, tagName, targetDate } });
  };

  const getTotalFavourites = (
    procurementFavourites: IFavouriteActivityTrackerEntity[] | null,
    promotionFavourites: IFavouriteActivityTrackerEntity[] | null
  ) => {
    let totalFav: IEventBuyPlanDashboardEntity[] = [];
    if (promotionFavourites && promotionFavourites.length > 0) {
      totalFav = [
        ...totalFav,
        ...promotionFavourites.map((item) => {
          return { ...item, tagType: TagType.PROMOTION_PLAN, key: nanoid() };
        }),
      ];
    }
    if (procurementFavourites && procurementFavourites.length > 0) {
      totalFav = [
        ...totalFav,
        ...procurementFavourites.map((item): IEventBuyPlanDashboardEntity => {
          return {
            tagType: TagType.PROCUREMENT_PLAN,
            eventId: item.buyPlanId!,
            eventName: item.buyPlanName!,
            targetDate: item.targetDate,
            targetAmount: item.targetAmount,
            key: nanoid(),
          };
        }),
      ];
    }

    setFavourite(totalFav);
    if (totalFav.length > 0) {
      handleFetchGraphData(totalFav[0]);
    } else {
      dispatch(setLoading(false));
      setShowSpinner(false);
    }
  };

  useEffect(() => {
    if (graphData.length > 0) {
      setRange(getRangeForGraph(Number(graphData[0].maxQuantity)));
    }
  }, [graphData]);

  const handleFetchGraphData = async (selectedCard: IEventBuyPlanDashboardEntity) => {
    try {
      dispatch(setLoading(true));
      let response = await getPromotionProcurementPlan({
        tagId: selectedCard.eventId,
        tagType: selectedCard.tagType,
        targetDate: selectedCard.targetDate
      });
      let procurementDetailsGraphData = response?.data.data;
      setGraphData(
        procurementDetailsGraphData.map((item: IBarGraphDataElement) => {
          if (item.name === 'Vendor Pending') {
            item.name = 'VP';
          }
          item['percentage'] = getPercentage(
            Number(item.value),
            Number(item.maxQuantity)
          );
          return item;
        })
      );
      setActiveCard(selectedCard);
      dispatch(setLoading(false));
      setShowSpinner(false);
    } catch (error: any) {
      dispatch(
        setShowAlert({
          showAlert: true,
          alertType: 'error',
          alertTitle: 'Failed to fetch event/inventory plan milestones',
          alertDescription: '',
        })
      );
      dispatch(setLoading(false));
    }
  };

  useEffect(() => {
    (async () => {
      setShowSpinner(true);
      dispatch(setLoading(true));
      try {
        const procurementPlanReRequest = getActivityTrackingDetails(
          'FAVOURITE',
          'INVENTORY_PLAN',
          Number.parseInt(activityFavouriteDaysLimit),
          2
        );
        const promotionPlanRequest = getActivityTrackingDetails(
          'FAVOURITE',
          'EVENT_PLAN',
          Number.parseInt(activityFavouriteDaysLimit),
          2
        );
        const response = await Promise.all([
          procurementPlanReRequest,
          promotionPlanRequest,
        ]);
        getTotalFavourites(response[0]?.data?.data, response[1]?.data?.data);
      } catch (error: any) {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Failed to fetch favorite event/inventory plans',
          })
        );
        dispatch(setLoading(false));
      }
    })();
  }, []);

  return (
    <div id='dashboardEventBuyPlanGraph'>
      {favourite.length > 0 ? (
        <>
          <div className='fav-row'>
            { (isStringValid(eventPlanPerm) && eventPlanPerm !== 'NA') &&
              <div className='column1'>
              <p className='fav-card-column-title'>Event Plans</p>
              <div className='column-wrap'>
                {favourite.filter(fav => fav.tagType === 'EVENT_PLAN').map((item) => (
                  <FavCard key={item.key} item={item} handleFetchGraphData={handleFetchGraphData} />
                ))}
                {favourite.filter(fav => fav.tagType === 'EVENT_PLAN').length === 0 && (
                  <>
                    <div className='fav-card empty-card' onClick={() => navigate(`/${routes.eventBuyPlanManagement}?tag=EVENT_PLAN`)}>
                      <i className="pi pi-plus-circle"></i>
                    </div>
                    <div className='fav-card empty-card' onClick={() => navigate(`/${routes.eventBuyPlanManagement}?tag=EVENT_PLAN`)}>
                      <i className="pi pi-plus-circle"></i>
                    </div>
                  </>
                )}
                {favourite.filter(fav => fav.tagType === 'EVENT_PLAN').length === 1 && (
                  <div className='fav-card empty-card' onClick={() => navigate(`/${routes.eventBuyPlanManagement}?tag=EVENT_PLAN`)}>
                    <i className="pi pi-plus-circle"></i>
                  </div>
                )}
              </div>
            </div>
            }

            { (isStringValid(inventoryPlanPerm) && inventoryPlanPerm !== 'NA') &&
              <div className='column2'>
              <p className='fav-card-column-title'>Inventory Plans</p>
              <div className='column-wrap'>
                {favourite.filter(fav => fav.tagType === 'INVENTORY_PLAN').map((item) => (
                  <FavCard key={item.key} item={item} handleFetchGraphData={handleFetchGraphData} />
                ))}
                {favourite.filter(fav => fav.tagType === 'INVENTORY_PLAN').length === 0 && (
                  <>
                    <div className='fav-card empty-card' onClick={() => navigate(`/${routes.eventBuyPlanManagement}?tag=INVENTORY_PLAN`)}>
                      <i className="pi pi-plus-circle"></i>
                    </div>
                    <div className='fav-card empty-card' onClick={() => navigate(`/${routes.eventBuyPlanManagement}?tag=INVENTORY_PLAN`)}>
                      <i className="pi pi-plus-circle"></i>
                    </div>
                  </>
                )}
                {favourite.filter(fav => fav.tagType === 'INVENTORY_PLAN').length === 1 && (
                  <div className='fav-card empty-card' onClick={() => navigate(`/${routes.eventBuyPlanManagement}?tag=INVENTORY_PLAN`)}>
                    <i className="pi pi-plus-circle"></i>
                  </div>
                )}
              </div>
            </div>
          }
          </div>
          {(graphData.length > 0 && activeCard) && (
            <div className={isStringValid(eventInventoryDetailsPerm) && eventInventoryDetailsPerm !== 'NA'? 'Card' : 'Card cursor-default' }
              onClick={() => {
                isStringValid(eventInventoryDetailsPerm) && eventInventoryDetailsPerm !== 'NA' &&
                navigateToEventInventoryDetails(activeCard.tagType, activeCard.eventId, activeCard.eventName, activeCard.targetDate)}}>
              <h5 className='graphHeader'>Plan details</h5>
              <div className='graphDetailsContainer'>
                <Text label={'Plan'} size='smallest' color='#B3B3B3'>
                  <p className='graphDetail'>{activeCard.eventName}</p>
                </Text>
                <Text label={labels.TargetDate} size='smallest' color='#B3B3B3'>
                  <p className='graphDetail'>
                    {getFormattedDate(activeCard.targetDate)}
                  </p>
                </Text>
                <Text
                  label={labels.TargetQuantity}
                  size='smallest'
                  color='#B3B3B3'
                >
                  <p className='graphDetail'>
                    {getFormattedNumber(activeCard.targetAmount)}
                  </p>
                </Text>
              </div>
              <BarGraph
                xAxisLegend
                yAxisLabel={labels.ItemQuantity}
                height={400}
                graphFontSize='10px'
                data={graphData}
                range={range}
                percentageLabelSize={'8px'}
              />
              <p className='xAxisLabel'>{labels.SupplyChain}</p>
            </div>
          )}
        </>
      ) : (
        <section className='empty-wrapper'>
          {
            showSpinner ? (
              <ProgressSpinner />
            ) : (
              <>
                <img className='empty-star' src={EmptyStarIcon} alt='sad empty star' />
                <p className='text-1'>No Favorite Plans Yet</p>
                <p className='text-2'>Keep track of 2 Events and 2 Inventory Plans</p>
                <p className='text-3'>you are interested in, by clicking the <span><img className='fav-star' src={FavStarIcon} alt='star icon' /></span> icon</p>
                {
                  ( !isStringValid(eventPlanPerm) || eventPlanPerm === 'NA') && ( !isStringValid(inventoryPlanPerm) || inventoryPlanPerm === 'NA' )?
                  <Tooltip title="Access not allowed" placement="bottom">
                    <button 
                      className='addNow-button-disabled' 
                      data-testid='add-now-btn' >
                      Add Now
                    </button>
                  </Tooltip>
                :
                    <button
                      data-testid='add-now-btn' 
                      onClick={() => navigate(`/${routes.eventBuyPlanManagement}`)}>
                      Add Now
                    </button>
                }
              </>
            )
          }
        </section>
      )}
    </div>
  );
};

export default EventBuyPlanDashboard;
