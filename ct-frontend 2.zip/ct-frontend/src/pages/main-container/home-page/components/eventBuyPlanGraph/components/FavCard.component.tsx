import { IFavCardProps } from '../../../../../../common/interfaces';
import { getFormattedDate, getFormattedNumber } from '../../../../../../common/utils';

export default function FavCard(props: IFavCardProps) {

  return (
    <div data-testid='fav-card-click' className='fav-card' onClick={() => props.handleFetchGraphData(props.item)}>
      <p className='fav-card-title'>
        {props.item.eventName}
      </p>
      <div className='fav-card-subsection'>
        <div>
          <p className='label'>Target Date</p>
          <p className='value'>{getFormattedDate(props.item.targetDate)}</p>
        </div>
        <div>
          <p className='label'>Target Quantity</p>
          <p className='value'>{getFormattedNumber(props.item.targetAmount)}</p>
        </div>
      </div>
    </div>
  );
}