import classNames from 'classnames';
import { format } from 'date-fns';
import { FC, ReactElement } from 'react';
import { useNavigate } from 'react-router-dom';
import { routes } from '../../../../../common/constants';
import { IRecentShipment, IRecentShipmentTable, IRoutePermission, IUserState } from '../../../../../common/interfaces';
import { getGMTTimeStamp } from '../../../../../common/utils';
import './RecentShipmentTable.style.css';
import { useSelector } from 'react-redux';

const RecentShipmentTable: FC<IRecentShipmentTable> = (props): ReactElement => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const shipmentLoadPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'SHIPMENT_AND_LOAD_MANAGEMENT')?.permission;
  
  const tableClassname = classNames('table');
  const navigate = useNavigate()

  const tableWrapperClassname = classNames('table-wrapper-nav', 'table-wrapper');
 
  const fillerRows = (row: number, colSpan: number) => {
    return (
      [...Array(row)].map((_, index) => {
        return (<tr key={index} className='filler-row'>
          <td colSpan={colSpan} className='filler-column'></td>
        </tr>);
      })
    );
  };
  return (
    <section id='recent-shipment-table'>
      <div className={tableWrapperClassname}>
        <table className={tableClassname}>
          <thead>
            <tr>
              <th>Shipment ID</th>
              <th>MABD</th>
              <th>Mode</th>
            </tr>
          </thead>
          <tbody>
            {
              (props.recentShipments === null && (
                <>
                  <tr>
                    <td colSpan={3}>Loading...</td>
                  </tr>
                  {fillerRows(4, 3)}
                </>
              ))
              ||
              ((props.recentShipments && props.recentShipments.length === 0) && (
                <>
                  <tr>
                    <td colSpan={3}>No Data</td>
                  </tr>
                  {fillerRows(4, 3)}
                </>
              ))
              ||
              ((props.recentShipments && props.recentShipments.length > 0) && props.recentShipments?.map((recentShipment: IRecentShipment) => (
                
                <tr key={recentShipment.key}>
                  <td 
                    className={( shipmentLoadPerm && shipmentLoadPerm !== 'NA' && recentShipment.shipmentId && recentShipment.shipmentId !== 'NA')? 'clickable' : 'non-clickable'}
                    onClick={() => { navigate(`/${routes.shipLoadManagement}?params=%7B%22shipment_id%22:%22${recentShipment.shipmentId}%22,%22mabd%22:%22${recentShipment.mabd}%22%7D`)}}>
                      {recentShipment.shipmentId}

                  </td>
                  <td> {recentShipment.mabd === 'NA' ? 'NA' : format(getGMTTimeStamp(recentShipment.mabd), 'MM/dd/yyyy')}</td>
                  <td>{recentShipment.transportModeType}</td>
                </tr>
              ))
              )
            }
            {
              props.recentShipments && props.recentShipments.length > 0 &&
              fillerRows(5-props.recentShipments.length,3)
            }
          </tbody>
        </table>
      </div>
    </section>
  );
};

export default RecentShipmentTable;