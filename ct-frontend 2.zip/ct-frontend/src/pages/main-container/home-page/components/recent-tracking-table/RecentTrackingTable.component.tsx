import Tooltip from '@mui/material/Tooltip';
import classNames from 'classnames';
import { format } from 'date-fns';
import { FC, ReactElement } from 'react';
import { useNavigate } from 'react-router-dom';
import { routes } from '../../../../../common/constants';
import { IRecentContainer, IRecentContainerTable, IRoutePermission, IUserState } from '../../../../../common/interfaces';
import { getGMTTimeStamp, isStringValid } from '../../../../../common/utils';
import './RecentTrackingTable.style.css';
import { useSelector } from 'react-redux';

const RecentTrackingTable: FC<IRecentContainerTable> = (props): ReactElement => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const containerPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'CONTAINER_TRACKING')?.permission;

  const navigate = useNavigate();
  const tableClassname = classNames('table');
  const tableWrapperClassname = classNames('table-wrapper-nav');

  const fillerRows = (row: number, colSpan: number) => {
    return (
      [...Array(row)].map((_, index) => {
        return (<tr key={index} className='filler-row'>
          <td colSpan={colSpan} className='filler-column'></td>
        </tr>);
      })
    );
  };
  return (
    <section id='recent-tracking-table'>
      <div className={tableWrapperClassname}>
        <table className={tableClassname}>
          <thead>
            <tr>
              <th></th>
              <th>
                Container ID
                {
                  props.singleTrackingData !== null && (
                    <Tooltip title="Reset" placement="right">
                      <i className="pi pi-sync" data-testid='link-icon' onClick={() => props.setSingleTrackingData(null)} style={{ marginLeft: '.4rem', cursor: 'pointer' }}></i>
                    </Tooltip>
                  )
                }
              </th>
              <th>Vessel ID</th>
              <th>MABD</th>
              <th>ETA</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {
              (props.recentContainers === null && (
                <>
                  <tr>
                    <td colSpan={6}>Loading..</td>
                  </tr>
                  {fillerRows(4, 6)}
                </>
              ))
              ||
              ((props.recentContainers && props.recentContainers.length === 0) && (
                <>
                  <tr>
                    <td colSpan={6}>No Data</td>
                  </tr>
                  {fillerRows(4, 6)}
                </>
              ))
              ||
              ((props.recentContainers && props.recentContainers.length > 0) && props.recentContainers?.map((recentContainer: IRecentContainer) => (
                <tr key={recentContainer.key}>
                  { isStringValid(containerPerm) && containerPerm !== 'NA' ?
                    <td 
                    className='clickable'
                    onClick={() => navigate(`/${routes.vesselTrackingDetails}`, { state: { containerId: recentContainer.containerId, mabd: recentContainer.mabd } })}>
                    <Tooltip title="Track" placement="right">
                      <i className="pi pi-external-link"></i>
                    </Tooltip>
                  </td> : <td></td>}
                  <td className='clickable' data-testid='recent-container-id' onClick={() => props.setSingleTrackingData(recentContainer)}>
                    {recentContainer.containerId}
                  </td>
                  <td>{recentContainer.carrierId}</td>
                  <td> {recentContainer.mabd === 'NA' ? 'NA' : format(getGMTTimeStamp(recentContainer.mabd), 'MM/dd/yyyy')}</td>
                  <td> {recentContainer.endDateTime === 'NA' ? 'NA' : format(getGMTTimeStamp(recentContainer.endDateTime), 'MM/dd/yyyy')}</td>
                  <td>{recentContainer.shipmentStatus}</td>
                </tr>
              )))
            }
            {
              props.recentContainers && props.recentContainers.length > 0 &&
              fillerRows(5 - props.recentContainers.length, 6)
            }
          </tbody>
        </table>
      </div>
    </section>
  );
};

export default RecentTrackingTable;