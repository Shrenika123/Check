import { useEffect, useState } from 'react';
import { Marker, Polyline, Tooltip } from "react-leaflet";
import { IDashboardMapMarkersProps } from '../../../../../common/interfaces';
import { portAnchorIcon, shipIcon } from '../../../../../common/markers';
import RotatedMarker from '../../../../../components/rotated-marker/RotatedMarker.component';

function DashboardMapMarkers(props: IDashboardMapMarkersProps) {

  const [markerAngle, setMarkerAngle] = useState(0);

  useEffect(() => {
    // calculating rotation angle for the ship marker
    const currentPosition: number[] = [props.data?.trackerGeoLatitude, props.data?.trackerGeoLongitude];
    const finalPosition: number[] = [props.data.toLocationLatitude, props.data.toLocationLongitude];
    let rotationAngle = Math.atan2(finalPosition[0] - currentPosition[0], finalPosition[1] - currentPosition[1]);
    rotationAngle = rotationAngle * (180 / Math.PI);
    rotationAngle = (rotationAngle + 360) % 360;
    rotationAngle = 360 - rotationAngle;
    setMarkerAngle(rotationAngle);
  }, [props.data]);

  return (
    <>
      {
        <>
          {/* source marker */}
          <Marker position={[props.data.fromLocationLatitude, props.data.fromLocationLongitude]} icon={portAnchorIcon}>
            <Tooltip offset={[0, -17] as any} direction='top'>
              <strong>{props.data.fromLocation}</strong>
              <p>ID: {props.data.fromLocationId}</p>
            </Tooltip>
          </Marker>
          {/* destination marker */}
          <Marker position={[props.data.toLocationLatitude, props.data.toLocationLongitude]} icon={portAnchorIcon}>
            <Tooltip offset={[0, -17] as any} direction='top'>
              <strong>{props.data.toLocation}</strong>
              <p>ID: {props.data.toLocationId}</p>
            </Tooltip>
          </Marker>
        </>
      }
      {
        <>
          {/* vessel marker */}
          <RotatedMarker
            alt='vessel-marker'
            position={[props.data.trackerGeoLatitude, props.data.trackerGeoLongitude]}
            eventHandlers={{ click: () => props.handleTrackerClick(props.data) }}
            icon={shipIcon}
            rotationAngle={markerAngle}
            rotationOrigin='center'
          >
            <Tooltip offset={[0, -5] as any} direction='top'>
              <strong>{props.data.carrierName}</strong><br />
              <p>Vessel Id: {props.data.carrierId}</p>
              <p>IMO: {props.data.imo}</p>
              <p>MMSI: {props.data.mmsi}</p>
            </Tooltip>
          </RotatedMarker>
        </>
      }
      {/* track lines */}
      {
        (props.dashboardVesselHistoryCoordinates && props.dashboardVesselHistoryCoordinates !== null) && (
          <>
            <Polyline
              pathOptions={{ color: '#8791C2', weight: 2 }}
              positions={[[props.data.fromLocationLatitude, props.data.fromLocationLongitude], [props.dashboardVesselHistoryCoordinates[0].trackerGeoLatitude, props.dashboardVesselHistoryCoordinates[0].trackerGeoLongitude]]}
            />
            {
              props.dashboardVesselHistoryCoordinates?.map((coordinate, index, coordinateArray) => {
                if (index < coordinateArray.length - 1) {
                  return (
                    <Polyline
                      key={coordinate.key}
                      pathOptions={{ color: '#8791C2', weight: 2 }}
                      positions={[[coordinateArray[index].trackerGeoLatitude, coordinateArray[index].trackerGeoLongitude], [coordinateArray[index + 1].trackerGeoLatitude, coordinateArray[index + 1].trackerGeoLongitude]]}
                    />
                  );
                }
              })
            }
            <Polyline
              pathOptions={{ color: '#8791C2', weight: 2, dashArray: '4' }}
              positions={[[props.dashboardVesselHistoryCoordinates[props.dashboardVesselHistoryCoordinates!.length - 1].trackerGeoLatitude, props.dashboardVesselHistoryCoordinates[props.dashboardVesselHistoryCoordinates!.length - 1].trackerGeoLongitude], [props.data.toLocationLatitude, props.data.toLocationLongitude]]}
            />
          </>
        )
      }
    </>
  );

}

export default DashboardMapMarkers;