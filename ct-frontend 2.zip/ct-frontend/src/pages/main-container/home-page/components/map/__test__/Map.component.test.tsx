import '@testing-library/jest-dom';
import { cleanup, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import Map from '../Map.component';
import { routes } from '../../../../../../common/navigation-utils';

afterEach(cleanup);

describe('Dashboard Map Component', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };
  const mockRecentContainers = [{
    "containerId": "CNT1807",
    "carrierId": "7582550",
    "endDateTime": "2023-04-27",
    "shipmentStatus": "Waiting at Port of Load",
    "trackerGeoLatitude": 40.554222106933594,
    "trackerGeoLongitude": 285.89666748046875,
    "fromLocation": "New York",
    "toLocation": "Southampton",
    "fromLocationLatitude": 40.554222106933594,
    "fromLocationLongitude": 285.89666748046875,
    "toLocationLatitude": 50.89573287963867,
    "toLocationLongitude": 358.61437594890594,
    "fromLocationId": "PORT483",
    "toLocationId": "PORT471",
    "carrierName": "MSC DIANA",
    "mabd": "2023-04-24",
    "imo": "7249080",
    "mmsi": "438953871"
  }];
  const mockSingleTrackingData = {
    "containerId": "CNT1807",
    "carrierId": "7582550",
    "endDateTime": "2023-04-27",
    "shipmentStatus": "Waiting at Port of Load",
    "trackerGeoLatitude": 40.554222106933594,
    "trackerGeoLongitude": 285.89666748046875,
    "fromLocation": "New York",
    "toLocation": "Southampton",
    "fromLocationLatitude": 40.554222106933594,
    "fromLocationLongitude": 285.89666748046875,
    "toLocationLatitude": 50.89573287963867,
    "toLocationLongitude": 358.61437594890594,
    "fromLocationId": "PORT483",
    "toLocationId": "PORT471",
    "carrierName": "MSC DIANA",
    "mabd": "2023-04-24",
    "imo": "7249080",
    "mmsi": "438953871"
  }
  const mockSetSingleTrackingData = jest.fn();
  const mockVesselHistory = [
    {
      "trackerGeoLatitude": -15.633709907531738,
      "trackerGeoLongitude": -148.76220703125
    }
  ];

  test('should render component without singleTrackingData', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <Map
          singleTrackingData={null}
          setSingleTrackingData={mockSetSingleTrackingData}
          dashboardVesselHistoryCoordinates={mockVesselHistory}
          recentContainers={mockRecentContainers}
        />
      </Provider>, { wrapper: BrowserRouter }
    );
  });

  test('should render component with singleTrackingData', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <Map
          singleTrackingData={mockSingleTrackingData}
          setSingleTrackingData={mockSetSingleTrackingData}
          dashboardVesselHistoryCoordinates={mockVesselHistory}
          recentContainers={mockRecentContainers}
        />
      </Provider>, { wrapper: BrowserRouter }
    );
  });
});