import { ReactElement, useEffect } from 'react';
import { useMap } from 'react-leaflet';
import { IDashboardMapProps, IRecentContainer } from '../../../../../common/interfaces';
import DashboardMapMarkers from './DashboardMapMarkers.component';

function Map(props: IDashboardMapProps): ReactElement {
  const map = useMap();

  useEffect(() => {
    if (props.singleTrackingData === null) {
      map.setView([32, 142], 2);
    } else {
      map.flyToBounds?.([[props.singleTrackingData.fromLocationLatitude, props.singleTrackingData.fromLocationLongitude], [props.singleTrackingData.toLocationLatitude, props.singleTrackingData.toLocationLongitude]], { padding: [30, 30] });
    }
  }, [props.singleTrackingData]);

  const handleTrackerClick = (container: IRecentContainer) => {
    props.setSingleTrackingData?.(container);
  };

  return (
    <>
      {
        (props.singleTrackingData !== null && (
          <DashboardMapMarkers
            data={props.singleTrackingData}
            handleTrackerClick={handleTrackerClick}
            dashboardVesselHistoryCoordinates={props.dashboardVesselHistoryCoordinates}
          />
        ))
        ||
        (props.recentContainers && props.recentContainers.map((recentContainer: IRecentContainer) => {
          return (
            <DashboardMapMarkers
              key={recentContainer.key}
              data={recentContainer}
              handleTrackerClick={handleTrackerClick}
            />
          );
        }))
      }
    </>
  );

}

export default Map;