import classNames from 'classnames';
import { nanoid } from 'nanoid';
import { FC, useEffect, useState } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useDispatch, useSelector } from 'react-redux';
import { labels, systemSettingNames } from '../../../common/constants';
import {
  IHomepageProps,
  IPromotionCommitmentEntity,
  IRecentContainer,
  IRecentPo,
  IRecentShipment,
  IRoutePermission,
  IUserState,
  IVesselHistoryCoordinate
} from '../../../common/interfaces';
import {
  getActivityTrackingDetails, getPromotionCommitmentPlan, getVesselHistoryCoordinates, isStringValid
} from '../../../common/utils';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import RecentBuyPlanGraph from './components/areaGraph/areaGraph.component';
import EventBuyPlanDashboard from './components/eventBuyPlanGraph/eventBuyPlanDashboard.component';
import Map from './components/map/Map.component';
import RecentPoTable from './components/recent-po-table/RecentPoTable.component';
import RecentShipmentTable from './components/recent-shipment-table/RecentShipmentTable.component';
import RecentTrackingTable from './components/recent-tracking-table/RecentTrackingTable.component';
import './Homepage.style.css';

const Homepage: FC<IHomepageProps> = (props) => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);

  const recentPOTilePerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'RECENT_PO_DASHBOARD_TILE')?.permission;
  const recentShipmentTilePerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'RECENT_SHIPMENT_DASHBOARD_TILE' )?.permission;
  const recentContainerTilePerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'RECENT_CONTAINER_DASHBOARD_TILE' )?.permission;
  const eventInventoryTrendPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'EVENT_INVENTORY_TREND_DASHBOARD_TILE' )?.permission;
  const favouriteEventInventoryPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE' )?.permission;

 

  const settings = useSelector((state: any) => state.systemSetting);
  let activityVisitedDaysLimit: string;

  if (settings && settings.length > 0) {
    settings.forEach((setting: any) => {
      if (!activityVisitedDaysLimit)
        activityVisitedDaysLimit = setting.name === systemSettingNames.activityVisitedDaysLimit ? setting.value : undefined;
    });
  }

  const dispatch = useDispatch();

  const [recentPos, setRecentPos] = useState<IRecentPo[] | null>(null);
  const [promotionCommitmentData, setPromotionCommitmentData] = useState<
    IPromotionCommitmentEntity[]
  >([]);
  const [recentShipments, setRecentShipments] = useState<
    IRecentShipment[] | null
  >(null);
  const [recentContainers, setRecentContainers] = useState<
    IRecentContainer[] | null
  >(null);
  const [singleTrackingData, setSingleTrackingData] =
    useState<IRecentContainer | null>(null);
  // to store single vessel's history of coordinates
  const [
    dashboardVesselHistoryCoordinates,
    setDashboardVesselHistoryCoordinates,
  ] = useState<IVesselHistoryCoordinate[] | null>(null);

  // fetching recent PO, recent Shipment, recent Container details
  useEffect(() => {
    (async function () {
      dispatch(setLoading(true));
      try {
        const recentPoRequest = getActivityTrackingDetails(
          'VISITED',
          'PURCHASE_ORDER',
          Number.parseInt(activityVisitedDaysLimit)
        );
        const recentShipmentRequest = getActivityTrackingDetails(
          'VISITED',
          'SHIPMENT',
          Number.parseInt(activityVisitedDaysLimit)
        );
        const recentContainerRequest = getActivityTrackingDetails(
          'VISITED',
          'CONTAINER',
          Number.parseInt(activityVisitedDaysLimit)
        );

        const response = await Promise.all([
          recentPoRequest,
          recentShipmentRequest,
          recentContainerRequest,
        ]);
        setRecentPos(
          response[0]?.data.data.map((recentPo: IRecentPo) => ({
            ...recentPo,
            key: nanoid(),
          }))
        );
        setRecentShipments(
          response[1]?.data.data.map((recentShipment: IRecentShipment) => ({
            ...recentShipment,
            key: nanoid(),
          }))
        );
        setRecentContainers(
          response[2]?.data.data.map((recentContainer: IRecentContainer) => ({
            ...recentContainer,
            key: nanoid(),
          }))
        );
        dispatch(setLoading(false));
      } catch (error: any) {
        console.log('error', error);
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: 'Failed to fetch recent purchase orders, shipments and containers',
              alertDescription: '',
            })
          );
        dispatch(setLoading(false));
      }
    })();
  }, []);

  // fetching recent buy plan graph data
  useEffect(() => {
    (async function () {
      dispatch(setLoading(true));
      try {
        const res = await getPromotionCommitmentPlan();
        setPromotionCommitmentData(res.data.data);
      } catch (error: any) {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: 'Failed to fetch recent inventory trend',
            })
          );
        dispatch(setLoading(false));
      }
    })();
  }, []);

  // fetching single vessel's history of coordinates
  useEffect(() => {
    (async function () {
      if (singleTrackingData !== null) {
        dispatch(setLoading(true));
        setDashboardVesselHistoryCoordinates(null);
        try {
          const response = await getVesselHistoryCoordinates(
            singleTrackingData.carrierId,
            singleTrackingData.containerId,
            singleTrackingData.mabd
          );
          setDashboardVesselHistoryCoordinates(
            response?.data.history.map(
              (coordinate: IVesselHistoryCoordinate) => ({
                ...coordinate,
                key: nanoid(),
              })
            )
          );
          dispatch(setLoading(false));
        } catch (error: any) {
            dispatch(
              setShowAlert({
                showAlert: true,
                alertType: 'error',
                alertTitle: 'Failed to fetch recent vessels',
              })
            );
          dispatch(setLoading(false));
        }
      }
    })();
  }, [singleTrackingData]);

  const headerClass = classNames({
    'header-shrink': props.isExpanded,
    header: !props.isExpanded,
  });

  const containerClass = classNames({
    'container-shrink': props.isExpanded,
    container: !props.isExpanded,
  });

  const leftContainerClass = classNames('left-container', {
    'shrink': props.isExpanded
  });
  const rightContainerClass = classNames('right-container', {
    'shrink': props.isExpanded
  });
  const recentPOClass = classNames('recent-po', {
    'shrink': props.isExpanded
  });
  const recentShipmentClass = classNames('recent-shipment', {
    'shrink': props.isExpanded
  });

  return (
    <section id='dashboard'>
      <section className={headerClass}>
        <div className='text-header'>{labels.home}</div>
      </section>
      <section className={containerClass}>
        <section className={leftContainerClass}>
          <section className='recent-po-and-shipment'>
            { isStringValid(recentPOTilePerm) && recentPOTilePerm !=='NA' &&
              <section className={recentPOClass}>
              <h3>Recent POs</h3>
              <RecentPoTable recentPos={recentPos} />
            </section>}
            { isStringValid(recentShipmentTilePerm) && recentShipmentTilePerm !=='NA' && 
              <section className={recentShipmentClass}>
              <h3>Recent Shipments</h3>
              <RecentShipmentTable recentShipments={recentShipments} />
            </section>}
          </section>
          { isStringValid(eventInventoryTrendPerm) && eventInventoryTrendPerm !=='NA' && 
            <section className='recent-buy-plan'>
            {promotionCommitmentData.length > 0 && (
              <div className='recentBuyPlanGraphContainer'>
                <h3>{labels.PromotionCommitment}</h3>
                <RecentBuyPlanGraph data={promotionCommitmentData} />
              </div>
            )}
          </section>}
          { isStringValid(recentContainerTilePerm) && recentContainerTilePerm !=='NA' && 
            <section className='recent-tracking'>
              <h3>Recent Containers</h3>
              <div className='map-section'>
                <MapContainer className='map-container'>
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url='https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png'
                  />
                  <Map
                    recentContainers={recentContainers}
                    singleTrackingData={singleTrackingData}
                    setSingleTrackingData={setSingleTrackingData}
                    dashboardVesselHistoryCoordinates={
                      dashboardVesselHistoryCoordinates
                    }
                  />
                </MapContainer>
              </div>
              <div className='tracking-table-section'>
                <RecentTrackingTable
                  recentContainers={recentContainers}
                  setSingleTrackingData={setSingleTrackingData}
                  singleTrackingData={singleTrackingData}
                />
              </div>
            </section>}
        </section>
        { isStringValid(favouriteEventInventoryPerm) && favouriteEventInventoryPerm !=='NA' && 
        <section className={rightContainerClass}>
          <section className='fav-event-buy-plan'>
            <h3>Favorite Events & Inventory Plans</h3>
            <EventBuyPlanDashboard />
          </section>
        </section>}
      </section>
    </section>
  );
};

export default Homepage;
