import '@testing-library/jest-dom';
import { act, cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import MainContainer from '../../MainContainer';

afterEach(cleanup);

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useLocation: () => ({
    pathname: "/vessel-tracking",
    hash: '',
    key: '1',
    search: '',
    state: {
      range: [{ startDate: new Date('2023-01-01T10:01:58.605Z'), endDate: new Date("2023-03-02T10:01:58.605Z"), key: "selection" }],
      containerId: 'CNT123'
    }
  }),
}));

describe('Vessel Tracking', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };

  test('should render component', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getAllVessels').mockResolvedValueOnce([]);
    jest.spyOn(util, 'getAllVesselsCount').mockResolvedValueOnce({
      "totalRecords": 0
    });

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTracking} />
      </Provider>, { wrapper: BrowserRouter }
    );

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });

  });

  test('should render component with error', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getAllVessels').mockRejectedValueOnce({ code: 'ERR_NETWORK', response: { status: 500, data: {} } });
    jest.spyOn(util, 'getAllVesselsCount').mockResolvedValueOnce({
      "totalRecords": 0
    });

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTracking} />
      </Provider>, { wrapper: BrowserRouter }
    );

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });

  });

  test('should pass "route to home" click', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTracking} />
      </Provider>, { wrapper: BrowserRouter }
    );

    const routeToHome = screen.getByTestId('route-to-home');
    userEvent.click(routeToHome);

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });
  });

  test('should pass "reset" click', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <MainContainer route={routes.vesselTracking} />
      </Provider>, { wrapper: BrowserRouter }
    );

    const resetBtn = screen.getByTestId('reset-btn');
    userEvent.click(resetBtn);

    // for re-rendering the component on state change
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });
  });

});