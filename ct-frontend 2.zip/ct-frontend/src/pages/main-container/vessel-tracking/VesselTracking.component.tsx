import { Pagination } from '@mui/material';
import { addDays, format, subDays } from 'date-fns';
import { nanoid } from 'nanoid';
import { MultiSelect } from 'primereact/multiselect';
import { FC, ReactElement, useEffect, useState } from "react";
import { Range } from 'react-date-range';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from "react-router-dom";
import { labels, routes, systemSettingNames, tableConfig } from '../../../common/constants';
import { IAllDetails, IVessel, IVesselHistoryCoordinate } from '../../../common/interfaces';
import { getAllDetails, getAllDetailsCount, getAllVessels, getAllVesselsCount, getGMTTimeStamp, getVesselHistoryCoordinates } from '../../../common/utils';
import CustomDateRangePicker from '../../../components/date-range-picker/CustomDateRangePicker';
import FilterOverlay from '../../../components/filter-overlay/FilterOverlay.component';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import Map from './components/map/Map.component';
import TrackingTable from './components/tracking-table/TrackingTable.component';
import { headerClass, mapSectionClass, rightSubheaderContainerClass, subHeaderClass, tablePaginationClass } from './VesselTracking.classnames';
import './VesselTracking.style.css';

const VesselTracking: FC<{ isExpanded: boolean; }> = (props): ReactElement => {

  const settings = useSelector((state: any) => state.systemSetting);
  let fixedSettingDate: undefined | string;
  let enableFixedDate: undefined | string;

  if (settings && settings.length > 0) {
    settings.forEach((setting: any) => {
      if (!enableFixedDate)
        enableFixedDate = setting.name === systemSettingNames.enableFixedDate ? setting.value : undefined;
      if (!fixedSettingDate)
        fixedSettingDate = setting.name === systemSettingNames.fixedDate ? setting.value : undefined;
    });
  }

  const initDateRange: Range[] = [
    {
      startDate: subDays(getGMTTimeStamp(enableFixedDate === 'true' ? fixedSettingDate : undefined), 7),
      endDate: addDays(getGMTTimeStamp(enableFixedDate === 'true' ? fixedSettingDate : undefined), 21),
      key: 'selection'
    }
  ];

  const vessels_ports_imports = ['Vessels', 'Ports', 'Imports'];
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  const [allVessels, setAllVessels] = useState<IVessel[] | null>(null);
  const [allDetails, setAllDetails] = useState<IAllDetails[] | null>(null);
  const [selectedVessel, setSelectedVessel] = useState<IVessel | null>(null);
  // to store single vessel's history of coordinates
  const [vesselHistoryCoordinates, setVesselHistoryCoordinates] = useState<IVesselHistoryCoordinate[] | null>(null);

  // for pagination - start
  const [allVesselsPageNumber, setAllVesselsPageNumber] = useState<number>(1);
  const [allDetailsPageNumber, setAllDetailsPageNumber] = useState<number>(1);
  const [allVesselsTotalRecords, setAllVesselsTotalRecords] = useState<number>(0);
  const [allDetailsTotalRecords, setAllDetailsTotalRecords] = useState<number>(0);
  // for pagination - end
  const [range, setRange] = useState<Range[]>(() => {
    if (location.state !== null) {
      return [{
        startDate: location.state?.range[0].startDate,
        endDate: location.state?.range[0].endDate,
        key: 'selection'
      }];
    }
    else {
      return initDateRange;
    }
  });

  const [selectedVesselsPortsImports, setSelectedVesselsPortsImports] = useState<string[]>(vessels_ports_imports);
  // to prevent api call when user has not applied any filter and filter box is opened and closed without any filter input data
  const [isFilterApplied, setIsFilterApplied] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<{ name: string; code: string; }>({ name: 'Container ID', code: 'containerId' });
  const [selectedTableFilter, setSelectedTableFilter] = useState<{ name: string; value: string; }>({ name: 'containerId', value: '' });
  const [inputFilterData, setInputFilterData] = useState(location.state?.containerId ?? '');

  // this is a toggle only to trigger api call when user clicks apply button in filter
  const [shouldFetchFilter, setShouldFetchFilter] = useState(true);
  // this is not toggle. this state will be used to check when the fetch should happen or not based on table filter input
  const [shouldResetTable, setShouldResetTable] = useState(false);

  // fetching all vessel ids or filtered vessel ids for showing on the map
  useEffect(() => {
    // when user navigated from shipload page to this page after clicking containerID in shipload page
    if (location.state?.containerId) {
      setIsFilterApplied(true);
    }

    (async () => {
      dispatch(setLoading(true));
      const fromDate = format(location.state?.range[0].startDate ?? range[0].startDate, 'yyyy-MM-dd');
      const toDate = format(location.state?.range[0].endDate ?? range[0].endDate, 'yyyy-MM-dd');
      try {
        // if searchValue is empty then all vessel ids will be fetched
        // if searchValue is not empty then the specified vessel ids will be fetched
        const allVesselsPromise = getAllVessels({
          fromDate,
          toDate,
          pageNumber: allVesselsPageNumber,
          pageSize: tableConfig.vesselTrackingMapPageSize,
          searchKey: selectedFilter.code,
          searchValue: inputFilterData.replaceAll(' ', '')
        });
        const allVesselsCountPromise = getAllVesselsCount({
          fromDate,
          toDate,
          searchKey: selectedFilter.code,
          searchValue: inputFilterData.replaceAll(' ', '')
        });
        const response: any = await Promise.all([allVesselsPromise, allVesselsCountPromise]);
        const allVessels = response[0]?.data.data;
        const allVesselsCount = response[1]?.data.totalRecords;
        // if no data then show error alert
        if (allVesselsCount === 0) {
          // if filter applied and data not found
          if (isFilterApplied || inputFilterData !== '') {
            dispatch(setShowAlert({ showAlert: true, alertType: 'error',
              alertTitle: `Invalid ${selectedFilter.name} or data not found for the selected Date Range.`,
              alertDescription: '',
            }));
          } else {
            // else if date range data is not found then show 'date range data not found'
            dispatch(setShowAlert({ showAlert: true, alertType: 'error',
              alertTitle: 'No data found for the selected date range',
              alertDescription: '',
            }));
          }
        }
        // if data found then reset the selected vessel view
        setSelectedVessel(null);
        setAllVessels(allVessels.map((vessel: IVessel) => ({ ...vessel, key: nanoid() })));
        setAllVesselsTotalRecords(allVesselsCount);
        dispatch(setLoading(false));
      } catch (error: any) {
        dispatch(setLoading(false));
        console.log('error', error);
          dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: `Failed to fetch vessel data`, alertDescription: '' }));
      }
    })();
  }, [allVesselsPageNumber, range, shouldFetchFilter]);

  // fetching vessel's container details to show on table
  useEffect(() => {
    (async function () {
      if (selectedVessel !== null) {
        const fromDate = format(range[0].startDate!, 'yyyy-MM-dd');
        const toDate = format(range[0].endDate!, 'yyyy-MM-dd');
        dispatch(setLoading(true));
        try {
          const allDetailsPromise = getAllDetails({
            fromDate,
            toDate,
            pageNumber: allDetailsPageNumber,
            pageSize: tableConfig.pageSize,
            searchKey: selectedTableFilter.name,
            searchValue: selectedTableFilter.value,
            vesselId: selectedVessel.vesselId
          });
          const allDetailsCountPromise = getAllDetailsCount({
            fromDate,
            toDate,
            searchKey: selectedTableFilter.name,
            searchValue: selectedTableFilter.value,
            vesselId: selectedVessel.vesselId
          });
          const response: any = await Promise.all([allDetailsPromise, allDetailsCountPromise]);
          const allDetails = response[0]?.data.data;
          const allDetailsCount = response[1]?.data.totalRecords;
          // if no data then show error alert
          if (allDetailsCount === 0) {
            // if filter applied and data not found
            if (isFilterApplied || inputFilterData !== '') {
              dispatch(setShowAlert({ showAlert: true, alertType: 'error',
                alertTitle: `Invalid ${selectedFilter.name} or data not found for the selected Date Range.` ,
                alertDescription: ''}));
            }
          }
          setAllDetails(allDetails.map((allDetails: IAllDetails) => ({ ...allDetails, key: nanoid() })));
          setAllDetailsTotalRecords(allDetailsCount);
          dispatch(setLoading(false));
        } catch (error) {
          console.log(error);
          dispatch(setLoading(false));
        }
      }
    })();
  }, [selectedVessel, allDetailsPageNumber, range, shouldFetchFilter, shouldResetTable]);

  // fetching vessel history coordinates
  useEffect(() => {
    (async () => {
      try {
        if (allDetails !== null && vesselHistoryCoordinates === null) {
          dispatch(setLoading(true));
          const historyDetails = await getVesselHistoryCoordinates(allDetails[0].vesselId, allDetails[0].containerId, allDetails[0].mabd);
          setVesselHistoryCoordinates(historyDetails?.data.history.map((coordinate: IVesselHistoryCoordinate) => ({ ...coordinate, key: nanoid() })));
          dispatch(setLoading(false));
        }
      } catch (error: any) {
        console.log('error', error);
        dispatch(setLoading(false));
      }
    })();
  }, [allDetails]);

  // handler methods -----------------------------
  const routeToHome = () => {
    navigate(`/${routes.home}`);
  };
  // handle 'Rest Filter / Reset View' click
  const handleResetClick = () => {
    // if user clicked on single vessel and filter is also applied then reset click will only reset to previous view but filter will not reset.
    // filter will only reset when user click on 'Reset Filter'
    if (selectedVessel !== null) {
      setSelectedVessel(null);
      setVesselHistoryCoordinates(null);
      setAllDetailsPageNumber(1);
    } else if (isFilterApplied && inputFilterData !== '') {
      // if apply button is clicked and inputFilterData is not empty then reset all below.
      location.state = null;
      setSelectedFilter({ name: 'Container ID', code: 'containerId' });
      setInputFilterData('');
      setShouldFetchFilter((prevState: boolean) => !prevState);
      setAllVesselsPageNumber(1);
      setIsFilterApplied(false);
    } else {
      // reset only the filter box contents if apply button is not clicked yet and user clicks only the reset Filter button
      setSelectedFilter({ name: 'Container ID', code: 'containerId' });
      setInputFilterData('');
    }
  };

  // handle vessels,ports,imports dropdown change
  const handleVesselPortImportChange = (e: any) => {
    setSelectedVesselsPortsImports(e.value);
  };

  const dropdownTemplate = (option: string) => {
    if (option === 'Vessels') {
      return (
        <div className="dropdown-template">
          <img alt={option} src='/markers/ship.svg' />
          <span>{option}</span>
        </div>
      );
    }
    if (option === 'Ports') {
      return (
        <div className="dropdown-template">
          <img alt={option} src='/markers/port.svg' />
          <span>{option}</span>
        </div>
      );
    }
    if (option === 'Imports') {
      return (
        <div className="dropdown-template">
          <img alt={option} src='/markers/import.svg' />
          <span>{option}</span>
        </div>
      );
    }
  };

  return (
    <section className='vessel-tracking'>
      <section className={headerClass(props.isExpanded)}>
        <section className='header-left-container'>
          <div className='text-header'>{labels.vesselTracking}</div>
          <div className='text-menu'>
            <div data-testid='route-to-home' className="nav" onClick={routeToHome}>{labels.homeNav}</div> &nbsp; &gt; &nbsp;
            <div className="nav">{labels.vesselTracking}</div>
          </div>
        </section>
        <section className='header-right-container'>
          {/* date range picker */}
          <div className="dropdown-group">
            <p>Date Range(UTC)</p>
            <CustomDateRangePicker range={range} setRange={setRange} footerLabel='By default date range of MABD will be T-7 to T+21' />
          </div>
        </section>
      </section>
      <section className={subHeaderClass(props.isExpanded)}>
        <section className='left-subheader-container'>
          <div className="dropdown-group">
            <p>Vessels, Ports, Imports</p>
            <MultiSelect
              inputId="vessel-ports-imports-multiselect"
              className='vessels-ports-imports-dropdown'
              value={selectedVesselsPortsImports}
              options={vessels_ports_imports}
              onChange={handleVesselPortImportChange}
              itemTemplate={dropdownTemplate}
            />
          </div>
          {/* filter overlay */}
          <FilterOverlay
            selectedFilter={selectedFilter}
            setSelectedFilter={setSelectedFilter}
            inputFilterData={inputFilterData}
            setInputFilterData={setInputFilterData}
            setShouldFetchFilter={setShouldFetchFilter}
            setAllVesselsPageNumber={setAllVesselsPageNumber}
            isFilterApplied={isFilterApplied}
            setIsFilterApplied={setIsFilterApplied}
          />
          {
            (selectedVessel !== null || inputFilterData !== '' || isFilterApplied) && (
              <button
                data-testid='reset-btn'
                onClick={handleResetClick}
                type='button'
                className='reset-button'
              >
                Reset {selectedVessel !== null ? 'View' : 'Filter'}
              </button>
            )
          }
        </section>
        {
          allVesselsTotalRecords > 0 && (
            <section className={rightSubheaderContainerClass(selectedVessel)}>
              <Pagination
                count={Math.ceil(allVesselsTotalRecords / tableConfig.vesselTrackingMapPageSize)}
                siblingCount={1}
                color='primary'
                showFirstButton
                showLastButton
                size='small'
                shape='rounded'
                onChange={(e, value) => setAllVesselsPageNumber(value)}
              />
            </section>
          )
        }
      </section>
      <section className={mapSectionClass(props.isExpanded)}>
        <MapContainer className='map-container'>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png"
          />
          <Map
            allVessels={allVessels}
            selectedVessel={selectedVessel}
            setSelectedVessel={setSelectedVessel}
            selectedVesselsPortsImports={selectedVesselsPortsImports}
            vesselHistoryCoordinates={vesselHistoryCoordinates}
          />
        </MapContainer>
      </section>
      <section className={tablePaginationClass(props.isExpanded)}>
        {
          (selectedVessel && allDetails) && (
            <>
              <TrackingTable
                isExpanded={props.isExpanded}
                allDetails={allDetails}
                setAllDetails={setAllDetails}
                setAllDetailsTotalRecords={setAllDetailsTotalRecords}
                range={range}
                vesselId={selectedVessel.vesselId}
                selectedTableFilter={selectedTableFilter}
                setSelectedTableFilter={setSelectedTableFilter}
                shouldResetTable={shouldResetTable}
                setShouldResetTable={setShouldResetTable}
              />
              <Pagination
                count={Math.ceil(allDetailsTotalRecords / tableConfig.pageSize)}
                shape='rounded'
                siblingCount={1}
                color={'standard'}
                showFirstButton
                showLastButton
                size='small'
                onChange={(e, value) => setAllDetailsPageNumber(value)}
              />
            </>
          )
        }
      </section>
    </section>
  );
};

export default VesselTracking;