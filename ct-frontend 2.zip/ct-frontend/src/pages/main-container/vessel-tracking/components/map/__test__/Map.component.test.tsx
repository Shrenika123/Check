import '@testing-library/jest-dom';
import { cleanup, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import Map from '../Map.component';
import { routes } from '../../../../../../common/navigation-utils';

afterEach(cleanup);

describe('Map Component', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };

  const mockAllVessels = [{
    "fromLocationId": "PORT482",
    "toLocationId": "PORT578",
    "fromLocation": "Los angeles",
    "toLocation": "Port of Taipei",
    "fromLocationLatitude": 33.736061096191406,
    "fromLocationLongitude": 241.72563934326172,
    "toLocationLatitude": 25.099689483642578,
    "toLocationLongitude": 121.45661926269531,
    "vesselName": "MOL TRUIMPH",
    "vesselId": "4928181",
    "tracker_geo_latitude": 32.696495056152344,
    "tracker_geo_longitude": 135.79739379882812,
    "imo": "5824960",
    "mmsi": "428924771",
    "idc_id": "IDC124",
    "idc_name": "WMT IDC CO",
    "idc_latitude": 23.71133041381836,
    "idc_longitude": 121.43281555175781
  }];
  const mockSelectedVesselsPortsImports = ['Vessels', 'Ports', 'Imports'];
  const mockVesselHistory = [
    {
      "trackerGeoLatitude": -15.633709907531738,
      "trackerGeoLongitude": -148.76220703125
    },
    {
      "trackerGeoLatitude": -15.633709907531738,
      "trackerGeoLongitude": -148.76220703125
    }
  ];

  test('should render component', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <Map
          allVessels={mockAllVessels}
          selectedVesselsPortsImports={mockSelectedVesselsPortsImports}
          vesselHistoryCoordinates={mockVesselHistory} 
          selectedVessel={null}
        />
      </Provider>, { wrapper: BrowserRouter }
    );
  });

  test('should render component with different props', async () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <Map
          allVessels={[]}
          selectedVesselsPortsImports={mockSelectedVesselsPortsImports}
          vesselHistoryCoordinates={mockVesselHistory} 
          selectedVessel={null}
        />
      </Provider>, { wrapper: BrowserRouter }
    );

  });

});