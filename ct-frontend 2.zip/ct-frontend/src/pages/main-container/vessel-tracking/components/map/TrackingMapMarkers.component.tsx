import { useEffect, useState } from 'react';
import { Marker, Polyline, Tooltip } from "react-leaflet";
import { IMapMarkersProps } from '../../../../../common/interfaces';
import { importContainerIcon, portAnchorIcon, shipIcon } from '../../../../../common/markers';
import RotatedMarker from '../../../../../components/rotated-marker/RotatedMarker.component';

function TrackingMapMarkers(props: IMapMarkersProps) {

  const [markerAngle, setMarkerAngle] = useState(0);

  useEffect(() => {
    // calculating rotation angle for the ship marker
    const currentPosition: number[] = [props.vessel?.tracker_geo_latitude, props.vessel?.tracker_geo_longitude];
    const finalPosition: number[] = [props.vessel.toLocationLatitude, props.vessel.toLocationLongitude];
    let rotationAngle = Math.atan2(finalPosition[0] - currentPosition[0], finalPosition[1] - currentPosition[1]);
    rotationAngle = rotationAngle * (180 / Math.PI);
    rotationAngle = (rotationAngle + 360) % 360;
    rotationAngle = 360 - rotationAngle;
    setMarkerAngle(rotationAngle);
  }, [props.vessel]);

  return (
    <>
      {
        props.selectedVesselsPortsImports.includes('Ports') && (
          <>
            {/* source marker */}
            <Marker position={[props.vessel.fromLocationLatitude, props.vessel.fromLocationLongitude]} icon={portAnchorIcon}>
              <Tooltip offset={[0, -17] as any} direction='top'>
                <strong>{props.vessel.fromLocation}</strong>
                <p>ID: {props.vessel.fromLocationId}</p>
              </Tooltip>
            </Marker>
            {/* destination marker */}
            <Marker position={[props.vessel.toLocationLatitude, props.vessel.toLocationLongitude]} icon={portAnchorIcon}>
              <Tooltip offset={[0, -17] as any} direction='top'>
                <strong>{props.vessel.toLocation}</strong>
                <p>ID: {props.vessel.toLocationId}</p>
              </Tooltip>
            </Marker>
          </>
        )
      }
      {
        props.selectedVesselsPortsImports.includes('Imports') && (
          <>
            {/* import marker */}
            <Marker position={[props.vessel.idc_latitude, props.vessel.idc_longitude]} icon={importContainerIcon}>
              <Tooltip offset={[0, -17] as any} direction='top'>
                <strong>{props.vessel.idc_name}</strong>
                <p>ID: {props.vessel.idc_id}</p>
                <p>Date: {props.vessel.idc_name}</p>
              </Tooltip>
            </Marker>
          </>
        )
      }
      {
        props.selectedVesselsPortsImports.includes('Vessels') && (
          <>
            {/* vessel marker */}
            <RotatedMarker
              alt='vessel-marker'
              position={[props.vessel.tracker_geo_latitude, props.vessel.tracker_geo_longitude]}
              eventHandlers={{ click: () => props.handleTrackerClick(props.vessel) }}
              icon={shipIcon}
              rotationAngle={markerAngle}
              rotationOrigin='center'
            >
              <Tooltip offset={[0, -5] as any} direction='top'>
                <strong>{props.vessel.vesselName}</strong><br />
                <p>Vessel Id: {props.vessel.vesselId}</p>
                <p>IMO: {props.vessel.imo}</p>
                <p>MMSI: {props.vessel.mmsi}</p>
              </Tooltip>
            </RotatedMarker>
          </>
        )
      }
      {/* track lines */}
      {
        (props.selectedVessel?.vesselId === props.vessel.vesselId && props.vesselHistoryCoordinates && props.vesselHistoryCoordinates.length !== 0) && (
          <>
            <Polyline
              pathOptions={{ color: '#8791C2', weight: 2 }}
              positions={[[props.vessel.fromLocationLatitude, props.vessel.fromLocationLongitude], [props.vesselHistoryCoordinates[0].trackerGeoLatitude, props.vesselHistoryCoordinates[0].trackerGeoLongitude]]}
            />
            {
              props.vesselHistoryCoordinates?.map((coordinate, index, coordinateArray) => {
                if (index < coordinateArray.length - 1) {
                  return (
                    <Polyline
                      key={coordinate.key}
                      pathOptions={{ color: '#8791C2', weight: 2 }}
                      positions={[[coordinateArray[index].trackerGeoLatitude, coordinateArray[index].trackerGeoLongitude], [coordinateArray[index + 1].trackerGeoLatitude, coordinateArray[index + 1].trackerGeoLongitude]]}
                    />
                  );
                }
              })
            }
            <Polyline
              pathOptions={{ color: '#8791C2', weight: 2, dashArray: '4' }}
              positions={[[props.vesselHistoryCoordinates[props.vesselHistoryCoordinates!.length - 1].trackerGeoLatitude, props.vesselHistoryCoordinates[props.vesselHistoryCoordinates!.length - 1].trackerGeoLongitude], [props.vessel.toLocationLatitude, props.vessel.toLocationLongitude]]}
            />
          </>
        )
      }
    </>
  );

}

export default TrackingMapMarkers;