import { ReactElement, useEffect } from 'react';
import { useMap } from 'react-leaflet';
import { IMapProps, IVessel } from '../../../../../common/interfaces';
import TrackingMapMarkers from './TrackingMapMarkers.component';

function Map(props: IMapProps): ReactElement {
  const map = useMap();

  useEffect(() => {
    if (props.selectedVessel === null) {
      map.setView([32, 142], 2);
    }

    if (props.selectedVessel !== null) {
      map.flyToBounds?.([[props.selectedVessel.fromLocationLatitude, props.selectedVessel.fromLocationLongitude], [props.selectedVessel.toLocationLatitude, props.selectedVessel.toLocationLongitude]], { padding: [60, 60] });
    }
  }, [props.selectedVessel]);

  const handleTrackerClick = (vessel: IVessel) => {
    if (props.selectedVesselsPortsImports.includes('Vessels') && props.selectedVesselsPortsImports.includes('Ports')) {
      props.setSelectedVessel?.(vessel);
    }
  };

  return (
    <>
      {
        props.selectedVessel !== null ? (
          <TrackingMapMarkers
            selectedVessel={props.selectedVessel}
            handleTrackerClick={handleTrackerClick}
            vessel={props.selectedVessel}
            selectedVesselsPortsImports={props.selectedVesselsPortsImports}
            vesselHistoryCoordinates={props.vesselHistoryCoordinates}
          />
        ) :
          props.allVessels && props.allVessels.map((vessel: IVessel) => {
            return (
              <TrackingMapMarkers
                key={vessel.key}
                handleTrackerClick={handleTrackerClick}
                vessel={vessel}
                selectedVesselsPortsImports={props.selectedVesselsPortsImports} />
            );
          })
      }
    </>
  );

}

export default Map;