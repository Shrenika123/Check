import '@testing-library/jest-dom';
import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { addDays, subDays } from 'date-fns';
import { Range } from 'react-date-range';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import TrackingTable from '../TrackingTable.component';
import { routes } from '../../../../../../common/navigation-utils';

afterEach(cleanup);

describe('Tracking Table', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };

  const allDetailsMock = [
    {
      "mabd": "2023-02-03",
      "shipmentStatus": "Underway",
      "fromLocation": "Los angeles",
      "toLocation": "New York",
      "vesselId": "5213958",
      "idcDate": "2023-02-08 00:00:00+00",
      "containerId": "CNT11513",
      "loadId": "581338161",
      "shipmentId": "MINDIDZOOOCYBCK",
      "supplierName": "SpookyCity",
      "poNumber": "23457232",
      "eta": "2023-01-13"
    }
  ]
  const initDateRange: Range[] = [
    {
      startDate: subDays(new Date(), 15),
      endDate: addDays(new Date(), 45),
      key: 'selection'
    }
  ];

  test('should render component with data', () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <TrackingTable
          allDetails={allDetailsMock}
          range={initDateRange}
          isExpanded={false}
          setAllDetails={jest.fn()}
          setAllDetailsTotalRecords={jest.fn()}
          vesselId={allDetailsMock[0].vesselId}
          selectedTableFilter={{ name: 'containerId', value: '' }}
          setSelectedTableFilter={jest.fn()}
          shouldResetTable={false}
          setShouldResetTable={jest.fn()}
        />
      </Provider>, { wrapper: BrowserRouter }
    );

    const containerSearchIcon = screen.getByTestId('container-search');
    userEvent.click(containerSearchIcon);
    const containerSearchIconReset = screen.getByTestId('container-search-reset');
    userEvent.click(containerSearchIconReset);
  });

  test('should render component with no data', () => {
    const powerUserStore = mockStore(powerUserState);

    render(
      <Provider store={powerUserStore}>
        <TrackingTable
          allDetails={[]}
          range={initDateRange}
          isExpanded={false}
          setAllDetails={jest.fn()}
          setAllDetailsTotalRecords={jest.fn()}
          vesselId={''}
          selectedTableFilter={{ name: 'containerId', value: '' }}
          setSelectedTableFilter={jest.fn()}
          shouldResetTable={false}
          setShouldResetTable={jest.fn()}
        />
      </Provider>, { wrapper: BrowserRouter }
    );
  });
});