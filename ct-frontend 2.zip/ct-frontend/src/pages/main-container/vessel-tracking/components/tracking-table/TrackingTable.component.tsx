import classNames from 'classnames';
import { format } from 'date-fns';
import { AutoComplete } from 'primereact/autocomplete';
import { FC, ReactElement, useState } from 'react';
import { Link } from 'react-router-dom';
import { routes, tableConfig } from '../../../../../common/constants';
import { IAllDetails, IRoutePermission, IUserState, IVesselTrackingTableProps } from '../../../../../common/interfaces';
import { getAllDetails, getFormattedDate } from '../../../../../common/utils';
import './TrackingTable.style.css';
import { useSelector } from 'react-redux';

const TrackingTable: FC<IVesselTrackingTableProps> = (props): ReactElement => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const containerPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'CONTAINER_TRACKING')?.permission;


  const [showFilter, setShowFilter] = useState(false);
  const [tableFilter, setTableFilter] = useState<{ name: string; value: string; }>({ name: 'containerId', value: '' });
  const [filteredSuggestions, setFilteredSuggestions] = useState<IAllDetails[]>();

  // handler method for search filter
  const handleSearch = async (event: any) => {
    try {
      const fromDate = format(props.range[0].startDate!, 'yyyy-MM-dd');
      const toDate = format(props.range[0].endDate!, 'yyyy-MM-dd');
      if (event.query !== '') {
        const response = await getAllDetails({
          fromDate,
          toDate,
          pageNumber: 1,
          pageSize: tableConfig.pageSize,
          searchKey: tableFilter.name,
          searchValue: event.query,
          vesselId: props.vesselId
        });
        setFilteredSuggestions(response?.data.data.map((allDetails: IAllDetails) => {
          switch (tableFilter.name) {
            case 'containerId':
              return allDetails.containerId;
            default:
              break;
          }
        }) ?? []);
      }
    } catch (error: any) {
      console.log('error - handleSearch()', error);
    }
  };

  const handleIconClick = (searchKey: string) => {
    setShowFilter(prevState => !prevState);
    switch (searchKey) {
      case 'containerId':
        setTableFilter({ name: 'containerId', value: '' });
        break;
      default:
        if (tableFilter.value !== '') {
          props.setShouldResetTable(false);
          props.setSelectedTableFilter({ name: tableFilter.name, value: '' });
        }
        if (tableFilter.value === '' && props.shouldResetTable) {
          props.setShouldResetTable(false);
          props.setSelectedTableFilter({ name: tableFilter.name, value: '' });
        }
        break;
    }
  };

  const handleSelectedTableFilter = (e: any) => {
    switch (tableFilter.name) {
      case 'containerId':
        props.setShouldResetTable(true);
        props.setSelectedTableFilter({ name: tableFilter.name, value: e.value });
        break;
      default:
        break;
    }
  };

  const tableClassname = classNames('table', {
    'table-shrink': props.isExpanded
  });
  const tableWrapperClassname = classNames('table-wrapper-nav', {
    'table-wrapper': props.allDetails?.length > 6,
    'table-wrapper-nav-shrink': props.isExpanded
  });

  return (
    <section id='vesselTracking-table'>
      <div className={tableWrapperClassname}>
        <table className={tableClassname}>
          <thead>
            <tr>
              <th>
                {
                  showFilter ? (
                    <AutoComplete
                      minLength={4}
                      delay={500}
                      showEmptyMessage={true}
                      value={tableFilter.value}
                      onChange={(e) => setTableFilter((prevState: any) => ({ ...prevState, value: e.value.toUpperCase() }))}
                      suggestions={filteredSuggestions}
                      completeMethod={handleSearch}
                      onSelect={handleSelectedTableFilter}
                      className='container-id-filter'
                    />
                  ) : <div className='container-id-filter'>Container ID</div>
                }
                {
                  showFilter ? (
                    <i data-testid='container-search-reset' className="pi pi-times" onClick={() => handleIconClick('')} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
                  ) : (
                    <i data-testid='container-search' className="pi pi-search" onClick={() => handleIconClick('containerId')} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
                  )
                }
              </th>
              <th>Load ID</th>
              <th>MABD</th>
              <th>Origin</th>
              <th>Destination</th>
              <th>ETA</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {
              props.allDetails?.length > 0 ? props.allDetails.map((data: IAllDetails, index) => {
                return (
                  <tr key={data.key}>
                    <td>
                      {(containerPerm && containerPerm !=='NA') ?
                      <Link
                        to={`/${routes.vesselTrackingDetails}`}
                        state={
                          {
                            containerId: data.containerId,
                            mabd: data.mabd,
                          }
                        }
                      >
                        {data.containerId}
                      </Link>
                      : data.containerId}

                    </td>
                    <td>{data.loadId}</td>
                    <td>{getFormattedDate(data.mabd)}</td>
                    <td>{data.fromLocation.toUpperCase()}</td>
                    <td>{data.toLocation.toUpperCase()}</td>
                    <td>{getFormattedDate(data.eta)}</td>
                    <td>{data.shipmentStatus}</td>
                  </tr>
                );
              }) : (
                <tr>
                    <td colSpan={7}>No data for the selected date range</td>
                </tr>
              )
            }
          </tbody>
        </table>
      </div>
    </section>
  );
};

export default TrackingTable;