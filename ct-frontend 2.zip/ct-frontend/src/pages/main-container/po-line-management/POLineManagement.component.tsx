import classNames from 'classnames';
import React, { BaseSyntheticEvent, useCallback, useEffect, useState } from "react";
import { useDispatch } from 'react-redux';
import { useLocation, useNavigate } from "react-router-dom";
import { labels, polineColumn, routes, tableConfig } from '../../../common/constants';
import { debounce } from '../../../common/debounce';
import { IPOLineFilterRequest, IPOLineTableRequest, IPOLineTableRow } from '../../../common/interfaces';
import { getPOLineManagementFilter, getPOLineManagementTableCount, getPOLineManagementTableData, postActivityTrackerDetails } from '../../../common/utils';
import AutoSuggest from '../../../components/auto-suggest/AutoSuggest.component';
import { useDidComponentUpdate } from '../../../hooks/useDidComponentUpdate';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import POLineTable from './component/poline-table/POLineTable.component';

import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import './POLineManagement.style.css';


interface Props {
  isExpanded: boolean;
}

const POLineManagement: React.FC<Props> = (props) => {

  const location = useLocation();
  const state = location.state;
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [tableData, setTableData] = useState<IPOLineTableRow[]>([]);
  const [tableCount, setTableCount] = useState<number>(0);

  const [itemNoFilterData, setItemNoFilterData] = useState<string[]>([]);
  const [shipmentIdFilterData, setShipmentIdFilterData] = useState<string[]>([]);
  const [itemNoFilterInput, setItemNoFilterInput] = useState<string>('');
  const [shipmentIdFilterInput, setShipmentIdFilterInput] = useState<string>('');
  const [showItemNoFilterLoader, setShowItemNoFilterLoader] = useState<boolean>(false);
  const [showshipmentIdFilterLoader, setShowShipmentIdFilterLoader] = useState<boolean>(false);
  const [isItemNoFilterClose, setItemNoFilterClose] = useState<boolean>(false);
  const [isShipmentIdFilterClose, setShipmentIdFilterClose] = useState<boolean>(false);
  
  const [poNumberState, setPONumberState] = useState<{poNumber:string,mabd:string}>();

  const routeTo = (route: string) => {
    navigate(`/${route}`);
  };

  useEffect(() => {
    (async function () {
      if (!state || state === null || !state.poNumber || state.poNumber === null) {
        routeTo(routes.poManagement);
      }
      else {
        setPONumberState(state);
        try {
          await postActivityTrackerDetails(state.poNumber, 'VISITED', 'PURCHASE_ORDER',undefined,undefined,undefined,state.mabd);
        } catch (error) {
          console.log('line management-use-effect() - error', error);
        }
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadTableAndPopulateView = (poNumVar: string, mabd:string,itemNumVar: string, shipIdVar: string, sortColumn: string, sortingInDesc: boolean, pageNumber: number) => {
    dispatch(setLoading(true));
    const request: IPOLineTableRequest = {
      poNumber: poNumVar,
      mabd,
      itemNumber: itemNumVar,
      shipmentId: shipIdVar,
      sortColumn,
      sortingInDesc,
      pageNumber,
      pageSize: tableConfig.pageSize
    };
    getPOLineManagementTableData(request).then(res => {
      setTableData(res.data.data);
    }).catch(err => {
      setTableData([]);
      console.log(err);
      dispatch(setShowAlert({
        showAlert: true,
        alertType: 'error',
        alertTitle: 'some error occurred while fetching table data',
        alertDescription: ``,
      }));
    }).finally(() => {
      dispatch(setLoading(false));
    });
  };

  const fetchTableCount = (poNumVar: string, mabd:string,itemNumVar: string, shipIdVar: string) => {
    const request: IPOLineTableRequest = {
      poNumber: poNumVar,
      mabd,
      itemNumber: itemNumVar,
      shipmentId: shipIdVar,
    };
    getPOLineManagementTableCount(request).then(res => {
      setTableCount(res.data.totalRecords);
    }).catch(err => {
      setTableCount(0);
      console.log(err);
      dispatch(setShowAlert({
        showAlert: true,
        alertType: 'error',
        alertTitle: 'Some error occurred while fetching total pages',
        alertDescription: ``,
      }));
    });
  };
  const fetchSuggestionData = (selectField: 'shipmentId' | 'itemNumber', inputString: string, poNumberStateVar:string,mabd:string) => {

    if (((selectField === 'itemNumber' && inputString.length >= 2) || (selectField === 'shipmentId' && inputString.length >= 4)) && poNumberStateVar) {
      const request: IPOLineFilterRequest = {
        poNumber: poNumberStateVar,
        mabd,
        selectField
      };
      if (selectField === 'shipmentId') {
        setShowShipmentIdFilterLoader(true);
        request.shipmentId = inputString;
      }
      else {
        setShowItemNoFilterLoader(true);
        request.itemNumber = inputString;
      }
      getPOLineManagementFilter(request).then(res => {
        if (selectField === 'shipmentId') {
          setShipmentIdFilterData(res.data.data);
        }
        else {
          setItemNoFilterData(res.data.data);
        }
      }).finally(() => {
        if (selectField === 'shipmentId') {
          setShowShipmentIdFilterLoader(false);
        }
        else {
          setShowItemNoFilterLoader(false);
        }
      });
    }
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const fetchSuggestionData_debounced = useCallback(debounce(fetchSuggestionData, 500), []);

  useDidComponentUpdate(() => {
    fetchSuggestionData_debounced('itemNumber', itemNoFilterInput,poNumberState?.poNumber,poNumberState?.mabd);
  }, [itemNoFilterInput]);

  useDidComponentUpdate(() => {
    fetchSuggestionData_debounced('shipmentId', shipmentIdFilterInput, poNumberState?.poNumber,poNumberState?.mabd);
  }, [shipmentIdFilterInput]);

  const handleInputChange = (e: BaseSyntheticEvent) => {
    if (e.target.name === labels.itemNumber)
      setItemNoFilterInput(e.target.value);
    else
      setShipmentIdFilterInput(e.target.value);
  };

  const handleItemNoSuggestionClick = (value:string) => {
    setItemNoFilterClose(true);
    setItemNoFilterInput(value)
    if(poNumberState ){
    loadTableAndPopulateView(poNumberState.poNumber, poNumberState.mabd,value, shipmentIdFilterInput, polineColumn.lineNumber, false, 1);
    fetchTableCount(poNumberState.poNumber, poNumberState.mabd,value, shipmentIdFilterInput);
  }
  }
  const handleShipmentIdSuggestionClick = (value: string) => {
    setShipmentIdFilterClose(true);
    setShipmentIdFilterInput(value);
    if (poNumberState) {
      loadTableAndPopulateView(poNumberState.poNumber, poNumberState.mabd,itemNoFilterInput, value, polineColumn.lineNumber, false, 1);
      fetchTableCount(poNumberState.poNumber,poNumberState.mabd, itemNoFilterInput, value);
    }
  }

  // classnames -----------------
  const headerClass = classNames({
    'header-shrink': props.isExpanded,
    'header': !props.isExpanded,
  });

  const queryWrapperClass = classNames('query-wrapper', {
    'shrink-query-wrapper': props.isExpanded
  });

  return (
    <section className='poLine-management'>
      <section className={headerClass} data-testid='po-line-management-header-testId'>
        <div className='text-header'>{labels.poLineManagement}</div>
        <div className='text-menu'>
          <div data-testid='route-to-home' className="nav" onClick={() => routeTo(routes.home)}>{labels.homeNav}</div> &nbsp;  &gt; &nbsp;
          <div data-testid='route-to-PO' className="nav" onClick={() => routeTo(routes.poManagement)}> {labels.poManagement} </div>&nbsp; &gt;&nbsp;
          <div className="nav">{labels.poLineNav}</div>
        </div>
      </section>
      <div className={queryWrapperClass}>

        <div className='query-box-wrapper' data-testid='itemNo-autoSuggest-testId'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.itemNumber}</p>

          <AutoSuggest inputSuggestionData={itemNoFilterData}
            onSuggestionClickHandler={(e: any, value: any) => handleItemNoSuggestionClick (value)} inputData={itemNoFilterInput} handleInputChange={handleInputChange}
            name={labels.itemNumber} isClosed={isItemNoFilterClose} inputLengthToShowSuggestion={2} isLoading={showItemNoFilterLoader} setClose={setItemNoFilterClose} />
        </div>
        <div className='query-box-wrapper' data-testid='shipId-autoSuggest-testId'>
          <p className={props.isExpanded ? 'query-text shrink-font' : 'query-text'}>{labels.shipmentId}</p>

          <AutoSuggest inputSuggestionData={shipmentIdFilterData}
            onSuggestionClickHandler={(e: any, value: any) => handleShipmentIdSuggestionClick(value)} inputData={shipmentIdFilterInput} handleInputChange={handleInputChange}
            name={labels.shipmentId} isClosed={isShipmentIdFilterClose} inputLengthToShowSuggestion={4} isLoading={showshipmentIdFilterLoader} setClose={setShipmentIdFilterClose} />
        </div>
      </div>
      {poNumberState &&
        <POLineTable isExpanded={props.isExpanded} poNumber={poNumberState.poNumber} itemId={itemNoFilterInput} shipmentId={shipmentIdFilterInput} loadTableAndPopulateView={loadTableAndPopulateView} fetchTableCount={fetchTableCount} tableData={tableData} tableCount={tableCount} mabd={poNumberState.mabd} />}

    </section>
  );
};

export default POLineManagement;