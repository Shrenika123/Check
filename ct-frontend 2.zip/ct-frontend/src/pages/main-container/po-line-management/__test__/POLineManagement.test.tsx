import {
  act,
  cleanup,
  fireEvent,
  render, screen, waitFor
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import router, { MemoryRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import {
  checkElementPresentInDomByTestId, clickElementByTestId, textPresentInDOM
} from '../../../../common/helper/testHelper';
import { POLineTableResponseData } from '../../../../common/mocks/POLineManagement';
import POLineManagement from '../POLineManagement.component';
import { routes } from '../../../../common/constants';



afterEach(() => {
  cleanup();
  jest.resetAllMocks();
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});
const mockedUsedNavigate = jest.fn();
const mockNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

const mockStore = configureStore();

const mockPoManagementTableResponse = {
  status: 200,
  data: POLineTableResponseData,
};

const suggestionRes = {
  data: { data: ['abcde', 'bcdef', 'cdefg', 'defgh', 'efghi'] },
  status: 200,
};

const countRes = {
  data: { totalRecords: 100 },
};
const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "NA",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};
const powerUserStore = mockStore(powerUserState);

const RenderPoLineManagement = ({ isExpanded }: { isExpanded?: boolean; }) => {
  return (
    <MemoryRouter
      initialEntries={[
        {
          pathname: 'po-management/details',
          search: '',
          state: { poNumber: '24681952', mabd: '2023-01-26' },
        },
      ]}
    >
      <Provider store={powerUserStore}>
        <POLineManagement isExpanded={false ?? isExpanded} />
      </Provider>
    </MemoryRouter>
  );
};

describe('PO Line Management Page', () => {
  beforeEach(() => {
    jest.spyOn(router, 'useNavigate').mockImplementation(() => mockNavigate);
    jest.clearAllMocks();
  });

  test('should render POLineManagement component on success', async () => {
    const util = require('../../../../common/utils');
    const poManagementData = jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue(mockPoManagementTableResponse);
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    render(<RenderPoLineManagement />);

    await waitFor(() => {
      expect(poManagementData).toBeCalled();
    });
    await checkElementPresentInDomByTestId('po-line-management-header-testId');
    await checkElementPresentInDomByTestId('itemNo-autoSuggest-testId');
    await checkElementPresentInDomByTestId('shipId-autoSuggest-testId');
    await checkElementPresentInDomByTestId('poLineManagementTable-testId');
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });
  });


  test('When Data is empty and clicked on PO navigation', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue({ res: { status: 200, data: { data: [] } } });
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    render(<RenderPoLineManagement />);

    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
      expect(screen.queryAllByTestId('poline-tableData')[0]).toBeUndefined();
    });
    await act(async () => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
      await clickElementByTestId('route-to-PO');
      expect(mockNavigate).toHaveBeenCalledTimes(1);
      expect(mockNavigate).toHaveBeenCalledWith('/po-management');
    });
  });

  test('should render PO Line Management component with api fail and when Dashboard Navigate is clicked', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockRejectedValue('network error');
    jest
      .spyOn(util, 'getPOLineManagementTableCount')
      .mockRejectedValue({ status: 500 });
    render(<RenderPoLineManagement />);
    await act(async () => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
      await clickElementByTestId('route-to-home');
      expect(mockNavigate).toHaveBeenCalledTimes(1);
      expect(mockNavigate).toHaveBeenCalledWith('/home');
    });
  });

  test('when sort and toggle is performed', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue(mockPoManagementTableResponse);
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    render(<RenderPoLineManagement />);
    await act(async () => {
      await clickElementByTestId('poline-lineNo');
      await clickElementByTestId('poline-lineNo');
    });
    await act(async () => {
      await clickElementByTestId('poline-shipmentid');
      await clickElementByTestId('poline-shipmentid');
    });
    await act(async () => {
      await clickElementByTestId('poline-itemNo');
      await clickElementByTestId('poline-itemNo');
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle  item no auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    const loadPoManagementDetails = jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue(mockPoManagementTableResponse);
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getPOLineManagementFilter')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoLineManagement />);
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[0], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle  shipment id auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    const loadPoManagementDetails = jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue(mockPoManagementTableResponse);
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getPOLineManagementFilter')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoLineManagement />);
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[1], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should paginate poLineManagement component', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue(mockPoManagementTableResponse);
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    render(<RenderPoLineManagement />);
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    userEvent.click(screen.getByTestId('NavigateNextIcon'));
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle enter key input', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue(mockPoManagementTableResponse);
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoLineManagement />);
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    userEvent.keyboard('{Enter}');
    userEvent.keyboard('{NumpadEnter}');
  });
  test('should show NA when shipment id is NULL', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getPOLineManagementTableData')
      .mockResolvedValue(mockPoManagementTableResponse);
    jest.spyOn(util, 'getPOLineManagementTableCount').mockResolvedValue(countRes);
    jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoLineManagement />);
    await waitFor(async () => {
      await textPresentInDOM('NA');
    });
  });

});