import { Pagination } from '@mui/material';
import classNames from 'classnames';
import { format } from 'date-fns';
import { nanoid } from 'nanoid';
import { FC, useEffect, useRef, useState } from 'react';
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io';
import { useNavigate } from "react-router-dom";
import { labels, polineColumn, routes, tableConfig } from '../../../../../common/constants';
import { IPOLineTableRow, IRoutePermission, ISortAndPagePOLine, IUserState } from '../../../../../common/interfaces';
import { getGMTTimeStamp, isStringValid } from '../../../../../common/utils';
import { useSelector } from 'react-redux';

interface Props {
  isExpanded: boolean;
  poNumber: string;
  mabd: string;
  itemId: string;
  shipmentId: string;
  loadTableAndPopulateView: Function;
  fetchTableCount: Function;
  tableData: IPOLineTableRow[];
  tableCount: number;
}


const POLineTable: FC<Props> = (props) => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const poItemPerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'PO_ITEM_MANAGEMENT')?.permission;

  const initSortPage: ISortAndPagePOLine = {
    sortColumn: polineColumn.lineNumber,
    sortingInDesc: false,
    pageNumber: 1
  };

  const navigate = useNavigate();

  const [sortAndPage, setSortAndPage] = useState<ISortAndPagePOLine>(initSortPage);

  const clickOutsideRef = useRef<HTMLTableCellElement>(null);

  const routeToItemManagement = (itemNumber: string, poNumber: string, mabd: string) => {
    navigate(`/${routes.itemManagement}`, { state: { itemNumber, poNumber, mabd } });
  };

  const routetoShipmentId = (shipmentIdVar: string, itemStatus: string) => {
    if (itemStatus === 'Shipped' || itemStatus === 'Ready To Ship')
      navigate(`/${routes.shipLoadManagement}?params=%7B%22shipment_id%22:%22${shipmentIdVar}%22,%22mabd%22:%22${props.mabd}%22%7D`);
  };

  useEffect(() => {
    props.loadTableAndPopulateView(props.poNumber, props.mabd, props.itemId, props.shipmentId, initSortPage.sortColumn, initSortPage.sortingInDesc, initSortPage.pageNumber);
    props.fetchTableCount(props.poNumber, props.mabd, props.itemId, props.shipmentId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.code === "Enter" || event.code === "NumpadEnter") {
        event.preventDefault();
        clickOutsideRef.current?.click();
        setSortAndPage(initSortPage);
        props.loadTableAndPopulateView(props.poNumber, props.mabd, props.itemId, props.shipmentId, initSortPage.sortColumn, initSortPage.sortingInDesc, initSortPage.pageNumber);
        props.fetchTableCount(props.poNumber, props.mabd, props.itemId, props.shipmentId);
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.itemId, props.shipmentId]);

  const getSortIcon = (columnName: string) => {

    if (sortAndPage.sortColumn === columnName) {
      if (sortAndPage.sortingInDesc) {
        return <IoMdArrowDropdown />;
      }
      else {
        return <IoMdArrowDropup />;
      }
    }
    else
      return <></>;
  };

  const handleSorting = (columnName: string) => {
    if (sortAndPage.sortColumn === columnName) {
      setSortAndPage({ ...sortAndPage, sortingInDesc: !sortAndPage.sortingInDesc, pageNumber: 1 });
      props.loadTableAndPopulateView(props.poNumber, props.mabd, props.itemId, props.shipmentId, sortAndPage.sortColumn, !sortAndPage.sortingInDesc, 1);

    }
    else {
      setSortAndPage({ ...sortAndPage, sortColumn: columnName, pageNumber: 1, sortingInDesc: false });
      props.loadTableAndPopulateView(props.poNumber, props.mabd, props.itemId, props.shipmentId, columnName, false, 1);

    }
  };

  const pageChangeHandler = (pageNum: number) => {
    props.loadTableAndPopulateView(props.poNumber, props.mabd, props.itemId, props.shipmentId, sortAndPage.sortColumn, sortAndPage.sortingInDesc, pageNum);
    setSortAndPage({ ...sortAndPage, pageNumber: pageNum });
  };

  const tableReportClass = classNames('table-report', {
    'table-report-shrink': props.isExpanded,
  });

  const paginatedClass = classNames('paginated', {
    'paginated-shrink': props.isExpanded
  });

  return (
    <>
      <div className={tableReportClass} data-testid='poLineManagementTable-testId'>
        <table className='table'>
          <thead className={props.isExpanded ? 'custom-thead shrink-font' : 'custom-thead'}>
            <tr className='custom-tr'>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.poNumber}
                </div>
              </th>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.maap}
                </div>
              </th>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.mabd}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(polineColumn.shipmentId)} data-testid='poline-shipmentid'>
                <div className='th-wrapper'>
                  {labels.shipmentId}
                  {getSortIcon(polineColumn.shipmentId)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(polineColumn.itemNumber)} data-testid='poline-itemNo'>
                <div className='th-wrapper'>
                  {labels.itemNumber}
                  {getSortIcon(polineColumn.itemNumber)}
                </div>
              </th>
              <th className='custom-th' onClick={() => handleSorting(polineColumn.lineNumber)} data-testid='poline-lineNo'>
                <div className='th-wrapper'>
                  {labels.lineNumber}
                  {getSortIcon(polineColumn.lineNumber)}
                </div>
              </th>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.department}
                </div>
              </th>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.itemDescription}
                </div>
              </th>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.orderedQuantity}
                </div>
              </th>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.shippedQuantity}
                </div>
              </th>
              <th className='custom-th'>
                <div className='th-wrapper'>
                  {labels.pendingQuantity}
                </div>
              </th>
            </tr>
          </thead>
          <tbody className={props.isExpanded ? 'custom-tbody shrink-font' : 'custom-tbody'}>
            {props.tableData ? props.tableData.map((row: IPOLineTableRow, index: number) => {
              return (
                <tr data-testid='poline-tableData' className='custom-tr' key={row.lineNumber + index}>
                  <td className='custom-td'>{row.poNumber}</td>
                  <td className='custom-td'>{format(getGMTTimeStamp(row.maap), 'MM/dd/yyyy')}</td>
                  <td ref={clickOutsideRef} className='custom-td'>{format(getGMTTimeStamp(row.mabd), 'MM/dd/yyyy')}</td>
                  <td className='custom-td' id={(row.itemStatus=== 'Shipped' || row.itemStatus === 'Ready To Ship')?'ItemNum':''} onClick={() => routetoShipmentId(row.shipmentId, row.itemStatus)}>{isStringValid(row.shipmentId) ? row.shipmentId : 'NA'}</td>
                  <td
                    id='ItemNum'
                    className= { poItemPerm && poItemPerm !== 'NA' ? 'custom-td hyperlink' : 'custom-td non-hyperlink'}
                    onClick={() => routeToItemManagement(row.itemNumber, row.poNumber, row.mabd)}>
                    {row.itemNumber}
                  </td>
                  <td className='custom-td'>{row.lineNumber}</td>
                  <td className='custom-td'>{row.department}</td>
                  <td className='custom-td'>{row.itemDescription}</td>
                  <td className='custom-td'>{row.orderedQuantity}</td>
                  <td className='custom-td'>{row.shippedQuantity}</td>
                  <td className='custom-td'>{row.pendingQuantity}</td>
                </tr>);
            }) :
              [...Array(8)].map(() => { return { key: nanoid() }; }).map((_, index) => {
                return (
                  <tr data-testid='filler' className='custom-tr' key={_.key}>
                    <td className='custom-td' colSpan={11}><div className='filler' ></div></td>
                  </tr>);
              })
            }
            {
              [...Array(props.tableData ? (props.tableData.length < 8 ? 8 - props.tableData.length : 0) : 0)].map(() => { return { key: nanoid() }; }).map((_, index) => {
                return (
                  <tr data-testid='filler' className='custom-tr' key={_.key}>
                    <td className='custom-td' colSpan={11}><div className='filler' ></div></td>
                  </tr>
                );
              })
            }
          </tbody>
        </table>
      </div>
      <div>
        <div className={paginatedClass}>
          <Pagination count={Math.ceil(props.tableCount / tableConfig.pageSize)} variant='text' shape='rounded' siblingCount={1} color={'standard'} showFirstButton showLastButton size="small"
            page={sortAndPage.pageNumber}
            onChange={(e, value) => pageChangeHandler(value)}
          />
          {/* </>
            : <></>
          } */}
        </div>
      </div></>
  );
};

export default POLineTable;