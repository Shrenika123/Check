import { Pagination } from '@mui/material';
import classNames from 'classnames';
import { format } from 'date-fns';
import {
  BaseSyntheticEvent,
  FC,
  useCallback,
  useEffect,
  useState,
} from 'react';
import { Range } from 'react-date-range';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  allowedMultiSelectFilters,
  labels,
  PoManagementColumn,
  routes,
  tableConfig,
} from '../../../common/constants';
import { debounce } from '../../../common/debounce';
import {
  IPoManagementFilterRequest,
  IPoManagementRequest,
  IPoManagementTableResponse,
  ISort,
  ISortAndPage,
} from '../../../common/interfaces';
import {
  getMultiSelectFilterData,
  getPoManagementAutoSuggestData,
  getPoManagementDataCount,
  getPoManagementDetails,
  getSettingModifiedData,
} from '../../../common/utils';
import AutoSuggest from '../../../components/auto-suggest/AutoSuggest.component';
import CustomDateRangePicker from '../../../components/date-range-picker/CustomDateRangePicker';
import MultiSelectFilter from '../../../components/multiselect-filter/MultiSelectFilter';
import { useDidComponentUpdate } from '../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import PoManagementTable from './components/po-management-table';
import './po-management.style.css';

interface Props {
  isExpanded: boolean;
}

const POManagement: FC<Props> = (props) => {
  const initSortPage: ISortAndPage = {
    sortColumn: PoManagementColumn.Mabd,
    sortOrder: '',
    pageNumber: 1,
  };
  const settings = useSelector((state: any) => state.systemSetting);
  const [range, setRange] = useState<Range[]>(() =>
    getSettingModifiedData(settings,15,45)
  );
  const [tableData, setTableData] = useState<IPoManagementTableResponse[]>();
  const [totalCount, setTotalCount] = useState<number>(0);
  const [sortAndPage, setSortAndPage] = useState<ISortAndPage>(initSortPage);

  const [statusFilterData, setStatusFilterData] = useState<string[]>([]);
  const [statusCheckedData, setStatusCheckedData] = useState<string[]>([]);

  const [poNumberInput, setPoNumberInput] = useState<string>('');
  const [poNumberSuggestData, setPoNumberSuggestData] = useState<string[]>([]);

  const [VendorIdInput, setVendorIdInput] = useState<string>('');
  const [vendorIdSuggestedData, setVendorIdSuggestData] = useState<string[]>(
    []
  );

  const [statusInput, setStatusInput] = useState<string>('');
  const [vendorDescriptionSuggestedData, setVendorDescriptionSuggestedData] =
    useState<string[]>([]);

  const [eventIdInput, setEventIdInput] = useState<string>('');
  const [eventIdSuggestData, setEventIdSuggestData] = useState<string[]>([]);

  const [businessUnitInput, setBusinessUnitInput] = useState<string>('');
  const [businessUnitSuggestedData, setBusinessUnitSuggestedData] = useState<
    string[]
  >([]);

  const [showPoInputLoader, setShowPoInputLoader] = useState<boolean>(false);
  const [showVendorIdInputLoader, setShowVendorIdInputLoader] =
    useState<boolean>(false);
  const [showVendorDescInputLoader, setShowVendorDescIdInputLoader] =
    useState<boolean>(false);
  const [showBusinessUnitInputLoader, setShowBusinessUnitInputLoader] =
    useState<boolean>(false);
  const [showEventIdLoader, setShowEventIdInputLoader] =
    useState<boolean>(false);

  const [closePoInputAutoSug, setClosePoInputAutoSug] =
    useState<boolean>(false);
  const [closeVendorIdInputAutoSug, setCloseVendorIdAutoSug] =
    useState<boolean>(false);
  const [closeVendorDescInputAutoSug, setCloseVendorDescInputAutoSug] =
    useState<boolean>(false);
  const [closeBusinessUnitInputAutoSug, setBusinessUnitInputAutoSug] =
    useState<boolean>(false);
  const [closeEventIdAutoSug, setCloseEventIdInputAutoSug] =
    useState<boolean>(false);
  const [statusData, setStatusData] = useState<string[]>([]);
  const [filterClicked, setFilteredClicked] = useState<boolean>(false);
  const [vendorDescriptionInput, setVendorDescriptionInput] =
    useState<string>('');
  const dispatch = useDispatch();

  const fetchStatusFilterData = () => {
    getMultiSelectFilterData(allowedMultiSelectFilters.purchaseOrderStatus)
      .then((res) => {
        setStatusData(res?.data?.data);
      })
      .catch((err) => {
        console.log(err);
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Failed to fetch status filter data',
            alertDescription: '',
          })
        );
      });
  };

  //initial table and filter render
  useEffect(() => {
    fetchTotalCount();
    fetchStatusFilterData();
  }, []);

  const handleSorting = (sortdata: ISort) => {
    setSortAndPage({
      sortColumn: sortdata.sortColumn,
      sortOrder: sortdata.sortOrder,
      pageNumber: 1,
    });
  };

  const getPoManagementDetailsParam = (): IPoManagementRequest => {
    return {
      pageSize: tableConfig.pageSize,
      pageNumber: sortAndPage.pageNumber,
      startDate: format(range[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(range[0].endDate!, 'yyyy-MM-dd'),
      sortColumn: sortAndPage.sortColumn,
      sortOrder: sortAndPage.sortOrder,
      poNumber: poNumberInput.trim() ?? '',
      businessUnit: businessUnitInput.trim() ?? '',
      vendorId: VendorIdInput.trim() ?? '',
      eventId: eventIdInput.trim() ?? '',
      vendorDescription: vendorDescriptionInput.trim() ?? '',
      status:
        statusCheckedData.length === 0 ? '' : statusCheckedData.toString(),
    };
  };

  const loadTableDataAndPopulateView = () => {
    dispatch(setLoading(true));
    getPoManagementDetails(getPoManagementDetailsParam())
      .then((res) => {
        if (res?.status === 200) {
          window.history.pushState(
            {},
            document.title,
            window.location.pathname
          );
          if (res?.data?.data?.length === 0)
            dispatch(
              setShowAlert({
                showAlert: true,
                alertType: 'warning',
                alertTitle: 'No data found for the selected filters',
                alertDescription: '',
              })
            );
          setTableData(res?.data?.data);
        } else {
          dispatch(setLoading(false));
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: 'Failed to fetch purchase order table data',
              alertDescription: '',
            })
          );
        }
      })
      .catch((err) => {
        setTableData(undefined);
        dispatch(setLoading(false));
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Failed to fetch purchase order table data',
            alertDescription: '',
          })
        );
        console.log('po-management api failed with status' + err);
      })
      .finally(() => {
        dispatch(setLoading(false));
        setFilteredClicked(false);
      });
  };

  const fetchTotalCount = () => {
    dispatch(setLoading(true));
    getPoManagementDataCount(getPoManagementDetailsParam())
      .then((res) => {
        setTotalCount(res?.data?.totalRecords);
      })
      .catch((err) => {
        console.log('count api failed with status' + err);
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: 'error',
            alertTitle: 'Failed to fetch total pages',
            alertDescription: '',
          })
        );
      });
  };

  const fetchSuggestData = (
    filterData: string,
    rangeVar: Range[],
    selectField: string
  ) => {
    if (
      filterData.length >= 4 ||
      (selectField === PoManagementColumn.businessUnit &&
        filterData.length >= 2)
    ) {
      const params: IPoManagementFilterRequest = {
        selectField: selectField,
        startDate: format(rangeVar[0].startDate!, 'yyyy-MM-dd'),
        endDate: format(rangeVar[0].endDate!, 'yyyy-MM-dd'),
      };
      switch (selectField) {
        case PoManagementColumn.PONumber:
          setShowPoInputLoader(true);
          params.poNumber = [filterData];
          break;
        case PoManagementColumn.vendorId:
          params.vendorId = [filterData];
          setShowVendorIdInputLoader(true);
          break;
        case PoManagementColumn.vendorDesc:
          setShowVendorDescIdInputLoader(true);
          params.vendorDescription = [filterData];
          break;
        case PoManagementColumn.businessUnit:
          setShowBusinessUnitInputLoader(true);
          params.businessUnit = [filterData];
          break;
        case PoManagementColumn.eventId:
          setShowEventIdInputLoader(true);
          params.eventId = [filterData];
          break;
      }
      getPoManagementAutoSuggestData(params)
        .then((res) => {
          if (res.status === 200) {
            switch (selectField) {
              case PoManagementColumn.PONumber:
                setPoNumberSuggestData(res?.data?.data);
                break;
              case PoManagementColumn.vendorId:
                setVendorIdSuggestData(res?.data?.data);
                break;
              case PoManagementColumn.vendorDesc:
                setVendorDescriptionSuggestedData(res?.data?.data);
                break;
              case PoManagementColumn.businessUnit:
                setBusinessUnitSuggestedData(res?.data?.data);
                break;
              case PoManagementColumn.eventId:
                setEventIdSuggestData(res?.data?.data);
                break;
            }
          }
        })
        .finally(() => {
          setShowPoInputLoader(false);
          setShowBusinessUnitInputLoader(false);
          setShowEventIdInputLoader(false);
          setShowVendorDescIdInputLoader(false);
          setShowVendorIdInputLoader(false);
        });
    }
  };

  const fetchSuggestData_debounced = useCallback(
    debounce(fetchSuggestData, 500),
    []
  );

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      poNumberInput,
      range,
      PoManagementColumn.PONumber
    );
  }, [poNumberInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      VendorIdInput,
      range,
      PoManagementColumn.vendorId
    );
  }, [VendorIdInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      vendorDescriptionInput,
      range,
      PoManagementColumn.vendorDesc
    );
  }, [vendorDescriptionInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(
      businessUnitInput,
      range,
      PoManagementColumn.businessUnit
    );
  }, [businessUnitInput]);

  useDidComponentUpdate(() => {
    fetchSuggestData_debounced(eventIdInput, range, PoManagementColumn.eventId);
  }, [eventIdInput]);

  useDidComponentUpdate(() => {
    dispatch(setLoading(false));
  }, [tableData]);

  useDidComponentUpdate(() => {
    setPoNumberInput('');
    setVendorIdInput('');
    setStatusInput('');
    setVendorDescriptionInput('');
    setEventIdInput('');
    setBusinessUnitInput('');
    setStatusCheckedData([]);
  }, [range]);

  useDidComponentUpdate(() => {
    loadTableDataAndPopulateView();
  }, [sortAndPage]);

  useDidComponentUpdate(() => {
    setSortAndPage(initSortPage);
    fetchTotalCount();
  }, [statusCheckedData]);

  const handleInputChange = (e: BaseSyntheticEvent) => {
    switch (e.target.name) {
      case labels.poNumber:
        setPoNumberInput(e.target.value);
        break;
      case labels.BusinessUnit:
        setBusinessUnitInput(e.target.value);
        break;
      case labels.VendorId:
        setVendorIdInput(e.target.value);
        break;
      case labels.VendorDes:
        setVendorDescriptionInput(e.target.value);
        break;
      case labels.Status:
        setStatusInput(e.target.value);
        break;
      case labels.EventId:
        setEventIdInput(e.target.value);
        break;
    }
  };
  useEffect(() => {
    if (filterClicked) {
      loadTableDataAndPopulateView();
      fetchTotalCount();
    }
  }, [filterClicked]);

  const handlePoNumberSuggestionClick = (value: string) => {
    setClosePoInputAutoSug(true);
    setPoNumberInput(value);
    setFilteredClicked(true);
  };
  const handleBusinessUnitSuggestionClick = (value: string) => {
    setBusinessUnitInputAutoSug(true);
    setBusinessUnitInput(value);
    setFilteredClicked(true);
  };
  const handleVendorDescriptionSuggestionClick = (value: string) => {
    setCloseVendorDescInputAutoSug(true);
    setVendorDescriptionInput(value);
    setFilteredClicked(true);
  };
  const handleVendorIdSuggestionClick = (value: string) => {
    setCloseVendorIdAutoSug(true);
    setVendorIdInput(value);
    setFilteredClicked(true);
  };

  const handleEventIdSuggestionClick = (value: string) => {
    setCloseEventIdInputAutoSug(true);
    setEventIdInput(value);
    setFilteredClicked(true);
  };

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.code === 'Enter' || event.code === 'NumpadEnter') {
        event.preventDefault();
        setSortAndPage(initSortPage);
        fetchTotalCount();
      }
    };
    document.addEventListener('keydown', listener);
    return () => {
      document.removeEventListener('keydown', listener);
    };
  }, [
    poNumberInput,
    businessUnitInput,
    vendorDescriptionInput,
    eventIdInput,
    VendorIdInput,
  ]);

  const onlyStatusClickHandler = (query: string) => {
    if (statusFilterData && query) {
      setStatusCheckedData(
        statusFilterData.filter(
          (value) =>
            value.toString().toLowerCase() === query.toLocaleLowerCase()
        )
      );
    }
  };

  const navigate = useNavigate();

  const routeToHome = () => {
    navigate(`/${routes.home}`);
  };

  // classnames -----------------
  const containerClass = classNames({
    'container-shrink': props.isExpanded,
    container: !props.isExpanded,
  });

  const paginationClass = classNames('paginated', {
    'paginated-shrink': props.isExpanded,
  });
  return (
    <section id='po-management'>
      <section className={containerClass}>
        <section
          className={'po-management-header'}
          data-testid='po-management-header-testId'>
          <section className='header-left-container'>
            <div className='text-header'>{labels.poManagement}</div>
            <div
              className='text-menu'
              data-testid='po-route-testId'>
              <div
                data-testid='route-to-home'
                className='navLink'
                onClick={routeToHome}>
                {labels.homeNav}
              </div>
              <div>{labels.poManagement}</div>
            </div>
          </section>
          <div
            className='dropdown-group'
            data-testid='po-datepicker-testId'>
            <p>Date Range(UTC)</p>
            <CustomDateRangePicker
              range={range}
              setRange={setRange}
              footerLabel='By default date range of MABD will be T-15 to T+45'
            />
          </div>
        </section>
        <section className='po-filters'>
          <div
            className='po-filter-wrapper'
            data-testid='poNumber-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.poNumber}
            </p>

            <AutoSuggest
              inputSuggestionData={poNumberSuggestData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handlePoNumberSuggestionClick(value)
              }
              inputData={poNumberInput}
              handleInputChange={handleInputChange}
              name={labels.poNumber}
              isClosed={closePoInputAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showPoInputLoader}
              setClose={setClosePoInputAutoSug}
            />
          </div>
          <div
            className='po-filter-wrapper'
            data-testid='vendorId-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.VendorId}
            </p>
            <AutoSuggest
              inputSuggestionData={vendorIdSuggestedData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleVendorIdSuggestionClick(value)
              }
              inputData={VendorIdInput}
              handleInputChange={handleInputChange}
              name={labels.VendorId}
              isClosed={closeVendorIdInputAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showVendorIdInputLoader}
              setClose={setCloseVendorIdAutoSug}
            />
          </div>
          <div
            className='po-filter-wrapper'
            data-testid='vendorDesc-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.VendorDes}
            </p>
            <AutoSuggest
              inputSuggestionData={vendorDescriptionSuggestedData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleVendorDescriptionSuggestionClick(value)
              }
              inputData={vendorDescriptionInput}
              handleInputChange={handleInputChange}
              name={labels.VendorDes}
              isClosed={closeVendorDescInputAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showVendorDescInputLoader}
              setClose={setCloseVendorDescInputAutoSug}
            />
          </div>
          <div
            className='po-filter-wrapper'
            data-testid='businessUnit-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.BusinessUnit}
            </p>
            <AutoSuggest
              inputSuggestionData={businessUnitSuggestedData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleBusinessUnitSuggestionClick(value)
              }
              inputData={businessUnitInput}
              handleInputChange={handleInputChange}
              name={labels.BusinessUnit}
              isClosed={closeBusinessUnitInputAutoSug}
              inputLengthToShowSuggestion={2}
              isLoading={showBusinessUnitInputLoader}
              setClose={setBusinessUnitInputAutoSug}
            />
          </div>
          <div
            className='po-filter-wrapper'
            data-testid='status-multiSelect-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.Status}
            </p>
            <MultiSelectFilter
              data={statusData}
              setCheckedData={setStatusCheckedData}
              checkedData={statusCheckedData}
              filterData={statusFilterData}
              setFilterData={setStatusFilterData}
              inputValue={statusInput}
              setInputValue={setStatusInput}
              onlyButtonHandler={onlyStatusClickHandler}
            />
          </div>
          <div
            className='po-filter-wrapper'
            data-testid='eventId-autoSuggest-testId'>
            <p
              className={
                props.isExpanded ? 'query-text shrink-font' : 'query-text'
              }>
              {labels.EventId}
            </p>
            <AutoSuggest
              inputSuggestionData={eventIdSuggestData}
              onSuggestionClickHandler={(e: any, value: any) =>
                handleEventIdSuggestionClick(value)
              }
              inputData={eventIdInput}
              handleInputChange={handleInputChange}
              name={labels.EventId}
              isClosed={closeEventIdAutoSug}
              inputLengthToShowSuggestion={4}
              isLoading={showEventIdLoader}
              setClose={setCloseEventIdInputAutoSug}
            />
          </div>
        </section>
        <section className='po-management-table-pagination-wrapper'>
          <PoManagementTable
            data={tableData || []}
            handleClick={(data) => handleSorting(data)}
          />
          <section className={paginationClass}>
            <Pagination
              count={Math.ceil(totalCount / tableConfig.pageSize)}
              variant='text'
              shape='rounded'
              siblingCount={1}
              color={'standard'}
              showFirstButton
              showLastButton
              size='small'
              onChange={(e, value) =>
                setSortAndPage({
                  pageNumber: value,
                  sortColumn: sortAndPage.sortColumn,
                  sortOrder: sortAndPage.sortOrder,
                })
              }
              page={sortAndPage.pageNumber}
            />
          </section>
        </section>
        <section />
      </section>
    </section>
  );
};

export default POManagement;
