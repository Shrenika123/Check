import {
  act,
  cleanup, fireEvent, render, screen, waitFor
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import router, { BrowserRouter, MemoryRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { PoManagementColumn } from '../../../../common/constants';
import {
  checkElementNotPresentInDomByTestId,
  checkElementPresentInDomByTestId,
  clickElementByTestId,
  textPresentInDOM
} from '../../../../common/helper/testHelper';
import {
  poManagement,
  statusResponse
} from '../../../../common/mocks/promotionAndProcurement';
import POManagement from '../POManagement';
import { routes } from '../../../../common/navigation-utils';

afterEach(() => {
  cleanup();
  jest.resetAllMocks();
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});
const mockedUsedNavigate = jest.fn();
const mockNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));

const mockStore = configureStore();

const mockPoManagementResponse = {
  status: 200,
  data: {
    data: poManagement,
  },
};

const suggestionRes = {
  data: { data: ['abcde', 'bcdef', 'cdefg', 'defgh', 'efghi'] },
  status: 200,
};

const countRes = {
  data: { totalRecords: 100 },
};
const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "NA",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};
const powerUserStore = mockStore(powerUserState);

const RenderPoManagement = ({ isExpanded }: { isExpanded?: boolean }) => {
  return (
    <Provider store={powerUserStore}>
      <POManagement isExpanded={false ?? isExpanded} />
    </Provider>
  );
};

describe('PoManagement Page', () => {
  beforeEach(() => {
    jest.spyOn(router, 'useNavigate').mockImplementation(() => mockNavigate);
    jest.clearAllMocks();
  });

  test('should render POManagement component on success', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const poManagementData = jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });

    await waitFor(() => {
      expect(poManagementData).toBeCalled();
    });
    await checkElementPresentInDomByTestId('po-management-header-testId');
    await checkElementPresentInDomByTestId('po-datepicker-testId');
    await checkElementPresentInDomByTestId('vendorId-autoSuggest-testId');
    await checkElementPresentInDomByTestId('vendorDesc-autoSuggest-testId');
    await checkElementPresentInDomByTestId('businessUnit-autoSuggest-testId');
    await checkElementPresentInDomByTestId('status-multiSelect-testId');
    await checkElementPresentInDomByTestId('eventId-autoSuggest-testId');
    await checkElementPresentInDomByTestId('poManagementTable-testId');
    await checkElementNotPresentInDomByTestId('po-managementConfirmBox-testId');

    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => { });
  });

  test('When Data is empty', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue({ res: { status: 200, data: { data: [] } } });
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });

    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
      expect(screen.queryAllByTestId('po-tableData')[0]).toBeUndefined();
    });
  });

  test('should render PO Management component with api fail and when Dashboard Navigate is clicked', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockRejectedValue('network error');
    jest
      .spyOn(util, 'getPoManagementDataCount')
      .mockRejectedValue({ status: 500 });
    render(
      <MemoryRouter
        initialEntries={[
          {
            pathname: '/po-management',
          },
        ]}>
        <RenderPoManagement />
      </MemoryRouter>
    );

    await act(async () => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
      await clickElementByTestId('route-to-home');
      expect(mockNavigate).toHaveBeenCalledTimes(1);
      expect(mockNavigate).toHaveBeenCalledWith('/home');
    });
  });

  test('when sort and toggle is performed', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    await act(async () => {
      await clickElementByTestId('po-table-mabd');
      await clickElementByTestId('po-table-mabd');
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('on sort of table', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    await act(async () => {
      await clickElementByTestId(`po-table-${PoManagementColumn.PONumber}`);
      await clickElementByTestId(`po-table-${PoManagementColumn.Idc}`);
      await clickElementByTestId(`po-table-${PoManagementColumn.eventId}`);
      await clickElementByTestId(`po-table-${PoManagementColumn.vendorDesc}`);
      await clickElementByTestId(`po-table-${PoManagementColumn.vendorId}`);
      await clickElementByTestId(`po-table-${PoManagementColumn.status}`);
      await clickElementByTestId(`po-table-${PoManagementColumn.Maap}`);
      await clickElementByTestId(`po-table-${PoManagementColumn.Mabd}`);
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle  poNumber auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[0], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle vendorId auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[1], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle vendorDesc auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[2], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle BusinessUnit auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[3], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should handle eventId auto suggest input box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    const loadPoManagementDetails = jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    const getPoManagementAutoSuggestMockData = jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    fireEvent.change(screen.getAllByTestId('input-auto-suggest')[4], {
      target: { value: 'abcd123' },
    });
    await waitFor(() => {
      expect(screen.getAllByTestId('filler')[0]).toBeInTheDocument();
    });
    await waitFor(() => {
      expect(getPoManagementAutoSuggestMockData).toBeCalled();
    });
    await waitFor(() => {
      screen.getAllByTestId('suggest-option');
    });
    userEvent.click(screen.getAllByTestId('suggest-option')[0]);
    await waitFor(() => {
      expect(loadPoManagementDetails).toBeCalled();
    });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('should paginate poManagement component', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    userEvent.click(screen.getByTestId('NavigateNextIcon'));
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });

  test('Navigate on Click of Po number', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    await waitFor(() => {
      expect(screen.getAllByTestId('poNumber-route')[0]).toBeInTheDocument();
    });
    userEvent.click(screen.getAllByTestId('poNumber-route')[0]);
    expect(mockNavigate).toHaveBeenCalledWith('/po-management/details', {
      state: { poNumber: 'abc', mabd: '2-12-2024' },
    });
  });

  test('should handle status check box changes', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });
    await waitFor(() => {
      expect(
        screen.getByTestId('multiselect-header-wrapper')
      ).toBeInTheDocument();
    });
    //open mode filter
    userEvent.click(screen.getByTestId('multiselect-header-wrapper'));
    //checked
    userEvent.click(screen.getAllByTestId('multiselect-checkbox')[0]);
    //unchecked
    userEvent.click(screen.getAllByTestId('multiselect-checkbox')[1]);
    const ele = screen.getAllByTestId('multiselect-only');
    userEvent.click(ele[0]);
  });

  test('should change the range of mabd', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });

    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    await clickElementByTestId('date-range-picker');
    userEvent.click(screen.getByText('Yesterday'));
    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
  });
  test('should handle enter key input', async () => {
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getMultiSelectFilterData')
      .mockResolvedValue(statusResponse);
    jest
      .spyOn(util, 'getPoManagementDetails')
      .mockResolvedValue(mockPoManagementResponse);
    jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
    jest
      .spyOn(util, 'getPoManagementAutoSuggestData')
      .mockResolvedValue(suggestionRes);
    render(<RenderPoManagement />, { wrapper: BrowserRouter });

    await waitFor(async () => {
      await textPresentInDOM('abc');
    });
    userEvent.keyboard('{Enter}');
    userEvent.keyboard('{NumpadEnter}');
  });
});
