import { nanoid } from '@reduxjs/toolkit';
import React, { useEffect, useState } from 'react';
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io';
import { useNavigate } from 'react-router-dom';
import { PoManagementColumn, routes } from '../../../../common/constants';
import {
  IPoManagementTableResponse,
  IRoutePermission,
  ISort,
  IUserState
} from '../../../../common/interfaces';
import { getFormattedDate } from '../../../../common/utils';
import './po-management-table.style.css';
import { useSelector } from 'react-redux';

interface IPoManagementProps {
  data: IPoManagementTableResponse[];
  handleClick: (data: ISort) => void;
}
interface ITableData {
  label: string;
  value: string;
}
const ColumnHeaders: ITableData[] = [
  { label: PoManagementColumn.PONumber, value: 'PO Number' },
  { label: PoManagementColumn.Maap, value: 'MAAP' },
  { label: PoManagementColumn.Mabd, value: 'MABD' },
  { label: PoManagementColumn.Idc, value: 'IDC Date' },
  { label: PoManagementColumn.vendorId, value: 'Vendor ID' },
  { label: PoManagementColumn.vendorDesc, value: 'Vendor Description' },
  { label: PoManagementColumn.businessUnit, value: 'Business Unit' },
  { label: PoManagementColumn.status, value: 'Status' },
  { label: PoManagementColumn.eventId, value: 'Event ID' },
];

const PoManagementTable: React.FC<IPoManagementProps> = ({
  data,
  handleClick,
}) => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const poLinePerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'PO_LINE_MANAGEMENT')?.permission;

  const [sort, setSort] = useState<ISort>({
    sortColumn: PoManagementColumn.Mabd,
    sortOrder: '',
  });

  const navigate = useNavigate();

  const getSortIcon = (columnName: string) => {
    if (sort.sortColumn === columnName) {
      if (sort.sortOrder === 'Desc') {
        return <IoMdArrowDropdown data-testid='dropDown-testId' />;
      } else {
        return <IoMdArrowDropup data-testid='dropUp-testId' />;
      }
    } else return <></>;
  };

  const handleOnSort = (sortColumn: string) => {
    if (sort.sortColumn.length > 0 && sort.sortColumn === sortColumn) {
      setSort({
        sortColumn: sort.sortColumn,
        sortOrder: sort.sortOrder === '' ? 'Desc' : '',
      });
    } else {
      setSort({ sortColumn: sortColumn, sortOrder: '' });
    }
  };

  useEffect(() => {
    handleClick({ ...sort });
  }, [sort]);

  const handleOnPoClick = (poNumber: string, mabd: string) => {
    navigate(`/${routes.lineDetails}`, { state: { poNumber, mabd } });
  };

  return (
    <>
      <section className={'po-management-table-wrapper'}>
        <table
          className='po-management-table'
          data-testid='poManagementTable-testId'>
          <thead>
            <tr>
              {ColumnHeaders.map((item) => {
                return (
                  <th
                    key={item.label}
                    onClick={() => handleOnSort(item.label)}
                    data-testid={`po-table-${item.label}`}>
                    <div>
                      {item.value}
                      {getSortIcon(item.label)}
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {data.length > 0 &&
              data.map((value, index) => {
                return (
                  <tr
                    key={value.poNumber + index}
                    data-testid='po-tableData'>
                    <td>
                      <div
                        className= { poLinePerm && poLinePerm !== 'NA' ?'hyperlink' : 'non-hyperlink'}
                        onClick={() => handleOnPoClick(value.poNumber, value.mabd)}
                        data-testid='poNumber-route'>
                        {value.poNumber}
                      </div>
                    </td>
                    <td>
                      {value.maap === 'NA'
                        ? 'NA'
                        : getFormattedDate(value.maap)}
                    </td>
                    <td>
                      {value.mabd === 'NA'
                        ? 'NA'
                        : getFormattedDate(value.mabd)}
                    </td>
                    <td>
                      {value.idcdate === 'NA'
                        ? 'NA'
                        : getFormattedDate(value.idcdate)}
                    </td>
                    <td>{value.vendorId}</td>
                    <td>{value.vendorDescription}</td>
                    <td>{value.businessUnit}</td>
                    <td className='status-row'>{value.status}</td>
                    <td>{value.eventId}</td>
                  </tr>
                );
              })}
            {[...Array(data ? (data.length < 8 ? 8 - data.length : 0) : 8)]
              .map(() => {
                return { key: nanoid() };
              })
              .map((_, index) => {
                return (
                  <tr
                    data-testid='filler'
                    key={_.key}>
                    <td colSpan={16}>
                      <div></div>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </section>
    </>
  );
};
export default PoManagementTable;
