import { Tab, Tabs } from '@mui/material';
import classNames from 'classnames';
import { addDays } from 'date-fns';
import React, { useState } from 'react';
import { Range } from 'react-date-range';
import { useSelector } from 'react-redux';
import { labels, supplierCRMDateStaticRanges } from '../../../common/constants';
import { getSettingModifiedData, isStringValid } from '../../../common/utils';
import CustomDateRangePicker from '../../../components/date-range-picker/CustomDateRangePicker';
import { useDidComponentUpdate } from '../../../hooks/useDidComponentUpdate';
import CarrierCRM from './components/carrier-crm/carrier-crm-component';
import InboundOptimization from './components/inbound-optimization/inbound-optimization-component';
import SupplierCrm from './components/supplier-crm/supplier-crm-component';
import './externalization.style.css';
import { IRoutePermission, IUserState } from '../../../common/interfaces';

interface IExternalizationProps {
  isExpanded: boolean;
}

const Externalization: React.FC<IExternalizationProps> = ({ isExpanded }) => {
  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const externalId: string = useSelector((state: IUserState) => state.user.userExternalId);
  const inboundOptimizationPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'INBOUND_OPTIMIZATION')?.permission;
  const carrierCrmPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'CARRIER_CRM' )?.permission;
  const suppliercrmPerm =  userGroupRoutes.find( val=> val.screen.trim().toUpperCase() === 'SUPPLIER_CRM' )?.permission;
  


  const [activeTab, setActiveTab] = useState<number>(0);
  // classnames -----------------
  const containerClass = classNames({
    'container-shrink': isExpanded,
    container: !isExpanded,
  });

  const settings = useSelector((state: any) => state.systemSetting);
  const [range, setRange] = useState<Range[]>(() =>
    getSettingModifiedData(settings, 0, 6)
  );

  useDidComponentUpdate(() => {
    if (activeTab === 0 && isStringValid(inboundOptimizationPerm) && inboundOptimizationPerm !== 'NA' ) {      
      setRange(getSettingModifiedData(settings, 0, 6));
    } else {
      setRange(getSettingModifiedData(settings, 0, 29));
    }
  }, [activeTab]);

  return (
    <section id='externalization'>
      <section className={containerClass}>
        <section
          className={'externalization-header'}
          data-testid='externalization-header-testId'>
          <section className='header-left-container'>
            <div className='text-header'>{labels.externalization}</div>
          </section>
          <div
            className='dropdown-group'
            data-testid='supplierCrm-datepicker-testId'>
            <p>Date Range(UTC)</p>
            <CustomDateRangePicker
              range={range}
              setRange={setRange}
              footerLabel={`By default capacity date range will be ${activeTab === 0 && isStringValid(inboundOptimizationPerm) && inboundOptimizationPerm !== 'NA' ? 'T to T+7' : 'T to T+30'}`}
              minDate={getSettingModifiedData(settings, 0, 0)[0].startDate}
              maxDate={addDays(getSettingModifiedData(settings, 0, 0)[0].startDate!, 180)}
              staticRanges={supplierCRMDateStaticRanges}
              isDateInputEditable={false}
            />
          </div>
        </section>
        <section className='externalizationTabs'>
          <Tabs
            variant='scrollable'
            scrollButtons='auto'
            onChange={(e, val) => {setActiveTab(val);}}
            value={activeTab}>
         { isStringValid(inboundOptimizationPerm) && inboundOptimizationPerm !== 'NA' && <Tab
              data-testid='InboundOptimizationTab'
              label={labels.inboundOptimization}></Tab>}
         { isStringValid(suppliercrmPerm) && suppliercrmPerm !=='NA' && <Tab
              data-testid='supplierCrmTab'
              label={labels.supplierCrm}></Tab>}
        { isStringValid(carrierCrmPerm) && carrierCrmPerm !== 'NA' &&  <Tab
              data-testid='carrierCrmTab'
              label={labels.carrierCrm}></Tab>}
          </Tabs>
        </section>
        { (isStringValid(inboundOptimizationPerm) && inboundOptimizationPerm !== 'NA')  && activeTab === 0 && <InboundOptimization dateRange={range} />}

        {  ((( isStringValid(suppliercrmPerm) && suppliercrmPerm !=='NA' && !isStringValid(inboundOptimizationPerm) || inboundOptimizationPerm ==='NA') && activeTab === 0)
            || (isStringValid(suppliercrmPerm) && suppliercrmPerm !=='NA' && (isStringValid(inboundOptimizationPerm) && inboundOptimizationPerm !== 'NA') && activeTab === 1)) && (
          <SupplierCrm
            isExpanded
            dateRange={range}
            accessLevel={suppliercrmPerm!} externalId={externalId} />
        )}
        {((carrierCrmPerm !== 'NA' &&  activeTab === 2) || 
        ((!isStringValid(inboundOptimizationPerm) || inboundOptimizationPerm ==='NA') && (!isStringValid(suppliercrmPerm) || suppliercrmPerm ==='NA') && activeTab === 0) || 
        ((!isStringValid(inboundOptimizationPerm) || inboundOptimizationPerm ==='NA') && (isStringValid(suppliercrmPerm) && suppliercrmPerm !=='NA') && activeTab === 1) || 
        ((isStringValid(inboundOptimizationPerm) && inboundOptimizationPerm !=='NA') &&  (!isStringValid(suppliercrmPerm) || suppliercrmPerm ==='NA') && activeTab === 1)) 
        && <CarrierCRM dateRange={range} accessLevel={carrierCrmPerm!} externalId={externalId} />}
      </section>
    </section>
  );
};
export default Externalization;
