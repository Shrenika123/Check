import '@testing-library/jest-dom';
import { act, cleanup, render, waitFor, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import {
  checkElementNotPresentInDomByTestId,
  checkElementPresentInDomByTestId,
  checkIfElementIfDisabledFromGroup,
  checkIfElementIsDisabled,
  checkIfElementNotDisabled,
  clickedSpecificElementInGroup,
  clickElementByTestId,
  elementContainsSpecifiedTextFromGroup,
  setInputValue,
  setInputValueFromGroup,
  textNotPresentInDOM,
} from '../../../../common/helper/testHelper';
import {
  SupplierCrmAll,
  SupplierCrmDetails,
} from '../../../../common/mocks/promotionAndProcurement';
import Externalization from '../externalization';

afterEach(() => {
  cleanup();
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});

beforeAll(() => {
  Object.defineProperty(window, 'matchMedia', {
    value: () => ({
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
    }),
  });
});

const setLocalStorage = (id: string, data: any) => {
  window.localStorage.setItem(id, data);
};
const externalUser = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_AND_INVENTORY_PLAN_DETAILS',
        permission: 'READ',
        route: 'event-inventory-plan/details',
      },
      {
        screen: 'PO_ITEM_MANAGEMENT',
        permission: 'READ',
        route: 'item-management',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',

        permission: 'WRITE',

        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const powerUser = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'NA',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_AND_INVENTORY_PLAN_DETAILS',
        permission: 'READ',
        route: 'event-inventory-plan/details',
      },
      {
        screen: 'PO_ITEM_MANAGEMENT',
        permission: 'READ',
        route: 'item-management',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',

        permission: 'WRITE',

        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const sysSettingsData = [
  {
    name: 'activity_visited_days_limit',
    value: '7',
  },
  {
    name: 'activity_favourite_days_limit',
    value: '30',
  },
  {
    name: 'enable_fixed_date',
    value: 'true',
  },
  {
    name: 'fixed_date',
    value: '2023-02-21',
  },
];

const supplierRead = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'NA',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: sysSettingsData,
  navbar: {
    isExpanded: false,
  },
};

const powerUserState = (type: string) => {
  switch (type) {
    case 'power':
      return powerUser;
    case 'read':
      return supplierRead;
    default:
      return externalUser;
  }
};

const setFilterDetails = async () => {
  await act(async () => {
    await clickElementByTestId('singleSelectButton-supplier-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-supplier-testid',
      1
    );
  });
  await act(async () => {
    await clickElementByTestId('singleSelectButton-shipPoint-testid');
  });
  await clickedSpecificElementInGroup(
    'singleSelectRadioButton-shipPoint-testid',
    1
  );
  await act(async () => {
    await clickElementByTestId('singleSelectButton-name-testid');
  });
  await clickedSpecificElementInGroup('singleSelectRadioButton-name-testid', 1);
  await act(async () => {
    await clickElementByTestId('singleSelectButton-type-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-type-testid',
      1
    );
  });
};

describe('Externalization for Supplier Crm for read Access Power User', () => {
  beforeAll(() => {
    const mockId = 'group_id';
    const mockJson = '034g0dwd13cd23l';
    setLocalStorage(mockId, mockJson);
  });
  const mockStore = configureStore();
  test('Initial render of Supplier crm fro power user', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockRejectedValue({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValue({ data: ['1505VDC', '1969VDC'] })
      .mockResolvedValue({ data: ['1505VDC', '1969VDC'] });

    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });
    await checkElementPresentInDomByTestId('supplier-crm');
    await checkIfElementNotDisabled('singleSelectButton-supplier-testid');
    await checkIfElementIsDisabled('singleSelectButton-shipPoint-testid');
    await checkIfElementIsDisabled('singleSelectButton-name-testid');
    await checkIfElementIsDisabled('singleSelectButton-type-testid');
    await textNotPresentInDOM('Save');
  });

  test('On Click Action of filters', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');

    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockRejectedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } });

    jest
      .spyOn(util, 'getSupplierCrmDetails')
      .mockResolvedValueOnce({ data: { data: SupplierCrmDetails } });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });

    await checkElementPresentInDomByTestId('supplier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-supplier-testid');
    });

    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-supplier-testid',
        1
      );
      await checkIfElementNotDisabled('singleSelectButton-shipPoint-testid');
      await checkIfElementIsDisabled('singleSelectButton-name-testid');
      await checkIfElementIsDisabled('singleSelectButton-type-testid');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-shipPoint-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-shipPoint-testid',
      1
    );
    await checkIfElementNotDisabled('singleSelectButton-shipPoint-testid');
    await checkIfElementNotDisabled('singleSelectButton-name-testid');
    await checkIfElementIsDisabled('singleSelectButton-type-testid');
    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-name-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-name-testid',
      1
    );
    await checkIfElementNotDisabled('singleSelectButton-type-testid');
    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-type-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-type-testid',
        1
      );
    });
  });

  test('table onSave and Input Functionality for Power User', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockRejectedValue({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } });

    jest
      .spyOn(util, 'getSupplierCrmDetails')
      .mockResolvedValueOnce({ data: { data: SupplierCrmDetails } });
    const postSavedData = jest
      .spyOn(util, 'supplierCRMBulkUpdatePost')
      .mockResolvedValueOnce({ data: { data: 'Updated started!!' } })
      .mockResolvedValueOnce({ data: { data: 'Updated started!!' } });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });
    await checkElementPresentInDomByTestId('supplier-crm');
    await setFilterDetails();
    await waitFor(async () => {
      await checkIfElementIfDisabledFromGroup('supplierCrmSave-testid', 0);
      await setInputValueFromGroup('supplierCrmTable-input-testid', 0, '10');
      await checkIfElementIfDisabledFromGroup('supplierCrmSave-testid', 0);
    });
    await act(async () => {
      await setInputValueFromGroup('supplierCrmTable-input-testid', 0, '1');
      await clickedSpecificElementInGroup('supplierCrmSave-testid', 0);
      await checkIfElementIfDisabledFromGroup('supplierCrmSave-testid', 0);
      expect(postSavedData).not.toBeCalled();
    });
    await act(async () => {
      await setInputValueFromGroup('supplierCrmTable-input-testid', 0, '100');
      await setInputValueFromGroup('supplierCrmTable-input-testid', 1, '100');
      await clickedSpecificElementInGroup('supplierCrmSave-testid', 0);
      expect(postSavedData).toBeCalled();
    });
    await elementContainsSpecifiedTextFromGroup(
      'supplierCrmTable-uncommitted-testid',
      0,
      '8'
    );
    await elementContainsSpecifiedTextFromGroup(
      'supplierCrmTable-committed-testid',
      0,
      '2'
    );
    await elementContainsSpecifiedTextFromGroup(
      'supplierCrmTable-uncommitted-testid',
      1,
      '100'
    );
    await elementContainsSpecifiedTextFromGroup(
      'supplierCrmTable-committed-testid',
      1,
      '0'
    );
  });

  test('On search power user', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockRejectedValue({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: ['1505VDC', '1969VDC'] })
      .mockResolvedValueOnce({ data: ['1505VDC', '1969VDC'] });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });
    await checkElementPresentInDomByTestId('supplier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-supplier-testid');
    });
    await setInputValue('single-select-input-supplier', '1234');
  });

  test('when API fails for Power User for all vendor', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockRejectedValueOnce({ status: 500 });
    jest.spyOn(util, 'getSupplierCrmFIlter').mockRejectedValue({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });

    await checkElementPresentInDomByTestId('supplier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-supplier-testid');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId(
        'singleSelect-noData-supplier-testid'
      );
    });
  });

  test('when API fails for Power User for filter all details', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockRejectedValueOnce({ status: 500 })
      .mockRejectedValueOnce({ status: 500 });
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });

    await checkElementPresentInDomByTestId('supplier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-supplier-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-supplier-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-shipPoint-testid');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId(
        'singleSelect-noData-shipPoint-testid'
      );
    });
  });

  test('when API fails for Power User for  all table details', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockRejectedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } });
    jest
      .spyOn(util, 'getSupplierCrmDetails')
      .mockRejectedValueOnce({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });
    await checkElementPresentInDomByTestId('supplier-crm');
    await checkElementPresentInDomByTestId('upload-button-supplier-crm');
    await checkElementPresentInDomByTestId('download-button-supplier-crm');
    await setFilterDetails();
    await checkElementNotPresentInDomByTestId('supplierCrmSave-testid');
  });

  test('when post api on updating table fails', async () => {
    const powerUserStore = mockStore(powerUserState('power'));
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } });

    jest
      .spyOn(util, 'getSupplierCrmDetails')
      .mockResolvedValueOnce({ data: { data: SupplierCrmDetails } });
    const postSavedData = jest
      .spyOn(util, 'supplierCRMBulkUpdatePost')
      .mockRejectedValueOnce({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });

    await checkElementPresentInDomByTestId('supplier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-supplier-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-supplier-testid',
        1
      );
    });
    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-shipPoint-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-shipPoint-testid',
      1
    );

    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-name-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-name-testid',
      1
    );
    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-type-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-type-testid',
        1
      );
    });
    await act(async () => {
      await setInputValueFromGroup('supplierCrmTable-input-testid', 0, '4');
      await clickedSpecificElementInGroup('supplierCrmSave-testid', 0);
      expect(postSavedData).toBeCalled();
    });
  });
});

describe('Externalization for Supplier Crm for read Access Supply Chain Ops', () => {
  const mockStore = configureStore();
  beforeAll(() => {
    const mockId = 'group_id';
    const mockJson = '039kk8xu4jbpycu';
    setLocalStorage(mockId, mockJson);
  });
  test('Suite for readAccess', async () => {
    const powerUserStore = mockStore(powerUserState('read'));
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } });
    jest
      .spyOn(util, 'getSupplierCrmDetails')
      .mockResolvedValueOnce({ data: { data: SupplierCrmDetails } });

    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );

    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });
    await checkElementNotPresentInDomByTestId('upload-button-supplier-crm');
    await checkElementNotPresentInDomByTestId('download-button-supplier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-supplier-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-supplier-testid',
        1
      );
    });
    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-shipPoint-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-shipPoint-testid',
      1
    );
    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-name-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-name-testid',
      1
    );
    await waitFor(async () => {
      await clickElementByTestId('singleSelectButton-type-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-type-testid',
        1
      );
    });
    await waitFor(async () => {
      await checkElementNotPresentInDomByTestId('supplierCrmSave-testid');
      await checkElementNotPresentInDomByTestId(
        'supplierCrmTable-input-testid'
      );
    });
  });
});

describe('Externalization for Supplier Crm for Supplier', () => {
  const mockStore = configureStore();
  beforeAll(() => {
    const mockId = 'group_id';
    const mockJson = '03j2qqm34kwh5cb';
    setLocalStorage(mockId, mockJson);
  });
  test('Suite for readAccess', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getSupplierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } })
      .mockResolvedValueOnce({ data: { data: SupplierCrmAll } });

    jest
      .spyOn(util, 'getSupplierCrmDetails')
      .mockResolvedValueOnce({ data: { data: SupplierCrmDetails } });

    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );

    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('supplierCrmTab');
    });
    await checkElementNotPresentInDomByTestId(
      'singleSelectButton-supplier-testid'
    );
    await checkElementPresentInDomByTestId('upload-button-supplier-crm');
  });
});
