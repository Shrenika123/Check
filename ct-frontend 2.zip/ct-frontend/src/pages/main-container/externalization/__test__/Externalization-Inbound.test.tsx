import '@testing-library/jest-dom';
import { act, cleanup, render, waitFor, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import {
  checkElementPresentInDomByTestId,
  clickedSpecificElementInGroup,
  clickElementByTestId,
} from '../../../../common/helper/testHelper';
import { inboundGraphData } from '../../../../common/mocks/promotionAndProcurement';
import Externalization from '../externalization';

afterEach(() => {
  cleanup();
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});

beforeAll(() => {
  Object.defineProperty(window, 'matchMedia', {
    value: () => ({
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
    }),
  });
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});

const setLocalStorage = (id: string, data: any) => {
  window.localStorage.setItem(id, data);
};
const externalUser = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_AND_INVENTORY_PLAN_DETAILS',
        permission: 'READ',
        route: 'event-inventory-plan/details',
      },
      {
        screen: 'PO_ITEM_MANAGEMENT',
        permission: 'READ',
        route: 'item-management',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',

        permission: 'WRITE',

        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const powerUser = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'NA',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_AND_INVENTORY_PLAN_DETAILS',
        permission: 'READ',
        route: 'event-inventory-plan/details',
      },
      {
        screen: 'PO_ITEM_MANAGEMENT',
        permission: 'READ',
        route: 'item-management',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',

        permission: 'WRITE',

        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const sysSettingsData = [
  {
    name: 'activity_visited_days_limit',
    value: '7',
  },
  {
    name: 'activity_favourite_days_limit',
    value: '30',
  },
  {
    name: 'enable_fixed_date',
    value: 'true',
  },
  {
    name: 'fixed_date',
    value: '2023-02-21',
  },
];

const inboundRead = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'NA',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: sysSettingsData,
  navbar: {
    isExpanded: false,
  },
};

const powerUserState = (type: string) => {
  switch (type) {
    case 'power':
      return powerUser;
    case 'read':
      return inboundRead;
    default:
      return externalUser;
  }
};

jest.mock('recharts', () => {
  const OriginalModule = jest.requireActual('recharts');
  return {
    ...OriginalModule,
    ResponsiveContainer: ({ children }: { children: any }) => (
      <OriginalModule.ResponsiveContainer
        width={350}
        height={350}>
        {children}
      </OriginalModule.ResponsiveContainer>
    ),
  };
});

const setFilterDetails = async () => {
  await act(async () => {
    await clickElementByTestId('singleSelectButton-dc-id-filter-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-dc-id-filter-testid',
      1
    );
  });
  await act(async () => {
    await clickElementByTestId(
      'singleSelectButton-facility-name-filter-testid'
    );
  });

  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-facility-name-filter-testid',
      1
    );
  });

  await act(async () => {
    await clickElementByTestId(
      'singleSelectButton-ptotection-type-filter-testid'
    );
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-ptotection-type-filter-testid',
      1
    );
  });
};

describe('Externalization for Supplier Crm for Supplier', () => {
  const mockStore = configureStore();
  beforeAll(() => {
    const mockId = 'group_id';
    const mockJson = '03j2qqm34kwh5cb';
    setLocalStorage(mockId, mockJson);
  });
  test('Suite for readAccess', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getInboundOptimizationFilter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValueOnce({ data: { data: ['AMBIENT', 'EXPRESS'] } })
      .mockResolvedValueOnce({ data: { data: ['HOT EQUIPMENT', 'FROZEN'] } })
      .mockResolvedValueOnce({ data: { data: ['102VDC', '103VDC'] } })
      .mockResolvedValueOnce({ data: { data: ['102DC', '103DC'] } });
    jest
      .spyOn(util, 'getInboundGraph')
      .mockResolvedValueOnce({ data: { data: inboundGraphData } });

    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await setFilterDetails();
    await checkElementPresentInDomByTestId('inbound-graph-id');
  });
});
