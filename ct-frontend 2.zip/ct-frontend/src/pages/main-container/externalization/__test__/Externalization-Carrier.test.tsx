import '@testing-library/jest-dom';
import { act, cleanup, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import {
  checkElementNotPresentInDomByTestId,
  checkElementPresentInDomByTestId,
  checkIfElementIfDisabledFromGroup,
  checkIfElementIsDisabled,
  checkIfElementNotDisabled,
  clickedSpecificElementInGroup,
  clickElementByTestId,
  setInputValueFromGroup,
  textNotPresentInDOM,
} from '../../../../common/helper/testHelper';
import { CarrierCrmDetails } from '../../../../common/mocks/promotionAndProcurement';
import Externalization from '../externalization';

afterEach(() => {
  cleanup();
});

beforeAll(() => {
  Object.defineProperty(window, 'matchMedia', {
    value: () => ({
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
    }),
  });
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});

const setLocalStorage = (id: string, data: any) => {
  window.localStorage.setItem(id, data);
};

const externalUser = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_AND_INVENTORY_PLAN_DETAILS',
        permission: 'READ',
        route: 'event-inventory-plan/details',
      },
      {
        screen: 'PO_ITEM_MANAGEMENT',
        permission: 'READ',
        route: 'item-management',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',

        permission: 'WRITE',

        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const powerUser = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'NA',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_AND_INVENTORY_PLAN_DETAILS',
        permission: 'READ',
        route: 'event-inventory-plan/details',
      },
      {
        screen: 'PO_ITEM_MANAGEMENT',
        permission: 'READ',
        route: 'item-management',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',

        permission: 'WRITE',

        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const sysSettingsData = [
  {
    name: 'activity_visited_days_limit',
    value: '7',
  },
  {
    name: 'activity_favourite_days_limit',
    value: '30',
  },
  {
    name: 'enable_fixed_date',
    value: 'true',
  },
  {
    name: 'fixed_date',
    value: '2023-02-21',
  },
];

const CarrierRead = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'NA',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'CARRIER_CRM',
        permission: 'READ',
        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: sysSettingsData,
  navbar: {
    isExpanded: false,
  },
};

const UserState = (type: string) => {
  switch (type) {
    case 'power':
      return powerUser;
    case 'read':
      return CarrierRead;
    default:
      return externalUser;
  }
};

const setFilterDetails = async () => {
  await act(async () => {
    await clickElementByTestId('singleSelectButton-carrierUserId-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-carrierUserId-testid',
      1
    );
  });

  await act(async () => {
    await clickElementByTestId('singleSelectButton-carrier-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-carrier-testid',
      1
    );
  });
  await act(async () => {
    await clickElementByTestId('singleSelectButton-origin-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-origin-testid',
      1
    );
  });
  await act(async () => {
    await clickElementByTestId('singleSelectButton-destination-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-destination-testid',
      1
    );
  });

  await act(async () => {
    await clickElementByTestId('singleSelectButton-facility-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-facility-testid',
      1
    );
  });

  await act(async () => {
    await clickElementByTestId('singleSelectButton-protection-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-protection-testid',
      1
    );
  });

  await act(async () => {
    await clickElementByTestId('singleSelectButton-mode-testid');
  });
  await act(async () => {
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-mode-testid',
      1
    );
  });
};

describe('Externalization for Carrier Crm for read Access Power User', () => {
  beforeAll(() => {
    const mockId = 'group_id';
    const mockJson = '034g0dwd13cd23l';
    setLocalStorage(mockId, mockJson);
  });
  const mockStore = configureStore();
  test('Initial render of Carrier crm from power user', async () => {
    const powerUserStore = mockStore(UserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getCarrierCrmFIlter')
      .mockResolvedValue({ data: ['1505VDC', '1969VDC'] });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('carrier-crm');
    });
    await act(async () => {
      await checkIfElementNotDisabled(
        'singleSelectButton-carrierUserId-testid'
      );
    });
    await act(async () => {
      await checkIfElementIsDisabled('singleSelectButton-carrier-testid');
    });
    await act(async () => {
      await checkIfElementIsDisabled('singleSelectButton-origin-testid');
    });
    await act(async () => {
      await checkIfElementIsDisabled('singleSelectButton-destination-testid');
    });
    await act(async () => {
      await checkIfElementIsDisabled('singleSelectButton-facility-testid');
    });
    await act(async () => {
      await checkIfElementIsDisabled('singleSelectButton-protection-testid');
    });
    await act(async () => {
      await checkIfElementIsDisabled('singleSelectButton-mode-testid');
    });
    await act(async () => {
      await textNotPresentInDOM('Save');
    });
  });

  test('On Click Action of filters', async () => {
    const powerUserStore = mockStore(UserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getCarrierCrmFIlter')
      .mockResolvedValue({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getCarrierCrmDetails')
      .mockResolvedValueOnce({ data: { data: CarrierCrmDetails } });

    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });

    await checkElementPresentInDomByTestId('carrier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrierUserId-testid');
    });

    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-carrierUserId-testid',
        1
      );
      await checkIfElementNotDisabled('singleSelectButton-carrier-testid');
      await checkIfElementIsDisabled('singleSelectButton-origin-testid');
      await checkIfElementIsDisabled('singleSelectButton-destination-testid');
      await checkIfElementIsDisabled('singleSelectButton-facility-testid');
      await checkIfElementIsDisabled('singleSelectButton-protection-testid');
      await checkIfElementIsDisabled('singleSelectButton-mode-testid');
    });

    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrier-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-carrier-testid',
      1
    );
    await checkIfElementNotDisabled('singleSelectButton-origin-testid');
    await checkIfElementIsDisabled('singleSelectButton-destination-testid');
    await checkIfElementIsDisabled('singleSelectButton-facility-testid');
    await checkIfElementIsDisabled('singleSelectButton-protection-testid');
    await checkIfElementIsDisabled('singleSelectButton-mode-testid');

    await act(async () => {
      await clickElementByTestId('singleSelectButton-origin-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-origin-testid',
      1
    );
    await checkIfElementNotDisabled('singleSelectButton-destination-testid');
    await checkIfElementIsDisabled('singleSelectButton-facility-testid');
    await checkIfElementIsDisabled('singleSelectButton-protection-testid');
    await checkIfElementIsDisabled('singleSelectButton-mode-testid');

    await act(async () => {
      await clickElementByTestId('singleSelectButton-destination-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-destination-testid',
      1
    );
    await checkIfElementNotDisabled('singleSelectButton-facility-testid');
    await checkIfElementIsDisabled('singleSelectButton-protection-testid');
    await checkIfElementIsDisabled('singleSelectButton-mode-testid');

    await act(async () => {
      await clickElementByTestId('singleSelectButton-facility-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-facility-testid',
      1
    );
    await checkIfElementNotDisabled('singleSelectButton-protection-testid');
    await checkIfElementIsDisabled('singleSelectButton-mode-testid');

    await act(async () => {
      await clickElementByTestId('singleSelectButton-protection-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-protection-testid',
      1
    );
    await checkIfElementNotDisabled('singleSelectButton-mode-testid');

    await act(async () => {
      await clickElementByTestId('singleSelectButton-mode-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-mode-testid',
        1
      );
    });
  });

  test('table onSave and Input Functionality for Power User', async () => {
    const powerUserStore = mockStore(UserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getCarrierCrmFIlter')
      .mockResolvedValue({ data: { data: ['1505VDC', '1969VDC'] } });

    jest
      .spyOn(util, 'getCarrierCrmDetails')
      .mockResolvedValueOnce({ data: { data: CarrierCrmDetails } });
    const postSavedData = jest
      .spyOn(util, 'carrierCRMBulkUpdatePost')
      .mockResolvedValueOnce({ data: { data: 'Updated successfully!!' } })
      .mockResolvedValueOnce({ data: { data: 'Updated successfully!!' } });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });

    await checkElementPresentInDomByTestId('carrier-crm');
    await setFilterDetails();
    await act(async () => {
      await checkIfElementIfDisabledFromGroup('carrierCrmSave-testid', 0);
      await setInputValueFromGroup('carrierCrmTable-input-testid', 0, '10');
      await checkIfElementIfDisabledFromGroup('carrierCrmSave-testid', 0);
    });
    await act(async () => {
      await setInputValueFromGroup('carrierCrmTable-input-testid', 0, '4');
      await setInputValueFromGroup('carrierCrmTable-input-testid', 1, '5');
      await clickedSpecificElementInGroup('carrierCrmSave-testid', 0);
      expect(postSavedData).toBeCalled();
    });
    await checkIfElementIfDisabledFromGroup('carrierCrmSave-testid', 0);
    await act(async () => {
      await clickedSpecificElementInGroup('carrierCrmSave-testid', 0);
    });
  });

  test('when API fails for Power User for all vendor', async () => {
    const powerUserStore = mockStore(UserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest.spyOn(util, 'getCarrierCrmFIlter').mockRejectedValue({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });

    await checkElementPresentInDomByTestId('carrier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrierUserId-testid');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId(
        'singleSelect-noData-carrierUserId-testid'
      );
    });
  });

  test('when API fails for Power User for filter all details', async () => {
    const powerUserStore = mockStore(UserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getCarrierCrmFIlter')
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValueOnce({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockRejectedValueOnce({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });

    await checkElementPresentInDomByTestId('carrier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrierUserId-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-carrierUserId-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrier-testid');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId(
        'singleSelect-noData-carrier-testid'
      );
    });
  });

  test('when API fails for Power User for  all table details', async () => {
    const powerUserStore = mockStore(UserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getCarrierCrmFIlter')
      .mockResolvedValue({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getCarrierCrmDetails')
      .mockRejectedValueOnce({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });
    await checkElementPresentInDomByTestId('carrier-crm');
    await checkElementPresentInDomByTestId('upload-button-carrier-crm');
    await checkElementPresentInDomByTestId('download-button-carrier-crm');
    await setFilterDetails();
    await checkElementNotPresentInDomByTestId('carrierCrmSave-testid');
  });

  test('when post api on updating table fails', async () => {
    const powerUserStore = mockStore(UserState('power'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getCarrierCrmFIlter')
      .mockResolvedValue({ data: { data: ['1505VDC', '1969VDC'] } });
    jest
      .spyOn(util, 'getCarrierCrmDetails')
      .mockResolvedValueOnce({ data: { data: CarrierCrmDetails } });
    const postSavedData = jest
      .spyOn(util, 'carrierCRMBulkUpdatePost')
      .mockRejectedValueOnce({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });
    await checkElementPresentInDomByTestId('carrier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrierUserId-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-carrierUserId-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrier-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-carrier-testid',
      1
    );
    await act(async () => {
      await clickElementByTestId('singleSelectButton-origin-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-origin-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-destination-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-destination-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-facility-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-facility-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-protection-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-protection-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-mode-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-mode-testid',
        1
      );
    });
    await act(async () => {
      await setInputValueFromGroup('carrierCrmTable-input-testid', 0, '4');
      await clickedSpecificElementInGroup('carrierCrmSave-testid', 0);
      expect(postSavedData).toBeCalled();
    });
  });
});

describe('Externalization for Carrier Crm for read Access Supply Chain Ops', () => {
  const mockStore = configureStore();
  beforeAll(() => {
    const mockId = 'group_id';
    const mockJson = '039kk8xu4jbpycu';
    setLocalStorage(mockId, mockJson);
  });
  test('Suite for readAccess', async () => {
    const powerUserStore = mockStore(UserState('read'));
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getInboundOptimizationFilter').mockRejectedValue({});
    jest
      .spyOn(util, 'getCarrierCrmFIlter')
      .mockResolvedValue({ data: { data: ['1505VDC', '1969VDC'] } })
      .mockResolvedValue({ data: { data: ['1505VDC', '1969VDC'] } });

    jest
      .spyOn(util, 'getCarrierCrmDetails')
      .mockResolvedValueOnce({ data: { data: CarrierCrmDetails } });

    render(
      <Provider store={powerUserStore}>
        <Externalization isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('supplierCrm-datepicker-testId');
    await act(async () => {
      await clickElementByTestId('carrierCrmTab');
    });
    await checkElementNotPresentInDomByTestId('upload-button-carrier-crm');
    await checkElementNotPresentInDomByTestId('download-button-carrier-crm');
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrierUserId-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-carrierUserId-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-carrier-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-carrier-testid',
      1
    );
    await act(async () => {
      await clickElementByTestId('singleSelectButton-origin-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-origin-testid',
      1
    );
    await act(async () => {
      await clickElementByTestId('singleSelectButton-destination-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-destination-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-facility-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-facility-testid',
        1
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-protection-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-protection-testid',
        0
      );
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-mode-testid');
    });
    await act(async () => {
      await clickedSpecificElementInGroup(
        'singleSelectRadioButton-mode-testid',
        0
      );
    });
    await act(async () => {
      await checkElementNotPresentInDomByTestId('carrierCrmSave-testid');
      await checkElementNotPresentInDomByTestId('carrierCrmTable-input-testid');
    });
  });
});
