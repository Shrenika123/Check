import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor
} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { externalizationSchema } from '../../../../../../common/constants';
import UploadModal from '../UploadModal.component';
import { routes } from '../../../../../../common/navigation-utils';

describe('upload modal for carrier crm', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };

  const carrierCRMCSVData_valid = `"Carrier User ID","Carrier ID","Origin","Destination","Facility Name","Protection Type","Mode","Load Capacity Availability by Date","No. of Modes"\n"123","123","mode","facility","type","10","place","place","2023-03-29"`;

  afterEach(cleanup);

  test('should render the upload modal component', () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.CARRIER}
        />
      </Provider>,
      { wrapper: BrowserRouter }
    );
  });

  test('should add file to upload and then remove', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.CARRIER}
        />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const data = new Blob([carrierCRMCSVData_valid],{type:'text/csv'})
    const file = new File([data], 'ping.csv', {type:'text/csv'});
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });

    await waitFor(() => {
      expect(screen.getByTestId('remove-file-icon')).toBeInTheDocument();
    });
    userEvent.click(screen.getByTestId('remove-file-icon'));
    await waitFor(() => {
      expect(screen.queryByTestId('remove-file-icon')).toBeNull();
    });
  });

  test('should reject non csv', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.CARRIER}
        />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const file = new File(['file'], 'ping.json', {
      type: 'application/json',
    });
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.queryByText('ping.json')).toBeNull();
    });
  });

  test('should reject duplicate csv', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.CARRIER}
        />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const data = new Blob([carrierCRMCSVData_valid], { type: 'text/csv' });
    const file = new File([data], 'ping.csv', { type: 'text/csv' });
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });
  });

  test('should upload csv file', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../../../common/utils');
    jest
      .spyOn(util, 'uploadCarrierCrmCSVFile')
      .mockResolvedValue({ status: 200 });
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.CARRIER}
        />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const data = new Blob([carrierCRMCSVData_valid], { type: 'text/csv' });
    const file = new File([data], 'ping.csv', { type: 'text/csv' });
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });
    userEvent.click(screen.getByTestId('upload-button'));
    await waitFor(() => {
      expect(screen.getByText('Success')).toBeInTheDocument();
    });
  });
});

describe('upload modal for supplier crm', () => {
  const mockStore = configureStore();
  const powerUserState = {
    user: {
      userRole: 'powerUserDummyId',
      userExternalId: 'externalId',
      appToken:'appToken',
      idToken:'idToken',
      appTokenExpiration:1200000,
      userId:'userId',
      refreshTokenId:'refreshTokenId',
      routePermissions: [
        {
          screen: "RECENT_PO_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "VESSEL_TRACKING",
          permission: "READ",
          route: "vessel-tracking"
        },
        {
          screen: "PORT_DOCUMENT_LIBRARY",
          permission: "READ",
          route: "document-library"
        },
        {
          screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "RECENT_CONTAINER_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "PO_MANAGEMENT",
          permission: "READ",
          route: "po-management"
        },
        {
          screen: "INBOUND_OPTIMIZATION",
          permission: "READ",
          route: "externalization"
        },
        {
          screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
          permission: "READ",
          route: "home"
        },
        {
          screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
          permission: "READ",
          route: "event-inventory-plan/details"
        },
        {
          screen: "PO_ITEM_MANAGEMENT",
          permission: "READ",
          route: "item-management"
        },
        {
          screen: "INVENTORY_PLAN",
          permission: "READ",
          route: "event-inventory-plan"
        },
        {
          screen: "PO_LINE_MANAGEMENT",
          permission: "READ",
          route: "po-management/details"
        },
        {
          screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
          permission: "READ",
          route: "ship-load-management"
        },
        {
          screen: "CONTAINER_TRACKING",
          permission: "WRITE",
          route: "vessel-tracking/details"
        },
        {
          screen: "CONTAINER_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "SUPPLIER_CRM",
          permission: "WRITE",
          route: "externalization"
        },
        {
          screen: "EVENT_PLAN",
          permission: "WRITE",
          route: "event-inventory-plan"
        },
        {
          screen: "LOAD_DOCUMENT_LIBRARY",
          permission: "WRITE",
          route: "document-library"
        },
        {
          screen: "ADMIN",
          permission: "WRITE",
          route: "admin-panel"
        },
        {
          screen: "CARRIER_CRM",
          permission: "WRITE",
          route: "externalization"
        }
      ],
      userDefaultRoute: routes.home,
    },
    systemSetting: [
      {
        name: 'activity_visited_days_limit',
        value: '7',
      },
      {
        name: 'activity_favourite_days_limit',
        value: '30',
      },
      {
        name: 'enable_fixed_date',
        value: 'true',
      },
      {
        name: 'fixed_date',
        value: '2023-02-21',
      },
    ],
    navbar: {
      isExpanded: false,
    },
  };

  const supplierCRMCSVData_valid = `"Supplier ID","Ship Point ID","Facility Name","Protection Type","Supplier Availability By Date","Shipping Capacity"\n"BATH10000","Hot equipment","MAIL","2924VDC","03/28/2023",""`

  afterEach(cleanup);

  test('should render the upload modal component', () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.SUPPLIER} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
  });

  test('should add file to upload and then remove', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.SUPPLIER} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const data = new Blob([supplierCRMCSVData_valid], { type: 'text/csv' });
    const file = new File([data], 'ping.csv', { type: 'text/csv' });
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });

    await waitFor(() => {
      expect(screen.getByTestId('remove-file-icon')).toBeInTheDocument();
    });
    userEvent.click(screen.getByTestId('remove-file-icon'));
    await waitFor(() => {
      expect(screen.queryByTestId('remove-file-icon')).toBeNull();
    });
  });

  test('should reject non csv', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.SUPPLIER}/>
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const file = new File(['file'], 'ping.json', {
      type: 'application/json',
    });
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.queryByText('ping.json')).toBeNull();
    });
  });

  test('should reject duplicate csv', async () => {
    const powerUserStore = mockStore(powerUserState);
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { }} schema={externalizationSchema.SUPPLIER}/>
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const data = new Blob([supplierCRMCSVData_valid], { type: 'text/csv' });
    const file = new File([data], 'ping.csv', { type: 'text/csv' });
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });
  });

  test('should upload csv file', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../../../common/utils');
    jest
      .spyOn(util, 'uploadSupplierCrmCSVFile')
      .mockResolvedValue({ status: 200 });
    render(
      <Provider store={powerUserStore}>
        <UploadModal
          isOpen={true}
          setOpen={() => { } } schema={externalizationSchema.SUPPLIER}/>
      </Provider>,
      { wrapper: BrowserRouter }
    );
    const inputEl = screen.getByTestId('drop-input');

    const data = new Blob([supplierCRMCSVData_valid], { type: 'text/csv' });
    const file = new File([data], 'ping.csv', { type: 'text/csv' });
    Object.defineProperty(inputEl, 'files', {
      value: [file],
    });
    fireEvent.drop(inputEl);
    await waitFor(() => {
      expect(screen.getByText('ping.csv')).toBeInTheDocument();
    });
    userEvent.click(screen.getByTestId('upload-button'));
    await waitFor(() => {
      expect(screen.getByText('Success')).toBeInTheDocument();
    });
  });
});
