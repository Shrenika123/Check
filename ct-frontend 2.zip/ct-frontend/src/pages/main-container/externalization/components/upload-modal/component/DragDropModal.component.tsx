import Tooltip from '@mui/material/Tooltip';
import { ReactElement } from 'react';
import Dropzone, { FileRejection } from 'react-dropzone';
import { useDispatch } from 'react-redux';
import UploadIcon from '../../../../../../assets/icons/Upload-Cloud.svg';
import { formatFileSize, schemaValidationForCSVUpload } from '../../../../../../common/utils';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';

interface Props {
  selectedFiles: File[];
  setSelectedFiles: Function;
  progress: number;
  isUploading: boolean;
  schema: string;
}

export default function DragDropModal(props: Props): ReactElement {

  const dispatch = useDispatch();

  const addToSelectedFiles = (filesToSelect: File[], rejectedFiles: FileRejection[]) => {
    const fileToInclude = filesToSelect[0];

    if (rejectedFiles && rejectedFiles.length > 0) {
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Only CSV files are allowed', alertDescription: 'File ' + rejectedFiles[0].file.name + ' has unsupported file format.' }));
      return;
    }

    if (fileToInclude.size > 5000000) {
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'File size of more than 5MB is not allowed', alertDescription: 'File ' + fileToInclude.name + ' has more than 5MB of size.' }));
      return;
    }

    if (props.selectedFiles.map((file: File) => file.name).includes(fileToInclude.name)) {
      dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'Duplicate Files selected', alertDescription: 'File ' + fileToInclude.name + ' has been already selected to upload' }));
      return;
    }
    // schema validation check
    schemaValidationForCSVUpload(fileToInclude, props.schema ,(validationErrors: string[]) => {
      if (validationErrors.length === 1) {
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'File validation fail', alertDescription: 'File ' + fileToInclude.name + validationErrors[0] }));
        return;
      }

      if (validationErrors.length >= 2) {
        dispatch(setShowAlert({ showAlert: true, alertType: 'error', alertTitle: 'File validation fail', alertDescription: "Selected CSV file should have correct column headers and contain data" }));
        return;
      }
      props.setSelectedFiles([fileToInclude]);
    });
  };

  const removeSelectedFile = (fileNameToRemove: string) => {
    props.setSelectedFiles(
      props.selectedFiles.filter((file: File) => file.name !== fileNameToRemove)
    );
  };

  return (
    <>
      <Dropzone multiple={false} accept={{ 'text/csv': ['.csv'] }} onDrop={(acceptedFiles, rejectedFiles) => addToSelectedFiles(acceptedFiles, rejectedFiles)}>
        {({ getRootProps, getInputProps }) => (
          <section>
            <div {...getRootProps()}>
              <input data-testid='drop-input' {...getInputProps()} />
              <div className="flex align-items-center flex-column modal-view2-dragdrop-area">
                <img className='uploadicon' src={UploadIcon} alt='' />
                <span className="my-2 uploadtext1">Drag & Drop files or <span className='uploadtext3'>Browse</span></span>
                <span className='uploadtext2'>Supported formats: .csv upto 5MB</span>
              </div>
            </div>
          </section>
        )}
      </Dropzone>
      {props.selectedFiles.length > 0 && !props.isUploading &&
        <>
          <div className='uploaded-files-area-wrapper'>
            <div id='uploaded-text'>Uploaded</div>
            <div className='uploaded-files-area'>
              {props.selectedFiles.map((file: File) => {
                return (
                  <div key={file.name} className='uploaded-file-info'>
                    <Tooltip id='doc-library-upload-tooltip' title={file.name} placement='bottom-start'><div id='uploaded-file-name'>{file.name}</div></Tooltip>
                    <div>{formatFileSize(file.size)}</div>
                    <i data-testid='remove-file-icon' onClick={() => removeSelectedFile(file.name)} className='pi pi-times-circle pointer-cursor'></i>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      }
      {
        props.isUploading &&
        <>
          <div id='uploaded-text'>Uploading File(s)</div>
          <div className='progress-bar-outer'>
            <div style={{ width: `${props.progress * 100}%` }} className='progress-bar-inner'>
            </div>
          </div>
        </>
      }
    </>
  );
}