import classNames from 'classnames';
import { Dialog } from 'primereact/dialog';
import { FC, useState } from 'react';
import { useDispatch } from 'react-redux';
import { externalizationSchema } from '../../../../../common/constants';
import { uploadCarrierCrmCSVFile, uploadSupplierCrmCSVFile } from '../../../../../common/utils';
import SuccessModalView from '../../../../../components/success-upload-modal/SuccessModalView.component';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import DragDropModal from './component/DragDropModal.component';
import './UploadModal.style.css';

interface Props {
  isOpen: boolean;
  setOpen: Function;
  schema: string;
}

const UploadAction: FC<Props> = (props) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [modalView, setModalView] = useState<1 | 2>(1);
  const [progress, setProgress] = useState<number>(0);
  const [isUploading, setUploading] = useState<boolean>(false);

  const dispatch = useDispatch();

  const handleClose = () => {
    setSelectedFiles([]);
    props.setOpen(false);
  };

  const handleSuccessModalClose = () => {
    setModalView(1);
    setSelectedFiles([]);
  };

  const uploadUpdateDocument = () => {
    setUploading(true);
    dispatch(setLoading(true));
    const formData = new FormData();

    formData.append('file', selectedFiles[0]);

    const onUploadProgress = (progressEvent: any) => {
      setProgress(progressEvent.progress);
    };
    if (props.schema === externalizationSchema.SUPPLIER) {
      uploadSupplierCrmCSVFile(formData, onUploadProgress)
        .then((res) => {
          props.setOpen(false);
          setModalView(2);
        })
        .catch((err) => {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: 'Error Occurred',
              alertDescription: 'Error Occurred while updating the Document',
            })
          );
        })
        .finally(() => {
          dispatch(setLoading(false));
          setUploading(false);
        });
    } else {
      uploadCarrierCrmCSVFile(formData, onUploadProgress)
        .then((res) => {
          props.setOpen(false);
          setModalView(2);
        })
        .catch((err) => {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: 'error',
              alertTitle: 'Error Occurred',
              alertDescription: 'Error Occurred while updating the Document',
            })
          );
        })
        .finally(() => {
          dispatch(setLoading(false));
          setUploading(false);
        });
    }
  };

  const nextAndUploadButtonClass = classNames('next-and-upload-button', {
    disabled: selectedFiles.length === 0,
  });

  return (
    <>
      <Dialog
        id='upload-modal'
        header='Upload Document'
        visible={props.isOpen}
        onHide={handleClose}>
        {modalView === 1 && (
          <>
            {' '}
            <DragDropModal
              selectedFiles={selectedFiles}
              setSelectedFiles={setSelectedFiles}
              progress={progress}
              isUploading={isUploading} 
              schema={props.schema}></DragDropModal>
            {!isUploading && (
              <button
                data-testid='upload-button'
                onClick={() => uploadUpdateDocument()}
                className={nextAndUploadButtonClass}>
                Upload
              </button>
            )}
          </>
        )}
      </Dialog>
      {modalView === 2 && (
        <Dialog
          header='Success'
          visible={modalView === 2}
          onHide={handleSuccessModalClose}>
          <SuccessModalView />
        </Dialog>
      )}
    </>
  );
};

export default UploadAction;
