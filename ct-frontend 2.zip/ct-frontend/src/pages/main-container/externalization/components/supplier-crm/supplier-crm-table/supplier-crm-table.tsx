import { Pagination } from '@mui/material';
import { nanoid } from '@reduxjs/toolkit';
import { format } from 'date-fns';
import moment from 'moment';
import React, { useEffect, useRef, useState } from 'react';
import { Range } from 'react-date-range';
import { useDispatch } from 'react-redux';
import backIcon from '../../../../../../assets/images/backicon.png';
import {
  ExternalizationSupplierColumn,
  labels
} from '../../../../../../common/constants';
import {
  alertStates,
  IPostSupplierCrmDetails,
  ISupplierCrmDetailsParam,
  ISupplierCrmEntity,
  ITableData
} from '../../../../../../common/interfaces';
import { SupplierCrmData } from '../../../../../../common/mocks/promotionAndProcurement';
import {
  getFillerLength,
  getFormattedDate, getGMTTimeStamp, getLastUpdatedDateTImeString,
  getSupplierCrmDetails,
  isDigit,
  paginationCount, supplierCRMBulkUpdatePost,
  validEntityString as validEntity
} from '../../../../../../common/utils';
import ConfirmationBox from '../../../../../../components/confimation-box/ConfirmationBox.component';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';
import './supplier-crm-table.style.css';

interface ISupplierCrmTableProps {
  isWriteAccess: boolean;
  param: ISupplierCrmDetailsParam;
  range: Range[];
}

const data = SupplierCrmData;
const ColumnHeadersSupplierCrm: ITableData[] = [
  {
    label: ExternalizationSupplierColumn.supplierAvailability,
    value: 'Supplier Availability By Date',
  },
  {
    label: ExternalizationSupplierColumn.shippingCapacity,
    value: 'Shipping Capacity',
  },
  { label: ExternalizationSupplierColumn.committed, value: 'Committed' },
  { label: ExternalizationSupplierColumn.unCommitted, value: 'Uncommitted' },
  { label: '', value: '' },
];

const SupplierCrmTable: React.FC<ISupplierCrmTableProps> = ({
  isWriteAccess,
  param,
  range,
}) => {
  const [tableData, setTableData] = useState<ISupplierCrmEntity[]>([]);
  const [updatedData, setUpdatedData] = useState<ISupplierCrmEntity[]>([]);
  const [tableParams, setTableParams] =
    useState<ISupplierCrmDetailsParam>(param);
  const [page, setPage] = useState<number>(1);
  const [count, setCount] = useState<number>(0);
  const pageSize = 30;
  const [errorRows, setErrorRows] = useState<Set<number>>(new Set());
  const [updatedRows, setUpdatedRows] = useState<Set<number>>(new Set());
  const [isConfirmBoxOpen, setConfirmBoxOpen] = useState<boolean>(false);
  const clickedPageRef = useRef<number>(1);

  const dispatch = useDispatch();

  useEffect(() => {
    let countDiff;
    countDiff = moment(new Date(range[0].endDate!)).diff(
      moment(new Date(range[0].startDate!)),
      'days'
    );
    if (!moment(range[0].endDate!).isSame(range[0].startDate!)) {
      countDiff += 1;
    }
    if (tableData.length > 0) {
      setCount(paginationCount(countDiff > 0 ? countDiff : 1, pageSize));
    }
  }, [range, tableData]);

  useEffect(() => {
    setTableParams({ ...tableParams, ...param });
  }, [param]);

  useEffect(() => {
    if (tableParams.pageNumber !== page && page) {
      setTableParams({ ...tableParams, pageNumber: page ?? 1 });
    }
  }, [page]);

  const getErrorAlert = (errorMessage: string) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: alertStates.ERROR,
        alertTitle: errorMessage,
        alertDescription: '',
      })
    );
  };

  const validateParams = () => {
    return (
      validEntity(tableParams.endDate) &&
      validEntity(tableParams.facility) &&
      validEntity(tableParams.protectionType) &&
      validEntity(tableParams.shipPointId) &&
      validEntity(tableParams.vendorId) &&
      param.pageNumber
    );
  };

  const loadTableData = () => {
    dispatch(setLoading(true));
    getSupplierCrmDetails(tableParams)
      .then((res) => {
        const dataWithKey = res.data.data.map((row: ISupplierCrmEntity) => { return { ...row, key: nanoid() }; });
        setTableData(dataWithKey);
        setUpdatedData(dataWithKey);
      })
      .catch(() => {
        getErrorAlert('Failed to fetch supplier CRM table data');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  useEffect(() => {
    if (validateParams()) {
      loadTableData();
    } else {
      setTableData([]);
      setUpdatedData([]);
      setCount(0);
    }
    setErrorRows(new Set());
    setUpdatedRows(new Set());
  }, [tableParams]);

  const getTableDataIndex = (
    date: string,
    supplierEntityArray: ISupplierCrmEntity[]
  ) => {
    return supplierEntityArray.findIndex(
      (itemData) => itemData.capacityDate === date
    );
  };

  const handleChangeSupplier = (
    e: React.ChangeEvent<HTMLInputElement>,
    item: ISupplierCrmEntity
  ) => {
    let index: number = getTableDataIndex(item.capacityDate, tableData);
    if (e.target.value !== null && isDigit(e.target.value)) {
      if (tableData[index].commitedCount?.toString() && tableData[index].commitedCount !== null) {
        if (e.target.value === '') {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: labels.capacityEmpty,
              alertDescription: '',
            })
          );
        }
        if (Number.parseInt(e.target.value) < updatedData[index].commitedCount!) {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: labels.capacityWarn,
              alertDescription: '',
            })
          );
          setErrorRows(errorRows.add(index));
        }
        else {
          errorRows.delete(index) && setErrorRows(errorRows);

          if (e.target.value !== '') {
            Number.parseInt(e.target.value) !== Number.parseInt(tableData[index].supplierCapacity.toString()) &&
              setUpdatedRows(updatedRows.add(index));
          }
          else {
            updatedRows.delete(index) && setUpdatedRows(updatedRows);
            tableData[index].commitedCount !== null && setErrorRows(errorRows.add(index));
          }

          Number.parseInt(e.target.value) === Number.parseInt(tableData[index].supplierCapacity.toString()) &&
            updatedRows.delete(index) && setUpdatedRows(updatedRows);

        }
      }
      else if (e.target.value && e.target.value != null && e.target.value !== '') {
        setUpdatedRows(updatedRows.add(index));
        errorRows.delete(index) && setErrorRows(errorRows);
      }
      else {
        updatedRows.delete(index) && setUpdatedRows(updatedRows);
      }

      setUpdatedData([
        ...updatedData.slice(0, index),
        {
          ...updatedData[index],
          supplierCapacity: e.target.value,
        },
        ...updatedData.slice(index + 1, updatedData.length),
      ]);
    }
  };

  const isDisabled = () => {
    if (errorRows.size > 0 || updatedRows.size === 0)
      return true;

    for (let i = 0; i < tableData.length; i++) {
      if (!(tableData[i].supplierCapacity === updatedData[i].supplierCapacity ||
        updatedData[i].supplierCapacity === null ||
        updatedData[i].supplierCapacity === '')) {
        return false;
      }
    }
    return true;
  };

  const supplierCrmBulkUpdate = (
    updatedSupplierEntity: ISupplierCrmEntity[]
  ) => {
    let payload: IPostSupplierCrmDetails[] = [];
    updatedSupplierEntity.forEach((row, index) => {
      if (!updatedRows.has(index))
        return;
      let supplierCrmPayLoadRow: IPostSupplierCrmDetails =
      {
        shipPointId: tableParams.shipPointId,
        facility: tableParams.facility,
        protectionType: tableParams.protectionType,
        vendorId: tableParams.vendorId,
        committedCount: row.commitedCount!,
        uncommittedCount: row.commitedCount!,
        supplierCapacity: Number(row.supplierCapacity),
        capacityDate: row.capacityDate,
        lastModifiedDatetime: row.lastModifiedDatetime
      };
      payload.push(supplierCrmPayLoadRow);
    });
    dispatch(setLoading(true));
    supplierCRMBulkUpdatePost(payload)
      .then(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.SUCCESS,
            alertTitle: labels.bulkUpdateStarted,
            alertDescription: '',
          })
        );
        persistTableData();
        setUpdatedRows(new Set());
        setErrorRows(new Set());
      })
      .catch(() => {
        getErrorAlert(labels.bulkUpdateFailed);
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const persistTableData = () => {
    updatedRows.forEach((_, value) => {
      updatedData[value].uncommitedCount =
        calculateUncommitedCount(updatedData[value], Number.parseInt(updatedData[value].supplierCapacity.toString()));
      updatedData[value].commitedCount =
        !updatedData[value].commitedCount || updatedData[value].commitedCount === null ? 0 : updatedData[value].commitedCount;
      updatedData[value].lastModifiedDatetime = format(getGMTTimeStamp(), 'yyyy-MM-dd HH:mm:ss.SSSSSS')+'+00';

    });
    setUpdatedData(updatedData);
    setTableData(updatedData);
  };
  const calculateUncommitedCount = (
    supplierEntity: ISupplierCrmEntity,
    supplierCapacity: number
  ) => {
    if (supplierEntity.commitedCount !== null) {
      return supplierCapacity - supplierEntity.commitedCount!;
    } else {
      return supplierCapacity;
    }
  };

  const getLastModifiedColumnValue = (dateString: string) => {
    if (!dateString || dateString == null || dateString === 'NA')
      return '-';
    return `updated ${getLastUpdatedDateTImeString(dateString)} ago`;
  };

  const updateClickedPage = (pageNo: number) => {
    clickedPageRef.current = pageNo;
    if (isDisabled())
      setPage(pageNo);
    else
      setConfirmBoxOpen(true);
  };
  const moveToNextPage = () => {
    setPage(clickedPageRef.current);
    setConfirmBoxOpen(false);
  };

  const inputBoxClass = (index: number) => {
    if (errorRows.has(index))
      return 'error';
    if (updatedRows.has(index))
      return 'updated';
  };

  return (
    <>
      <section className='supplier-crm-table-pagination-wrapper'>
        <section className={'supplier-crm-table-wrapper'}>
          <table
            className='supplier-crm-table'
            data-testid='cemTable-testId'>
            <thead>
              <tr>
                {ColumnHeadersSupplierCrm.map((item) => {
                  return (
                    <th
                      key={item.label}
                      data-testid={`crm-table-${item.label}`}>
                      <div>{item.value}</div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {data.length > 0 &&
                updatedData.map((value, index) => {
                  return (
                    <tr
                      key={value.key}
                      data-testid='supplier-crm-tableData'>
                      <td>{getFormattedDate(value.capacityDate)}</td>
                      <td data-testid='supplierCrmTable-capacity-testid'>
                        {isWriteAccess ? (
                          <input className={inputBoxClass(index)}
                            value={value.supplierCapacity ?? ''}
                            onChange={(e) => {
                              handleChangeSupplier(e, tableData[index]);
                            }}
                            data-testid='supplierCrmTable-input-testid'
                          />
                        ) : (
                          value.supplierCapacity ?? 0
                        )}
                      </td>
                      <td data-testid='supplierCrmTable-committed-testid'>
                        {value.commitedCount ?? 'NA'}
                      </td>
                      <td data-testid='supplierCrmTable-uncommitted-testid'>
                        {value.uncommitedCount ?? 'NA'}
                      </td>
                      <td className='last-updated-column'>
                        <i>{getLastModifiedColumnValue(value.lastModifiedDatetime)}</i>
                      </td>
                    </tr>
                  );
                })}
              {[...Array(getFillerLength(tableData))]
                .map(() => {
                  return { key: nanoid() };
                })
                .map((_, index) => {
                  return (
                    <tr
                      data-testid='filler'
                      key={_.key}>
                      <td colSpan={16}>
                        <div></div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </section>
        <section className={'paginated'}>
          <Pagination
            count={count}
            variant='text'
            shape='rounded'
            siblingCount={1}
            color={'standard'}
            showFirstButton
            showLastButton
            size='small'
            onChange={(e, value) => updateClickedPage(value)}
            page={page}
          />
        </section>
        <section className={'save-button-wrapper'}>
          {tableData.length > 0 && isWriteAccess && (
            <button
              className='saveActionButton'
              data-testid='supplierCrmSave-testid'
              disabled={isDisabled()}
              onClick={() => supplierCrmBulkUpdate(updatedData)  // TODO: API integration
              }>
              {'Save'}
            </button>
          )}
        </section>
        <ConfirmationBox title='Leave this page without saving?'
          content='You have unsaved data left on this page. 
          Do you want to move to
          other page? Usaved data will be lost.'
          open={isConfirmBoxOpen} onClose={() => setConfirmBoxOpen(false)}
          confirmAction={() => moveToNextPage()}
          cancelAction={() => setConfirmBoxOpen(false)} image={<img src={backIcon} alt='' />} />
      </section>
    </>
  );
};
export default SupplierCrmTable;
