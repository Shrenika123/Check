import CloudDownloadOutlinedIcon from '@mui/icons-material/CloudDownloadOutlined';
import CloudUploadOutlinedIcon from '@mui/icons-material/CloudUploadOutlined';
import Tooltip from '@mui/material/Tooltip';
import { nanoid } from '@reduxjs/toolkit';
import classNames from 'classnames';
import { format } from 'date-fns';
import React, { useEffect, useRef, useState } from 'react';
import { CSVLink } from "react-csv";
import { Range } from 'react-date-range';
import { useDispatch } from 'react-redux';
import { externalizationSchema, labels, supplierCRMCSVHeaders } from '../../../../../common/constants';
import {
  alertStates,
  ISupplierCrmAllDetails,
  ISupplierCrmDetailsParam
} from '../../../../../common/interfaces';
import {
  fetchUserRole, formatSupplierCRMResponseForCSV, getSupplierCrmDetails, getSupplierCrmFIlter,
  validEntityString
} from '../../../../../common/utils';
import SingleSelect, {
  ISelectElement
} from '../../../../../components/SingleSelect';
import { useDidComponentUpdate } from '../../../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import UploadModal from '../upload-modal/UploadModal.component';
import SupplierCrmTable from './supplier-crm-table/supplier-crm-table';
import './supplier-crm.style.css';

interface ISupplierCrmProps {
  isExpanded: boolean;
  dateRange: Range[];
  accessLevel:string;
  externalId:string;
}

const SupplierCrm: React.FC<ISupplierCrmProps> = ({ dateRange, accessLevel, externalId }) => {

  const [reset, setReset] = useState<boolean>(false);
  const [supplierId, setSupplier] = useState<string>(externalId); //'LAPX8087'
  const [shipPointId, setShipPointId] = useState<string>('');
  const [facilityName, setFacilityName] = useState<string>('');
  const [protectionType, setProtectionType] = useState<string>('');
  const [vendorList, setVendorList] = useState<ISelectElement[]>([]);
  const [totalData, setTotalData] = useState<ISupplierCrmAllDetails>();
  const [searchTotalData, setSearchTotalData] =
    useState<ISupplierCrmAllDetails | null>(null);
  const [shipPointList, setShipPointList] = useState<ISelectElement[]>([]);
  const [facilityNameList, setFacilityNameList] = useState<ISelectElement[]>(
    []
  );
  const [protectionTypeList, setProtectionTypeList] = useState<
    ISelectElement[]
  >([]);
  const [isDownLoadUploadable, setIsDownLoadUploadable] =
    useState<boolean>(false);
  const [csvData, setCSVData] = useState<[]>([]);
  const csvDownloadRef = useRef<any>(null);

  const dispatch = useDispatch();

  const initialParams: ISupplierCrmDetailsParam = {
    startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
    endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    pageSize: 30,
    pageNumber: 1,
    sortColumn: 'capacityDate',
    sortOrderDesc: false,
    vendorId: supplierId,
    shipPointId: '',
    protectionType: '',
    facility: '',
  };
  const [tableParams, setTableParams] =
    useState<ISupplierCrmDetailsParam>(initialParams);

  useEffect(() => {
    setTableParams(initialParams);
  }, []);

  const formatToSelectFilterType = (rawArray: string[]) => {
    return rawArray.map((item) => {
      return {
        key: nanoid(),
        value: item,
      };
    });
  };

  const getSupplierId = (searchStr?: string) => {
    dispatch(setLoading(true));
    getSupplierCrmFIlter({ selectField: 'vendorId', vendorId: searchStr ?? '' })
      .then((res) => {
        setVendorList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch supplier IDs');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getShipPointId = (isSearch: boolean, searchStr?: string) => {
    dispatch(setLoading(true));
    getSupplierCrmFIlter({
      selectField: 'all',
      vendorId: supplierId,
      shipPointId: searchStr ?? '',
    })
      .then((res) => {
        if (isSearch) {
          setSearchTotalData(res.data.data ?? {});
        } else {
          setTotalData(res.data.data ?? {});
        }
      })
      .catch(() => {
        getErrorAlert('Failed to fetch ship point IDs');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const onSearchShipment = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getSupplierId(searchStr);
    } else {
      setVendorList([]);
    }
  };

  const onSearchShipPointId = (searchStr: string) => {
    if (searchStr.length > 0 && searchStr.length < 4) {
      setSearchTotalData({});
    } else {
      getShipPointId(true, searchStr);
    }
  };

  const getErrorAlert = (message:string) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: alertStates.ERROR,
        alertTitle: message,
        alertDescription: '',
      })
    );
  };

  const alertToGetAllFiltersSelected = () => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: alertStates.INFO,
        alertTitle: 'All filters needs to be selected for retrieving Data!!',
        alertDescription: '',
      })
    );
  };

  const onSelectOfShipPointID = (val: string, searchStr?: string | null) => {
    if (searchStr !== null) {
      setTotalData(searchTotalData!);
    }
    setShipPointId(val);
  };

  useEffect(() => {
    dispatch(setLoading(true));
    if (externalId === 'NA') {
      getSupplierId();
    }
  }, [externalId]);

  useEffect(() => {
    setShipPointId('');
    setFacilityNameList([]);
    setProtectionTypeList([]);
    setTableParams({ ...tableParams, vendorId: supplierId, shipPointId: '' });
    dispatch(setLoading(true));
    if (supplierId.length > 0) {
      alertToGetAllFiltersSelected();
      setReset(true);
      getShipPointId(false);
    }
  }, [supplierId]);

  useEffect(() => {
    if (totalData) {
      setShipPointList(formatToSelectFilterType(Object.keys(totalData)));
    }
  }, [totalData]);

  useEffect(() => {
    if (searchTotalData) {
      setShipPointList(formatToSelectFilterType(Object.keys(searchTotalData)));
      setReset(false);
    }
  }, [searchTotalData]);

  useEffect(() => {
    if (dateRange[0]?.startDate && dateRange[0]?.endDate) {
      setTableParams({
        ...tableParams,
        startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
        endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
      });
    }
  }, [dateRange]);

  useEffect(() => {
    setFacilityName('');
    setFacilityNameList([]);
    setProtectionTypeList([]);
    alertToGetAllFiltersSelected();
    setTableParams({ ...tableParams, shipPointId: shipPointId, facility: '' });
    if (shipPointId.length > 0) {
      for (let item in totalData) {
        if (item === shipPointId) {
          setFacilityNameList(
            formatToSelectFilterType(Object.keys(totalData[item]))
          );
        }
      }
    }
  }, [shipPointId]);

  useEffect(() => {
    setProtectionType('');
    setProtectionTypeList([]);
    setTableParams({
      ...tableParams,
      facility: facilityName,
      protectionType: '',
    });
    alertToGetAllFiltersSelected();
    if (facilityName.length > 0) {
      for (let item in totalData) {
        if (item === shipPointId) {
          for (let facilityNameItem in totalData[item]) {
            if (facilityNameItem === facilityName) {
              setProtectionTypeList(
                formatToSelectFilterType(totalData[item][facilityNameItem])
              );
            }
          }
        }
      }
    }
  }, [facilityName]);

  useEffect(() => {
    setTableParams({ ...tableParams, protectionType: protectionType });
  }, [protectionType]);

  useEffect(() => {
    if (
      validEntityString(tableParams.vendorId) &&
      validEntityString(tableParams.shipPointId) &&
      validEntityString(tableParams.facility) &&
      validEntityString(tableParams.protectionType)
    ) {
      setIsDownLoadUploadable(true);
    } else {
      setIsDownLoadUploadable(false);
    }
  }, [tableParams]);

  const [isUploadModalOpen, setUploadModalOpen] = useState<boolean>(false);

  const downloadCSV = () => {
    dispatch(setLoading(true));
    getSupplierCrmDetails({ ...tableParams, pageSize: 180 }).then((res) => {
      setCSVData(formatSupplierCRMResponseForCSV(res.data.data, tableParams));
    }).catch((err) => {
      console.log(err);
      getErrorAlert('Failed to download csv file');
    }).finally(()=>{
      dispatch(setLoading(false));
    });
  };

  useDidComponentUpdate(() => {    
    csvDownloadRef.current.link.click()
  }, [csvData]);
  return (
    <section>
      <div
        className='supplier-crm-wrapper'
        data-testid='supplier-crm'>
        <div className='supplier-crm-filter-upload-wrapper'>
          <div className='supplier-crm-filter-wrapper'>
            {externalId === 'NA' && (
              <div className='filter'>
                <p className='query-text'>{labels.supplierId}</p>
                <SingleSelect
                  dataTestId='supplier'
                  buttonTittle='Select Supplier ID'
                  minLength={4}
                  data={vendorList}
                  onRadioClick={(ele) => setSupplier(ele.value)}
                  onSearchValue={(value) => onSearchShipment(value)}
                  className='selectWrapper'
                  search
                />
              </div>
            )}
            <div className='filter'>
              <p className='query-text'>{labels.shipPointId}</p>
              <SingleSelect
                buttonTittle='Select ID'
                dataTestId='shipPoint'
                data={shipPointList}
                minLength={4}
                onRadioClick={(ele, searchStr) =>
                  onSelectOfShipPointID(ele.value, searchStr)
                }
                onSearchValue={(ele) => onSearchShipPointId(ele)}
                disabled={ supplierId === 'NA' || supplierId.length === 0}
                className='selectWrapper'
                search
                resetSelectedValue={reset}
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.facilityName}</p>
              <SingleSelect
                dataTestId='name'
                buttonTittle='Select Name'
                data={facilityNameList}
                onRadioClick={(ele) => setFacilityName(ele.value)}
                disabled={shipPointId.length === 0}
                className='selectWrapper'
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.protectionType}</p>
              <SingleSelect
                dataTestId='type'
                buttonTittle='Select Type'
                data={protectionTypeList}
                onRadioClick={(ele) => setProtectionType(ele.value)}
                disabled={facilityName.length === 0}
                className='selectWrapper'
              />
            </div>
          </div>
          {accessLevel ==='WRITE' && (
            <div className='upload-download-supplier-wrapper'>
              <Tooltip
                title='download csv file'
                placement='top'>
                <CloudDownloadOutlinedIcon
                  data-testid='download-button-supplier-crm'
                  onClick={downloadCSV}
                  className={classNames(
                    'uploadDownload-button',
                    !isDownLoadUploadable ? 'disabled' : ''
                  )}>
                </CloudDownloadOutlinedIcon>
              </Tooltip>
              <Tooltip
                title='upload csv file'
                placement='top'>
                <CloudUploadOutlinedIcon
                  data-testid='upload-button-supplier-crm'
                  onClick={() => setUploadModalOpen(true)}
                  className={classNames(
                    'uploadDownload-button',
                    !isDownLoadUploadable ? 'disabled' : ''
                  )}></CloudUploadOutlinedIcon>
              </Tooltip>
            </div>
          )}
        </div>
        <SupplierCrmTable
          isWriteAccess={accessLevel ==='WRITE'}
          param={tableParams!}
          range={dateRange}
        />
      </div>
      <UploadModal
        isOpen={isUploadModalOpen}
        setOpen={setUploadModalOpen} 
        schema={externalizationSchema.SUPPLIER}></UploadModal>
        <CSVLink
          data={csvData}
          headers={supplierCRMCSVHeaders}
          target="_blank"
          filename='supplier-crm.csv'
          ref={csvDownloadRef}
        />
    </section>
  );
};
export default SupplierCrm;

