import CloudDownloadOutlinedIcon from '@mui/icons-material/CloudDownloadOutlined';
import CloudUploadOutlinedIcon from '@mui/icons-material/CloudUploadOutlined';
import { Tooltip } from '@mui/material';
import classNames from 'classnames';
import { format } from 'date-fns';
import React, { useEffect, useRef, useState } from 'react';
import { CSVLink } from 'react-csv';
import { Range } from 'react-date-range';
import { useDispatch } from 'react-redux';
import { carrierCRMCSVHeaders, externalizationSchema, labels } from '../../../../../common/constants';
import {
  alertStates, ICarrierCrmDetailsParam
} from '../../../../../common/interfaces';
import {
  fetchUserRole,
  formatCarrierCRMResponseForCSV, formatToSelectFilterType, getCarrierCrmDetails,
  getCarrierCrmFIlter,
  validEntityString
} from '../../../../../common/utils';
import SingleSelect, {
  ISelectElement
} from '../../../../../components/SingleSelect';
import { useDidComponentUpdate } from '../../../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import UploadModal from '../upload-modal/UploadModal.component';
import CarrierCrmTable from './carrier-crm-table/carrier-crm-table';
import './carrier-crm.style.css';
interface ICarrierCrmProps {
  dateRange: Range[];
  accessLevel:string;
  externalId:string;
}

const CarrierCRM: React.FC<ICarrierCrmProps> = ({ dateRange, accessLevel, externalId }) => {

  const [reset, setReset] = useState<boolean>(false);

  const [carrierUserId, setCarrierUserId] = useState<string>(externalId);//CNU103
  const [carrierUserIdList, setCarrierUserIdList] = useState<ISelectElement[]>(
    []
  );
  const [carrierId, setCarrier] = useState<string>('');
  const [carrierList, setCarrierList] = useState<ISelectElement[]>([]);
  const [origin, setOrigin] = useState<string>('');
  const [originList, setOriginList] = useState<ISelectElement[]>([]);
  const [destination, setDestination] = useState<string>('');
  const [destinationList, setDestinationList] = useState<ISelectElement[]>([]);
  const [facilityName, setFacilityName] = useState<string>('');
  const [facilityNameList, setFacilityNameList] = useState<ISelectElement[]>(
    []
  );
  const [protectionType, setProtectionType] = useState<string>('');
  const [protectionTypeList, setProtectionTypeList] = useState<
    ISelectElement[]
  >([]);
  const [mode, setMode] = useState<string>('');
  const [modeList, setModeList] = useState<ISelectElement[]>([]);

  const [isDownLoadUploadable, setIsDownLoadUploadable] =
    useState<boolean>(false);
  const [csvData, setCSVData] = useState<[]>([]);
  const csvDownloadRef = useRef<any>(null);

  const dispatch = useDispatch();

  const initialParams: ICarrierCrmDetailsParam = {
    startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
    endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    pageSize: 30,
    pageNumber: 1,
    sortColumn: 'capacityDate',
    sortOrderDesc: false,
    carrierUserId: carrierUserId,
    carrierId: '',
    origin: '',
    destination: '',
    facility: '',
    protectionType: '',
    mode: '',
  };
  const [tableParams, setTableParams] =
    useState<ICarrierCrmDetailsParam>(initialParams);

  useEffect(() => {
    setTableParams(initialParams);
  }, []);

  const getCarrierUserId = (searchStr?: string) => {
    dispatch(setLoading(true));
    getCarrierCrmFIlter({
      selectField: 'carrieruserid',
      carrierUserId: searchStr ?? '',
    })
      .then((res) => {
        setCarrierUserIdList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch carrier user IDs');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getCarrierId = (searchStr?: string) => {
    dispatch(setLoading(true));
    getCarrierCrmFIlter({
      selectField: 'carrierId',
      carrierUserId: carrierUserId,
      carrierId: searchStr ?? '',
    })
      .then((res) => {
        setCarrierList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch carrier IDs');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getOrigin = (searchStr?: string) => {
    dispatch(setLoading(true));
    getCarrierCrmFIlter({
      selectField: 'origin',
      carrierUserId: carrierUserId,
      carrierId: carrierId ?? '',
      origin: searchStr ?? '',
    })
      .then((res) => {
        setOriginList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch origins');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getDestination = (searchStr?: string) => {
    dispatch(setLoading(true));
    getCarrierCrmFIlter({
      selectField: 'destination',
      carrierUserId: carrierUserId,
      carrierId: carrierId ?? '',
      origin: origin ?? '',
      destination: searchStr ?? '',
    })
      .then((res) => {
        setDestinationList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch destinations');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getFacility = () => {
    dispatch(setLoading(true));
    getCarrierCrmFIlter({
      selectField: 'facility',
      carrierUserId: carrierUserId,
      carrierId: carrierId ?? '',
      origin: origin ?? '',
      destination: destination ?? '',
    })
      .then((res) => {
        setFacilityNameList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch facilities');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getProtectionType = () => {
    dispatch(setLoading(true));
    getCarrierCrmFIlter({
      selectField: 'protectionType',
      carrierUserId: carrierUserId,
      carrierId: carrierId ?? '',
      origin: origin ?? '',
      destination: destination ?? '',
      facility: facilityName ?? '',
    })
      .then((res) => {
        setProtectionTypeList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch protection types');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getMode = () => {
    dispatch(setLoading(true));
    getCarrierCrmFIlter({
      selectField: 'mode',
      carrierUserId: carrierUserId,
      carrierId: carrierId ?? '',
      origin: origin ?? '',
      destination: destination ?? '',
      facility: facilityName ?? '',
      protectionType: protectionType ?? '',
    })
      .then((res) => {
        setModeList(formatToSelectFilterType(res.data.data));
      })
      .catch(() => {
        getErrorAlert('Failed to fetch modes');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const onSearchCarrierUserId = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getCarrierUserId(searchStr);
    } else {
      setCarrierUserIdList([]);
    }
  };

  const onSearchCarrierId = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getCarrierId(searchStr);
    } else {
      setCarrierList([]);
    }
  };

  const onSearchOrigin = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getOrigin(searchStr);
    } else {
      setOriginList([]);
    }
  };

  const onSearchDestination = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getDestination(searchStr);
    } else {
      setDestinationList([]);
    }
  };

  const getErrorAlert = (message: string) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: alertStates.ERROR,
        alertTitle: message,
        alertDescription: '',
      })
    );
  };

  const alertToGetAllFiltersSelected = () => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: alertStates.INFO,
        alertTitle: 'All filters needs to be selected for retrieving Data!!',
        alertDescription: '',
      })
    );
  };

  useEffect(() => {
    if (dateRange[0]?.startDate && dateRange[0]?.endDate) {
      setTableParams({
        ...tableParams,
        startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
        endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
      });
    }
  }, [dateRange]);

  useEffect(() => {
    dispatch(setLoading(true));
    if (externalId==='NA') {
      getCarrierUserId();
    }
  }, [externalId]);

  useEffect(() => {
    setCarrier('');
    setCarrierList([]);
    setOriginList([]);
    setDestinationList([]);
    setFacilityNameList([]);
    setProtectionTypeList([]);
    setModeList([]);
    setTableParams({
      ...tableParams,
      carrierUserId: carrierUserId,
      carrierId: '',
    });
    dispatch(setLoading(true));
    if (carrierUserId.length > 0) {
      alertToGetAllFiltersSelected();
      setReset(true);
      getCarrierId();
    }
  }, [carrierUserId]);

  useEffect(() => {
    setOrigin('');
    setOriginList([]);
    setDestinationList([]);
    setFacilityNameList([]);
    setProtectionTypeList([]);
    setModeList([]);
    alertToGetAllFiltersSelected();
    setTableParams({ ...tableParams, carrierId: carrierId, origin: '' });
    if (carrierId.length > 0) {
      getOrigin();
    }
  }, [carrierId]);

  useEffect(() => {
    setDestination('');
    setDestinationList([]);
    setFacilityNameList([]);
    setProtectionTypeList([]);
    setModeList([]);
    alertToGetAllFiltersSelected();
    setTableParams({ ...tableParams, origin: origin, destination: '' });
    if (origin.length > 0) {
      getDestination();
    }
  }, [origin]);

  useEffect(() => {
    setFacilityName('');
    setFacilityNameList([]);
    setProtectionTypeList([]);
    setModeList([]);
    alertToGetAllFiltersSelected();
    setTableParams({ ...tableParams, destination: destination, facility: '' });
    if (destination.length > 0) {
      getFacility();
    }
  }, [destination]);

  useEffect(() => {
    setProtectionType('');
    setProtectionTypeList([]);
    setModeList([]);
    alertToGetAllFiltersSelected();
    setTableParams({
      ...tableParams,
      facility: facilityName,
      protectionType: '',
    });
    if (facilityName.length > 0) {
      getProtectionType();
    }
  }, [facilityName]);

  useEffect(() => {
    setMode('');
    setModeList([]);
    alertToGetAllFiltersSelected();
    setTableParams({
      ...tableParams,
      protectionType: protectionType,
      mode: '',
    });
    if (protectionType.length > 0) {
      getMode();
    }
  }, [protectionType]);

  useEffect(() => {
    setTableParams({ ...tableParams, mode: mode });
  }, [mode]);

  useEffect(() => {
    if (
      validEntityString(tableParams.carrierUserId) &&
      validEntityString(tableParams.carrierId) &&
      validEntityString(tableParams.origin) &&
      validEntityString(tableParams.destination) &&
      validEntityString(tableParams.facility) &&
      validEntityString(tableParams.protectionType) &&
      validEntityString(tableParams.mode)
    ) {
      setIsDownLoadUploadable(true);
    } else {
      setIsDownLoadUploadable(false);
    }
  }, [tableParams]);

  const [isUploadModalOpen, setUploadModalOpen] = useState<boolean>(false);

  const downloadCSV = () => {
    dispatch(setLoading(true));
    getCarrierCrmDetails({ ...tableParams, pageSize: 180 }).then((res) => {
      setCSVData(formatCarrierCRMResponseForCSV(res.data.data, tableParams));
    }).catch((err) => {
      console.log(err);
      getErrorAlert('Failed to download csv file ');
    }).finally(() => {
      dispatch(setLoading(false));
    });
  };

  useDidComponentUpdate(() => {
    csvDownloadRef.current.link.click();
  }, [csvData]);

  return (
    <section>
      <div
        className='carrier-crm-wrapper'
        data-testid='carrier-crm'>
        <div className='carrier-crm-filter-upload-wrapper'>
          <div className='carrier-crm-filter-wrapper'>
            {externalId === 'NA' && (
              <div className='filter'>
                <p className='query-text'>{labels.carrierUserId}</p>
                <SingleSelect
                  dataTestId='carrierUserId'
                  buttonTittle='Select ID'
                  data={carrierUserIdList}
                  onRadioClick={(ele) => setCarrierUserId(ele.value)}
                  onSearchValue={(value) => onSearchCarrierUserId(value)}
                  className='selectWrapper'
                  search
                  minLength={4}
                />
              </div>
            )}
            <div className='filter'>
              <p className='query-text'>{labels.carrierId}</p>
              <SingleSelect
                dataTestId='carrier'
                buttonTittle='Select ID'
                data={carrierList}
                onRadioClick={(ele) => setCarrier(ele.value)}
                onSearchValue={(value) => onSearchCarrierId(value)}
                disabled={carrierUserId === 'NA' || carrierUserId.length===0}
                className='selectWrapper'
                search
                minLength={4}
                resetSelectedValue={reset}
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.origin}</p>
              <SingleSelect
                buttonTittle='Select Origin'
                dataTestId='origin'
                data={originList}
                onRadioClick={(ele) => setOrigin(ele.value)}
                onSearchValue={(value) => onSearchOrigin(value)}
                disabled={carrierId.length === 0}
                className='selectWrapper'
                search
                minLength={4}
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.destination}</p>
              <SingleSelect
                dataTestId='destination'
                buttonTittle='Select Destination'
                data={destinationList}
                onRadioClick={(ele) => setDestination(ele.value)}
                onSearchValue={(value) => onSearchDestination(value)}
                disabled={origin.length === 0}
                className='selectWrapper'
                search
                minLength={4}
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.facilityName}</p>
              <SingleSelect
                dataTestId='facility'
                buttonTittle='Select Name'
                data={facilityNameList}
                onRadioClick={(ele) => setFacilityName(ele.value)}
                disabled={destination.length === 0}
                className='selectWrapper'
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.protectionType}</p>
              <SingleSelect
                dataTestId='protection'
                buttonTittle='Select Type'
                data={protectionTypeList}
                onRadioClick={(ele) => setProtectionType(ele.value)}
                disabled={facilityName.length === 0}
                className='selectWrapper'
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.mode}</p>
              <SingleSelect
                dataTestId='mode'
                buttonTittle='Select Mode'
                data={modeList}
                onRadioClick={(ele) => setMode(ele.value)}
                disabled={protectionType.length === 0}
                className='selectWrapper'
              />
            </div>
          </div>
          { accessLevel === 'WRITE' && (
            <div className='upload-download-carrier-wrapper'>
              <Tooltip
                title='download csv file'
                placement='top'>
                <CloudDownloadOutlinedIcon
                  data-testid='download-button-carrier-crm'
                  onClick={downloadCSV}
                  className={classNames(
                    'uploadDownload-button',
                    !isDownLoadUploadable ? 'disabled' : ''
                  )}></CloudDownloadOutlinedIcon>
              </Tooltip>
              <Tooltip
                title='upload csv file'
                placement='top'>
                <CloudUploadOutlinedIcon
                  data-testid='upload-button-carrier-crm'
                  onClick={() => setUploadModalOpen(true)}
                  className={classNames(
                    'uploadDownload-button',
                    !isDownLoadUploadable ? 'disabled' : ''
                  )}></CloudUploadOutlinedIcon>
              </Tooltip>
            </div>
          )}
        </div>
        <CarrierCrmTable
          writeAccess={accessLevel === 'WRITE'}
          param={tableParams!}
          range={dateRange} 
          selectedMode={mode}/>
      </div>
      <UploadModal
        isOpen={isUploadModalOpen}
        setOpen={setUploadModalOpen}
        schema={externalizationSchema.CARRIER}></UploadModal>
      <CSVLink
        data={csvData}
        headers={carrierCRMCSVHeaders}
        target="_blank"
        filename='carrier-crm.csv'
        ref={csvDownloadRef}
      />
    </section>
  );
};
export default CarrierCRM;
