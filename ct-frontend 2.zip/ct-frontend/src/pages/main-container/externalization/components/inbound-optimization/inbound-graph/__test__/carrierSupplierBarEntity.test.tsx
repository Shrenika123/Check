import { cleanup, render } from '@testing-library/react';
import BarEntity from '../carrierSupplierBarEntity/carrier-supplier-entity';
afterEach(() => {
  cleanup();
});

jest.mock('recharts', () => {
  const OriginalModule = jest.requireActual('recharts');
  return {
    ...OriginalModule,
    ResponsiveContainer: ({ children }: { children: any }) => (
      <OriginalModule.ResponsiveContainer
        width={350}
        height={350}>
        {children}
      </OriginalModule.ResponsiveContainer>
    ),
  };
});

describe('Inbound Graph Entity', () => {
  test('render the Entity', () => {
    render(
      <BarEntity
        data={{ x: 20, y: 40 }}
        className={''}
      />
    );
  });
});
