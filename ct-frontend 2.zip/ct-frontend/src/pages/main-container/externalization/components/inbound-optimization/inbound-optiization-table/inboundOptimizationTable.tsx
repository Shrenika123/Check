import { Pagination } from '@mui/material';
import { format } from 'date-fns';
import { nanoid } from 'nanoid';
import { AutoComplete } from 'primereact/autocomplete';
import { classNames } from 'primereact/utils';
import { FC, useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import backicon from '../../../../../../assets/images/backicon.png';
import { labels, routes, tableConfig } from '../../../../../../common/constants';
import { alertStates, IGraphClickEvent, IInboundOptimizationCommonParams, IInboundOptimizationTable, IInboundOptimizationTableParams } from '../../../../../../common/interfaces';
import { getGMTTimeStamp, getInboundOptimizationTable, getInboundOptimizationTableCount } from '../../../../../../common/utils';
import ConfirmationBox from '../../../../../../components/confimation-box/ConfirmationBox.component';
import { useDidComponentUpdate } from '../../../../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';
import './inboundOptimizationTable.css';

interface Props {
  graphParams: IInboundOptimizationCommonParams,
  graphClickEvent: IGraphClickEvent;
}

interface IPageAndFilter {
  page: number;
  selectedPoNumber: string;
  selectedShipId: string;
  selectedLoadId: string;
}

const InBoundOptimizationTable: FC<Props> = ({ graphParams, graphClickEvent }) => {

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const initPageAndFilter: IPageAndFilter = {
    page: 1,
    selectedPoNumber: '',
    selectedShipId: '',
    selectedLoadId: ''
  };

  const [tableData, setTableData] = useState<IInboundOptimizationTable[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [showPOFilter, setShowPOFilter] = useState<boolean>();
  const [showLoadFilter, setShowLoadFilter] = useState<boolean>();
  const [showShipFilter, setShowShipFilter] = useState<boolean>();
  const [poNumberList, setPoNumberList] = useState<string[]>([]);
  const [searchPoNumber, setSearchPoNumber] = useState<string>('');
  const [loadIdList, setLoadIdList] = useState<string[]>([]);
  const [searchLoadId, setSearchLoadId] = useState<string>('');
  const [shipmentIdList, setShipmentIdList] = useState<string[]>([]);
  const [searchShipmentId, setSearchShipmentId] = useState<string>('');
  const [pageAndFilter, setPageAndFilter] = useState<IPageAndFilter>(initPageAndFilter);
  const [isConfirmBoxOpen, setConfirmBoxOpen] = useState<boolean>(false);
  const clickedPORef = useRef<{ poNumber: string, mabd: string; }>();

  const prevPageAndFilter = useRef<IPageAndFilter>();

  const paginationRef = useRef<any>(null);
  const tableRef = useRef<any>(null);

  useDidComponentUpdate(() => {

    if(!prevPageAndFilter.current){ 
      getTableDetails('all', pageAndFilter.selectedPoNumber, pageAndFilter.selectedLoadId, pageAndFilter.selectedShipId, 1);
      getTotalRecord('all', pageAndFilter.selectedPoNumber, pageAndFilter.selectedLoadId, pageAndFilter.selectedShipId, 1);
    }
    else{

      if(prevPageAndFilter.current.selectedLoadId !== pageAndFilter.selectedLoadId ||
        prevPageAndFilter.current.selectedShipId !== pageAndFilter.selectedShipId ||
        prevPageAndFilter.current.selectedPoNumber !== pageAndFilter.selectedPoNumber
        ){
        getTableDetails('all', pageAndFilter.selectedPoNumber, pageAndFilter.selectedLoadId, pageAndFilter.selectedShipId, 1);
        getTotalRecord('all', pageAndFilter.selectedPoNumber, pageAndFilter.selectedLoadId, pageAndFilter.selectedShipId, 1);
        }
      else{
        getTableDetails('all', pageAndFilter.selectedPoNumber, pageAndFilter.selectedLoadId, pageAndFilter.selectedShipId, pageAndFilter.page);
      }
    }
    prevPageAndFilter.current = pageAndFilter;
  }, [pageAndFilter]);

  useEffect(() => {
    prevPageAndFilter.current = undefined;
    setPageAndFilter({ ...initPageAndFilter });
    setShowPOFilter(false);
    setShowLoadFilter(false);
    setShowShipFilter(false);
    setPoNumberList([]);
    setLoadIdList([]);
    setShipmentIdList([]);
  }, [graphClickEvent]);

  const getTableDetails = (fetchType?: 'poNumber' | 'shipmentId' | 'loadId' | 'all', poNumVar?: string, loadIdVar?: string, shipIdVar?: string, pageNoVar?: number) => {
    fetchType === 'all' && setTableData([]);
    if(fetchType === 'all')
    dispatch(setLoading(true));
    const request: IInboundOptimizationTableParams = {
      ...graphParams,
      startDate: graphClickEvent.capacityDate,
      endDate: graphClickEvent.capacityDate,
      shipPointId: graphParams.dcId,
      selectField: fetchType,
      poNumberSearch: poNumVar,
      loadIdSearch: loadIdVar,
      shipmentIdSearch: shipIdVar,
      pageSize: tableConfig.pageSize,
      loadType: graphClickEvent.loadType,
      pageNumber: pageNoVar ? pageNoVar : pageAndFilter.page,
    };

    getInboundOptimizationTable(request).then((res) => {
      switch (true) {
        case fetchType === 'poNumber':
          setPoNumberList(res.data.data.map((value: any) => value.selectFieldValue));
          break;
        case fetchType === 'loadId':
          setLoadIdList(res.data.data.map((value: any) => value.selectFieldValue));
          break;
        case fetchType === 'shipmentId':
          setShipmentIdList(res.data.data.map((value: any) => value.selectFieldValue));
          break;
        case fetchType === 'all':
          setTableData(res.data.data.map((value: IInboundOptimizationTable) => { return { ...value, key: nanoid() }; }));
          break;
      }
    }).catch(() => {
      dispatch(
        setShowAlert({
          showAlert: true,
          alertType: alertStates.ERROR,
          alertTitle: 'Failed to fetch' + fetchType === 'all'? 'table':'filter' + ' data',
        })
      );

    }).finally(() => {
      dispatch(setLoading(false));
    });
  };

  useDidComponentUpdate(()=>{
    tableRef.current?.scrollTo({ left: 0 });
    paginationRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  },[tableData])

  const getTotalRecord = (fetchType?: 'poNumber' | 'shipmentId' | 'loadId' | 'all', poNumVar?: string, loadIdVar?: string, shipIdVar?: string, pageNoVar?: number) => {
    setTotalRecords(0);
    const request: IInboundOptimizationTableParams = {
      ...graphParams,
      startDate: graphClickEvent.capacityDate,
      endDate: graphClickEvent.capacityDate,
      shipPointId: graphParams.dcId,
      selectField: fetchType,
      poNumberSearch: poNumVar,
      loadIdSearch: loadIdVar,
      shipmentIdSearch: shipIdVar,
      pageSize: tableConfig.pageSize,
      loadType: graphClickEvent.loadType,
      pageNumber: pageNoVar ? pageNoVar : pageAndFilter.page,
    };

    if (fetchType === 'all') {
      getInboundOptimizationTableCount(request).then((res) => {
        setTotalRecords(res.data.totalRecords);
      }).catch(()=>{
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.ERROR,
            alertTitle: 'Failed to fetch total pages',
            alertDescription:'',
          })
        );
      });
    }
  };

  useDidComponentUpdate(()=>{
    tableRef.current?.scrollTo({ left: 0 });
    paginationRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  },[totalRecords])

  const handleFilterCross = (filterType: 'poNum' | 'shipId' | 'loadId' | undefined) => {
    switch (filterType) {
      case 'poNum':
        setShowPOFilter(false);
        setSearchPoNumber('')
        setPageAndFilter({ ...pageAndFilter, page: 1, selectedPoNumber: '' })
        break;
      case 'loadId':
        setShowLoadFilter(false);
        setSearchLoadId('')
        setPageAndFilter({ ...pageAndFilter, page: 1, selectedLoadId: '' })
        break;
      case 'shipId':
        setShowShipFilter(false);
        setSearchShipmentId('')
        setPageAndFilter({ ...pageAndFilter, page: 1, selectedShipId: '' })
        break;
      default:
        break;
    }
  };


  const assignedHeaders = () => {
    return (
      <>
        <th className='custom-th-assigned'>
          {
            showPOFilter ? (
              <>
                <AutoComplete
                  onKeyPress={(e) => e.code=== "Space" && e.preventDefault()}
                  autoFocus
                  minLength={4}
                  delay={500}
                  showEmptyMessage={true}
                  value={searchPoNumber}
                  onChange={(e) => setSearchPoNumber(e.value.replace(/\s/g, ''))}
                  suggestions={poNumberList}
                  completeMethod={(event) => getTableDetails('poNumber', event.query,pageAndFilter.selectedLoadId,pageAndFilter.selectedShipId,1)}
                  onSelect={(event) => setPageAndFilter({ ...pageAndFilter, page: 1, selectedPoNumber: event.value })}
                  className='inbound-table-filter'
                />
                <i data-testid='container-search-reset' className="pi pi-times" onClick={() => handleFilterCross('poNum')} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
              </>
            ) : <div className='inbound-table-filter'>PO No.
              <i data-testid='container-search' className="pi pi-search" onClick={() => setShowPOFilter(true)} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
            </div>
          }
        </th>
        <th className='custom-th-assigned'>Origin</th>
        <th className='custom-th-assigned'>Destination</th>
        <th className='custom-th-assigned'>
          {
            showShipFilter ? (
              <>
                <AutoComplete
                  onKeyPress={(e) => e.code === "Space" && e.preventDefault()}
                  autoFocus
                  minLength={4}
                  delay={500}
                  showEmptyMessage={true}
                  value={searchShipmentId}
                  onChange={(e) => setSearchShipmentId(e.value.replace(/\s/g, ''))}
                  suggestions={shipmentIdList}
                  completeMethod={(event) => getTableDetails('shipmentId', pageAndFilter.selectedPoNumber, pageAndFilter.selectedLoadId, event.query,1)}
                  onSelect={(event) => setPageAndFilter({ ...pageAndFilter, page: 1, selectedShipId: event.value })}
                  className='inbound-table-filter'
                />
                <i data-testid='container-search-reset' className="pi pi-times" onClick={() => handleFilterCross('shipId')} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
              </>
            ) : <div className='inbound-table-filter'>Shipment ID
              <i data-testid='container-search' className="pi pi-search" onClick={() => setShowShipFilter(true)} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
            </div>
          }

        </th>
        <th className='custom-th-assigned'>
          {
            showLoadFilter ? (
              <>
                <AutoComplete
                  onKeyPress={(e) => e.code === "Space" && e.preventDefault()}
                  autoFocus
                  minLength={4}
                  delay={500}
                  showEmptyMessage={true}
                  value={searchLoadId}
                  onChange={(e) => setSearchLoadId(e.value.replace(/\s/g, ''))}
                  suggestions={loadIdList}
                  completeMethod={(event) => getTableDetails('loadId', pageAndFilter.selectedPoNumber, event.query,pageAndFilter.selectedShipId,1)}
                  onSelect={(event) => setPageAndFilter({ ...pageAndFilter, page: 1, selectedLoadId: event.value })}
                  className='inbound-table-filter'
                />
                <i data-testid='container-search-reset' className="pi pi-times" onClick={() => handleFilterCross('loadId')} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
              </>
            ) : <div className='inbound-table-filter'>Load ID
              <i data-testid='container-search' className="pi pi-search" onClick={() => setShowLoadFilter(true)} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
            </div>
          }
        </th>
        <th className='custom-th-assigned'>Planned Pickup Date</th>
        <th className='custom-th-assigned'>Scheduled Delivery</th>
        <th className='custom-th-assigned'>MABD</th>
        <th className='custom-th-assigned'>Carrier ID</th>
        <th className='custom-th-assigned'>Lane ID</th>
        <th id='scheduler-date' className='custom-th-assigned'>Scheduler Appointment ID by Date</th>
      </>
    );
  };

  const pendingHeaders = () => {
    return (
      <>
        <th className='custom-th-pending'>
          {
            showPOFilter ? (
              <>
                <AutoComplete
                  onKeyPress={(e) => e.code === "Space" && e.preventDefault()}
                  autoFocus
                  minLength={4}
                  delay={500}
                  showEmptyMessage={true}
                  value={searchPoNumber}
                  onChange={(e) => setSearchPoNumber(e.value.replace(/\s/g, ''))}
                  suggestions={poNumberList}
                  completeMethod={(event) => getTableDetails('poNumber', event.query,pageAndFilter.selectedLoadId,pageAndFilter.selectedShipId,1)}
                  onSelect={(event) => setPageAndFilter({ ...pageAndFilter, page: 1, selectedPoNumber: event.value })}
                  className='inbound-table-filter'
                />
                <i data-testid='container-search-reset' className="pi pi-times" onClick={() => handleFilterCross('poNum')} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
              </>
            ) : <div className='inbound-table-filter'>PO No.
              <i data-testid='container-search' className="pi pi-search" onClick={() => setShowPOFilter(true)} style={{ fontSize: '.9rem', fontWeight: 'bold', marginLeft: '.4rem', cursor: 'pointer' }}></i>
            </div>
          }
        </th>
        <th className='custom-th-pending'>Origin</th>
        <th className='custom-th-pending'>Destination</th>
        <th className='custom-th-pending'>MABD</th>
      </>
    );
  };

  const checkNullorNADate = (dateString : string)=>{
      if( !dateString || dateString === null || dateString === 'NA' )
          return 'NA'
       else 
        return format(getGMTTimeStamp(dateString), 'MM/dd/yyyy')
  }

  const handlePOClick = (data: { poNumber: string, mabd: string; }) => {
    clickedPORef.current = data;
    setConfirmBoxOpen(true);
  };

  const navigateToPOLine = () => {
    navigate(`/${routes.lineDetails}`, { state: clickedPORef.current });
  };

  const tableClass = classNames('inbound-optimization-table',{
    'assigned-table-width': graphClickEvent.loadType === 'assignedLoad' || graphClickEvent.loadType === 'unAssignedLoad'
  })

  return (
    <section className='inbound-optimization-table-page-wrapper'>
      <section ref={tableRef} className='inbound-optimization-table-wrapper'>
        <table className={tableClass}>
          <thead>
            {graphClickEvent.loadType.toLowerCase() === 'pendingload' ? pendingHeaders() : assignedHeaders()}
          </thead>
          <tbody>
            {graphClickEvent.loadType.toLowerCase() === 'pendingload' ?
              tableData.map((value) => {
                return (
                  <tr className='custom-tr' key={value.key}>
                    <td onClick={() => handlePOClick({ poNumber: value.poNumber, mabd: value.mabd })} className='custom-td hyperlink'>{value.poNumber}</td>
                    <td className='custom-td'>{value.origin}</td>
                    <td className='custom-td'>{value.destination}</td>
                    <td className='custom-td'>{checkNullorNADate(value.mabd)}</td>
                  </tr>);
              })
              :
              tableData.map((value) => {
                return (
                  <tr className='custom-tr' key={value.key}>
                    <td onClick={() => handlePOClick({ poNumber: value.poNumber, mabd: value.mabd })} className='custom-td hyperlink'>{value.poNumber}</td>
                    <td className='custom-td'>{value.origin}</td>
                    <td className='custom-td'>{value.destination}</td>
                    <td className='custom-td'>{value.shipmentId}</td>
                    <td className='custom-td'>{value.loadId}</td>
                    <td className='custom-td'>{checkNullorNADate(value.plannedPickupDate)}</td>
                    <td className='custom-td'>{checkNullorNADate(value.scheduledDelivery)}</td>
                    <td className='custom-td'>{checkNullorNADate(value.mabd)}</td>
                    <td className='custom-td'>{value.carrierId}</td>
                    <td className='custom-td'>{value.laneId}</td>
                    <td className='custom-td'>{checkNullorNADate(value.schedulerAppointmentDate)}</td>
                  </tr>);
              })
            }

            {tableData && tableData.length < 3 && [...Array(3 - tableData.length)].map((_, index) => {
              return (
                <tr data-testid='filler' className='custom-tr' key={index}>
                  <td className='custom-td' colSpan={11}><div className='filler' ></div></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>
      <ConfirmationBox title='Leave this page?'
        content='You will be redirected to Line Management page'
        open={isConfirmBoxOpen} onClose={() => setConfirmBoxOpen(false)}
        confirmAction={() => navigateToPOLine()}
        cancelAction={() => setConfirmBoxOpen(false)}
        image={<img src={backicon} alt='' />} />
      <section className='paginated'>
        <Pagination
          ref={paginationRef}
          count={Math.ceil(totalRecords / tableConfig.pageSize)}
          shape='rounded'
          siblingCount={1}
          color={'standard'}
          showFirstButton
          showLastButton
          size='small'
          page={pageAndFilter.page}
          onChange={(e, value) => setPageAndFilter({ ...pageAndFilter, page: value })}
        />
      </section>
    </section>
  );

};

export default InBoundOptimizationTable;