import { cleanup, render } from '@testing-library/react';
import ToolTip from '../cutsomTooltop/customToottip';
afterEach(() => {
  cleanup();
});

describe('Inbound Graph', () => {
  test('should render tooltip', () => {
    render(
      <ToolTip
        active
        payload={[
          {
            payload: {
              assignedLoads: 2,
              unAssignedLoads: 3,
              pendingLoads: 4,
              supplierCapacity: 2,
              carrierCapacity: 4,
            },
          },
        ]}
      />
    );
  });

  test('should render tooltip when no value', () => {
    render(
      <ToolTip
        active
        payload={[
          {
            payload: {
              assignedLoads: '',
              unAssignedLoads: 3,
              pendingLoads: 4,
              supplierCapacity: 2,
              carrierCapacity: 4,
            },
          },
        ]}
      />
    );
  });
});
