import React from 'react';

interface CarrierSupplierEntityProps {
  data: any;
  className: string;
}

const CarrierSupplierEntity: React.FC<CarrierSupplierEntityProps> = ({
  data,
  className,
}) => {
  const { x, y } = data;
  return (
    <foreignObject
      x={x - 46}
      y={y}
      width={'100'}
      height={5}>
      <div className={className} />
    </foreignObject>
  );
};
export default CarrierSupplierEntity;
