import './inboundGraphLegend.style.css';
import warningInbound from '../../../../../../../assets/icons/warningInbound.svg';
import { labels } from '../../../../../../../common/constants';

interface IInboundGraphLegendProps {
  selectedValue: string;
}

const InboundGraphLegend: React.FC<IInboundGraphLegendProps> = ({
  selectedValue,
}) => {
  const getLegend = (
    Legend: React.ReactNode,
    label: string | React.ReactNode,
    type?: string
  ) => {
    const colorStyle = selectedValue === type ? '#B6F24D' : '';
    return (
      <div className='LegendEntityWrapper'>
        {Legend}
        <div style={{ color: colorStyle }}>{label}</div>
      </div>
    );
  };

  const getLegendSymbolStyle = (type: string) => {
    switch (type) {
      case 'assignedLoad':
        return 'assignedLoadStyle';
      case 'unAssignedLoad':
        return 'unAssignedLoadStyle';
      case 'pendingLoad':
        return 'pendingLoadStyle';
      case 'carrierCapacity':
        return 'carrierCapacityStyle';
      case 'supplierCapacity':
        return 'supplierCapacityStyle';
      case 'warning':
        return 'warningStyle';
    }
  };

  const getSymbol = (type: string) => {
    return <div className={getLegendSymbolStyle(type)} />;
  };

  return (
    <div className='LegendMainWrapper'>
      {getLegend(
        getSymbol('assignedLoad'),
        labels.assignedLoads,
        'assignedLoad'
      )}
      {getLegend(
        getSymbol('unAssignedLoad'),
        labels.unAssignedLoads,
        'unAssignedLoad'
      )}
      {getLegend(
        getSymbol('pendingLoad'),
        <>
          <p>{labels.pendingLoads}</p>
          <span>{'(Confirmed Orders)'}</span>
        </>,
        'pendingLoad'
      )}
      {getLegend(
        <img
          src={warningInbound}
          className={getLegendSymbolStyle('warning')}
          alt='warning'
        />,
        'PO > Capacity'
      )}
      {getLegend(
        getSymbol('supplierCapacity'),
        <>
          <p>{labels.supplierShippingCapacity}</p>
          <span>{'Capacity'}</span>
        </>
      )}
      {getLegend(getSymbol('carrierCapacity'), labels.carrierCapacity)}
    </div>
  );
};
export default InboundGraphLegend;
