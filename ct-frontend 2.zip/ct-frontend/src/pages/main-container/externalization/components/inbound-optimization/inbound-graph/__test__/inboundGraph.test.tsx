import { cleanup, render } from '@testing-library/react';
import { inboundGraphData } from '../../../../../../../common/mocks/promotionAndProcurement';
import InBoundGraph from '../inbound-graph';
afterEach(() => {
  cleanup();
});

jest.mock('recharts', () => {
  const OriginalModule = jest.requireActual('recharts');
  return {
    ...OriginalModule,
    ResponsiveContainer: ({ children }: { children: any }) => (
      <OriginalModule.ResponsiveContainer
        width={350}
        height={350}>
        {children}
      </OriginalModule.ResponsiveContainer>
    ),
  };
});

describe('Inbound Graph', () => {
  test('render the graph', () => {
    render(
      <InBoundGraph
        data={inboundGraphData}
        maxLoad={80}
        onClick={() => {}}
      />
    );
  });
});
