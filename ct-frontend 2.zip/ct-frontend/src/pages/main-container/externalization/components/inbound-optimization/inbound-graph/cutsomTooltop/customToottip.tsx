import React from 'react';
import { labels } from '../../../../../../../common/constants';
import { numberFormat } from '../../../../../../../common/utils';

const CustomTooltip: React.FC<any> = (props) => {
  const getToolTipValue = (value: string | number) => {
    return value === '' || value === 'NA' || value === null
      ? 'NA'
      : numberFormat(Number(value));
  };

  const checkIfValidPayload = () => {
    if (
      payload[0].payload.assignedLoads !== '' &&
      payload[0].payload.unAssignedLoads !== '' &&
      payload[0].payload.pendingLoads !== '' &&
      payload[0].payload.supplierCapacity !== '' &&
      payload[0].payload.carrierCapacity !== ''
    ) {
      return true;
    } else {
      return false;
    }
  };

  const { active, payload } = props;
  return active && active && payload.length && checkIfValidPayload() ? (
    <div className='customToolTip'>
      <p
        style={{
          color: '#B6F24D',
        }}>{`${labels.assignedLoads}: ${getToolTipValue(
        payload[0].payload.assignedLoads
      )}`}</p>
      <p style={{ color: '#1659ED' }}>
        {`${labels.unAssignedLoads}: ${getToolTipValue(
          payload[0].payload.unAssignedLoads
        )}`}
      </p>
      <p
        style={{
          color: '#FEBD02',
        }}>{`${labels.pendingLoads}: ${getToolTipValue(
        payload[0].payload.pendingLoads
      )}`}</p>
      <p
        style={{
          color: 'white',
        }}>{`${labels.supplierCapacity}: ${getToolTipValue(
        payload[0].payload.supplierCapacity
      )}`}</p>
      <p
        style={{
          color: 'red',
        }}>{`${labels.carrierCapacity}: ${getToolTipValue(
        payload[0].payload.carrierCapacity
      )}`}</p>
    </div>
  ) : null;
};
export default CustomTooltip;
