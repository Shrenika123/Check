import { Pagination } from '@mui/material';
import classNames from 'classnames';
import { format } from 'date-fns';
import moment from 'moment';
import React, { useEffect, useState } from 'react';
import { Range } from 'react-date-range';
import { useDispatch } from 'react-redux';
import { inboundOptimizationFilters, labels } from '../../../../../common/constants';
import { alertStates, IGraphClickEvent, IInboundGraphAPI, IInboundOptimizationCommonParams, IInboundOptimizationFilterParams } from '../../../../../common/interfaces';
import {
  formatToSelectFilterType, getDatesInRange, getInboundGraph,
  getInboundOptimizationFilter, getNPercentOfValue, paginationCount, removeTimeZone,
  sortDate, validEntityString
} from '../../../../../common/utils';
import SingleSelect, {
  ISelectElement
} from '../../../../../components/SingleSelect';
import { useDidComponentUpdate } from '../../../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import InboundGraph from './inbound-graph/inbound-graph';
import InBoundOptimizationTable from './inbound-optiization-table/inboundOptimizationTable';
import './inbound-optimization.style.css';

interface IInboundOptimizationProps {
  dateRange: Range[];
}
export interface IInboundGraphData {
  data: IInboundGraphAPI[];
  maxValue: number;
}

const InboundOptimization: React.FC<IInboundOptimizationProps> = ({
  dateRange,
}) => {
  
  const initGraphParam: IInboundOptimizationCommonParams = {
    startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
    endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    dcId: '',
    supplierId: '',
    carrierId: '',
    facility: '',
    protectionType: '',
  };

  const [dcIdList, setDcIdList] = useState<ISelectElement[]>([]);
  const [facilityNameList, setFacilityNameList] = useState<ISelectElement[]>(
    []
  );
  const [protectionTypeList, setProtectionTypeList] = useState<
    ISelectElement[]
  >([]);
  const [carrierIdList, setCarrierIdList] = useState<ISelectElement[]>([]);
  const [supplierIdList, setSupplierIdList] = useState<ISelectElement[]>([]);
  const [graphParam, setGraphParam] =
    useState<IInboundOptimizationCommonParams>(initGraphParam);
  const [graphClickEvent, setGraphClickEvent] = useState<IGraphClickEvent>();
  const dispatch = useDispatch();
  const [graphData, setGraphData] = useState<IInboundGraphData>({
    maxValue: -1,
    data: [],
  });
  const [graphPage, setGraphPage] = useState<number>(1);
  const [totalGraphCount, setTotalGraphCount] = useState<number>(0);
  const graphPageSize = 7;

  useDidComponentUpdate(() => {
    switch (true) {
      case graphParam.supplierId!.length > 0 ||
        graphParam.carrierId!.length > 0:
        break;
      case graphParam.protectionType!.length > 0:
        getCarrierId();
        getSupplierId();
        break;
      case graphParam.facility!.length > 0:
        getProtection();
        break;
      case graphParam.dcId!.length > 0:
        getFacility();
        break;
    }
  }, [graphParam]);

  const onRadioSelectParamUpdate = (
    ele: string,
    filter: inboundOptimizationFilters
  ) => {
    switch (filter) {
      case inboundOptimizationFilters.dcId:
        setFacilityNameList([]);
        setProtectionTypeList([]);
        setCarrierIdList([]);
        setSupplierIdList([]);
        setGraphData({maxValue:-1,data:[]})
        setGraphClickEvent(undefined);
        setGraphParam({ ...initGraphParam, dcId: ele });
        break;
      case inboundOptimizationFilters.protection:
        setCarrierIdList([]);
        setSupplierIdList([]);
        setGraphClickEvent(undefined);
        setGraphParam({
          ...initGraphParam,
          dcId: graphParam.dcId,
          facility: graphParam.facility,
          protectionType: ele,
        });
        break;
      case inboundOptimizationFilters.facility:
        setProtectionTypeList([]);
        setCarrierIdList([]);
        setSupplierIdList([]);
        setGraphData({ maxValue: -1, data: [] });
        setGraphClickEvent(undefined);
        setGraphParam({
          ...initGraphParam,
          dcId: graphParam.dcId,
          facility: ele,
        });
        break;
      case inboundOptimizationFilters.supplier:
        setGraphParam({ ...graphParam, supplierId: ele });
        setGraphClickEvent(undefined);
        break;
      case inboundOptimizationFilters.carrier:
        setGraphParam({ ...graphParam, carrierId: ele });
        setGraphClickEvent(undefined);
        break;
    }
  };

  const getDcId = (searchString: string = '') => {
    dispatch(setLoading(true));
    const params: IInboundOptimizationFilterParams = {
      selectField: 'shipPointId',
      shipPointId: searchString,
      startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    };
    getInboundOptimizationFilter(params)
      .then((res) => {
        setDcIdList(formatToSelectFilterType(res.data.data));
        res.data.data.length === 0 &&
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: 'DC IDs not available for selected date range',
              alertDescription: '',
            })
          );
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.ERROR,
            alertTitle: 'Failed to fetch DC IDs',
            alertDescription: '',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getFacility = (searchString: string = '') => {
    dispatch(setLoading(true));
    const params: IInboundOptimizationFilterParams = {
      selectField: 'facility',
      facility: searchString,
      shipPointId: graphParam.dcId,
      startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    };
    getInboundOptimizationFilter(params)
      .then((res) => {
        setFacilityNameList(formatToSelectFilterType(res.data.data));
        res.data.data.length === 0 &&
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: 'Facilities not available for selected filters',
              alertDescription: '',
            })
          );
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.ERROR,
            alertTitle: 'Failed to fetch facilities',
            alertDescription: '',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getProtection = (searchString: string = '') => {
    dispatch(setLoading(true));
    const params: IInboundOptimizationFilterParams = {
      selectField: 'protectionType',
      protectionType: searchString,
      shipPointId: graphParam.dcId,
      facility: graphParam.facility,
      startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    };
    getInboundOptimizationFilter(params)
      .then((res) => {
        setProtectionTypeList(formatToSelectFilterType(res.data.data));
        res.data.data.length === 0 &&
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: 'Protection Types not available for selected filters',
              alertDescription: '',
            })
          );
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.ERROR,
            alertTitle: 'Failed to fetch protection types',
            alertDescription:'',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getSupplierId = (searchString: string = '') => {
    dispatch(setLoading(true));
    const params: IInboundOptimizationFilterParams = {
      selectField: 'supplierId',
      supplierId: searchString,
      shipPointId: graphParam.dcId,
      facility: graphParam.facility,
      protectionType: graphParam.protectionType,
      startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    };
    getInboundOptimizationFilter(params)
      .then((res) => {
        setSupplierIdList(formatToSelectFilterType(res.data.data));
        res.data.data.length === 0 &&
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: 'Supplier IDs not available for selected filters',
              alertDescription: '',
            })
          );
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.ERROR,
            alertTitle: 'Failed to fetch supplier IDs',
            alertDescription: '',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getCarrierId = (searchString: string = '') => {
    dispatch(setLoading(true));
    const params: IInboundOptimizationFilterParams = {
      selectField: 'carrierId',
      carrierId: searchString,
      shipPointId: graphParam.dcId,
      facility: graphParam.facility,
      protectionType: graphParam.protectionType,
      startDate: format(dateRange[0].startDate!, 'yyyy-MM-dd'),
      endDate: format(dateRange[0].endDate!, 'yyyy-MM-dd'),
    };
    getInboundOptimizationFilter(params)
      .then((res) => {
        setCarrierIdList(formatToSelectFilterType(res.data.data));
        res.data.data.length === 0 &&
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.INFO,
              alertTitle: 'Carrier IDs not available for selected filters',
              alertDescription: '',
            })
          );
      })
      .catch(() => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.ERROR,
            alertTitle: 'Failed to fetch carrier IDs',
            alertDescription: '',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const onSearchDcId = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getDcId(searchStr);
    } else {
      setDcIdList([]);
    }
  };
  const onSearchSupplierId = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getSupplierId(searchStr);
    } else {
      setSupplierIdList([]);
    }
  };
  const onSearchCarrierId = (searchStr: string) => {
    if (!(searchStr.length > 0 && searchStr.length < 4)) {
      getCarrierId(searchStr);
    } else {
      setCarrierIdList([]);
    }
  };

  useEffect(() => {
    let countDiff;
    countDiff = moment(new Date(dateRange[0].endDate!)).diff(
      moment(new Date(dateRange[0].startDate!)),
      'days'
    );
    if (!moment(dateRange[0].endDate!).isSame(dateRange[0].startDate!)) {
      countDiff += 1;
    }
    setTotalGraphCount(
      paginationCount(countDiff > 0 ? countDiff : 1, graphPageSize)
    );
    
    setGraphData({maxValue:-1,data:[]})
    setGraphParam({
      ...initGraphParam,
    });
    setGraphClickEvent(undefined)
    getDcId();
    setFacilityNameList([]);
    setProtectionTypeList([]);
    setCarrierIdList([]);
    setSupplierIdList([]);
  }, [dateRange]);

  const getStartDate = () => {
    if (graphPage === 1) {
      return moment(removeTimeZone(dateRange[0].startDate!.toString())).format(
        'YYYY-MM-DD'
      );
    } else {
      return moment(removeTimeZone(dateRange[0].startDate!.toString()))
        .add(graphPageSize * (graphPage - 1), 'days')
        .format('YYYY-MM-DD');
    }
  };

  const getEndDate = () => {
    if (graphPage === totalGraphCount) {
      return moment(removeTimeZone(dateRange[0].endDate!.toString())).format(
        'YYYY-MM-DD'
      );
    } else
      return moment(removeTimeZone(dateRange[0].startDate!.toString()))
        .add(graphPageSize * graphPage - 1, 'days')
        .format('YYYY-MM-DD');
  };

  const addMissingGraphData = (graphData: IInboundGraphAPI[]) => {
    let weeksDate = getDatesInRange(getStartDate(), getEndDate()).map(
      (item) => {
        return moment(item).format('YYYY-MM-DD');
      }
    );
    let newObj = {
      capacityDate: '',
      assignedLoads: '',
      unAssignedLoads: '',
      pendingLoads: '',
      carrierCapacity: null,
      supplierCapacity: null,
      hasWarning: false,
    };
    for (let i = 0; i < weeksDate.length; i++) {
      let val = graphData.find((item) => item.capacityDate === weeksDate[i]);
      if (!val) {
        graphData.push({ ...newObj, capacityDate: weeksDate[i] });
      }
    }
    return graphData.sort((dateA, dateB) =>
      sortDate(dateA.capacityDate, dateB.capacityDate)
    );
  };

  const setGraphPaginatedData = (unformattedData: IInboundGraphAPI[]) => {
    let maxValue = -1;
    let formattedData = unformattedData.map((item) => {
      return { ...item, hasWarning: false };
    });
    formattedData.forEach((item) => {
      let sum =
        Number(item.assignedLoads) +
        Number(item.unAssignedLoads) +
        Number(item.pendingLoads);
      if (sum > item.supplierCapacity!) {
        item.hasWarning = true;
      }
      maxValue = Math.max(
        sum,
        Number(item.carrierCapacity),
        Number(item.supplierCapacity),
        maxValue
      );
    });

    setGraphData({
      maxValue:
        unformattedData.length === 0
          ? 4
          : Number(maxValue) + getNPercentOfValue(Number(maxValue), 5),
      data: addMissingGraphData(formattedData),
    });
  };

  const checkIfValidParams = () => {
    if (graphParam.dcId && graphParam.facility && graphParam.protectionType) {
      if (
        validEntityString(graphParam.dcId!) &&
        validEntityString(graphParam.facility!) &&
        validEntityString(graphParam.protectionType!)
      ) {
        return true;
      }
      return false;
    }
    return false;
  };

  const getBarGraphAPI = (filterChange?: boolean) => {
    if (checkIfValidParams()) {
      dispatch(setLoading(true));
      if (filterChange) {
        setGraphPage(1);
      }
      getInboundGraph({
        ...graphParam,
        startDate: getStartDate(),
        endDate: getEndDate(),
      })
        .then((res) => {
          console.log(res);
          setGraphPaginatedData(res.data.data);
        })
        .catch(() => {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: 'Failed to fetch graph data',
            })
          );
          setGraphData({ maxValue: -1, data: [] });
          setGraphPage(1);
        })
        .finally(() => {
          dispatch(setLoading(false));
        });
    } else {
      setGraphData({ ...graphData, data: [] });
      setGraphPage(1);
    }
  };

  useEffect(() => {
    getBarGraphAPI(true);
  }, [graphParam]);

  useEffect(() => {
    if (checkIfValidParams()) {
      getBarGraphAPI();
    }
  }, [graphPage]);
console.log(graphData);
  const rightSubheaderContainerClass = (graphData: IInboundGraphAPI[]) =>
    classNames('graph-subheader-container', {
      hide: graphData?.length === 0,
    });

  const dropDownStyling = () => {
    return classNames(
      'selectWrapper',
      graphData.data.length > 0 ? '' : 'filterStyling'
    );
  };
  return (
    <div
      className='inbound-optimization-wrapper'
      data-testid='inbound-optimization'>
      <div className='inbound-optimization-main-filter-wrapper'>
        <div className='inbound-optimization-filter-wrapper'>
          <div className='filter'>
            <p className='query-text'>{labels.dcId}</p>
            <SingleSelect
              dataTestId='dc-id-filter'
              buttonTittle='Select DC ID'
              minLength={4}
              data={dcIdList}
              onRadioClick={(ele) =>
                onRadioSelectParamUpdate(
                  ele.value,
                  inboundOptimizationFilters.dcId
                )
              }
              onSearchValue={(searchString) => onSearchDcId(searchString)}
              className={dropDownStyling()}
              search
            />
          </div>
          <div className='filter'>
            <p className='query-text'>{labels.facilityName}</p>
            <SingleSelect
              buttonTittle='Select Name'
              dataTestId='facility-name-filter'
              data={facilityNameList}
              onRadioClick={(ele) =>
                onRadioSelectParamUpdate(
                  ele.value,
                  inboundOptimizationFilters.facility
                )
              }
              className={dropDownStyling()}
              disabled={facilityNameList.length === 0}
            />
          </div>
          <div className='filter'>
            <p className='query-text'>{labels.protectionType}</p>
            <SingleSelect
              dataTestId='ptotection-type-filter'
              buttonTittle='Select Type'
              data={protectionTypeList}
              onRadioClick={(ele) =>
                onRadioSelectParamUpdate(
                  ele.value,
                  inboundOptimizationFilters.protection
                )
              }
              className={dropDownStyling()}
              disabled={protectionTypeList.length === 0}
            />
          </div>
          <div className='filter'>
            <p className='query-text'>
              {labels.supplierId}
              <i>(Optional)</i>
            </p>
            <SingleSelect
              dataTestId='supplier-id-filter'
              buttonTittle='Select Supplier ID'
              data={supplierIdList}
              search
              onSearchValue={(ele) => onSearchSupplierId(ele)}
              onRadioClick={(ele) =>
                onRadioSelectParamUpdate(
                  ele.value,
                  inboundOptimizationFilters.supplier
                )
              }
              className={dropDownStyling()}
              disabled={supplierIdList.length === 0}
              minLength={4}
            />
          </div>
          <div className='filter'>
            <p className='query-text'>
              {labels.carrierId}
              <i>(Optional)</i>
            </p>
            <SingleSelect
              dataTestId='carrier-id-filter'
              buttonTittle='Select Carrier ID'
              data={carrierIdList}
              search
              onSearchValue={(ele) => onSearchCarrierId(ele)}
              onRadioClick={(ele) =>
                onRadioSelectParamUpdate(
                  ele.value,
                  inboundOptimizationFilters.carrier
                )
              }
              className={dropDownStyling()}
              disabled={carrierIdList.length === 0}
              minLength={4}
            />
          </div>
        </div>
      </div>
      {graphData.data.length > 0 && (
        <>
          <section className={rightSubheaderContainerClass(graphData.data)}>
            <Pagination
              count={totalGraphCount}
              siblingCount={1}
              color='primary'
              showFirstButton
              showLastButton
              size='small'
              shape='rounded'
              onChange={(e, value) => setGraphPage(value)}
              page={graphPage}
            />
          </section>

          <div className='Card'>
            <InboundGraph
              data={graphData.data}
              maxLoad={graphData.maxValue}
              onClick={(data, label) => setGraphClickEvent({ capacityDate: data.capacityDate, loadType: label })}
            />
          </div>
        </>
      )}
      {
        graphClickEvent ?
          <InBoundOptimizationTable graphParams={graphParam} graphClickEvent={graphClickEvent} /> : <></>
      }
    </div>
  );
};
export default InboundOptimization;


