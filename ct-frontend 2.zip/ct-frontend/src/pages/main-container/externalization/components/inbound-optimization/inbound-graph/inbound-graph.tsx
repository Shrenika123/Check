import React, { useEffect, useRef, useState } from 'react';
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Label,
  LabelList,
  ResponsiveContainer,
  Scatter,
  Tooltip,
  XAxis,
  YAxis,
  Text,
} from 'recharts';
import warningInbound from '../../../../../../assets/icons/warningInbound.svg';
import CloseIcon from '@mui/icons-material/Close';
import { Popper, Tooltip as TooltipLoad } from '@mui/material';
import './inbound-graph.style.css';
import InboundGraphLegend from './inboundGraphLegend/inboundGraphLegend';
import {
  getFormattedDate,
  getRangeForGraph,
  numberFormat,
} from '../../../../../../common/utils';
import CustomTooltip from './cutsomTooltop/customToottip';
import { useOnClickOutside } from '../../../../../../hooks/useOnClickOutside';
import { IInboundGraphAPI } from '../../../../../../common/interfaces';
import { classNames } from 'primereact/utils';
import CarrierSupplierEntity from './carrierSupplierBarEntity/carrier-supplier-entity';
import { labels } from '../../../../../../common/constants';

interface IInboundGraphProps {
  data: IInboundGraphAPI[];
  maxLoad: number;
  onClick: (data: any, label: string) => void;
}

interface ISelectedElement {
  selectedIndex: string;
  selectedType: string;
}

const InboundGraph: React.FC<IInboundGraphProps> = ({
  data,
  maxLoad,
  onClick,
}) => {
  const [activeLabel, setActiveLabel] = useState<number>(-1);
  const [anchorEl, setAnchorEl] = React.useState<any | null>(null);
  const [selectedData, setSelectedData] = useState<ISelectedElement>({
    selectedIndex: '',
    selectedType: '',
  });
  const open = Boolean(anchorEl);

  const opRef = useRef(null);

  useOnClickOutside(opRef, () => setAnchorEl(null));

  const renderCustomizedLabel = (props: any) => {
    const { x, y, index } = props;
    return (
      <g>
        {data[index].hasWarning ? (
          <foreignObject
            width={100}
            height={40}
            x={x + 25}
            y={y - 42}>
            <TooltipLoad
              title={
                <>
                  <p className='AlertLabel'>Alert</p>
                  <p className='AlertLabelSubTitle'>
                    {labels.inboundLoadWarning}
                  </p>
                </>
              }
              placement='top'
              arrow
              componentsProps={{
                tooltip: {
                  sx: {
                    bgcolor: '#FFE3E0',
                    '& .MuiTooltip-arrow': {
                      color: '#FFE3E0',
                    },
                  },
                },
              }}>
              <img
                alt='loadWarning'
                src={warningInbound}
                className='warningData'
              />
            </TooltipLoad>
          </foreignObject>
        ) : (
          <></>
        )}
      </g>
    );
  };

  const CarrierComponent = (props: any) => {
    return (
      <CarrierSupplierEntity
        data={props}
        className='carrierCapacityEntity'
      />
    );
  };

  const SupplierComponent = (props: any) => {
    return (
      <CarrierSupplierEntity
        data={props}
        className='supplierCapacityEntity'
      />
    );
  };

  const onLabelClick = (
    e: React.MouseEvent<SVGTextElement, MouseEvent>,
    value: any,
    index: any
  ) => {
    setAnchorEl(e.currentTarget);
    setActiveLabel(index);
  };

  const changeTickColor = (e: any) => {
    const {
      payload: { value, index },
    } = e;
    e['fill'] = value === selectedData.selectedIndex ? '#B6F24D' : '#B3B3B3';
    return (
      <>
        <Text
          {...e}
          onClick={(e) => onLabelClick(e, value, index)}
          style={{
            cursor: 'pointer',
          }}>
          {getFormattedDate(value)}
        </Text>
      </>
    );
  };

  const handleOnClick = (index: any, label: string, isDisabled?: boolean) => {
    setAnchorEl(null);
    if (!isDisabled) {
      const selectedEntity = isNaN(index) ? index : data[index];
      setSelectedData({
        selectedIndex: selectedEntity.capacityDate,
        selectedType: label,
      });
      onClick(isNaN(index) ? index : data[index], label);
    }
  };

  useEffect(() => {
    setSelectedData({ selectedIndex: '', selectedType: '' });
  }, [data]);

  const getIsDisabledStyle = (value: number | string) => {
    if (value === 'NA' || value === '' || value === null || value === 0) {
      return true;
    } else {
      return false;
    }
  };
  return (
    <>
      <div
        className='scatterChart-Wrapper'
        data-testid='inbound-graph-id'>
        <ResponsiveContainer height={360}>
          <ComposedChart
            width={500}
            height={400}
            data={data}
            margin={{
              top: 20,
              right: 20,
              bottom: 20,
              left: 10,
            }}>
            <XAxis
              dataKey='capacityDate'
              fontSize={'14px'}
              tick={(e) => changeTickColor(e)}
              tickLine={{ stroke: 'transparent' }}></XAxis>
            <YAxis
              tickFormatter={(value) => numberFormat(value)}
              ticks={getRangeForGraph(Number(maxLoad))}
              tickLine={false}
              tick={{ fill: '#B3B3B3' }}
              allowDataOverflow={true}
              fontSize={'14px'}
              offset={-10}
              domain={[0, maxLoad]}>
              <Label
                value={'COUNT OF LOADS'}
                position='insideLeft'
                angle={-90}
                fill={'#b6f24d'}
                style={{
                  textAnchor: 'middle',
                  fontSize: `${'14px'}`,
                }}
                dx={-2}
                data-testid='LabelYAxis'
              />
            </YAxis>
            <Tooltip
              wrapperStyle={{ outline: 'none' }}
              content={<CustomTooltip />}
              cursor={false}
            />
            <CartesianGrid
              vertical={false}
              stroke='#B3B3B366'
            />
            <Bar
              dataKey='pendingLoads'
              stackId='a'
              fill='#FEBD02'
              barSize={80}
              cursor={'pointer'}
              onClick={(i) => handleOnClick(i, 'pendingLoad')}
              isAnimationActive={false}></Bar>

            <Bar
              dataKey='unAssignedLoads'
              stackId='a'
              fill='#1659ED'
              barSize={80}
              cursor={'pointer'}
              onClick={(i) => handleOnClick(i, 'unAssignedLoad')}
              isAnimationActive={false}></Bar>
            <Bar
              dataKey='assignedLoads'
              stackId='a'
              fill='#B6F24D'
              barSize={80}
              cursor={'pointer'}
              isAnimationActive={false}
              onClick={(i) => handleOnClick(i, 'assignedLoad')}>
              <LabelList
                dataKey='capacityDate'
                content={renderCustomizedLabel}
                position={'top'}
              />
            </Bar>
            <Scatter
              className='scatterCarrier'
              dataKey='carrierCapacity'
              shape={<CarrierComponent />}
            />
            <Scatter
              className='scatterCarrier'
              dataKey='supplierCapacity'
              shape={<SupplierComponent />}
            />
          </ComposedChart>
        </ResponsiveContainer>
        <InboundGraphLegend selectedValue={selectedData.selectedType} />
        <Popper
          open={open}
          anchorEl={anchorEl}
          ref={opRef}>
          <div className='popupContainer'>
            <CloseIcon
              onClick={() => {
                setAnchorEl(null);
              }}
              fontSize='small'
              className='popupCloseButton'
            />
            <div className='popupEntityWrapper'>
              <p
                className={classNames(
                  'popUpLabel',
                  getIsDisabledStyle(data[activeLabel]?.assignedLoads)
                    ? 'popupClickDisabled'
                    : ''
                )}
                onClick={() =>
                  handleOnClick(
                    activeLabel,
                    'assignedLoad',
                    getIsDisabledStyle(data[activeLabel]?.assignedLoads)
                  )
                }>
                {labels.assignedLoads}
              </p>
              <p
                className={
                  getIsDisabledStyle(data[activeLabel]?.pendingLoads)
                    ? 'popupClickDisabled'
                    : ''
                }>
                {data[activeLabel]?.assignedLoads !== ''
                  ? numberFormat(Number(data[activeLabel]?.assignedLoads))
                  : ''}
              </p>
            </div>
            <div className='popupEntityWrapper'>
              <p
                className={classNames(
                  'popUpLabel',
                  getIsDisabledStyle(data[activeLabel]?.unAssignedLoads)
                    ? 'popupClickDisabled'
                    : ''
                )}
                onClick={() =>
                  handleOnClick(
                    activeLabel,
                    'unAssignedLoad',
                    getIsDisabledStyle(data[activeLabel]?.unAssignedLoads)
                  )
                }>
                {labels.unAssignedLoads}
              </p>
              <p
                className={
                  getIsDisabledStyle(data[activeLabel]?.pendingLoads)
                    ? 'popupClickDisabled'
                    : ''
                }>
                {data[activeLabel]?.unAssignedLoads !== ''
                  ? numberFormat(Number(data[activeLabel]?.unAssignedLoads))
                  : ''}
              </p>
            </div>
            <div className='popupEntityWrapper'>
              <p
                className={classNames(
                  'popUpLabel',
                  getIsDisabledStyle(data[activeLabel]?.pendingLoads)
                    ? 'popupClickDisabled'
                    : ''
                )}
                onClick={() =>
                  handleOnClick(
                    activeLabel,
                    'pendingLoad',
                    getIsDisabledStyle(data[activeLabel]?.pendingLoads)
                  )
                }>
                {labels.pendingLoads}
              </p>
              <p
                className={
                  getIsDisabledStyle(data[activeLabel]?.pendingLoads)
                    ? 'popupClickDisabled'
                    : ''
                }>
                {data[activeLabel]?.pendingLoads !== ''
                  ? numberFormat(Number(data[activeLabel]?.pendingLoads))
                  : ''}
              </p>
            </div>
          </div>
        </Popper>
      </div>
    </>
  );
};
export default InboundGraph;
