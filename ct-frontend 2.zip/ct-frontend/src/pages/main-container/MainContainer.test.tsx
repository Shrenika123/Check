import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../common/constants';
import {
  itemManagementData,
  poManagement,
  statusResponse,
  userRole
} from '../../common/mocks/promotionAndProcurement';
import MainContainer from './MainContainer';

afterEach(() => {
  cleanup();
  jest.resetAllMocks();
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});

const powerUserExpandedState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: true,
  },
};
const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const mockStore = configureStore();

test('should render MainContainer component with navbar expanded', () => {
  const powerUserExpandedStore = mockStore(powerUserExpandedState);

  render(
    <Provider store={powerUserExpandedStore}>
      <MainContainer route={''} />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();
});

test('should render MainContainer component with navbar shrinked', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.home} />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();
});

test('should render MainContainer component with po management screen', () => {
  const mockPoManagementResponse = {
    status: 200,
    data: {
      data: poManagement,
    },
  };
  const countRes = {
    data: { totalRecords: 100 },
  };
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../common/utils');
  jest
    .spyOn(util, 'getPoManagementDetails')
    .mockResolvedValue(mockPoManagementResponse);
  jest.spyOn(util, 'getPoManagementDataCount').mockResolvedValue(countRes);
  jest
    .spyOn(util, 'getMultiSelectFilterData')
    .mockResolvedValue(statusResponse);

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.poManagement} />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();
});

test('should render MainContainer component with po line management screen', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.lineDetails} />
    </Provider>,
    { wrapper: BrowserRouter }
  );
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();
});

test('should render MainContainer component with item management screen', () => {
  const powerUserStore = mockStore(powerUserState);
  const mockItemManagementResponse = {
    status: 200,
    data: {
      data: itemManagementData,
    },
  };
  const countRes = {
    data: { totalRecords: 100 },
  };
  const util = require('../../common/utils');
  jest
    .spyOn(util, 'getMultiSelectFilterData')
    .mockResolvedValue(statusResponse);
  jest
    .spyOn(util, 'getItemManagementDetails')
    .mockResolvedValue(mockItemManagementResponse);
  jest.spyOn(util, 'getItemManagementDataCount').mockResolvedValue(countRes);
  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.itemManagement} />
    </Provider>, { wrapper: BrowserRouter });
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();

});

test('should render MainContainer component with vessel tracking screen', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.vesselTracking} />
    </Provider>, { wrapper: BrowserRouter });
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();

});

test('should render MainContainer component with vessel tracking details screen', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.vesselTrackingDetails} />
    </Provider>, { wrapper: BrowserRouter });
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();

});

test('should render MainContainer component with admin  screen', () => {
  const util = require('../../common/utils');
  jest.spyOn(util, 'getUsers').mockResolvedValue({ data: userRole })
  jest.spyOn(util, 'getUsersCount').mockResolvedValue({ data: 6 })
  jest.spyOn(util, 'getAdminPanelUserRoles').mockResolvedValue({data:[]})
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.adminPanel} />
    </Provider>, { wrapper: BrowserRouter });
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();

});

test('should render MainContainer component with ship and load screen', () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../common/utils');
  const res = {
    status: 200,
    data:
    {
      totalRecords: 169618,
      actualPageSize: 1,
      responses: [
        {
          poNumber: "70331316",
          shipmentId: "NQWV5163",
          loadId: "343989811",
          transportDocId: "5163NQWV",
          carrierSCAC: "OSAB",
          mode: "Truckload",
          equipmentId: "84LIP",
          equipmentDesc: "Truck",
          cube: "14",
          weight: 43,
          shippingUnitCount: "1/2",
          mabd: "2022-11-27",
          containerId: "CNT8481"
        }
      ],
    }
  };
  jest.spyOn(util, 'getShipAndLoadData').mockResolvedValue(res);
  jest.spyOn(util,'getShipAndLoadDataCount').mockResolvedValue({data:100})
  jest.spyOn(util, 'getMultiSelectFilterData').mockResolvedValue({data:{data:['Ocean']}})

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.shipLoadManagement} />
    </Provider>, { wrapper: BrowserRouter });
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();

});

test('should render MainContainer component with promotion and procurement screen', () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../common/utils');
  const tableResponse = {
    status: 200,
    data: {
      tagType: "EVENT_PLAN",
      totalRecords: "6",
      promotionProcurementPlanResponseList: [
        {
          promotionOrProcurementPlanId: "ThanksGiving",
          promotionOrProcurementPlanName: "ThanksGiving",
          targetDate: "2022-11-20",
          targetAmount: "4100128",
          atRiskAmount: "10871679"
        },
        {
          promotionOrProcurementPlanId: "Christmas",
          promotionOrProcurementPlanName: "Christmas",
          targetDate: "2022-12-20",
          targetAmount: "4699060",
          atRiskAmount: "2419723"
        },
      ]
    }
  };

  const favResponse = {
    status: 200,
    data: {
      data: [
        {
          eventId: "Christmas",
          eventName: "Christmas",
          targetAmount: "4699060",
          targetDate: "2022-12-20"
        }
      ],
      errorMessage: null
    }
  }
  const getEventAndBuyPlanTableData = jest.spyOn(util, 'getEventAndBuyPlanTableData').mockResolvedValue(tableResponse);
  const getActivityTrackingDetails = jest.spyOn(util, 'getActivityTrackingDetails').mockResolvedValue(favResponse)
  jest.spyOn(util, 'getEventAndBuyPlanTableCount').mockResolvedValue({data:100})

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.eventBuyPlanManagement} />
    </Provider>, { wrapper: BrowserRouter });
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();

});

test('should render MainContainer component with promotion and procurement details screen', () => {
  const powerUserStore = mockStore(powerUserState);
  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.promotionProcurementDetails} />
    </Provider>, { wrapper: BrowserRouter });
  const mainCon = screen.getByTestId('main-container');
  expect(mainCon).toBeInTheDocument();
  expect(mainCon).toBeVisible();

});

test('should logout when click on log out button', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.home} />
    </Provider>, { wrapper: BrowserRouter });
  const logout = screen.getByTestId('logoutButton');
  userEvent.click(logout);
  expect(window.location.pathname).toBe('/logout');
});

test('should render the expanded view on Navigation Bar component', () => {
  const powerUserExpandedStore = mockStore(powerUserExpandedState);

  render(
    <Provider store={powerUserExpandedStore}>
      <MainContainer route={routes.home} />
    </Provider>, { wrapper: BrowserRouter });
  const toggleButton = screen.getByTestId('toggleButton');
  userEvent.click(toggleButton);

  expect(screen.getAllByText('Dashboard')[0]).toBeVisible();
  expect(screen.getByText('PO Management')).toBeVisible();
  expect(screen.getByText('Item Management')).toBeVisible();
 // expect(screen.getByText('Vendor Management')).toBeVisible();
  expect(screen.getByText('Shipment & Load Management')).toBeVisible();
  //expect(screen.getByText('Zone & Loc Management')).toBeVisible();
  expect(screen.getByText('Event & Inventory Plan Management')).toBeVisible();
  expect(screen.getByText('Vessel Tracking')).toBeVisible();
  expect(screen.getByText('Document Library')).toBeVisible();
  expect(screen.getByText('Admin Panel')).toBeVisible();
}
);

test('should render the shrinked view on Navigation Bar component', () => {
  const powerUserStore = mockStore(powerUserState);

  render(
    <Provider store={powerUserStore}>
      <MainContainer route={routes.home} />
    </Provider>, { wrapper: BrowserRouter });
  const toggleButton = screen.getByTestId('toggleButton');
  userEvent.click(toggleButton);

  expect(screen.getByTestId('title').className).toBe('title');
}
);