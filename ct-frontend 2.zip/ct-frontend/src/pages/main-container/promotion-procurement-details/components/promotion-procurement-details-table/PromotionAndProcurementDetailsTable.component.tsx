import { Pagination } from '@mui/material';
import classNames from 'classnames';
import { format } from 'date-fns';
import { FC, useEffect, useRef, useState } from 'react';
import { IoMdArrowDropdown, IoMdArrowDropup } from 'react-icons/io';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import backicon from '../../../../../assets/images/backicon.png';
import { routes, tableConfig } from '../../../../../common/constants';
import { IPromotionProcurementPOPageResponse, IPromotionProcurementPORequest, IRoutePermission, ISortAndPage, IUserState, TagType } from '../../../../../common/interfaces';
import { getGMTTimeStamp, getPromotionProcurementPlanPOData, getPromotionProcurementPlanPOTableCount, isStringValid } from '../../../../../common/utils';
import ConfirmationBox from '../../../../../components/confimation-box/ConfirmationBox.component';
import { useDidComponentUpdate } from '../../../../../hooks/useDidComponentUpdate';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';
import './PromotionAndProcurementDetailsTable.style.css';

interface Props {
  isExpanded: boolean;
  tagType: TagType,
  tagId: string,
  locationType: string;
  targetDate: string;
}

const PromotionAndProcurementDetailsTable: FC<Props> = (props) => {

  const userGroupRoutes: IRoutePermission[] = useSelector((state: IUserState) => state.user.routePermissions);
  const poLinePerm = userGroupRoutes.find(val => val.screen.trim().toUpperCase() === 'PO_LINE_MANAGEMENT')?.permission;

  const initSortPage: ISortAndPage = {
    sortColumn: 'mabd',
    sortOrder: '',
    pageNumber: 1
  };

  const [tableData, setTableData] = useState<IPromotionProcurementPOPageResponse>({ totalRecords: 0, data: [] });
  const [totalCount, setTotalCount] = useState<number>(0);
  const [sortAndPage, setSortAndPage] = useState<ISortAndPage>(initSortPage);
  const [tableLoading, setTableLoading] = useState<boolean>(false);
  const [isConfirmBoxOpen, setConfirmBoxOpen] = useState<boolean>(false);
  const clickedPORef = useRef<{ poNumber: string, mabd: string; }>();

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const getSortIcon = () => {
    if (sortAndPage.sortOrder === 'desc')
      return <IoMdArrowDropdown data-testid='down-sort' className='sort-icon' />;
    else
      return <IoMdArrowDropup data-testid='up-sort' className='sort-icon' />;

  };

  const handlePOClick = (data: { poNumber: string, mabd: string; }) => {
    clickedPORef.current = data;
    setConfirmBoxOpen(true);
  };

  const navigateToPOLine = () => {
    navigate(`/${routes.lineDetails}`, { state: clickedPORef.current });
  };

  useEffect(() => {
    renderPOTable();
    fetchTotalCount();
  }, [props.locationType, props.tagType, props.tagId]);

  useDidComponentUpdate(() => {
    renderPOTable();
  }, [sortAndPage]);

  const renderPOTable = () => {
    dispatch(setLoading(true));
    setTableLoading(true);
    setTableData({ totalRecords: 0, data: [] });
    const request: IPromotionProcurementPORequest = {
      tagType: props.tagType,
      tagId: props.tagId,
      locationType: props.locationType,
      sortColumn: sortAndPage.sortColumn,
      sortOrder: sortAndPage.sortOrder,
      pageSize: tableConfig.pageSize,
      pageNumber: sortAndPage.pageNumber,
      targetDate: props.targetDate
    };
    getPromotionProcurementPlanPOData(request).then((res) => {
      if (res.status === 200) {
        setTableData(res.data);
      }
      else {
        setTableData({ totalRecords: 0, data: [] });
      }
    }).catch((err) => {
      console.log(err);
      setTableData({ totalRecords: 0, data: [] });
      dispatch(setShowAlert({
        showAlert: true,
        alertType: 'error',
        alertTitle: 'some error occurred while fetching table data',
        alertDescription: ``,
      }));
    }).finally(() => {
      dispatch(setLoading(false));
      setTableLoading(false);
    });
  };

  const fetchTotalCount = () => {
    const request: IPromotionProcurementPORequest = {
      tagType: props.tagType,
      tagId: props.tagId,
      locationType: props.locationType,
      targetDate: props.targetDate
    };
    getPromotionProcurementPlanPOTableCount(request).then(res => {
      setTotalCount(res.data.totalRecords);
    }).catch(err => {
      setTotalCount(0);
      console.log(err);
      dispatch(setShowAlert({
        showAlert: true,
        alertType: 'error',
        alertTitle: 'Some error occurred while fetching total pages',
        alertDescription: ``,
      }));
    });
  };

  const wrapperClass = classNames('promotion-procurement-details-table-wrapper', {
    'promotion-procurement-details-table-wrapper-shrink': props.isExpanded
  });
  const paginationClass = classNames('paginated', {
    'paginated-shrink': props.isExpanded
  });
  return (
    <section className='promotion-procurement-details-table-pagination-wrapper'>
      <section className={wrapperClass}>
        <table className='promotion-procurement-details-table'>
          <thead>
            <tr>
              <th>PO Number</th>
              <th><div className='pointer-cursor'
                onClick={() =>
                  setSortAndPage({
                    pageNumber: 1,
                    sortColumn: sortAndPage.sortColumn,
                    sortOrder: sortAndPage.sortOrder === '' ? 'desc' : ''
                  })}>MABD{getSortIcon()}</div></th>
              <th>Target Date</th>
              <th>Target Quantity</th>
              <th>Supply Chain Segment</th>
              <th>Quantity in Transit</th>
              <th>Department</th>
            </tr>
          </thead>
          <tbody>
            {tableData.data.length > 0 ? tableData.data.map((value, index) => {
              return (
                <tr key={value.poNumber + index}>
                  <td >
                    <div className={ isStringValid(poLinePerm) && poLinePerm !== 'NA' ? 'hyperlink' : 'non-hyperlink' } 
                    onClick={() => handlePOClick({poNumber:value.poNumber,mabd:value.mabd})}>{value.poNumber}
                    </div>
                  </td>
                  <td> {value.mabd === 'NA' ? 'NA' : format(getGMTTimeStamp(value.mabd), 'MM/dd/yyyy')}</td>
                  <td> {value.targetDate === 'NA' ? 'NA' : format(getGMTTimeStamp(value.targetDate), 'MM/dd/yyyy')}</td>
                  <td> {Number.parseInt(value.targetAmount).toLocaleString('en-US')}</td>
                  <td>{value.supplyChainSegment}</td>
                  <td> {Number.parseInt(value.quantity).toLocaleString('en-US')}</td>
                  <td>{value.department}</td>
                </tr>
              );
            }) :
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>{tableLoading ? 'Loading...' : 'No Data'}</td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            }
          </tbody>
        </table>
      </section>
      <ConfirmationBox title='Leave this page?'
        content='You will be redirected to Line Management page'
        open={isConfirmBoxOpen} onClose={() => setConfirmBoxOpen(false)}
        confirmAction={() => navigateToPOLine()}
        cancelAction={() => setConfirmBoxOpen(false)}
        image={<img src={backicon} alt='' />} />
      <section className={paginationClass}>
        <Pagination count={Math.ceil(totalCount / tableConfig.pageSize)} variant='text' shape='rounded' siblingCount={1} color={'standard'} showFirstButton showLastButton size="small"
          onChange={(e, value) => setSortAndPage({ pageNumber: value, sortColumn: sortAndPage.sortColumn, sortOrder: sortAndPage.sortOrder })} page={sortAndPage.pageNumber}
        />
      </section>
    </section>

  );
};

export default PromotionAndProcurementDetailsTable;