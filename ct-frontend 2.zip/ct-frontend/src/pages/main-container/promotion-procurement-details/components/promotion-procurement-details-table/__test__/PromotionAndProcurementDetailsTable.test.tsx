import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../../../common/constants';
import { TagType } from '../../../../../../common/interfaces';
import PromotionAndProcurementDetailsTable from '../PromotionAndProcurementDetailsTable.component';

afterEach(() => {
  cleanup();
  jest.resetAllMocks();
});

jest.mock("nanoid", () => {
  return { nanoid: () => Math.random().toString() };
});

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

const tableResponse = {
  status: 200,
  data: {
    totalRecords: 6,
    data: [
      {
        poNumber: "23457044",
        mabd: "2022-12-27",
        targetDate: "2023-01-16",
        targetAmount: "4900280",
        supplyChainSegment: "IDC",
        quantity: "6593",
        department: "Technology"
      },
      {
        poNumber: "23457702",
        mabd: "2022-12-27",
        targetDate: "2023-01-16",
        targetAmount: "4900280",
        supplyChainSegment: "IDC",
        quantity: "6510",
        department: "Firework"
      },
      {
        poNumber: "23457508",
        mabd: "2022-12-28",
        targetDate: "2023-01-16",
        targetAmount: "4900280",
        supplyChainSegment: "IDC",
        quantity: "5576",
        department: "Technology"
      },
      {
        poNumber: "23456944",
        mabd: "2022-12-28",
        targetDate: "2023-01-16",
        targetAmount: "4900280",
        supplyChainSegment: "IDC",
        quantity: "5417",
        department: "Prop"
      },
      {
        poNumber: "23457226",
        mabd: "NA",
        targetDate: "NA",
        targetAmount: "4900280",
        supplyChainSegment: "IDC",
        quantity: "5570",
        department: "Electrical accessories"
      },
      {
        poNumber: "23456912",
        mabd: "2022-12-28",
        targetDate: "2023-01-16",
        targetAmount: "4900280",
        supplyChainSegment: "IDC",
        quantity: "6350",
        department: "Prop"
      }
    ]
  }
};

const tableResponseNon200 = {
  status: 202,
  data: {
    totalRecords: 0,
    data: []
  }
};
const tableResponseError = {
  status: 500,
  error: 'network error'
};

const mockStore = configureStore();

test('should render promotion and procurement details PO table', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockResolvedValue(tableResponse);
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockResolvedValue({ data: { totalRecords: 100 } });
  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={false} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('23457044')).toBeInTheDocument();
  });
}
);

test('should render promotion and procurement details PO table and navigate to POline', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockResolvedValue(tableResponse);
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockResolvedValue({ data: { totalRecords: 100 } });
  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={false} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('23457044')).toBeInTheDocument();
  });
  fireEvent.click(screen.getByText('23457044'));
  await waitFor(() => {
    expect(screen.getByTestId('confirm-action-button')).toBeInTheDocument();
  });
  fireEvent.click(screen.getByTestId('confirm-action-button'));
}
);
test('should render promotion and procurement details tabla and cancel naviagate prompt', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockResolvedValue(tableResponse);
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockResolvedValue({ data: { totalRecords: 100 } });
  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={false} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('23457044')).toBeInTheDocument();
  });
  fireEvent.click(screen.getByText('23457044'));
  await waitFor(() => {
    expect(screen.getByTestId('cancel-action-button')).toBeInTheDocument();
  });
  fireEvent.click(screen.getByTestId('cancel-action-button'));
}
);
test('should render promotion and procurement details tabla and close naviagate prompt', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockResolvedValue(tableResponse);
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockResolvedValue({ data: { totalRecords: 100 } });
  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={false} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('23457044')).toBeInTheDocument();
  });
  fireEvent.click(screen.getByText('23457044'));
  await waitFor(() => {
    expect(screen.getByTestId('CloseRoundedIcon')).toBeInTheDocument();
  });
  fireEvent.click(screen.getByTestId('CloseRoundedIcon'));
}
);

test('should render promotion and procurement details PO table with no response', () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  const getPromotionProcurementPlanPOData = jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockResolvedValue(tableResponseNon200);
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockResolvedValue({ data: { totalRecords: 0 } });
  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={true} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });
}
);

test('should render promotion and procurement details PO table with error response', () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  const getPromotionProcurementPlanPOData = jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockRejectedValue(tableResponseError);
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockRejectedValue({ status: 500 });

  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={false} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });
}
);


test('should sort based on mabd', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockResolvedValue({ data: { totalRecords: 100 } });
  const getPromotionProcurementPlanPOData = jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockResolvedValue(tableResponse);
  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={false} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByText('23457044')).toBeInTheDocument();
  });

  const mabdSort = screen.getByText('MABD');
  userEvent.click(mabdSort);

  await waitFor(() => {
    expect(screen.getByTestId('down-sort')).toBeInTheDocument();
  });
  userEvent.click(mabdSort);

  await waitFor(() => {
    expect(screen.getByTestId('up-sort')).toBeInTheDocument();
  });
}
);

test('should render promotion and procurement details PO table and paginate', async () => {
  const powerUserStore = mockStore(powerUserState);
  const util = require('../../../../../../common/utils');
  jest.spyOn(util, 'getPromotionProcurementPlanPOData').mockResolvedValue(tableResponse);
  jest.spyOn(util, 'getPromotionProcurementPlanPOTableCount').mockResolvedValue({ data: { totalRecords: 100 } });
  render(
    <Provider store={powerUserStore}>
      <PromotionAndProcurementDetailsTable isExpanded={false} tagType={TagType.PROMOTION_PLAN} tagId={''} locationType={''} targetDate={''}></PromotionAndProcurementDetailsTable>
    </Provider>, { wrapper: BrowserRouter });

  await waitFor(() => {
    expect(screen.getByLabelText('Go to page 2')).toBeInTheDocument();
  });
  userEvent.click(screen.getByLabelText('Go to page 2'));
  await waitFor(() => {
    expect(screen.getByText('23457044')).toBeInTheDocument();
  });
}
);