import { act, render } from '@testing-library/react';
import { Provider } from 'react-redux';
import router, { MemoryRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import { routes } from '../../../../common/constants';
import {
  checkElementNotPresentInDomByTestId,
  //checkElementPresentInDomByTestId,
  clickElementByTestId,
  textNotPresentInDOM
} from '../../../../common/helper/testHelper';
import { promotionProcurementGraphData } from '../../../../common/mocks/promotionAndProcurement';
import MainContainer from '../../MainContainer';
window.alert = jest.fn();
const mockNavigate = jest.fn();
jest.mock('axios');
const mockData = promotionProcurementGraphData;
const mockedUsedNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockedUsedNavigate,
}));
jest.spyOn(window, 'alert').mockImplementation(() => {
  'Something went wrong';
});

jest.mock('../../../../common/utils.ts', () => ({
  axiosGetUnAuth: () => jest.fn(),

  getPercentage: function (value: number, value2: number) {
    return Math.round((value / value2) * 100) + '%';
  },
  getRangeForGraph: function () {
    return [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000];
  },
  getPromotionProcurementPlan: () => jest.fn(),
  getGMTTimeStamp:()=>jest.fn()
}));

jest.mock('recharts', () => {
  const OriginalModule = jest.requireActual('recharts');
  return {
    ...OriginalModule,
    ResponsiveContainer: ({ children }: { children: any }) => (
      <OriginalModule.ResponsiveContainer width={350} height={350}>
        {children}
      </OriginalModule.ResponsiveContainer>
    ),
  };
});

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken:'appToken',
    idToken:'idToken',
    appTokenExpiration:1200000,
    userId:'userId',
    refreshTokenId:'refreshTokenId',
    routePermissions: [
      {
        screen: "RECENT_PO_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "VESSEL_TRACKING",
        permission: "READ",
        route: "vessel-tracking"
      },
      {
        screen: "PORT_DOCUMENT_LIBRARY",
        permission: "READ",
        route: "document-library"
      },
      {
        screen: "RECENT_SHIPMENT_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "RECENT_CONTAINER_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "PO_MANAGEMENT",
        permission: "READ",
        route: "po-management"
      },
      {
        screen: "INBOUND_OPTIMIZATION",
        permission: "READ",
        route: "externalization"
      },
      {
        screen: "FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_INVENTORY_TREND_DASHBOARD_TILE",
        permission: "READ",
        route: "home"
      },
      {
        screen: "EVENT_AND_INVENTORY_PLAN_DETAILS",
        permission: "READ",
        route: "event-inventory-plan/details"
      },
      {
        screen: "PO_ITEM_MANAGEMENT",
        permission: "READ",
        route: "item-management"
      },
      {
        screen: "INVENTORY_PLAN",
        permission: "READ",
        route: "event-inventory-plan"
      },
      {
        screen: "PO_LINE_MANAGEMENT",
        permission: "READ",
        route: "po-management/details"
      },
      {
        screen: "SHIPMENT_AND_LOAD_MANAGEMENT",
        permission: "READ",
        route: "ship-load-management"
      },
      {
        screen: "CONTAINER_TRACKING",
        permission: "WRITE",
        route: "vessel-tracking/details"
      },
      {
        screen: "CONTAINER_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "SUPPLIER_CRM",
        permission: "WRITE",
        route: "externalization"
      },
      {
        screen: "EVENT_PLAN",
        permission: "WRITE",
        route: "event-inventory-plan"
      },
      {
        screen: "LOAD_DOCUMENT_LIBRARY",
        permission: "WRITE",
        route: "document-library"
      },
      {
        screen: "ADMIN",
        permission: "WRITE",
        route: "admin-panel"
      },
      {
        screen: "CARRIER_CRM",
        permission: "WRITE",
        route: "externalization"
      }
    ],
    userDefaultRoute: routes.home,
  },
  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

beforeEach(() => {
  jest.clearAllMocks();
});

afterEach(() => {
  jest.clearAllMocks();
});

describe('Promotion Procurement plan details page and for success and state variable changes', () => {
  const mockStore = configureStore();
  beforeEach(() => {
    jest.spyOn(router, 'useNavigate').mockImplementation(() => mockNavigate);
  });
  afterAll(() => {
    jest.clearAllMocks();
  });

  test('should render component and check navigation and all positive scenarios', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getPromotionProcurementPlan')
      .mockResolvedValue({ data: mockData });
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () =>
      render(
        <MemoryRouter
          initialEntries={[
            {
              pathname: 'event-inventory-plan/details',
              search: '',
              state: { tagId: 'lkmdskla', tagName: 'dadasd', tagType: '' },
            },
          ]}
        >
          <Provider store={powerUserStore}>
            <MainContainer route={routes.promotionProcurementDetails} />
          </Provider>
        </MemoryRouter>
      )
    );
    // eslint-disable-next-line testing-library/no-debugging-utils
    //await checkElementPresentInDomByTestId('BarGraphMainContainer');
    //await textPresentInDOM('Vendor Pending');
    await clickElementByTestId('backButtonGeneral');
    // expect(mockNavigate).toHaveBeenCalledWith('/event-inventory-plan?tag=', {
    //   replace: true,
    // });
  });

  test('when location not precent', async () => {
    const powerUserStore = mockStore(powerUserState);
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () =>
      render(
        <MemoryRouter
          initialEntries={[
            {
              pathname: '/',
              search: '',
              state: null,
            },
          ]}
        >
          <Provider store={powerUserStore}>
            <MainContainer route={routes.promotionProcurementDetails} />
          </Provider>
        </MemoryRouter>
      )
    );
    // eslint-disable-next-line testing-library/no-debugging-utils
    expect(mockNavigate).toHaveBeenCalledTimes(1);
  });
});

describe('Promotion Procurement plan details page and api fails', () => {
  const mockStore = configureStore();
  afterAll(() => {
    jest.clearAllMocks();
  });

  jest.mock('react-router-dom', () => ({
    ...jest.requireActual('react-router-dom'),
    useNavigate: () => mockedUsedNavigate,
  }));
  const util = require('../../../../common/utils');
  jest
    .spyOn(util, 'getPromotionProcurementPlan')
    .mockRejectedValueOnce({ error: { response: { status: 500 } } });
  test('when error', async () => {
    const powerUserStore = mockStore(powerUserState);
    // eslint-disable-next-line testing-library/no-unnecessary-act
    await act(async () =>
      render(
        <MemoryRouter
          initialEntries={[
            {
              pathname: '/promotion-procurement/details',
              search: '',
              state: { tagId: 'lkmdskla', tagName: 'dadasd', tagType: '' },
            },
          ]}
        >
          <Provider store={powerUserStore}>
            <MainContainer route={routes.promotionProcurementDetails} />
          </Provider>
        </MemoryRouter>
      )
    );
    checkElementNotPresentInDomByTestId('BarGraphMainContainer');
    await textNotPresentInDOM('Vendor Pending');
  });
});
