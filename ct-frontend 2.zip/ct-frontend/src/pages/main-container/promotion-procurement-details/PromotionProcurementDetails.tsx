import classNames from 'classnames';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { labels, milestoneStatus, routes } from '../../../common/constants';
import { TagType } from '../../../common/interfaces';
import {
  getPercentage,
  getPromotionProcurementPlan,
  getRangeForGraph
} from '../../../common/utils';
import BarGraph, { IBarGraphDataElement } from '../../../components/BarGraph';
import Milestone from '../../../components/milestone/Milestone.component';
import NavigateBackButton from '../../../components/navigateBackButton/NavigateBackButton.component';
import { setShowAlert } from '../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../redux/reducers/loading.reducer';
import PromotionAndProcurementDetailsTable from './components/promotion-procurement-details-table/PromotionAndProcurementDetailsTable.component';
import './promotionProcurementDetails.style.css';

interface IPromotionProcurementDetailsProps {
  isExpanded: boolean;
}

const PromotionProcurementDetails: React.FC<
  IPromotionProcurementDetailsProps
> = ({ isExpanded }) => {
  const [graphData, setGraphData] = useState<IBarGraphDataElement[]>([]);
  const [navButtonLabel, setNavButtonLabel] = useState<string>('');
  const [activeState, setActiveState] = useState<number>(-1);
  const [range, setRange] = useState<number[]>([]);
  const [showTableFor, setShowTableFor] = useState<string>();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    (async () => {
      try {
        dispatch(setLoading(true));
        if (location?.state !==null && location?.state.tagId && location?.state.tagType && location?.state.targetDate) {
          let response = await getPromotionProcurementPlan({
            tagId: location?.state.tagId,
            tagType: location?.state.tagType,
            targetDate: location?.state.targetDate
          });
          let procurementDetailsGraphData = response?.data.data;
          setGraphData(
            procurementDetailsGraphData.map((item: IBarGraphDataElement) => {
              item['percentage'] = getPercentage(
                Number(item.value),
                Number(item.maxQuantity)
              );
              return item;
            })
          );
        } else {
          goBack();
        }
        dispatch(setLoading(false));
      } catch (error: any) {
        dispatch(setLoading(false));
        switch (error.response?.status) {
          case 404:
            dispatch(
              setShowAlert({
                showAlert: true,
                alertType: 'warn',
                alertTitle: 'No data found for event/inventory plan milestones',
                alertDescription: ``,
              })
            );
            break;
          default:
            dispatch(
              setShowAlert({
                showAlert: true,
                alertType: 'error',
                alertTitle: 'Failed to fetch event/inventory plan milestones',
                alertDescription: '',
              })
            );
            break;
        }
        console.log('error', error);
      }
    })();
  }, []);

  const getBackNavigationLabel = (): string => {
    const { tagType, tagName } = location?.state;
    const type =
      tagType === TagType.PROCUREMENT_PLAN
        ? labels.ProcurementPlan
        : labels.PromotionPlan;
    return `${tagName} ${type}`;
  };

  useEffect(() => {
    if (location?.state) {
      setNavButtonLabel(getBackNavigationLabel());
    }
  }, [location]);

  useEffect(() => {
    if (graphData.length > 0) {
      setRange(getRangeForGraph(Number(graphData[0].maxQuantity)));
    }
  }, [graphData]);

  const goBack = () => {
    navigate(`/${routes.eventBuyPlanManagement}`, { replace: true });
  };

  const barGraphSection = (isExpanded: boolean) =>
    classNames('barGraph-section', {
      'barGraph-section-shrink': isExpanded,
    });

  return (
    <>
      <section id='evenBuyPlanDetails'>
        <NavigateBackButton
          isExpanded={isExpanded}
          navigate={goBack}
          label={navButtonLabel}
        />
        <section
          className={classNames(barGraphSection(isExpanded), 'graphContainer')}
        >
          {graphData.length > 0 && (
            <div className='Card'>
              <div className='milestone'>
                <div className='milestoneMainLabel'>
                  {labels.MilestoneLabel}
                </div>
                <Milestone data={milestoneStatus} active={activeState} />
              </div>
              <BarGraph
                xAxisLegend
                yAxisLabel={labels.ItemQuantity}
                height={300}
                graphFontSize='14px'
                data={graphData}
                click={(e, index) => {
                  setShowTableFor(e.name);
                  setActiveState(index);
                }}
                range={range}
              />
              <p className='footerTitle'>{labels.SupplyChain}</p>
            </div>
          )}
        </section>
      </section>
      {showTableFor && location.state?.tagType && location.state?.tagId && (
        <PromotionAndProcurementDetailsTable
          isExpanded={isExpanded}
          tagType={location?.state.tagType}
          tagId={location?.state.tagId}
          locationType={showTableFor} targetDate={location?.state.targetDate}></PromotionAndProcurementDetailsTable>
      )}
    </>
  );
};
export default PromotionProcurementDetails;
