import { Tab, Tabs } from '@mui/material';
import classNames from 'classnames';
import { FC, useState } from "react";
import { labels } from '../../../common/constants';
import './AdminPanel.style.css';
import RoleAccess from './components/role-access/role-access-component';
import UserAccess from './components/user-access/user-access-component';

interface IAdminPanelProps {
  isExpanded: boolean;
}

const AdminPanel: FC<IAdminPanelProps> = (props) => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const containerClass = classNames({
    'container-shrink': props.isExpanded,
    container: !props.isExpanded,
  })

  return (
    <section id='adminPanel'>
      <section className={containerClass}>
        <section
          className={'adminPanel-header'}
          data-testid='adminPanel-header-testId'>
          <div className='text-header'>{labels.adminPanel}</div>
        </section>
        <section className='adminPanelTabs'>
          <Tabs
            variant='scrollable'
            scrollButtons='auto'
            onChange={(e, val) => setActiveTab(val)}
            value={activeTab}>
            <Tab
              data-testid='userAccessTab'
              label={labels.userAccess}></Tab>
            <Tab
              data-testid='roleAccessTab'
              label={labels.roleAccess}></Tab>
          </Tabs>
        </section>
        <section>
          {activeTab === 0 && (
            <UserAccess />
          )}
          {activeTab === 1 && (
            <RoleAccess />
          )}
        </section>
      </section>
    </section>
  );

};

export default AdminPanel

