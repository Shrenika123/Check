import { Dialog } from 'primereact/dialog';
import { FC, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { labels } from '../../../../../../common/constants';
import {
  addRoleType,
  alertStates,
  sortOrder,
} from '../../../../../../common/interfaces';
import {
  addRole,
  getListScreens,
  getMapToggleToType,
  getMapTypeToToggle,
  isAlphanumericWithSpace,
  removeExtraSpaces,
} from '../../../../../../common/utils';
import ToggleButton from '../../../../../../components/toogleSelect';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';
import SuccessRoleModalView from '../successModal';
import './AddRoleModal.style.css';

interface IAddRoleProps {
  isOpen: boolean;
  setOpen: Function;
  onSuccess: () => void;
}

interface IScreenResponse {
  screen: string;
  permission: string;
}

const AddRole: FC<IAddRoleProps> = ({ isOpen, setOpen, onSuccess }) => {
  const [role, setRole] = useState<string>('');
  const [screens, setScreens] = useState<IScreenResponse[]>([]);
  const [checked, setChecked] = useState<boolean>(false);
  const [updateScreen, setUpdatedScreen] = useState<IScreenResponse[]>([]);
  const [addRoleModalOpen, setAddRoleModalOpen] = useState<boolean>(false);

  const dispatch = useDispatch();

  const handleClose = () => {
    setOpen(false);
  };

  useEffect(() => {
    if (isOpen) {
      dispatch(setLoading(true));
      getListScreens({
        includeRolePermissions: false,
        includeUniqueRoles: true,
        sortOrder: sortOrder.ASC,
        sortColumn: 'screen',
      })
        .then((res) => {
          setScreens(
            res.data.data.screens.map((item: string) => {
              return {
                screen: item,
                permission: '',
              };
            })
          );
        })
        .catch(() => {
          setAlertOnAPICall(alertStates.ERROR, 'Failed to fetch screens list', '');
        })
        .finally(() => {
          dispatch(setLoading(false));
        });
    }
    if (!isOpen) {
      setUpdatedScreen([]);
      setScreens([]);
      setChecked(false);
      setRole('');
    }
  }, [isOpen]);

  const setAlertOnAPICall = (
    alertType: alertStates,
    alertTitle: string,
    alertDescription: string
  ) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType,
        alertTitle,
        alertDescription,
      })
    );
  };

  const handleOnToggleChange = (
    selectedValue: string,
    data: IScreenResponse
  ) => {
    const existingIndex = updateScreen.findIndex(
      (item) => item.screen === data.screen
    );
    if (existingIndex > -1) {
      setUpdatedScreen([
        ...updateScreen.slice(0, existingIndex),
        {
          ...data,
          permission: getMapToggleToType(selectedValue),
        },
        ...updateScreen.splice(existingIndex + 1),
      ]);
    } else {
      setUpdatedScreen([
        ...updateScreen,
        {
          ...data,
          permission: getMapToggleToType(selectedValue),
        },
      ]);
    }
  };

  const getRoleElement = (item: IScreenResponse) => {
    return (
      <div
        className='rolePermissionElement'
        key={`${item.screen}`}>
        <p>{item.screen}</p>
        <ToggleButton
          toggleTitles={['Read', 'Edit', 'NA']}
          preSelectedValue={getMapTypeToToggle(item.permission)}
          onClick={(_, selectedValue) => {
            handleOnToggleChange(selectedValue, item);
          }}
        />
      </div>
    );
  };

  const checkIfElementNotPresent = (item: IScreenResponse) => {
    for (let updatedItem of updateScreen) {
      if (updatedItem.screen === item.screen) {
        return false;
      }
    }
    return true;
  };

  const submitAddRole = () => {
    let newScreen = screens
      .filter((item) => checkIfElementNotPresent(item))
      .map((item) => {
        return {
          ...item,
          permission: 'NA',
          isExternalRole: checked,
          role: role.trim(),
        };
      });
    let finalData = [
      ...newScreen,
      ...updateScreen.map((item) => {
        return {
          ...item,
          isExternalRole: checked,
          role: role.trim(),
        };
      }),
    ];
    dispatch(setLoading(true));
    addRole(finalData)
      .then((res) => {
        setAddRoleModalOpen(true);
        handleClose();
        onSuccess();
      })
      .catch((e) => {
        setAlertOnAPICall(alertStates.ERROR, 
          e 
          && e.response 
          && e.response.data 
          && e.response.data.errorMessage 
          && e.response.data.errorMessage? 
          e.response.data.errorMessage : 'Failed to add the new role', '');
      })
      .finally(() => dispatch(setLoading(false)));
  };

  const onRoleInput = (name: string) => {
    if (isAlphanumericWithSpace(name)) {
      setRole(removeExtraSpaces(name.trimStart()));
    }
  };

  return (
    <>
      <Dialog
        data-testid='add-role'
        header='Add Role'
        id='add-role'
        onHide={handleClose}
        visible={isOpen}>
        <section className='add-role-section-wrapper'>
          <p className='add-role-subheader'>{labels.role}</p>
          <input
            spellCheck={true}
            onChange={(e) => onRoleInput(e.target.value)}
            className='addRoleInput'
            placeholder='Enter Role'
            value={role}
            data-testid='addRole-input'
          />
        </section>
        <section className='checkBoxMainWrapper'>
          <h4>{labels.selectExternalRole}</h4>
          <div
            className='checkBoxWrapper'
            onClick={() => setChecked(!checked)}>
            <input
              type='checkbox'
              defaultChecked={checked}
              data-testid='addRole-checkbox'
            />
            <p>{labels.externalRole}</p>
          </div>
        </section>
        <section>
          <p className='add-role-subheader'>{labels.screenNPermission}</p>
          <p className='add-role-text'>{labels.selectScreensNPermission}</p>
          {screens.length > 0 && (
            <div className='rolePermissionElementWrapper'>
              {screens.map((item) => getRoleElement(item))}
            </div>
          )}
        </section>
        <button
          disabled={role.length === 0 || updateScreen.length === 0}
          className='add-role-button'
          data-testid='add-role-submit-button'
          onClick={() => submitAddRole()}>
          {labels.AddRole}
        </button>
      </Dialog>
      {
        <Dialog
          header={labels.addRole}
          visible={addRoleModalOpen}
          className='addScreen'
          onHide={() => setAddRoleModalOpen(false)}>
          <SuccessRoleModalView
            type={addRoleType.ADD_ROLE}
            message={labels.roleAddedSuccess}
          />
        </Dialog>
      }
    </>
  );
};

export default AddRole;
