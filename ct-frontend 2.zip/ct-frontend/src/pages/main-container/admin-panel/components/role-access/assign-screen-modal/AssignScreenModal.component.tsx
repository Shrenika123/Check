import { Dialog } from "primereact/dialog";
import { FC, useEffect, useState } from 'react';
import './AssignScreenModal.style.css';
import SingleSelect from '../../../../../../components/SingleSelect';
import {
  addRoleType,
  alertStates,
  IRoleAccessEntity,
  ISaveAssignScreenParams,
  IScreenAssignResponse,
  IScreenRoleEntity,
  ISelectElement,
  sortOrder,
} from '../../../../../../common/interfaces';
import {
  formatToSelectFilterType,
  getListScreens,
  getMapToggleToType,
  getMapTypeToToggle,
  saveScreenPermission,
  sortForRoleScreen,
} from '../../../../../../common/utils';
import ToggleButton from '../../../../../../components/toogleSelect';
import SuccessRoleModalView from '../successModal';
import { useDispatch } from 'react-redux';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';
import { labels } from '../../../../../../common/constants';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
interface IAssignModalProps {
  isOpen: boolean;
  setOpen: Function;
  onSuccess: () => void;
}

const AssignScreen: FC<IAssignModalProps> = ({
  isOpen,
  setOpen,
  onSuccess,
}) => {
  const [data, setData] = useState<IScreenAssignResponse | null>(null);
  const [selectedScreen, setSelectedScreen] = useState<string>('');
  const [screens, setScreens] = useState<ISelectElement[]>([]);
  const [selectedScreenRoles, setSelectedScreenRoles] = useState<
    IRoleAccessEntity[]
  >([]);
  const [updatedScreenRoles, setUpdatedScreenRoles] = useState<
    ISaveAssignScreenParams[]
  >([]);
  const [successModalOpen, setSuccessModalOpen] = useState<boolean>(false);
  const handleClose = () => {
    setOpen(false);
  };

  const setAlertOnAPICall = (
    alertType: alertStates,
    alertTitle: string,
    alertDescription: string
  ) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType,
        alertTitle,
        alertDescription,
      })
    );
  };

  const dispatch = useDispatch();
  useEffect(() => {
    if (isOpen) {
      dispatch(setLoading(true));
      getListScreens({
        includeRolePermissions: true,
        includeUniqueRoles: true,
        sortOrder: sortOrder.ASC,
        sortColumn: 'screen',
      })
        .then((res) => {
          let resData = res?.data?.data as IScreenAssignResponse;
          const defaultValueRoles = resData?.roles?.map(
            (item: IScreenRoleEntity) => {
              return {
                ...item,
                action: 'insert',
                permission: '',
              };
            }
          );
          let newScreens = resData
            ?.screensRolesPermissionMappings!.filter(
              (item) => item.roles.length === 0
            )
            .map((item) => {
              return {
                ...item,
                roles: defaultValueRoles,
              };
            });

          let existingScreens = resData.screensRolesPermissionMappings!.filter(
            (item) => item.roles.length !== 0
          );

          const manipulatedData = {
            ...resData,
            screensRolesPermissionMappings: [...newScreens, ...existingScreens],
          };
          setData({
            ...manipulatedData,
            screensRolesPermissionMappings:
              manipulatedData.screensRolesPermissionMappings.map((item) => {
                return {
                  screen: item.screen,
                  roles: sortForRoleScreen(item.roles!, false),
                };
              }),
          });
        })
        .catch(() =>
          setAlertOnAPICall(
            alertStates.ERROR,
            'Failed to fetch screens list',
            ''
          )
        )
        .finally(() => {
          dispatch(setLoading(false));
        });
    }
    if (!isOpen) {
      setSelectedScreenRoles([]);
      setScreens([]);
      setData(null);
      setSelectedScreen('');
      setUpdatedScreenRoles([]);
    }
  }, [isOpen]);

  const handleOnToggleChange = (
    preSelectedValue: string,
    selectedValue: string,
    data: IRoleAccessEntity
  ) => {
    const existingIndex = updatedScreenRoles
      .filter((item) => item.screen === selectedScreen)
      .findIndex((item) => item.role === data.role);
    if (preSelectedValue !== selectedValue) {
      if (existingIndex === -1) {
        setUpdatedScreenRoles([
          ...updatedScreenRoles,
          {
            ...data,
            action: data?.action ?? 'update',
            screen: selectedScreen,
            permission: getMapToggleToType(selectedValue),
          },
        ]);
      } else {
        setUpdatedScreenRoles([
          ...updatedScreenRoles.slice(0, existingIndex),
          {
            ...updatedScreenRoles[existingIndex],
            permission: getMapToggleToType(selectedValue),
          },
          ...updatedScreenRoles.slice(existingIndex + 1),
        ]);
      }
    } else {
      setUpdatedScreenRoles([
        ...updatedScreenRoles.slice(0, existingIndex),
        ...updatedScreenRoles.slice(existingIndex + 1),
      ]);
    }
  };

  const getRolePermissionsElement = (item: IRoleAccessEntity) => {
    return (
      <div
        className='rolePermissionElement'
        key={`${selectedScreen}+${item.role}`}
        data-testid={`${selectedScreen}+${item.role}`}>
        <p>{item.role}</p>
        <ToggleButton
          toggleTitles={['Read', 'Edit', 'NA']}
          preSelectedValue={getMapTypeToToggle(item.permission)}
          onClick={(_, selectedValue, preSelectedValue) => {
            handleOnToggleChange(preSelectedValue, selectedValue, item);
          }}
        />
      </div>
    );
  };

  useEffect(() => {
    if (data) setScreens(formatToSelectFilterType(data?.screens ?? []));
  }, [data]);

  useEffect(() => {
    if (selectedScreen.length > 0 && data?.screensRolesPermissionMappings) {
      setSelectedScreenRoles([
        ...data.screensRolesPermissionMappings.find(
          (item) => item.screen === selectedScreen
        )?.roles!,
      ]);
    }
    setUpdatedScreenRoles([]);
  }, [selectedScreen]);

  const checkIfElementNotPresent = (item: IRoleAccessEntity) => {
    for (let updatedItem of updatedScreenRoles) {
      if (updatedItem.role === item.role) {
        return false;
      }
    }
    return true;
  };

  const handleOnSubmitButton = () => {
    if (updatedScreenRoles.length > 0) {
      let onSubmitPayload;
      if (updatedScreenRoles[0].action === 'insert') {
        onSubmitPayload = [
          ...selectedScreenRoles
            .filter((item) => checkIfElementNotPresent(item))
            .map((item) => {
              return {
                ...item,
                permission: 'NA',
                screen: selectedScreen,
              };
            })
            .concat(...updatedScreenRoles),
        ];
      } else {
        onSubmitPayload = updatedScreenRoles;
      }
      dispatch(setLoading(true));
      saveScreenPermission(onSubmitPayload)
        .then((res) => {
          setSuccessModalOpen(true);
          onSuccess();
          handleClose();
        })
        .catch(() =>
          setAlertOnAPICall(alertStates.ERROR, labels.AssignScreenError, '')
        )
        .finally(() => {
          dispatch(setLoading(false));
        });
    }
  };

  return (
    <>
      <Dialog
        data-testid='assign-screen'
        header={labels.AssignScreenTitle}
        id='assign-screen'
        onHide={handleClose}
        visible={isOpen}>
        <section className='assign-screen-section-wrapper'>
          <p className='assign-screen-subheader'>{labels.screen}</p>
          <SingleSelect
            dataTestId='assign-seen-role-filter'
            buttonTittle='Select Screen'
            data={screens}
            onRadioClick={(ele) => setSelectedScreen(ele.value)}
            search={false}
          />
        </section>
        <section>
          <p className='assign-screen-subheader'>{labels.RoleNPermission}</p>
          <p className='assign-screen-text'>
            {selectedScreenRoles.length === 0 && selectedScreen === ''
              ? labels.selectScreenToProceed
              : labels.selectRolesNPermission}
          </p>
          {!(selectedScreenRoles.length === 0 && selectedScreen === '') && (
            <div className='rolePermissionElementWrapper'>
              {selectedScreenRoles.map((item) =>
                getRolePermissionsElement(item)
              )}
            </div>
          )}
        </section>
        <button
          disabled={selectedScreen === '' || updatedScreenRoles.length === 0}
          className='assign-screen-button'
          data-testid='assign-screen-button'
          onClick={() => handleOnSubmitButton()}>
          {labels.Assign}
        </button>
      </Dialog>
      {
        <Dialog
          header={labels.AssignScreenTitle}
          visible={successModalOpen}
          className='addScreen'
          onHide={() => setSuccessModalOpen(false)}>
          <SuccessRoleModalView
            type={addRoleType.ADD_SCREEN}
            message={labels.AssignScreenSuccess}
          />
        </Dialog>
      }
    </>
  );
};

export default AssignScreen;