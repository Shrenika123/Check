import { FC } from 'react';
import AddScreen from '../../../../../../assets/icons/screenAssigned.svg';
import AddUser from '../../../../../../assets/icons/addUser.svg';
import ModifyRole from '../../../../../../assets/icons/modifyRole.svg';
import { addRoleType } from '../../../../../../common/interfaces';

interface SuccessRoleModal {
  type: addRoleType;
  message: string;
}

const SuccessRoleModalView: FC<SuccessRoleModal> = ({ type, message }) => {
  const getImage = () => {
    switch (type) {
      case addRoleType.ADD_ROLE:
        return AddUser;
      case addRoleType.ADD_SCREEN:
        return AddScreen;
      default:
        return ModifyRole;
    }
  };
  return (
    <div
      className='flex align-items-center flex-column modal-success-area'
      data-testid='successModalForRoleScreen'>
      <img
        style={{ width: '4rem', height: '4rem' }}
        src={getImage()}
        alt='success'
      />
      <span className='my-2 success-modal-header'>Success!</span>
      <span className='success-modal-text '>{message}</span>
    </div>
  );
};

export default SuccessRoleModalView;
