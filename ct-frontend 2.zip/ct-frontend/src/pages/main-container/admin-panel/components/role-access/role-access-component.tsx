import React, { useState } from 'react';
import { labels } from '../../../../../common/constants';
import AddIcon from '@mui/icons-material/Add';
import './role-access.style.css';
import RoleAccessTable from './role-access-table/role-access-table';
import AddRole from './add-role-modal/AddRoleModal.component';
import AssignScreen from './assign-screen-modal/AssignScreenModal.component';
import { addRoleType } from '../../../../../common/interfaces';

const RoleAccess: React.FC = () => {
  const [isAddRoleModalOpen, setAddRoleModalOpen] = useState<boolean>(false);
  const [isAssignScreenModalOpen, setAssignScreenModalOpen] =
    useState<boolean>(false);
  const [roleOrScreenAdded, setRoleOrScreenAdded] = useState<addRoleType>(
    addRoleType.NONE
  );

  return (
    <section>
      <div className='role-access-wrapper'>
        <div className='role-access-header-wrapper'>
          <div className='role-access-details-label'>
            {labels.roleAccessDetails}
          </div>
          <div className='role-access-button-wrapper'>
            <button
              className=' role-access-button role-screen-access-button'
              data-testid='assign-role-to-screen'
              onClick={() => setAssignScreenModalOpen(true)}>
              {labels.AssignScreenTitle}
            </button>
            <button
              data-testid='add-role-button'
              className='role-access-button add-role-button'
              onClick={() => setAddRoleModalOpen(true)}>
              <AddIcon className='addIcon' />
              <div>{labels.addRole}</div>
            </button>
          </div>
        </div>
        <RoleAccessTable
          data-testid='role-table'
          onSuccess={() => setRoleOrScreenAdded(addRoleType.NONE)}
          success={roleOrScreenAdded}
        />
      </div>
      <AddRole
        data-testid='addRole-modal'
        isOpen={isAddRoleModalOpen}
        setOpen={setAddRoleModalOpen}
        onSuccess={() => {
          setRoleOrScreenAdded(addRoleType.ADD_ROLE);
        }}
      />
      <AssignScreen
        data-testid='assignScreen-modal'
        isOpen={isAssignScreenModalOpen}
        setOpen={setAssignScreenModalOpen}
        onSuccess={() => setRoleOrScreenAdded(addRoleType.ADD_SCREEN)}
      />
    </section>
  );
};

export default RoleAccess;