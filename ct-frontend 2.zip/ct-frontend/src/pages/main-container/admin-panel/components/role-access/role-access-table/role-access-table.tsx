import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Pagination,
} from '@mui/material';
import React, { useEffect, useRef, useState } from 'react';
import './role-access-table.style.css';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ToggleButton from '../../../../../../components/toogleSelect';
import { nanoid } from '@reduxjs/toolkit';
import {
  addRoleType,
  alertStates,
  IListRolesParams,
  IRoleToScreenPermissionEntity,
  IScreenAccessEntity,
} from '../../../../../../common/interfaces';
import {
  getListRoles,
  getListRolesCount,
  getMapToggleToType,
  getMapTypeToToggle,
  postSaveTable,
  sortForRoleScreen,
} from '../../../../../../common/utils';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
import { useDispatch } from 'react-redux';
import { labels } from '../../../../../../common/constants';

interface ISelectedValueProps {
  selectedValue: string;
  preSelectedValue: string;
  screen: string;
  role: string;
}

interface IRoleTableProps {
  onSuccess: () => void;
  success: addRoleType;
}

const RoleAccessTable: React.FC<IRoleTableProps> = ({ success, onSuccess }) => {
  const iconRefs = useRef<HTMLElement[]>([]);
  const [data, setData] = useState<IRoleToScreenPermissionEntity[]>([]);
  const [count, setCount] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const pageSize = 10;
  const dispatch = useDispatch();

  const intParams = {
    includeScreenPermissions: true,
    includeUniqueScreen: true,
    sortOrder: 'ASC',
    sortColumn: 'role',
    pageNumber: 1,
    pageSize: pageSize,
  };

  const getRoleApi = (params: IListRolesParams) => {
    iconRefs.current = [];
    dispatch(setLoading(true));
    getListRoles(params)
      .then((res) => {
        setData(
          res?.data?.screensRolesPermissionMappings.map(
            (item: IRoleToScreenPermissionEntity) => {
              return {
                role: item.role,
                screens: sortForRoleScreen(item.screens, true),
              };
            }
          )
        );
      })
      .catch(() =>
        setAlertOnAPI(alertStates.ERROR, 'Failed to fetch role-permissions', '')
      )
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  useEffect(() => {
    if (
      success === addRoleType.ADD_ROLE ||
      success === addRoleType.ADD_SCREEN
    ) {
      if (success === addRoleType.ADD_ROLE) {
        setCount((preVal) => preVal + 1);
      }
      getRoleApi({ ...intParams, pageNumber: page });
      onSuccess();
    }
  }, [success]);

  useEffect(() => {
    getListRolesCount()
      .then((res) => {
        setCount(res.data.data);
      })
      .catch(() =>
        setAlertOnAPI(
          alertStates.ERROR,
          'Failed to fetch total table pages',
          ''
        )
      );
  }, []);

  useEffect(() => {
    getRoleApi({
      ...intParams,
      pageNumber: page,
    });
  }, [page]);

  const setAlertOnAPI = (
    alertType: alertStates,
    alertTitle: string,
    alertDescription: string
  ) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType,
        alertTitle,
        alertDescription,
      })
    );
  };

  /**
   *
   * @param val SelectedToggleButton Change
   *
   *This function will help to update the permission and also update the react state
   */
  const handleOnToggleChange = (val: ISelectedValueProps) => {
    if (val.preSelectedValue !== val.selectedValue) {
      let findRoleIndex = data.findIndex((item) => item.role === val.role);
      let screenIndex = data
        .filter((item) => item.role === val.role)[0]
        .screens.findIndex((item) => item.screen === val.screen);
      let dataVal = data[findRoleIndex].screens;
      const newData = [
        ...dataVal.slice(0, screenIndex),
        {
          screen: val.screen,
          permission: getMapToggleToType(val.selectedValue),
        },
        ...dataVal.slice(screenIndex + 1),
      ] as IScreenAccessEntity[];

      dispatch(setLoading(true));
      postSaveTable([
        {
          permission: getMapToggleToType(val.selectedValue),
          role: val.role,
          screen: val.screen,
        },
      ])
        .then(() => {
          setData([
            ...data.slice(0, findRoleIndex),
            { role: val.role, screens: newData },
            ...data.slice(findRoleIndex + 1),
          ]);
          setAlertOnAPI(alertStates.SUCCESS, labels.modifiedRole, '');
        })
        .catch(() => {
          setAlertOnAPI(alertStates.ERROR, 'Failed to modify the role', '');
        })
        .finally(() => {
          dispatch(setLoading(false));
        });
    }
  };

  const getAccordionItem = (data: IScreenAccessEntity[], role: string) => {
    return (
      <>
        {data.map((item) => {
          return (
            <div
              className='accordionEntityWrapper'
              key={`${role}.${item.screen}`}
              data-testid={`${role}.${item.screen}`}>
              <p className='two'>{item.screen}</p>
              <div className='three'>
                <ToggleButton
                  toggleTitles={['Read', 'Edit', 'NA']}
                  preSelectedValue={getMapTypeToToggle(item.permission)}
                  onClick={(e, selectedValue, preSelectedValue) =>
                    handleOnToggleChange({
                      selectedValue,
                      preSelectedValue,
                      screen: item.screen,
                      role,
                    })
                  }
                />
              </div>
            </div>
          );
        })}
      </>
    );
  };

  const scrollOnAccordianExpand = (item: HTMLElement) => {
    setTimeout(() => {
      item.scrollIntoView({ behavior: 'smooth', inline: 'start' });
    }, 100);
  };

  const getAccordionDetails = (
    item: IRoleToScreenPermissionEntity,
    index: number
  ) => {
    return (
      <Accordion
        disableGutters={true}
        ref={(element) => (iconRefs.current[index] = element!)}
        onChange={(e, expanded) => {
          if (expanded) {
            scrollOnAccordianExpand(iconRefs.current[index]);
          }
        }}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon fontSize='large' />}
          aria-controls='panel1a-content'
          id='panel1a-header'>
          <div
            className='accordionSummary'
            key={`${item?.role}.${item?.screens[0]}`}
            data-testid={`${item?.role}.${item?.screens[0]}`}>
            <p>{item?.role}</p>
            <p>{item?.screens[0]?.screen}</p>
            <div>
              <ToggleButton
                toggleTitles={['Read', 'Edit', 'NA']}
                preSelectedValue={getMapTypeToToggle(
                  item?.screens[0]?.permission
                )}
                onClick={(e, selectedValue, preSelectedValue) => {
                  handleOnToggleChange({
                    selectedValue,
                    preSelectedValue,
                    screen: item?.screens[0]?.screen,
                    role: item.role,
                  });
                  e.stopPropagation();
                }}
              />
            </div>
          </div>
        </AccordionSummary>
        <AccordionDetails>
          {getAccordionItem(item.screens.slice(1), item.role)}
        </AccordionDetails>
      </Accordion>
    );
  };

  return (
    <>
      <div className='role-access-table-wrapper'>
        <table
          className='role-access-table'
          data-testid='roleAccess-testId'>
          <thead>
            <tr key='tableRoleHeader'>
              <th>
                <div className='headerStyling'>
                  <p className='roleHeader'>{labels.role}</p>
                  <p className='screenHeader'>{labels.screen}</p>
                  <p className='permissionHeader'>{labels.permission}</p>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            {data?.map((item: IRoleToScreenPermissionEntity, index) => (
              <tr key={item.role}>
                <td>{getAccordionDetails(item, index)}</td>
              </tr>
            ))}
            {[...Array(data ? (data.length < 7 ? 7 - data.length : 0) : 8)]
              .map(() => {
                return { key: nanoid() };
              })
              .map((_, index) => {
                return (
                  <tr
                    data-testid='filler'
                    key={_.key}>
                    <td colSpan={16}>
                      <div></div>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
      <section className='paginated'>
        <Pagination
          count={Math.ceil(count / pageSize)}
          variant='text'
          shape='rounded'
          siblingCount={1}
          color={'standard'}
          showFirstButton
          showLastButton
          size='small'
          onChange={(e, value) => setPage(value)}
          page={page}
        />
      </section>
    </>
  );
};

export default RoleAccessTable;
