import React, { useEffect, useRef, useState } from 'react';
import './user-access-table.style.css';
import { labels } from '../../../../../../common/constants';
import { Pagination } from '@mui/material';
import { AutoComplete } from 'primereact/autocomplete';
import { IUserDetails, IUserDetailsCountParam, IUserDetailsParam, alertStates } from '../../../../../../common/interfaces';
import { nanoid } from '@reduxjs/toolkit';
import {
  deleteUser,
  getFillerLength,
  getUsers,
  getUsersCount,
  isStringValid,
} from '../../../../../../common/utils';
import { useDispatch } from 'react-redux';
import { setLoading } from '../../../../../../redux/reducers/loading.reducer';
import { setShowAlert } from '../../../../../../redux/reducers/alert.reducer';
import { useDidComponentUpdate } from '../../../../../../hooks/useDidComponentUpdate';

interface IUserAccessTableProps {
  newUser?: IUserDetails;
}

interface IPageAndFilter {
  page: number;
  selectedEmailId: string;
  selectedExternalId: string;
}

const UserAccessTable: React.FC<IUserAccessTableProps> = ({ newUser }) => {
  const dispatch = useDispatch();

  const initPageAndFilter: IPageAndFilter = {
    page: 1,
    selectedEmailId: '',
    selectedExternalId: '',
  };

  const [emailIdList, setEmailIdList] = useState<string[]>([]);
  const [externalIdList, setExternalIdList] = useState<string[]>([]);
  const [searchEmailId, setSearchEmailId] = useState<string>('');
  const [searchExternalId, setSearchExternalId] = useState<string>('');
  const [showEmailIdFilter, setShowEmailIdFilter] = useState<boolean>();
  const [showExternalIdFilter, setShowExternalIdFilter] = useState<boolean>();
  const [tableData, setTableData] = useState<IUserDetails[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [pageAndFilter, setPageAndFilter] =
    useState<IPageAndFilter>(initPageAndFilter);
  const pageSize = 10;
  const prevPageAndFilter = useRef<IPageAndFilter>();
  const paginationRef = useRef<any>(null);

  useEffect(() => {
    getTableDetails('all');
    getTotalRecords('all');
    prevPageAndFilter.current = undefined;
  }, []);

  useEffect(() => {
    if (newUser) {
      const newTableData: IUserDetails[] = [];
      if (
        !isStringValid(searchEmailId) &&
        !isStringValid(searchExternalId) &&
        pageAndFilter.page === 1
      ) {
        newTableData.push({ ...newUser, key: nanoid() });
        newTableData.push(...tableData);

        if (tableData.length >= pageSize) {
          newTableData.pop();
        }

        setTableData(newTableData);
        setTotalRecords(totalRecords + 1);
      } else {
        if (isStringValid(searchEmailId)) {
          handleFilterCross('emailId');
        } else {
          handleFilterCross('externalId');
        }
      }
    }
  }, [newUser]);

  useDidComponentUpdate(() => {
    prevPageAndFilter.current = pageAndFilter;
    if (!prevPageAndFilter.current) {
      getTableDetails(
        'all',
        pageAndFilter.selectedEmailId,
        pageAndFilter.selectedExternalId,
        1
      );
      if (
        !(
          isStringValid(pageAndFilter.selectedEmailId) ||
          isStringValid(pageAndFilter.selectedExternalId)
        )
      )
        getTotalRecords(
          'all',
          pageAndFilter.selectedEmailId,
          pageAndFilter.selectedExternalId
        );
    } else {
      if (
        prevPageAndFilter.current.selectedEmailId !==
          pageAndFilter.selectedEmailId ||
        prevPageAndFilter.current.selectedExternalId !==
          pageAndFilter.selectedExternalId
      ) {
        getTableDetails(
          'all',
          pageAndFilter.selectedEmailId,
          pageAndFilter.selectedExternalId,
          1
        );
        if (
          !(
            isStringValid(pageAndFilter.selectedEmailId) ||
            isStringValid(pageAndFilter.selectedExternalId)
          )
        )
          getTotalRecords(
            'all',
            pageAndFilter.selectedEmailId,
            pageAndFilter.selectedExternalId
          );
      } else {
        getTableDetails(
          'all',
          pageAndFilter.selectedEmailId,
          pageAndFilter.selectedExternalId,
          pageAndFilter.page
        );
      }
    }
  }, [pageAndFilter]);

  const getErrorAlert = (message: string) => {
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: alertStates.ERROR,
        alertTitle: message,
        alertDescription: '',
      })
    );
  };

  const getTableDetails = (
    fetchType?: 'all' | 'emailId' | 'externalId',
    emailIdVar?: string,
    externalIdVar?: string,
    pageNoVar?: number
  ) => {
    fetchType === 'all' && setTableData([]);
    if (fetchType === 'all') {
      dispatch(setLoading(true));
    }

    var request: IUserDetailsParam = {
      selectField: fetchType ? fetchType : 'all',
      pageNumber: pageNoVar ? pageNoVar : pageAndFilter.page,
      pageSize: pageSize,
    };

    if (emailIdVar) {
      request = { ...request, emailId: emailIdVar };
    }
    if (externalIdVar) {
      request = { ...request, externalId: externalIdVar };
    }

    getUsers(request)
      .then((res) => {
        switch (fetchType) {
          case 'all':
            setTableData(
              res.data.data[0].map((row: IUserDetails) => {
                return { ...row, key: nanoid() };
              })
            );
            break;
          case 'emailId':
            setEmailIdList(res.data.data[0].map((value: any) => value));
            break;
          case 'externalId':
            setExternalIdList(res.data.data[0].map((value: any) => value));
            break;
        }
      })
      .catch(() => {
        getErrorAlert('Failed to fetch user access details table data');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const getTotalRecords = (
    fetchType?: 'all' | 'emailId' | 'externalId',
    emailIdVar?: string,
    externalIdVar?: string
  ) => {
    setTotalRecords(0);
    if (fetchType === 'all') {
      dispatch(setLoading(true));
    }

    var request: IUserDetailsCountParam = {
      selectField: fetchType ? fetchType : 'all',
    };

    if (emailIdVar) {
      request = { ...request, emailId: emailIdVar };
    }
    if (externalIdVar) {
      request = { ...request, externalId: externalIdVar };
    }

    getUsersCount(request)
      .then((res) => {
        setTotalRecords(res.data.data);
      })
      .catch(() => {
        getErrorAlert('Failed to fetch user access details table total pages');
      });
  };

  const handleFilterCross = (
    filterType: 'emailId' | 'externalId' | undefined
  ) => {
    switch (filterType) {
      case 'emailId':
        setShowEmailIdFilter(false);
        setSearchEmailId('');
        setPageAndFilter({ ...pageAndFilter, page: 1, selectedEmailId: '' });
        getTotalRecords('all');
        break;
      case 'externalId':
        setShowExternalIdFilter(false);
        setSearchExternalId('');
        setPageAndFilter({ ...pageAndFilter, page: 1, selectedExternalId: '' });
        getTotalRecords('all');
        break;
      default:
        break;
    }
  };

  const handleDeleteUser = (emailId: string) => {
    dispatch(setLoading(true));

    deleteUser(emailId)
      .then((res) => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.SUCCESS,
            alertTitle: res.data.data,
            alertDescription: '',
          })
        );
        if (isStringValid(searchEmailId)) {
          handleFilterCross('emailId');
        } else {
          handleFilterCross('externalId');
        }
        getTotalRecords('all');
      })
      .catch((err) => {
        dispatch(
          setShowAlert({
            showAlert: true,
            alertType: alertStates.ERROR,
            alertTitle:
              err &&
              err.response &&
              err.response.data &&
              err.response.data.errorMessage
                ? err.response.data.errorMessage
                : 'Failed to delete the user access',
            alertDescription: '',
          })
        );
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };
  return (
    <section className='user-access-table-pagination-wrapper'>
      <section className='user-access-table-wrapper'>
        <table
          className='user-access-table'
          data-testid='userAccessTable-testId'>
          <thead>
            <tr>
              <th>
                {showEmailIdFilter ? (
                  <>
                    <AutoComplete
                      autoFocus
                      minLength={4}
                      delay={500}
                      showEmptyMessage={true}
                      value={searchEmailId}
                      onChange={(e) => setSearchEmailId(e.value)}
                      suggestions={emailIdList}
                      completeMethod={(event) =>
                        getTableDetails(
                          'emailId',
                          event.query,
                          pageAndFilter.selectedExternalId,
                          1
                        )
                      }
                      onSelect={(event) => {
                        setPageAndFilter({
                          ...pageAndFilter,
                          page: 1,
                          selectedEmailId: event.value,
                        });
                        setTotalRecords(1);
                      }}
                      className='user-access-table-filter'
                    />
                    <i
                      data-testid='container-search-reset'
                      className='pi pi-times'
                      onClick={() => handleFilterCross('emailId')}
                      style={{
                        fontSize: '.9rem',
                        fontWeight: 'bold',
                        marginLeft: '.4rem',
                        cursor: 'pointer',
                      }}></i>
                  </>
                ) : (
                  <div className='inbound-table-filter'>
                    {labels.emailId}
                    <i
                      data-testid='container-search'
                      className='pi pi-search'
                      onClick={() => setShowEmailIdFilter(true)}
                      style={{
                        fontSize: '.9rem',
                        fontWeight: 'bold',
                        marginLeft: '.4rem',
                        cursor: 'pointer',
                      }}></i>
                  </div>
                )}
              </th>
              <th>{labels.userRole}</th>
              <th>
                {showExternalIdFilter ? (
                  <>
                    <AutoComplete
                      autoFocus
                      minLength={4}
                      delay={500}
                      showEmptyMessage={true}
                      value={searchExternalId}
                      onChange={(e) => setSearchExternalId(e.value)}
                      suggestions={externalIdList}
                      completeMethod={(event) =>
                        getTableDetails(
                          'externalId',
                          pageAndFilter.selectedEmailId,
                          event.query,
                          1
                        )
                      }
                      onSelect={(event) => {
                        setPageAndFilter({
                          ...pageAndFilter,
                          page: 1,
                          selectedExternalId: event.value,
                        });
                        setTotalRecords(1);
                      }}
                      className='user-access-table-filter'
                    />
                    <i
                      data-testid='container-search-reset'
                      className='pi pi-times'
                      onClick={() => handleFilterCross('externalId')}
                      style={{
                        fontSize: '.9rem',
                        fontWeight: 'bold',
                        marginLeft: '.4rem',
                        cursor: 'pointer',
                      }}></i>
                  </>
                ) : (
                  <div className='inbound-table-filter'>
                    {labels.externalId}
                    <i
                      data-testid='container-search'
                      className='pi pi-search'
                      onClick={() => setShowExternalIdFilter(true)}
                      style={{
                        fontSize: '.9rem',
                        fontWeight: 'bold',
                        marginLeft: '.4rem',
                        cursor: 'pointer',
                      }}></i>
                  </div>
                )}
              </th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tableData.length > 0 &&
              tableData.map((value) => {
                return (
                  <tr key={value.key}>
                    <td>{value.emailId}</td>
                    <td>{value.role}</td>
                    <td>{value.externalId}</td>
                    <td>
                      {value.role.toUpperCase().trim() !==
                        'SUPER POWER USER' && (
                        <button
                          data-testid='deleteUser-testid'
                          className='deleteActionButton'
                          onClick={() => handleDeleteUser(value.emailId)}>
                          {'Delete'}
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            {[...Array(getFillerLength(tableData, 6))]
              .map(() => {
                return { key: nanoid() };
              })
              .map((_, index) => {
                return (
                  <tr
                    data-testid='filler'
                    key={_.key}>
                    <td colSpan={16}>
                      <div></div>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </section>
      <section className={'paginated'}>
        <Pagination
          ref={paginationRef}
          count={Math.ceil(totalRecords / pageSize)}
          variant='text'
          shape='rounded'
          siblingCount={1}
          color={'standard'}
          showFirstButton
          showLastButton
          size='small'
          onChange={(e, value) =>
            setPageAndFilter({ ...pageAndFilter, page: value })
          }
          page={pageAndFilter.page}
        />
      </section>
    </section>
  );
};

export default UserAccessTable;