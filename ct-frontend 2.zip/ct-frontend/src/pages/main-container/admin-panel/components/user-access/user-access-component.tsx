import React, { useEffect, useState } from 'react';
import SingleSelect, { ISelectElement } from '../../../../../components/SingleSelect';
import { labels } from '../../../../../common/constants';
import './user-access.style.css';
import UserAccessTable from './user-access-table/user-access-table';
import AutoSuggestSearch from '../../../../../components/autoSuggestSearch';
import {
  getAdminPanelUserRoles,
  getUserEmailIds,
  isAlphaNumericString,
  postUser,
} from '../../../../../common/utils';
import { useDispatch } from 'react-redux';
import { setShowAlert } from '../../../../../redux/reducers/alert.reducer';
import { IUserDetails, alertStates } from '../../../../../common/interfaces';
import { setLoading } from '../../../../../redux/reducers/loading.reducer';

const UserAccess: React.FC = () => {
  const [emailId, setEmailId] = useState<string>('');
  const [emailList, setEmailList] = useState<ISelectElement[]>([]);
  const [externalId, setExternalId] = useState<string>('');
  const [externalRoleList, setExternalRoleList] = useState<string[]>([]);
  const [newUser, setNewUser] = useState<IUserDetails>();
  const [userRole, setUserRole] = useState<string>('');
  const [userRoleList, setUserRoleList] = useState<ISelectElement[]>([]);
  const [reset, setReset] = useState<boolean>(false);

  const dispatch = useDispatch();

  useEffect(() => {
    getUserRoleList();
  }, []);

  useEffect(() => {
    if (emailId === '') {
      setReset(false);
      setUserRoleList([...userRoleList]);
    }
  }, [emailId]);

  useEffect(() => {
    if (userRole.length > 0 && !isExternalUser()) {
      setExternalId('');
    }
  }, [userRole]);

  const isValidExternalId = () => {
    if (isExternalUser()) {
      if (
        externalId === 'NA' ||
        externalId === 'na' ||
        !(externalId.length >= 4 && externalId.length <= 8)
      ) {
        return false;
      }
    }
    return true;
  };

  const addUser = () => {
    dispatch(setLoading(true));

    if (isValidExternalId()) {
      postUser({
        emailId: emailId,
        role: userRole,
        externalId: externalId.length > 0 ? externalId : 'NA',
      })
        .then((res) => {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.SUCCESS,
              alertTitle: res.data.data,
              alertDescription: '',
            })
          );
          setNewUser({
            emailId: emailId,
            role: userRole,
            externalId: externalId.length > 0 ? externalId : 'NA',
          });
          setEmailId('');
          setEmailList([]);
          setUserRole('');
          setExternalId('');
          setReset(true);
        })
        .catch((err) => {
          dispatch(
            setShowAlert({
              showAlert: true,
              alertType: alertStates.ERROR,
              alertTitle: 'Existing User',
              alertDescription: err.response.data.errorMessage,
            })
          );
        })
        .finally(() => {
          dispatch(setLoading(false));
        });
    } else {
      dispatch(
        setShowAlert({
          showAlert: true,
          alertType: alertStates.ERROR,
          alertTitle: 'Invalid External ID',
          alertDescription:
            'External IDs cannot contain special characters/NA and should have length in the range [4-8]',
        })
      );
      dispatch(setLoading(false));
    }
  };

  const getErrorAlert = (message: string) => {
    dispatch(setLoading(true));
    dispatch(
      setShowAlert({
        showAlert: true,
        alertType: alertStates.ERROR,
        alertTitle: message,
        alertDescription: '',
      })
    );
  };

  const getUserRoleList = () => {
    setReset(false);
    dispatch(setLoading(true));
    getAdminPanelUserRoles({
      includeScreenPermissions: false,
      includeUniqueScreen: false,
      pageNumber: 1,
      pageSize: 25,
    })
      .then((res) => {
        const externalRoleListData: string[] = [];
        const userRoleListData: ISelectElement[] = [];
        res.data.forEach((row: any) => {
          const role = row.role;
          if (!(role === undefined || role === null || role === '')) {
            if (row.is_external_user) {
              externalRoleListData.push(role);
            }
            userRoleListData.push({
              key: role,
              value: role,
            });
          }
        });
        setExternalRoleList(externalRoleListData);
        setUserRoleList(userRoleListData);
      })
      .catch(() => {
        getErrorAlert('Failed to fetch roles list');
      })
      .finally(() => {
        dispatch(setLoading(false));
      });
  };

  const isDisabled = () => {
    if (emailId.length > 0 && userRole.length > 0) {
      if (!isExternalUser()) {
        return false;
      } else if (externalId.length > 0) {
        return false;
      }
    }

    return true;
  };

  const isExternalUser = () => {
    if (
      userRole.length > 0 &&
      externalRoleList.find((role) => role === userRole)
    ) {
      return true;
    }

    return false;
  };

  const onSearch = (val: string) => {
    if (val.length >= 4) {
      dispatch(setLoading(true));
      getUserEmailIds(val)
        .then((res) => {
          const data: ISelectElement[] = [];
          if (res.data.users) {
            res.data.users.forEach((user: any) => {
              const email = user.emails[0].address;
              if (!(email === undefined || email === null || email === '')) {
                data.push({
                  key: email,
                  value: email,
                });
              }
            });
            setEmailList(data);
          } else {
            setEmailList([]);
          }
        })
        .catch(() => {
          getErrorAlert('Failed to fetch user email IDs');
        })
        .finally(() => {
          dispatch(setLoading(false));
        });
    } else {
      setEmailList([]);
    }
  };

  return (
    <section>
      <div
        className='user-access-wrapper'
        data-testid='user-access'>
        <div className='user-access-filter-add-wrapper'>
          <div className='user-access-filter-wrapper'>
            <div className='filter'>
              <p className='query-text'>{labels.emailId}</p>
              <AutoSuggestSearch
                data={emailList}
                onSearch={(val) => onSearch(val)}
                onRadioClick={(val) => setEmailId(val)}
                searchLength={4}
                dataTestId='email'
                reset={reset}
              />
            </div>
            <div className='filter'>
              <p className='query-text'>{labels.userRole}</p>
              <SingleSelect
                dataTestId='userRole'
                buttonTittle='Select Role'
                data={userRoleList}
                onRadioClick={(ele) => setUserRole(ele.value)}
                className='selectWrapper'
              />
            </div>
            {isExternalUser() && (
              <div className='filter'>
                <p className='query-text'>{labels.externalId}</p>
                <input
                  data-testid='external-testId'
                  className='external-id-input'
                  type='text'
                  placeholder='Enter ID'
                  disabled={!isExternalUser()}
                  onChange={(e) =>
                    isAlphaNumericString(e.target.value)
                      ? setExternalId(e.target.value)
                      : null
                  }
                  value={externalId}
                />
              </div>
            )}
          </div>
          <div className='user-access-button-wrapper'>
            <button
              className='add-button'
              data-testid='addUserButton-testid'
              disabled={isDisabled()}
              onClick={() => addUser()}>
              Add User
            </button>
          </div>
        </div>
        <div className='user-access-divider'></div>
        <div className='user-access-details-label'>
          {labels.userAccessDetails}
        </div>
        <UserAccessTable newUser={newUser} />
      </div>
    </section>
  );
};

export default UserAccess;