import { act, cleanup, render, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import AdminPanel from '../AdminPanel';
import {
  checkElementNotPresentInDomByTestId,
  checkElementPresentInDomByTestId,
  checkIfElementIsDisabled,
  clickElementByTestId,
  clickedSpecificElementInGroup,
  setInputValue,
  textPresentInDOM,
} from '../../../../common/helper/testHelper';
import {
  UserAccessRoles,
  userRole,
} from '../../../../common/mocks/promotionAndProcurement';
import { routes } from '../../../../common/constants';

afterEach(() => {
  cleanup();
});

const powerUserState = {
  user: {
    userRole: 'powerUserDummyId',
    userExternalId: 'externalId',
    appToken: 'appToken',
    idToken: 'idToken',
    appTokenExpiration: 1200000,
    userId: 'userId',
    refreshTokenId: 'refreshTokenId',
    routePermissions: [
      {
        screen: 'RECENT_PO_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'VESSEL_TRACKING',
        permission: 'READ',
        route: 'vessel-tracking',
      },
      {
        screen: 'PORT_DOCUMENT_LIBRARY',
        permission: 'READ',
        route: 'document-library',
      },
      {
        screen: 'RECENT_SHIPMENT_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'RECENT_CONTAINER_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'PO_MANAGEMENT',
        permission: 'READ',
        route: 'po-management',
      },
      {
        screen: 'INBOUND_OPTIMIZATION',
        permission: 'READ',
        route: 'externalization',
      },
      {
        screen: 'FAVOURITE_EVENT_INVENTORY_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_INVENTORY_TREND_DASHBOARD_TILE',
        permission: 'READ',
        route: 'home',
      },
      {
        screen: 'EVENT_AND_INVENTORY_PLAN_DETAILS',
        permission: 'READ',
        route: 'event-inventory-plan/details',
      },
      {
        screen: 'PO_ITEM_MANAGEMENT',
        permission: 'READ',
        route: 'item-management',
      },
      {
        screen: 'INVENTORY_PLAN',
        permission: 'READ',
        route: 'event-inventory-plan',
      },
      {
        screen: 'PO_LINE_MANAGEMENT',
        permission: 'READ',
        route: 'po-management/details',
      },
      {
        screen: 'SHIPMENT_AND_LOAD_MANAGEMENT',
        permission: 'READ',
        route: 'ship-load-management',
      },
      {
        screen: 'CONTAINER_TRACKING',
        permission: 'WRITE',
        route: 'vessel-tracking/details',
      },
      {
        screen: 'CONTAINER_DOCUMENT_LIBRARY',
        permission: 'WRITE',
        route: 'document-library',
      },
      {
        screen: 'SUPPLIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
      {
        screen: 'EVENT_PLAN',
        permission: 'WRITE',
        route: 'event-inventory-plan',
      },
      {
        screen: 'LOAD_DOCUMENT_LIBRARY',
        permission: 'WRITE',
        route: 'document-library',
      },
      {
        screen: 'ADMIN',
        permission: 'WRITE',
        route: 'admin-panel',
      },
      {
        screen: 'CARRIER_CRM',
        permission: 'WRITE',
        route: 'externalization',
      },
    ],
    userDefaultRoute: routes.home,
  },

  systemSetting: [
    {
      name: 'activity_visited_days_limit',
      value: '7',
    },
    {
      name: 'activity_favourite_days_limit',
      value: '30',
    },
    {
      name: 'enable_fixed_date',
      value: 'true',
    },
    {
      name: 'fixed_date',
      value: '2023-02-21',
    },
  ],
  navbar: {
    isExpanded: false,
  },
};

describe('Admin Panel for User Access', () => {
  const mockStore = configureStore();

  test('Initial render of User Access', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getUsers')
      .mockResolvedValue({ data: { data: userRole } });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockResolvedValue({ data: UserAccessRoles });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId(
        'singleSelectButton-userRole-testid'
      );
    });
    await act(async () => {
      await checkElementNotPresentInDomByTestId('external-testId');
    });
    await act(async () => {
      await textPresentInDOM('Add User');
    });
    await act(async () => {
      await checkIfElementIsDisabled('addUserButton-testid');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('userAccessTable-testId');
    });
  });

  test('When getAdminPanelUserRoles API fails', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getUsers')
      .mockResolvedValue({ data: { data: userRole } });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockRejectedValue({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-userRole-testid');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId(
        'singleSelect-noData-userRole-testid'
      );
    });
  });

  test('Render of External Id field based on User Role', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getUsers')
      .mockResolvedValue({ data: { data: userRole } });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockResolvedValue({ data: UserAccessRoles });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await checkElementNotPresentInDomByTestId('external-testId');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-userRole-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-userRole-testid',
      0
    );
    await act(async () => {
      await checkElementPresentInDomByTestId('external-testId');
    });
  });

  test('On click of Add User button for non-external user', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockResolvedValue({ data: userRole });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockResolvedValue({ data: UserAccessRoles });
    const postUser = jest
      .spyOn(util, 'postUser')
      .mockResolvedValue({ data: { data: 'User added successfully' } });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await setInputValue('searchInput-email-testid', 'test@deloitte.com');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-userRole-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-userRole-testid',
      1
    );
    await act(async () => {
      await checkElementNotPresentInDomByTestId('external-testId');
    });
    await act(async () => {
      await clickElementByTestId('addUserButton-testid');
      expect(postUser).not.toBeCalled();
    });
  });

  test('On click of Add User button for external user', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockResolvedValue({ data: userRole });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockResolvedValue({ data: UserAccessRoles });
    const postUser = jest
      .spyOn(util, 'postUser')
      .mockResolvedValue({ data: { data: 'User added successfully' } });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await setInputValue('searchInput-email-testid', 'adam@deloitte.com');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-userRole-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-userRole-testid',
      1
    );
    await act(async () => {
      await checkElementNotPresentInDomByTestId('external-testId');
    });
    // await act(async () => {
    //   await clickElementByTestId('addUserButton-testid');
    //   expect(postUser).toBeCalled();
    // });
  });

  test('When External Id is invalid', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getUsers')
      .mockResolvedValue({ data: { data: userRole } });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockResolvedValue({ data: UserAccessRoles });
    const postUser = jest
      .spyOn(util, 'postUser')
      .mockResolvedValue({ status: 500 });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await setInputValue('searchInput-email-testid', 'test@deloitte.com');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-userRole-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-userRole-testid',
      0
    );
    await act(async () => {
      await checkElementPresentInDomByTestId('external-testId');
    });
    await act(async () => {
      await setInputValue('external-testId', '@test');
      await clickElementByTestId('addUserButton-testid');
      expect(postUser).not.toBeCalled();
    });
    await act(async () => {
      await setInputValue('external-testId', '1234567890');
      await clickElementByTestId('addUserButton-testid');
      expect(postUser).not.toBeCalled();
    });
  });

  test('On click of Delete user button', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getUsers')
      .mockResolvedValue({ data: { data: userRole } });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockResolvedValue({ data: UserAccessRoles });
    const deleteUser = jest.spyOn(util, 'deleteUser').mockResolvedValue({
      status: 200,
      data: {
        data: 'User deleted successfully',
      },
    });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-userRole-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-userRole-testid',
      0
    );
    await act(async () => {
      await checkElementPresentInDomByTestId('external-testId');
    });
    await act(async () => {
      await clickedSpecificElementInGroup('deleteUser-testid', 0);
      expect(deleteUser).toBeCalled();
    });
  });

  test('When delete user API fails', async () => {
    const powerUserStore = mockStore(powerUserState);
    const util = require('../../../../common/utils');
    jest
      .spyOn(util, 'getUsers')
      .mockResolvedValue({ data: { data: userRole } });
    jest
      .spyOn(util, 'getUsersCount')
      .mockResolvedValue({ data: { data: userRole.length } });
    jest
      .spyOn(util, 'getAdminPanelUserRoles')
      .mockResolvedValue({ data: UserAccessRoles });
    const deleteUser = jest.spyOn(util, 'deleteUser').mockRejectedValue({
      status: 500,
      response: {
        data: {
          errorMessage: '',
        },
      },
    });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementPresentInDomByTestId('adminPanel-header-testId');
    await act(async () => {
      await clickElementByTestId('userAccessTab');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('user-access');
    });
    await act(async () => {
      await checkElementPresentInDomByTestId('autoSuggestSearch-email-testid');
    });
    await act(async () => {
      await clickElementByTestId('singleSelectButton-userRole-testid');
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-userRole-testid',
      0
    );
    await act(async () => {
      await clickedSpecificElementInGroup('deleteUser-testid', 0);
    });
    expect(deleteUser).toBeCalled();
  });
});
