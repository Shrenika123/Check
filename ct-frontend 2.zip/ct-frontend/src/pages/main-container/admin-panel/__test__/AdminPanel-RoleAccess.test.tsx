import { act, cleanup, render, screen, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import AdminPanel from '../AdminPanel';
import {
  clickElementByTestId,
  clickedSpecificElementInGroup,
  textNotPresentInDOM,
  checkElementPresentInDomByTestId,
  checkIfElementIsDisabled,
  checkIfElementNotDisabled,
  textPresentInDOM,
  checkElementNotPresentInDomByTestId,
  setInputValue,
} from '../../../../common/helper/testHelper';
import {
  RoleScreenData,
  ScreenData,
} from '../../../../common/mocks/promotionAndProcurement';
import userEvent from '@testing-library/user-event';

afterEach(() => {
  cleanup();
});

jest.mock('nanoid', () => {
  return { nanoid: () => Math.random().toString() };
});

const getUserGroup = (userGroup?: string) => {
  const powerUserState = {
    user: {
      userGroupId: '034g0dwd13cd23l',
      userGroupName: userGroup ?? 'Power User',
      userGroupRoutes: [
        '/po-management',
        '/po-management/details',
        '/item-management',
        '/vessel-tracking',
        '/vessel-tracking/details',
        '/admin-panel',
        '/externalization',
      ],
    },
    navbar: {
      isExpanded: false,
    },
  };
  return powerUserState;
};

jest.mock('axios', () => {
  return {
    interceptors: {
      request: { use: jest.fn(), eject: jest.fn() },
      response: { use: jest.fn(), eject: jest.fn() },
    },
  };
});

describe('Admin Panel for Table', () => {
  const mockStore = configureStore();
  test('Initial render of User Access and modify permissions', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    const saveAccess = jest
      .spyOn(util, 'postSaveTable')
      .mockResolvedValue({ data: {} });
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest
      .spyOn(util, 'getListRoles')
      .mockResolvedValue({ data: RoleScreenData });
    jest
      .spyOn(util, 'getListRolesCount')
      .mockResolvedValue({ data: { data: 30 } });

    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await act(async () => {
      await clickedSpecificElementInGroup('toggleThree', 0);
    });
    expect(saveAccess).toBeCalled();
    await checkElementPresentInDomByTestId('Supplier.PO Item Management');
    userEvent.click(screen.getByTestId('NavigateNextIcon'));
  });
});

describe('Admin Panel for Screen Access', () => {
  const mockStore = configureStore();
  test('Assign Screen to role', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getListRoles').mockResolvedValue({ data: [] });
    jest
      .spyOn(util, 'getListRolesCount')
      .mockResolvedValue({ data: { data: 30 } });
    const saveScreenPermission = jest
      .spyOn(util, 'saveScreenPermission')
      .mockResolvedValue({ data: {} });
    const screenList = jest
      .spyOn(util, 'getListScreens')
      .mockResolvedValue({ data: { data: ScreenData[0] } });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await act(async () => {
      await clickElementByTestId('assign-role-to-screen');
    });
    expect(screenList).toBeCalled();
    await waitFor(async () => {
      await textNotPresentInDOM('assign-screen-button');
    });
    await checkIfElementIsDisabled('assign-screen-button');
    await act(async () => {
      await clickElementByTestId(
        'singleSelectButton-assign-seen-role-filter-testid'
      );
    });
    await textPresentInDOM('Please select the screen to proceed further');
    await textNotPresentInDOM(
      'Select role(s) and permission(s) type for the above selected screen'
    );
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-assign-seen-role-filter-testid',
      0
    );
    await textNotPresentInDOM('Please select the screen to proceed further');
    await textPresentInDOM(
      'Select role(s) and permission(s) type for the above selected screen'
    );
    await act(async () => {
      await clickedSpecificElementInGroup('toggleTwo', 0);
    });
    await act(async () => {
      await clickedSpecificElementInGroup('toggleThree', 0);
    });
    await checkIfElementNotDisabled('assign-screen-button');
    await clickElementByTestId('assign-screen-button');
    expect(saveScreenPermission).toBeCalled();
  });

  test('Assign Screen to role new Screen', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getListRoles').mockResolvedValue({ data: [] });
    jest
      .spyOn(util, 'getListRolesCount')
      .mockResolvedValue({ data: { data: 30 } });
    jest
      .spyOn(util, 'getListScreens')
      .mockResolvedValue({ data: { data: ScreenData[0] } });
    const saveScreenPermission = jest
      .spyOn(util, 'saveScreenPermission')
      .mockResolvedValue({ data: {} });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await checkElementNotPresentInDomByTestId('successModalForRoleScreen');
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await act(async () => {
      await clickElementByTestId('assign-role-to-screen');
    });
    await waitFor(async () => {
      await textNotPresentInDOM('assign-screen-button');
    });
    await checkIfElementIsDisabled('assign-screen-button');
    await act(async () => {
      await clickElementByTestId(
        'singleSelectButton-assign-seen-role-filter-testid'
      );
    });
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-assign-seen-role-filter-testid',
      3
    );
    await act(async () => {
      await clickedSpecificElementInGroup('toggleTwo', 0);
    });
    await checkIfElementNotDisabled('assign-screen-button');
    await clickElementByTestId('assign-screen-button');
    expect(saveScreenPermission).toBeCalled();
    await checkElementPresentInDomByTestId('assign-screen-button');
    await checkElementPresentInDomByTestId('successModalForRoleScreen');
  });
});

describe('Admin Panel for add Role', () => {
  const mockStore = configureStore();
  test('Initial render of User Access', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getListRoles').mockRejectedValue({});
    jest
      .spyOn(util, 'getListScreens')
      .mockResolvedValue({ data: { data: ScreenData[0] } });
    jest.spyOn(util, 'getListRolesCount').mockRejectedValue({});
    const roleSave = jest.spyOn(util, 'addRole').mockResolvedValue({});

    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await checkElementNotPresentInDomByTestId('add-role');
    await act(async () => {
      await clickElementByTestId('add-role-button');
    });
    await waitFor(async () => {
      await textPresentInDOM(
        'Select screen(s) and permission type for the above mentioned user'
      );
    });
    await setInputValue('addRole-input', '');
    await checkIfElementIsDisabled('add-role-submit-button');
    await act(async () => {
      await clickedSpecificElementInGroup('toggleThree', 0);
    });
    await act(async () => {
      await clickedSpecificElementInGroup('toggleTwo', 0);
    });
    await clickElementByTestId('addRole-checkbox');
    await setInputValue('addRole-input', 'Admin');
    await checkIfElementNotDisabled('add-role-submit-button');
    await clickElementByTestId('add-role-submit-button');
    expect(roleSave).toBeCalled();
    await checkElementPresentInDomByTestId('successModalForRoleScreen');
  });
});

describe('Admin Panel for API failures', () => {
  const mockStore = configureStore();
  test('initial API failure for table and assign Screen', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getListRoles').mockRejectedValue({});
    jest.spyOn(util, 'getListScreens').mockRejectedValue({});
    jest.spyOn(util, 'getListRolesCount').mockRejectedValue({});
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await checkElementNotPresentInDomByTestId('add-role');
    await act(async () => {
      await clickElementByTestId('add-role-button');
    });
    await waitFor(async () => {
      await textPresentInDOM(
        'Select screen(s) and permission type for the above mentioned user'
      );
    });
    await act(async () => {
      await clickElementByTestId('assign-role-to-screen');
    });
  });

  test('initial API failure for change permission and add role initial API', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getListScreens').mockRejectedValue({});
    jest.spyOn(util, 'postSaveTable').mockRejectedValue({ data: {} });
    jest
      .spyOn(util, 'getListRoles')
      .mockResolvedValue({ data: RoleScreenData });
    jest
      .spyOn(util, 'getListRolesCount')
      .mockResolvedValue({ data: { data: 30 } });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await checkElementNotPresentInDomByTestId('add-role');
    await act(async () => {
      await clickedSpecificElementInGroup('toggleThree', 0);
    });
    await checkElementNotPresentInDomByTestId('add-role');
    await act(async () => {
      await clickElementByTestId('add-role-button');
    });
    await waitFor(async () => {
      await textPresentInDOM(
        'Select screen(s) and permission type for the above mentioned user'
      );
    });
  });

  test('Assign Screen to role', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getListRoles').mockResolvedValue({ data: [] });
    jest
      .spyOn(util, 'getListRolesCount')
      .mockResolvedValue({ data: { data: 30 } });
    jest.spyOn(util, 'saveScreenPermission').mockRejectedValue({ data: {} });
    const screenList = jest
      .spyOn(util, 'getListScreens')
      .mockResolvedValue({ data: { data: ScreenData[0] } });
    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await act(async () => {
      await clickElementByTestId('assign-role-to-screen');
    });
    expect(screenList).toBeCalled();
    await waitFor(async () => {
      await textNotPresentInDOM('assign-screen-button');
    });
    await checkIfElementIsDisabled('assign-screen-button');
    await act(async () => {
      await clickElementByTestId(
        'singleSelectButton-assign-seen-role-filter-testid'
      );
    });
    await textPresentInDOM('Please select the screen to proceed further');
    await textNotPresentInDOM(
      'Select role(s) and permission(s) type for the above selected screen'
    );
    await clickedSpecificElementInGroup(
      'singleSelectRadioButton-assign-seen-role-filter-testid',
      0
    );
    await textNotPresentInDOM('Please select the screen to proceed further');
    await textPresentInDOM(
      'Select role(s) and permission(s) type for the above selected screen'
    );
    await act(async () => {
      await clickedSpecificElementInGroup('toggleTwo', 0);
    });
    await act(async () => {
      await clickedSpecificElementInGroup('toggleThree', 0);
    });
    await checkIfElementNotDisabled('assign-screen-button');
    await clickElementByTestId('assign-screen-button');
  });

  test('Initial render of User Access', async () => {
    const powerUserStore = mockStore(getUserGroup());
    const util = require('../../../../common/utils');
    jest.spyOn(util, 'getUsers').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getUsersCount').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getAdminPanelUserRoles').mockRejectedValue({ data: {} });
    jest.spyOn(util, 'getListRoles').mockRejectedValue({});
    jest
      .spyOn(util, 'getListScreens')
      .mockResolvedValue({ data: { data: ScreenData[0] } });
    jest.spyOn(util, 'getListRolesCount').mockRejectedValue({});
    const roleSave = jest.spyOn(util, 'addRole').mockRejectedValue({});

    render(
      <Provider store={powerUserStore}>
        <AdminPanel isExpanded={false} />
      </Provider>,
      { wrapper: BrowserRouter }
    );
    await act(async () => {
      await clickElementByTestId('roleAccessTab');
    });
    await checkElementNotPresentInDomByTestId('add-role');
    await act(async () => {
      await clickElementByTestId('add-role-button');
    });
    await waitFor(async () => {
      await textPresentInDOM(
        'Select screen(s) and permission type for the above mentioned user'
      );
    });
    await setInputValue('addRole-input', '');
    await checkIfElementIsDisabled('add-role-submit-button');
    await act(async () => {
      await clickedSpecificElementInGroup('toggleThree', 0);
    });
    await act(async () => {
      await clickedSpecificElementInGroup('toggleTwo', 0);
    });
    await clickElementByTestId('addRole-checkbox');
    await setInputValue('addRole-input', 'Admin');
    await checkIfElementNotDisabled('add-role-submit-button');
    await clickElementByTestId('add-role-submit-button');
    expect(roleSave).toBeCalled();
  });
});

