import { FC, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { setUserRolePermissions } from '../../redux/reducers/userPermissions.reducer';
import { setSystemSetting } from '../../redux/reducers/systemSetting.reducer';
import { toast } from "react-toastify";
import { IUserState } from '../../common/interfaces';

const Logout: FC = () => {

  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const refreshTokenIdVar = useSelector((state: IUserState) => state.user.refreshTokenId);

  useEffect(() => {
    clearInterval(refreshTokenIdVar)
    if(location.search === '?session-expired'){
      toast.error('User session expired, Please login again',{type:'error'});
    }

    if (location.pathname === '/logout') {
      localStorage.clear();
      dispatch(setUserRolePermissions({ 
        user_role: '', 
        user_routes: [], 
        default_route: '',
        external_id: '' ,
        app_token: '',
        id_token: '',
        expiration: 0,
        user_id: '',
        refresh_token_id: 0
      }));
      dispatch(setSystemSetting([]))
      navigate('/login');
    }
  }, []);

  return null;
};

export default Logout;