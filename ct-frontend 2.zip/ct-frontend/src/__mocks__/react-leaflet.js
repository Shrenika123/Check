export const MapContainer = jest.fn();
export const TileLayer = jest.fn();
export const Tooltip = jest.fn();
export const Marker = jest.fn();
export const Polyline = jest.fn();
export const useMap = function () {
  return {
    setView: jest.fn()
  };
};