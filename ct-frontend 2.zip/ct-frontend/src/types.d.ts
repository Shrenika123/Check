declare module "*.pdf";
declare module "*.docx";
declare module "*.doc";