import axios from "axios";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import { IUserState } from "../common/interfaces";

const useAxiosInterceptor = () => {
   
    const refreshTokenIdVar = useSelector((state: IUserState) => state.user.refreshTokenId);

    useEffect(() => {
        axios.interceptors.response.use((response) => {
            if (  response.status === 440 ) {
                console.log(response);
                clearInterval(refreshTokenIdVar);
                (window as Window).location = '/logout?session-expired'
            }
            if (  response.status === 401 ) {
                console.log(response);
                clearInterval(refreshTokenIdVar);
                (window as Window).location = '/logout'
            }
            return response;
        }, (error) => {
            console.log(error)
            if (error.response.status === 440 ) {
                clearInterval(refreshTokenIdVar);
                (window as Window).location = '/logout?session-expired'
            }
            if (  error.response.status === 401 ) {
                clearInterval(refreshTokenIdVar);
                (window as Window).location = '/logout'
            }
            return Promise.reject(error);
        });


    }, [])

    return null;
};

export default useAxiosInterceptor;