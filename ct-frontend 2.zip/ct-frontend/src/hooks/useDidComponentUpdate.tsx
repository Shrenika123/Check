import { useLayoutEffect, useRef } from 'react';


export const useDidComponentUpdate= (callback:Function , deps : any[]) => {
  const hasMount = useRef(false);

  useLayoutEffect(() => {
    if (hasMount.current) {
      callback();
    } else {
      hasMount.current = true;
    }
  }, deps);
}
