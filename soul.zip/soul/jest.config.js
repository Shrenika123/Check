/* eslint-disable no-undef */
/** @type {import('ts-jest/dist/types').InitialOptionsTsJest} */
module.exports = {
  verbose: true,
  preset: 'ts-jest',
  testEnvironment: 'node',
  reporters: ['default', 'jest-junit'],
  modulePathIgnorePatterns: ['<rootDir>/dist'],
  testPathIgnorePatterns: [
    "dist/", "src/functional-tests"
  ]
};