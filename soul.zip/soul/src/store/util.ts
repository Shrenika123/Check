export const fromDate = (value: Date): number => {
  return value ? value.getTime() : null;
};

export const toDate = (value: number): Date => {
  return value ? new Date(value) : null;
};

export const daysBefore = (date: Date, days: number): Date => {
  const daysInMilliseconds = days * 24 * 60 * 60 * 1000;
  return new Date(date.valueOf() - daysInMilliseconds);
};

export const sleep = async (millis: number) =>
  new Promise((r) => setTimeout(r, millis));

export const fixUptoNDigits = (val: number, fix: number) => {
  const fixedVal = val.toFixed(fix);
  return parseFloat(fixedVal);
};
