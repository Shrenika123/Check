import pg from 'pg';
import { Model, knexSnakeCaseMappers } from 'objection';
import Knex from 'knex';
import { getLogger } from '../logger';
import { databaseSettings, debugSettings } from '../config';
import { sleep } from './util';
import fs from 'fs';

export const getDbConfig = () => {
  return {
    client: 'pg',
    connection: {
      host: databaseSettings.dbHost,
      port: databaseSettings.dbPort,
      user: databaseSettings.dbUser,
      password: databaseSettings.dbPassword,
      database: databaseSettings.dbName,
      ...(databaseSettings.dbSsl && {
        ssl: {
          rejectUnauthorized: true,
          ca: fs.readFileSync(databaseSettings.dbCert).toString(),
        },
      }),
    },
    migrations: {
      disableMigrationsListValidation: true,
    },
    ...knexSnakeCaseMappers(),
  };
};

let knex;

export const establishDbConnection = async () => {
  initStore();
  getLogger().info('Establishing DB connection...');
  let established = false;
  while (!established) {
    try {
      established = await checkDbConnection();
    } catch (error) {
      getLogger().info('Unable to connect to the database:', error);
    }
    if (!established) {
      getLogger().info(
        `Retrying DB Connection in ${databaseSettings.dbRetrySec} seconds...`
      );
      await sleep(databaseSettings.dbRetrySec * 1000);
    }
  }
  getLogger().info('DB connection established.');
};

const initStore = () => {
  knex = Knex(getDbConfig());
  if (debugSettings.debugKnex && debugSettings.logLevel === 'debug') {
    knex.on('query', (data) =>
      getLogger().debug(JSON.stringify(data, null, 2))
    );
  }
  Model.knex(knex);
  pg.types.setTypeParser(pg.types.builtins.INT8, (value: string) => {
    return parseInt(value);
  });

  pg.types.setTypeParser(pg.types.builtins.FLOAT8, (value: string) => {
    return parseFloat(value);
  });

  pg.types.setTypeParser(pg.types.builtins.NUMERIC, (value: string) => {
    return parseFloat(value);
  });
};

export const checkDbConnection = async () => {
  return await knex.raw('SELECT 1');
};
