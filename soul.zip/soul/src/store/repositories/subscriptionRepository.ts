import { Transaction } from 'objection';
import { Subscription } from '../models/subscription';

export const upsert = async (
  orgId: number,
  subscription: number,
  trx?: Transaction
) => {
  // update the subscription value for any orgs that already have an entry in Subscription
  const query = Subscription.query(trx).findById(orgId).patch({
    subscription: subscription,
  });
  const numUpdated = await query;
  // otherwise insert a new row in Subscription
  if (numUpdated === 0) {
    await Subscription.query().insert({
      orgId: orgId,
      subscription: subscription,
      consumption: 0,
    });
  }
};

export const get = async (orgId: number): Promise<Subscription> => {
  const queryBuilder = Subscription.query().findOne({ orgId: orgId });
  return await queryBuilder;
};

export const upsertConsumption = async (
  orgId: number,
  consumption: number,
  txn?: Transaction
) => {
  const query = await Subscription.query(txn).findById(orgId).patch({
    consumption: consumption,
  });
  if (query === 0) {
    await Subscription.query(txn).insert({
      orgId: orgId,
      consumption: consumption,
      subscription: 0,
    });
  }
};
