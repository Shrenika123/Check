import { OrderModel } from '../../api/models/order';
import { Order } from '../models/order';
import * as orderApiModel from '../../api/models/order';

import { OrderTableKeys, EmailSentEnum, HttpStatusMessage } from '../../types';
import { Transaction } from 'objection';

export const createOrder = async (
  orderModel: OrderModel,
  trx?: Transaction
): Promise<Order> => {
  if (orderModel.emailSent == null) {
    orderModel.emailSent = EmailSentEnum.NONE;
  }

  const createdOrder = await Order.query(trx).insert(
    orderApiModel.toObjectionModel(orderModel)
  );

  return createdOrder;
};

export const get = async (
  orgId?: number,
  trx?: Transaction
): Promise<Order[]> => {
  const queryBuilder = Order.query(trx)
    .orderBy('subscriptionStartDate')
    .orderBy('expirationDate');
  if (orgId) {
    queryBuilder
      .throwIfNotFound({ message: HttpStatusMessage.ORDER_NOT_FOUND })
      .where('orgId', orgId);
  }
  return queryBuilder;
};

export const getOrderById = async (id: number): Promise<Order> => {
  const order = Order.query().findById(id);

  return order;
};

export const deleteExpiredBeforeDate = async (
  before: Date,
  orgId?: number,
  trx?: Transaction
): Promise<number> => {
  const queryBuilder = Order.query(trx)
    .delete()
    .where('expirationDate', '<=', before);
  if (orgId) {
    queryBuilder.where('orgId', orgId);
  }
  return await queryBuilder;
};

export const deleteByOrderId = async (id: number, trx?: Transaction) => {
  return await Order.query(trx)
    .delete()
    .where({ id: id })
    .returning(OrderTableKeys.ORG_ID);
};

export const updateOrder = async (
  id: number,
  orderModel: OrderModel,
  trx?: Transaction
): Promise<Order> => {
  const updatedOrder = Order.query(trx).updateAndFetchById(
    id,
    orderApiModel.toObjectionModel(orderModel)
  );

  return updatedOrder;
};

export const calculateSubscriptionCount = async (
  orgId?: number,
  trx?: Transaction
) => {
  let condition = '';
  if (orgId) {
    condition = `WHERE s.org_id=${orgId} OR activeOrder.org_id=${orgId}`;
  }
  const searchQuery = `
          SELECT
            COALESCE(s.org_id, activeOrder.org_id) AS orgId,
            COALESCE(SUM(quantity), 0)             AS subscriptionCount 
          FROM
            subscriptions s 
            FULL OUTER JOIN
                (
                  SELECT
                      * 
                  FROM
                      orders 
                  WHERE
                      DATE(subscription_start_date) <= CURRENT_DATE 
                      AND CURRENT_DATE < DATE(expiration_date)
                )
                AS activeOrder 
                ON activeOrder.org_id = s.org_id 
                ${condition}
          GROUP BY
            orgId
  `;
  const query = Order.knex().raw(searchQuery);
  if (trx) {
    query.transacting(trx);
  }
  const { rows } = await query;
  return rows;
};
