import { MpLicense } from '../models/mpLicense';
import { MpLicenseModel } from '../../api/models/mpLicense';
import { MpLicenseTableKeys } from '../../types';
import { PrimitiveValue, Transaction } from 'objection';

export const getByOrgIdOrParentOrgId = async (
  orgIds: number[],
  trx?: Transaction
): Promise<MpLicense[]> =>
  MpLicense.query(trx)
    .whereIn('orgId', orgIds)
    .orWhereIn('parentOrgId', orgIds);

export const upsertMpLicense = async (
  data: MpLicenseModel,
  trx?: Transaction
) => {
  // update the consumptionAddon consumptionBase value for any orgs that already have an entry in
  const {
    orgId,
    mpName,
    mpType,
    parentOrgId,
    consumptionAddon,
    consumptionBase,
  } = data;
  const query = MpLicense.query(trx)
    .findById([orgId, mpName, mpType, parentOrgId])
    .patch({
      consumptionBase: consumptionBase,
      consumptionAddon: consumptionAddon,
    });
  const numUpdated = await query;
  // otherwise insert a new row in mpLicense
  if (numUpdated === 0) {
    await MpLicense.query(trx).insert(data);
  }
};

export const deleteMpsNotInReport = async (
  data: MpLicenseModel[],
  parentOrgId: number,
  trx?: Transaction
) => {
  const mpPrimaryKeyValues = data.map((item) => {
    return [item.orgId, item.mpName, item.mpType, item.parentOrgId];
  });

  await MpLicense.query(trx)
    .whereComposite(MpLicenseTableKeys.PARENT_ORG_ID, parentOrgId)
    .whereNotIn(
      [
        MpLicenseTableKeys.ORG_ID,
        MpLicenseTableKeys.MP_NAME,
        MpLicenseTableKeys.MP_TYPE,
        MpLicenseTableKeys.PARENT_ORG_ID,
      ],
      mpPrimaryKeyValues as PrimitiveValue[]
    )
    .del();
};
