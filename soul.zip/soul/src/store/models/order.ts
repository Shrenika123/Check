import { Model } from 'objection';

export class Order extends Model {
  static tableName = 'orders';

  id: number;
  orgId!: number;
  subscriptionStartDate!: Date;
  expirationDate!: Date;
  quantity!: number;
  emailSent!: string;
  customerNote?: string;
  internalNote?: string;
  contractNumber?: string;
}
