import { Model } from 'objection';
import { MpLicenseTableKeys } from '../../types';

export class MpLicense extends Model {
  static tableName = 'mp_licenses';
  static idColumn = [
    MpLicenseTableKeys.ORG_ID,
    MpLicenseTableKeys.MP_NAME,
    MpLicenseTableKeys.MP_TYPE,
    MpLicenseTableKeys.PARENT_ORG_ID,
  ];

  orgId!: number;
  mpName!: string;
  mpType!: string;
  parentOrgId!: number;
  consumptionBase?: number;
  consumptionAddon?: number;
}
