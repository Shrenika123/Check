import { Model } from 'objection';

export class Subscription extends Model {
  static tableName = 'subscriptions';
  static idColumn = 'orgId';

  orgId!: number;
  subscription?: number;
  consumption?: number;
}
