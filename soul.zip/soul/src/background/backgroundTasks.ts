import { getLogger } from '../logger';
import { backgroundTaskSettings } from '../config';
import * as orderService from '../service/orderService';

export function startBackgroundTasks() {
  updateSubscriptionsAndDeleteOldOrdersTask();
}

async function updateSubscriptionsAndDeleteOldOrdersTask() {
  const { periodInMinutes } =
    backgroundTaskSettings.updateSubscriptionsAndDeleteOldOrders;
  try {
    getLogger().debug(
      `Background task: Process orders to calculate total subscription for orgs and delete old orders; run every ${periodInMinutes} minutes.`
    );
    await orderService.updateSubscriptionsAndDeleteOldOrders();
    getLogger().info(
      `Completed background task to calculate total subscription for orgs and delete old orders.`
    );
  } catch (err) {
    getLogger().error(
      `Failed to run background task to update total subscriptions and delete old orders: ${err.message}`
    );
  }
  setTimeout(
    updateSubscriptionsAndDeleteOldOrdersTask,
    periodInMinutes * 60 * 1000
  );
}
