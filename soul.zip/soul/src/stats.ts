import { getLogger } from './logger';
import StatsD from 'node-statsd';
import { statsdSettings } from './config';

export const statsd = new StatsD(
  statsdSettings.host,
  statsdSettings.port,
  statsdSettings.prefix + (statsdSettings.prefix.endsWith('.') ? '' : '.')
);

// Prevent statsd errors from bubbling up and impacting the caller
statsd.socket.on('error', (err) =>
  getLogger().error(`Statsd socket error ${err}`)
);

// Utility class for timing operations
export class StatsTimer {
  label: string;
  start: number;

  constructor(label: string) {
    this.label = label;
    this.start = Date.now();
  }

  finish() {
    const timing = Date.now() - this.start;
    getLogger().debug(`stats: ${this.label} in ${timing} millis`);
    statsd.timing(this.label, timing);
  }
}
