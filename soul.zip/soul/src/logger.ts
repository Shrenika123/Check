import { DefaultContext, DefaultState, ParameterizedContext } from 'koa';
import { loggers, format, transports } from 'winston';
import { debugSettings } from './config';

const DEFAULT_LOGGER = 'default';
const AUDIT_LOGGER = 'audit';

const defaultFormat = format.printf(({ level, message, timestamp }) => {
  return `${timestamp} ${level} ${message}`;
});

const auditFormat = format.printf(({ message, timestamp }) => {
  return `${timestamp} ${message}`;
});

export function initLoggers() {
  loggers.add(DEFAULT_LOGGER, {
    transports: [
      new transports.Console({
        level: debugSettings.logLevel,
        format: format.combine(
          format.colorize(),
          format.timestamp(),
          defaultFormat
        ),
      }),
      new transports.File({
        level: debugSettings.logLevel,
        format: format.combine(format.timestamp(), defaultFormat),
        filename: debugSettings.logLocation,
        maxsize: 5000000,
        maxFiles: 5,
        tailable: true,
      }),
    ],
  });

  loggers.add(AUDIT_LOGGER, {
    format: format.combine(format.timestamp(), auditFormat),
    transports: [
      new transports.File({
        level: debugSettings.logLevel,
        filename: debugSettings.auditLogLocation,
        maxsize: 5000000,
        maxFiles: 5,
        tailable: true,
      }),
    ],
  });
}

export function getLogger() {
  return loggers.get(DEFAULT_LOGGER);
}

export function getAuditLogger() {
  return loggers.get(AUDIT_LOGGER);
}

export function auditLog() {
  return async function auditLog(
    ctx: ParameterizedContext<DefaultState, DefaultContext>,
    next: () => Promise<void>
  ) {
    getAuditLogger().info(`${ctx.method} ${ctx.url}`);
    await next();
  };
}
