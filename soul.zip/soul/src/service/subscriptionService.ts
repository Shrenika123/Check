import * as subscriptionRepository from '../store/repositories/subscriptionRepository';
import { Subscription } from '../store/models/subscription';
import { HttpStatusError } from '../api/errors';

export const retrieveCustomerSubscription = async (
  orgId: number
): Promise<Subscription> => {
  const subscription = await subscriptionRepository.get(orgId);

  if (!subscription) {
    throw new HttpStatusError(404, `No records found for orgId: ${orgId}`);
  }

  return subscription;
};
