import { MpLicenseModel } from '../../api/models/mpLicense';
import { IMonitoringPointsEntity } from '../../types';
import {
  calculateConsumptionAddOn,
  convertToAUL,
  getTotalConsumptionAndMpLicenses,
} from '../mpLicenseService';

jest.mock('../../logger', () => ({
  getLogger: jest.fn(() => ({ debug: (msg: string) => msg })),
}));

const mp: IMonitoringPointsEntity = {
  mpName: 'name',
  applications: 91,
  orgId: 4,
  mpType: '',
};

const mpTypes180 = ['appliance-r1000'];
const mpTypes90 = [
  'appliance-r90',
  'appliance-r45',
  'appliance-r40',
  'appliance-r400',
];
const mpTypes15 = [
  'appliance-m70',
  'appliance-m70-no-wifi',
  'appliance-m50',
  'appliance-m35',
  'appliance-m20',
  'appliance-m22',
  'appliance-m25',
  'appliance-m30',
  'appliance-c50',
  'appliance-c40',
  'appliance-vv35',
  'appliance-vk35',
  'appliance-vh35',
  'appliance-gmp',
];
const mpTypesNmps = ['WinNT', 'MAC'];

describe('mpLicenseService', () => {
  describe('convertToAul', () => {
    test.each`
      mpTypes              | applications | expectedBase | expectedAddon
      ${mpTypes180}        | ${180}       | ${12}        | ${0}
      ${mpTypes90}         | ${90}        | ${6}         | ${0}
      ${mpTypes15}         | ${15}        | ${1}         | ${0}
      ${mpTypesNmps}       | ${5}         | ${0.02}      | ${0}
      ${['appliance-gmt']} | ${100}       | ${0}         | ${0}
      ${['appliance-c05']} | ${0}         | ${0}         | ${0}
      ${['unknown']}       | ${15}        | ${1}         | ${0}
      ${'appliance-m70'}   | ${30}        | ${1}         | ${1}
      ${'appliance-m70'}   | ${60}        | ${1}         | ${3}
    `(
      'should properly set consumption for $mpTypes and Addon value will be Integer for multiples of 15',
      async ({ mpTypes, applications, expectedBase, expectedAddon }) => {
        for (const mpType of mpTypes) {
          mp.applications = applications;
          mp.mpType = mpType;
          const mpLicenseModel: MpLicenseModel = convertToAUL(mp, 1);
          expect(mpLicenseModel.mpType).toBe(mpType);
          expect(mpLicenseModel.consumptionBase).toBe(expectedBase);
          expect(mpLicenseModel.consumptionAddon).toBe(expectedAddon);
        }
      }
    );
  });

  describe('calculateConsumptionAddOn', () => {
    test.each`
      totalApp | appConsumed | expectedConsumptionAddon
      ${15}    | ${60}       | ${3}
      ${60}    | ${120}      | ${4}
    `(
      'get consumptionAddon for totalApp:$totalApp & appConsumed:$appConsumed',
      async ({ totalApp, appConsumed, expectedConsumptionAddon }) => {
        const consumptionAddOn: number = calculateConsumptionAddOn(
          totalApp,
          appConsumed
        );
        expect(consumptionAddOn).toBe(expectedConsumptionAddon);
      }
    );
  });

  describe('getTotalConsumptionAndMpLicenses', () => {
    test.each`
      mpType                     | applicationsConsumed | expectedTotalConsumption | expectedBaseConsumption | expectedAddon
      ${'appliance-r1000'}       | ${180}               | ${12}                    | ${12}                   | ${0}
      ${'appliance-r90'}         | ${100}               | ${6.667}                 | ${6}                    | ${0.667}
      ${'appliance-r45'}         | ${90}                | ${6}                     | ${6}                    | ${0}
      ${'appliance-r40'}         | ${90}                | ${6}                     | ${6}                    | ${0}
      ${'appliance-r400'}        | ${90}                | ${6}                     | ${6}                    | ${0}
      ${'appliance-m70'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-m70-no-wifi'} | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-m50'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-m35'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-m20'}         | ${10}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-m22'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-m25'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-m30"'}        | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-c50'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'ppliance-vv35'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-vk35'}        | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-vh35'}        | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-c40'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-c05'}         | ${0}                 | ${0}                     | ${0}                    | ${0}
      ${'WinNT'}                 | ${5}                 | ${0.02}                  | ${0.02}                 | ${0}
      ${'MAC'}                   | ${5}                 | ${0.02}                  | ${0.02}                 | ${0}
      ${'appliance-gmp'}         | ${15}                | ${1}                     | ${1}                    | ${0}
      ${'appliance-gmt'}         | ${100}               | ${0}                     | ${0}                    | ${0}
    `(
      'total consumption,consumptionAddon & consumptionBase for $mpType',
      async ({
        mpType,
        applicationsConsumed,
        expectedTotalConsumption,
        expectedAddon,
        expectedBaseConsumption,
      }) => {
        const monitoringPoints: IMonitoringPointsEntity[] = [
          {
            applications: applicationsConsumed,
            mpName: 'router' + mpType,
            mpType: mpType,
            orgId: 120,
          },
        ];
        const result = getTotalConsumptionAndMpLicenses({
          monitoringPoints: monitoringPoints,
          parentOrgId: 44,
        });
        const { consumption, mpReports } = result;
        expect(consumption).toBe(expectedTotalConsumption);
        expect(mpReports[0].consumptionAddon).toBe(expectedAddon);
        expect(mpReports[0].consumptionBase).toBe(expectedBaseConsumption);
      }
    );
  });
});
