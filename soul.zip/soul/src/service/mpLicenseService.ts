import { MpLicenseModel, fromObjectionModel } from '../api/models/mpLicense';
import { getLogger } from '../logger';
import {
  deleteMpsNotInReport,
  upsertMpLicense,
  getByOrgIdOrParentOrgId,
} from '../store/repositories/mpLicenseRepository';
import {
  IMpLicenseRequestBody,
  IMonitoringPointsEntity,
  AULCosts,
  IMpDefinitionObject,
  IMpReportsAndConsumption,
} from '../types';
import mp_definition from '../store/mp_definition.json';
import { fixUptoNDigits } from '../store/util';
import { upsertConsumption } from '../store/repositories/subscriptionRepository';
import { Model } from 'objection';

export const calculateConsumptionAddOn = (
  aulTotalApp: number,
  appConsumed: number
): number => {
  const aulCalculation = AULCosts.SINGLE_APP / AULCosts.SINGLE_AUL_APPS;
  return appConsumed < aulTotalApp
    ? 0
    : fixUptoNDigits(aulCalculation * (appConsumed - aulTotalApp), 3);
};

export const convertToAUL = (
  data: IMonitoringPointsEntity,
  parentOrgId: number
) => {
  const { mpType, applications, mpName, orgId } = data;
  const mpElement = (
    mp_definition[mpType] ? mp_definition[mpType] : mp_definition['default']
  ) as IMpDefinitionObject;
  const resObj = { orgId, mpType, mpName, parentOrgId } as MpLicenseModel;
  const { applicationCount: appCountFromMpDefinition, aulCost } = mpElement;
  resObj.consumptionBase = aulCost;
  resObj.consumptionAddon = calculateConsumptionAddOn(
    appCountFromMpDefinition,
    applications
  );
  return resObj;
};

export const getTotalConsumptionAndMpLicenses = (
  data: IMpLicenseRequestBody
): IMpReportsAndConsumption => {
  let totalConsumption = 0;
  const { monitoringPoints, parentOrgId } = data;
  return {
    mpReports: monitoringPoints.map((item) => {
      const res = convertToAUL(item, parentOrgId);
      totalConsumption += res.consumptionAddon + res.consumptionBase;
      return res;
    }),
    consumption: totalConsumption,
  };
};

export const licenseReport = async (data: IMpLicenseRequestBody) => {
  const { parentOrgId } = data;
  const { mpReports, consumption } = getTotalConsumptionAndMpLicenses(data);
  const trx = await Model.startTransaction();
  try {
    await deleteMpsNotInReport(mpReports, parentOrgId, trx);
    await Promise.all(mpReports.map((item) => upsertMpLicense(item, trx)));
    await upsertConsumption(parentOrgId, consumption, trx);
    await trx.commit();
  } catch (err) {
    await trx.rollback();
    throw err;
  }
};

export const getByOrgIdOrParentOrgIds = async (
  orgIds: number[]
): Promise<MpLicenseModel[]> => {
  const mpLicenseList = (await getByOrgIdOrParentOrgId(orgIds)).map((each) =>
    fromObjectionModel(each)
  );
  getLogger().info(
    `GET /api/mpLicenses : RESULT : Retrieved ${
      mpLicenseList.length
    } mp licenses against OrgIds[ ${orgIds.join(',')} ]`
  );
  return mpLicenseList;
};
