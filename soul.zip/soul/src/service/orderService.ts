import { Model, Transaction } from 'objection';
import { HttpStatusError } from '../api/errors';
import {
  OrderModel,
  fromObjectionModel as fromOrderModelToDto,
  toObjectionModel,
} from '../api/models/order';
import { getLogger } from '../logger';
import * as repository from '../store/repositories/orderRepository';
import * as subscriptionRepository from '../store/repositories/subscriptionRepository';
import { daysBefore } from '../store/util';
import { HttpStatusCode, HttpStatusMessage } from '../types';

export const DELETION_THRESHOLD_DAYS = 90;

export const updateSubscriptionsAndDeleteOldOrders = async () => {
  const numUpdated = await updateSubscriptionsForActiveOrders();
  getLogger().info(`Updated subscriptions records for ${numUpdated} orgs.`);

  const deletionThreshold = daysBefore(new Date(), DELETION_THRESHOLD_DAYS);
  const numDeleted = await repository.deleteExpiredBeforeDate(
    deletionThreshold
  );
  getLogger().info(
    `Deleted ${numDeleted} orders that expired before ${deletionThreshold}.`
  );
};

export const updateSubscriptionAndDeleteOldOrdersForOrg = async (
  orgId: number,
  trx?: Transaction
) => {
  await updateSubscriptionsForActiveOrders(orgId, trx);
  getLogger().info(`Updated subscriptions records for org ${orgId}.`);

  const deletionThreshold = daysBefore(new Date(), DELETION_THRESHOLD_DAYS);
  const numDeleted = await repository.deleteExpiredBeforeDate(
    deletionThreshold,
    orgId,
    trx
  );
  getLogger().info(
    `Deleted ${numDeleted} orders that expired before ${deletionThreshold} for org ${orgId}.`
  );
};

export const updateSubscriptionsForActiveOrders = async (
  orgId?: number,
  trx?: Transaction
): Promise<number> => {
  const subscriptionCounts = await repository.calculateSubscriptionCount(
    orgId,
    trx
  );

  for (const { orgid, subscriptioncount } of subscriptionCounts) {
    await subscriptionRepository.upsert(orgid, subscriptioncount, trx);
  }
  return subscriptionCounts.length;
};

export const create = async (orderModel: OrderModel): Promise<OrderModel> => {
  return Model.transaction(async (trx: Transaction): Promise<OrderModel> => {
    const newOrder = await repository.createOrder(orderModel, trx);
    await updateSubscriptionAndDeleteOldOrdersForOrg(orderModel.orgId, trx);
    getLogger().info(
      `Order creation process completed successfully for OrgId ${orderModel.orgId}`
    );
    return fromOrderModelToDto(newOrder);
  });
};

export const deleteByOrderId = async (id: number) => {
  return Model.transaction(async (trx: Transaction) => {
    const resOrder = await repository.deleteByOrderId(id, trx);
    if (!resOrder.length) {
      getLogger().info(`Order not found for ${id}`);
      throw new HttpStatusError(
        HttpStatusCode.NOT_FOUND,
        HttpStatusMessage.ORDER_NOT_FOUND
      );
    }
    await updateSubscriptionAndDeleteOldOrdersForOrg(resOrder[0].orgId, trx);
    getLogger().info(
      `Order deletion process completed successfully for OrgId ${id}`
    );
  });
};

export const get = async (orgId: number): Promise<OrderModel[]> => {
  return (await repository.get(orgId)).map((item) => fromOrderModelToDto(item));
};

export const updateOrderAndSubscription = async (
  id: number,
  orderModel: OrderModel
): Promise<OrderModel> => {
  const order = await repository.getOrderById(id);

  if (!order) {
    throw new HttpStatusError(HttpStatusCode.NOT_FOUND, `Order not found.`);
  }

  if (orderModel.id) {
    delete orderModel.id;
  }

  if (order.orgId != orderModel.orgId) {
    throw new HttpStatusError(
      HttpStatusCode.BAD_REQUEST,
      'Cannot change orgId'
    );
  }

  return Model.transaction(async (trx: Transaction): Promise<OrderModel> => {
    const updatedOrder = await repository.updateOrder(id, orderModel, trx);
    await updateSubscriptionAndDeleteOldOrdersForOrg(orderModel.orgId, trx);
    getLogger().info(
      `Order updating process completed successfully for OrgId ${orderModel.orgId} and Order ID ${id}`
    );
    return fromOrderModelToDto(updatedOrder);
  });
};
