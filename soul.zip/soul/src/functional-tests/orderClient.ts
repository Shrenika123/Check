import { MpLicenseModel } from '../api/models/mpLicense';
import {
  create,
  get,
  statusOrBody,
  put,
  remove,
  statusWithBody,
} from './serviceClient';

export async function createOrder(order) {
  return await create('/order', order);
}

export async function putOrder(id, order) {
  const response = await put(`/order/${id}`, order);
  return await statusWithBody(response);
}

export async function getOrder(orgId) {
  const response = await get(`/order/${orgId}`);
  return await statusWithBody(response);
}

export async function getOrderByIdAndOrgId(id, orgId) {
  const response = await get(`/order/${orgId}`);
  const data = (await statusWithBody(response)).body?.find(
    (item) => item.id === id
  );
  return data;
}

export async function deleteByOrderId(id) {
  const response = await remove(`/order/${id}`);
  return await statusWithBody(response);
}
