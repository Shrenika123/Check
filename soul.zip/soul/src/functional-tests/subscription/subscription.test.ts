import { createOrder } from '../orderClient';
import { cleanupResources } from '../serviceClient';
import { getSubscription } from '../subscriptionClient';

describe('GET /api/subscription/:id', () => {
  let orgId: number;
  let subscription: number;

  beforeAll(async () => {
    orgId = 1;
    subscription = 10;
    const order1 = {
      orgId: orgId,
      subscriptionStartDate: new Date().toISOString(),
      expirationDate: new Date(
        new Date().setDate(new Date().getDate() + 30)
      ).toISOString(),
      quantity: subscription,
    };
    await cleanupResources();
    await createOrder(order1);
  });

  afterAll(async () => {
    await cleanupResources();
  });

  test('returns 200 OK and the subscription object if it is a valid orgId', async () => {
    const res = await getSubscription(orgId);

    expect(res.statusCode).toEqual(200);
    expect(res.body.orgId).toEqual(orgId);
    expect(res.body.subscription).toEqual(subscription);
    expect(res.body.consumption).toEqual(0);
  });

  test('returns 404 when the orgId does not exist', async () => {
    const randomOrgId = 100;

    const res = await getSubscription(randomOrgId);
    expect(res.statusCode).toEqual(404);
    expect(res.body.httpStatusCode).toEqual(404);
    expect(res.body.messages[0]).toEqual(
      `No records found for orgId: ${randomOrgId}`
    );
  });

  test('returns 400 if orgId < 0', async () => {
    const invalidOrgId = -1;

    const res = await getSubscription(invalidOrgId);

    expect(res.statusCode).toEqual(400);
    expect(res.body.httpStatusCode).toEqual(400);
    expect(res.body.messages[0]).toEqual('orgId should be a positive integer.');
  });

  test('returns 400 if orgId is not a number', async () => {
    const invalidOrgId = 'abc';

    const res = await getSubscription(invalidOrgId);

    expect(res.statusCode).toEqual(400);
    expect(res.body.httpStatusCode).toEqual(400);
    expect(res.body.messages[0]).toEqual('orgId is not a number.');
  });
});
