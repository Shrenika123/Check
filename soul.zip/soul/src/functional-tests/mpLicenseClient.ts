import { get, post, statusWithBody } from './serviceClient';

let cleanups = [];

export async function licenseReport(data) {
  const response = await post('/licenseReport', data);
  if (response.status === 200) {
    cleanups.unshift(data.parentOrgId);
  }
  return await statusWithBody(response);
}

export async function getMpLicense(orgIds: (string | number)[]) {
  const queryParam = orgIds.map((each) => `orgIds=${each}`).join('&');
  const resp = await get(`/mplicenses?${queryParam}`);
  return await statusWithBody(resp);
}

export async function cleanupMpLicenses() {
  const cleanupPromise = cleanups.map((orgId) => {
    licenseReport({
      parentOrgId: orgId,
      monitoringPoints: [],
    });
  });
  cleanups = [];
  return await Promise.all(cleanupPromise);
}
