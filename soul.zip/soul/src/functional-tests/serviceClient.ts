import fetch from 'node-fetch';

import { systemSettings } from '../config';

const host = process.env.SOUL_HOST;
export const nodeBtoa = (b: string) => Buffer.from(b).toString('base64');

const headers = {
  Authorization: `Basic ${nodeBtoa(
    systemSettings.user + ':' + systemSettings.password
  )}`,
  'Content-Type': 'application/json',
};

const buildUrl = (path: string) => `${host}/api${path}`;

const serviceFetch =
  (method: string) =>
  async (path: string, body?: unknown, customHeaders = {}) => {
    return await fetch(buildUrl(path), {
      headers: {
        ...headers,
        ...customHeaders,
      },
      method,
      body: body ? JSON.stringify(body) : undefined,
    });
  };

export const get = serviceFetch('GET');
export const post = serviceFetch('POST');
export const put = serviceFetch('PUT');
export const patch = serviceFetch('PATCH');
export const remove = serviceFetch('DELETE');

// keeping track of resources that need to be deleted after the test completes
type Resource = {
  path: string;
  id?: number;
};

let cleanups: Resource[] = [];

export async function cleanupResources() {
  for (const { path, id } of cleanups) {
    const response = await remove(`${path}/${id ? id : ''}`);

    if (
      response.status !== 204 &&
      response.status !== 404 &&
      response.status !== 405
    ) {
      console.log(
        `Failed to clean up resource: ${path}/${id} (status code: ${response.status})`
      );
    }
  }
  cleanups = [];
}

export async function create(path: string, data, allowDuplicates = false) {
  const response = await post(
    path,
    data,
    allowDuplicates ? { allowDuplicates: true } : {}
  );

  const { status } = response;
  if (status === 204) {
    // created without returning body
    cleanups.unshift({ path });
  }
  // if (status !== 200) return { statusCode:status };

  let obj = undefined;
  try {
    obj = await response.json();
    if (status == 200) {
      // add to cleanups in reverse order of creation
      cleanups.unshift({ path, id: obj.id });
    }
  } catch (err) {
    //pass
  }

  return { body: obj, statusCode: status };
}

export async function statusOrBody(response) {
  const { status } = response;
  if (status !== 200) return { status };

  return await response.json();
}

export async function statusWithBody(response) {
  const { status } = response;
  let body;
  try {
    body = await response.json();
  } catch (err) {
    //pass
  }

  return { statusCode: status, body };
}
