import { get, statusWithBody } from './serviceClient';

export async function getSubscription(orgId: number | string) {
  const response = await get(`/subscription/${orgId}`);
  return await statusWithBody(response);
}
