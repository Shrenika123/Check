import { MpLicenseModel } from '../../api/models/mpLicense';
import {
  cleanupMpLicenses,
  getMpLicense,
  licenseReport,
} from '../mpLicenseClient';
import { createOrder } from '../orderClient';
import { cleanupResources } from '../serviceClient';
import mpLicenseData from './data/mpLicense.json';
import { getSubscription } from '../subscriptionClient';
import { fixUptoNDigits } from '../../store/util';
import { HttpStatusCode } from '../../types';
import { mockData } from '../../api/helper/__test__/apiHelper.test';

const orgIds = [1, 2];
const mockRequest = {
  positive: {
    parentOrgId: 1,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 15,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
      {
        mpName: 'router1',
        applications: 200,
        orgId: 16,
        mpType: 'appliance-r1000',
      },
    ],
  },
  positive2: {
    parentOrgId: 1,
    monitoringPoints: [],
  },
  positive3: {
    parentOrgId: 1,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 15,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  positive4: {
    parentOrgId: 1,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 181,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  positive5: {
    parentOrgId: 1,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 5,
        orgId: 4,
        mpType: 'MAC',
      },
    ],
  },
  negative: {
    parentOrgId: 101,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
      {
        mpName: 'router1',
        applications: 200,
        orgId: 28,
        mpType: 'appliance-r1000',
      },
    ],
  },
  invalid: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: 4,
        mpType: 'appliance',
      },
    ],
  },
  invalidMpname: [
    {
      parentOrgId: 2,
      monitoringPoints: [
        {
          mpName: 1,
          applications: 1,
          orgId: 4,
          mpType: 'appliance-r1000',
        },
      ],
    },
    {
      parentOrgId: 2,
      monitoringPoints: [
        {
          mpName: '',
          applications: 1,
          orgId: 4,
          mpType: 'appliance-r1000',
        },
      ],
    },
  ],
  invalidOrgId: [
    {
      parentOrgId: 'abc',
      monitoringPoints: [
        {
          mpName: 1,
          applications: 1,
          orgId: 4,
          mpType: 'appliance-r1000',
        },
      ],
    },
    {
      monitoringPoints: [
        {
          mpName: 1,
          applications: 1,
          orgId: 4,
          mpType: 'appliance-r1000',
        },
      ],
    },
  ],
  invalidApplication: {
    monitoringPoints: [
      {
        mpName: 1,
        applications: 'ab',
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
};

const { invalid2, invalid3, invalid4 } = mockData;
const invalidParentOrgAndOrgId = [
  invalid2,
  ...mockRequest.invalidOrgId,
  invalid4,
];
const invalidApplication = [invalid3, mockRequest.invalidApplication];

const getMpDetailsFromMock = (parentOrgId, orgId) => {
  const data = mpLicenseData.find((each) => each.parentOrgId === parentOrgId);

  return data['monitoringPoints'].find((each) => each.orgId === orgId);
};

const insertMpLicenses = async () => {
  const order1 = {
    orgId: 1,
    subscriptionStartDate: new Date().toISOString(),
    expirationDate: new Date(
      new Date().setDate(new Date().getDate() + 30)
    ).toISOString(),
    quantity: 10,
  };
  const order2 = {
    orgId: 2,
    subscriptionStartDate: new Date().toISOString(),
    expirationDate: new Date(
      new Date().setDate(new Date().getDate() + 30)
    ).toISOString(),
    quantity: 10,
  };
  await createOrder(order1);
  await createOrder(order2);
  const allPromises = mpLicenseData.map((data) => licenseReport(data));
  await Promise.all(allPromises);
};

describe('Test cases for Mp license Routes', () => {
  // setup
  beforeAll(async () => {
    await cleanupResources();
    await cleanupMpLicenses();
  });
  // tear down
  afterAll(async () => {
    await cleanupResources();
    await cleanupMpLicenses();
  });

  describe('GET /api/mplicenses', () => {
    beforeAll(async () => {
      await cleanupMpLicenses();
      await insertMpLicenses();
    });
    afterAll(async () => {
      await cleanupMpLicenses();
    });

    test('returns 200 for valid query params', async () => {
      const res = await getMpLicense(orgIds);

      expect(res.statusCode).toBe(200);
    });

    test.each([1, 2, 11, 15, 24])(
      'Checking if only OrgId %i is present',
      async (orgId) => {
        const resp = await getMpLicense([orgId]);
        expect(resp.statusCode).toBe(200);

        resp.body.forEach((each: MpLicenseModel) => {
          expect(
            orgId === each.orgId || orgId === each.parentOrgId
          ).toBeTruthy();
        });
      }
    );

    test('all entries should have valid data', async () => {
      const res = await getMpLicense(orgIds);

      const actual = res.body;
      expect(res.statusCode).toBe(200);

      actual.forEach((each: MpLicenseModel) => {
        expect(
          orgIds.includes(each.orgId) || orgIds.includes(each.parentOrgId)
        ).toBeTruthy();

        // verifying other field values
        const expectedData = getMpDetailsFromMock(each.parentOrgId, each.orgId);

        expect(each.mpName).toBe(expectedData.mpName);
        expect(each.mpType).toBe(expectedData.mpType);
        expect(each.consumptionBase).toBeGreaterThan(0);
        expect(each.consumptionAddon).toBeGreaterThanOrEqual(0);
      });
    });

    test("returns empty list if org ids doesn't match", async () => {
      const res = await getMpLicense([100]);

      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual([]);
    });

    test('returns 400 if invalid query params (anything other than Array<int> ) are sent', async () => {
      const res = await getMpLicense([]);

      expect(res.statusCode).toBe(400);
      expect(res.body.httpStatusCode).toBe(400);
    });

    test('returns 400 if invalid query params (anything other than Array<int> ) are sent', async () => {
      const invalidOrgs = ['abs', '123'];
      const res = await getMpLicense(invalidOrgs);

      expect(res.statusCode).toBe(400);
      expect(res.body.httpStatusCode).toBe(400);
    });
  });

  describe('POST /api/licenseReport', () => {
    beforeEach(async () => {
      await cleanupMpLicenses();
      await insertMpLicenses();
    });
    // tear down
    afterEach(async () => {
      await cleanupMpLicenses();
      await cleanupResources();
    });
    test('returns 200 for valid data with no monitoring points', async () => {
      const res = await licenseReport(mockRequest.positive2);
      expect(res.statusCode).toBe(200);
    });

    test('returns 200 for valid data ,consumtion,sonsumtion Addon and base,mps to be reduced :data(1 fully utilized MP + 1 application license.) ', async () => {
      const { body: mpLicenseBefore } = await getMpLicense([
        mockRequest.positive.parentOrgId,
      ]);

      const res = await licenseReport(mockRequest.positive4);
      const { body: mpLicenseAfter } = await getMpLicense([
        mockRequest.positive.parentOrgId,
      ]);
      const { body: subscription } = await getSubscription(1);
      expect(res.statusCode).toBe(200);
      expect(mpLicenseBefore.length).toBe(7);
      expect(mpLicenseAfter.length).toBe(1);
      expect(mpLicenseAfter[0].consumptionBase).toBe(12);
      expect(mpLicenseAfter[0].consumptionAddon).toBe(0.067);
      expect(subscription.consumption).toBe(12.067);
    });

    test('Send a payload using 1 workstation license. Verify this set uses 1/50 of an AUL.', async () => {
      const res = await licenseReport(mockRequest.positive5);
      const { body } = await getMpLicense([mockRequest.positive.parentOrgId]);
      const { body: subscription } = await getSubscription(1);
      const oneFifthOfAUL = fixUptoNDigits(1 / 50, 3);
      expect(res.statusCode).toBe(200);
      expect(body[0].consumptionBase).toBe(0.02);
      expect(body[0].consumptionAddon).toBe(0);
      expect(subscription.consumption).toBe(oneFifthOfAUL);
    });

    test('returns 200 for valid data and check with db', async () => {
      await licenseReport(mockRequest.positive);
      const res = await licenseReport(mockRequest.positive3);
      const { body: res1 } = await getMpLicense([
        mockRequest.positive.parentOrgId,
      ]);
      const { body: subscription } = await getSubscription(1);

      expect(res.statusCode).toBe(200);
      expect(res1.length).toBe(1);
      expect(subscription.consumption).toBe(12);
    });

    test('do upsert if parentOrgId not present', async () => {
      const res = await licenseReport(mockRequest.negative);
      const { body } = await getMpLicense([mockRequest.negative.parentOrgId]);
      expect(res.statusCode).toBe(200);
      expect(body.length).toBe(2);
    });

    test.each(invalidParentOrgAndOrgId)(
      'return 400 for invalid parentOrgId or orgId',
      async (item) => {
        const resp = await licenseReport(item);
        expect(resp.statusCode).toBe(HttpStatusCode.BAD_REQUEST);
      }
    );

    test.each(invalidApplication)(
      'return 400 for invalid applications',
      async (item) => {
        const resp = await licenseReport(item);
        expect(resp.statusCode).toBe(HttpStatusCode.BAD_REQUEST);
      }
    );

    test('return 200 and set consumption properly for unknown mpType', async () => {
      const unknownMpType = {
        parentOrgId: 1,
        monitoringPoints: [
          {
            mpName: 'router',
            applications: 90,
            orgId: 4,
            mpType: 'appliance',
          },
        ],
      };
      const postResult = await licenseReport(unknownMpType);
      expect(postResult.statusCode).toBe(200);

      const { body: mpLicenseReport } = await getMpLicense([
        unknownMpType.parentOrgId,
      ]);
      expect(mpLicenseReport[0].consumptionBase).toBe(1);
      expect(mpLicenseReport[0].consumptionAddon).toBe(5);
      expect(mpLicenseReport[0].mpType).toBe(
        unknownMpType.monitoringPoints[0].mpType
      );
    });

    test.each(mockRequest.invalidMpname)(
      'return 400 for invalid mpName',
      async (item) => {
        const res = await licenseReport(item);
        expect(res.statusCode).toBe(HttpStatusCode.BAD_REQUEST);
      }
    );
  });
});
