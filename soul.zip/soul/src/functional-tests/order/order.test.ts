import mockedData from './data/createOrder.json';
import orderLifecycle from './data/orderLifecycle.json';
import updateOrder from './data/updateOrder.json';
import { EmailSentEnum, HttpStatusCode } from '../../types';
import { config } from 'dotenv';
import { cleanupResources } from '../serviceClient';
import {
  createOrder,
  getOrder,
  getOrderByIdAndOrgId,
  putOrder,
  deleteByOrderId,
} from '../orderClient';
import { getSubscription } from '../subscriptionClient';
import { daysBefore } from '../../store/util';
config();
const invalidOrgId = ['abc', -1, 1.09];

describe('Test cases for Order Apis', () => {
  describe('POST /api/order', () => {
    const { positiveCase, negativeCase } = mockedData;

    afterAll(async () => {
      await cleanupResources();
    });

    test('Returns 200 : creating order with default values', async () => {
      const data = positiveCase.default;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();

      const resp = await createOrder(data);

      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      const insertedData = await getOrderByIdAndOrgId(
        newData.id,
        newData.orgId
      );
      expect(insertedData.contractNumber).toBeNull();
      expect(insertedData.customerNote).toBeNull();
      expect(insertedData.internalNote).toBeNull();
      expect(insertedData.emailSent).toBe('NONE');
    });

    test('Returns 200 : create order with past dates', async () => {
      const data = positiveCase.pastDate;
      const resp = await createOrder(data);
      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      expect(newData.id).not.toBeNull();
    });

    test('Returns 200 : create order with future dates', async () => {
      const data = positiveCase.futureDate;
      const resp = await createOrder(data);
      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      expect(newData.id).not.toBeNull();
    });

    test('Returns 200 : create order with valid quantity, contractNumber, customerNote, internalNote', async () => {
      const data = positiveCase.valid1;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();

      const resp = await createOrder(data);
      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      const insertedData = await getOrderByIdAndOrgId(
        newData.id,
        newData.orgId
      );
      expect(insertedData).not.toBeUndefined();

      expect(insertedData.quantity).toBe(data.quantity);
      expect(insertedData.contractNumber).toBe(data.contractNumber);
      expect(insertedData.customerNote).toBe(data.customerNote);
      expect(insertedData.internalNote).toBe(data.internalNote);
    });

    test('Returns 200 : create order with given email sent ', async () => {
      const data = negativeCase.withEmailSent;

      const resp = await createOrder(data);

      expect(resp.statusCode).toBe(200);
      expect(resp.body.emailSent).toBe('NONE');
      const insertedData = await getOrderByIdAndOrgId(resp.body.id, data.orgId);
      expect(insertedData.emailSent).toBe('NONE');
    });

    test('Returns 400 : create order with invalid Dates', async () => {
      const data = {
        orgId: 1,
        subscriptionStartDate: '2022/10/10T12:00:00',
        expirationDate: '2022/11/10T13:00:00Z',
        quantity: 1,
      };

      const resp = await createOrder(data);

      expect(resp.statusCode).toBe(400);
      expect(resp.body.messages).toContain(
        'Subscription start date is not valid'
      );
      expect(resp.body.messages).toContain('Expiration date is not valid');
    });

    test.each(negativeCase.invalidOrgIds)(
      'Returns 400 : create order with invalid OrgId : $orgId',
      async (item) => {
        const resp = await createOrder(item);

        expect(resp.statusCode).toBe(400);
        expect(resp.body.messages).toContain('OrgId should be an integer');
      }
    );

    test('Returns 400 : create order with expiration date before start date', async () => {
      const data = negativeCase.invalidStartAndEndDate;

      const resp = await createOrder(data);

      expect(resp.statusCode).toBe(400);
      expect(resp.body.messages).toContain(
        'Expiration date should be greater than Start date'
      );
    });

    test.each(negativeCase.invalidQuantity)(
      'Returns 400 : create order with invalid quantity : $quantity',
      async (item) => {
        const resp = await createOrder(item);

        expect(resp.statusCode).toBe(400);
        expect(resp.body.messages).toContain(
          'Quantity should be a positive integer'
        );
      }
    );
  });

  describe('PUT /api/order/:id', () => {
    let orgId: number;
    let id: number;
    let order;

    beforeAll(async () => {
      await cleanupResources();
    });

    beforeEach(async () => {
      const endDate = new Date();
      orgId = 1;
      order = {
        orgId,
        subscriptionStartDate: new Date().toISOString(),
        expirationDate: new Date(
          endDate.setDate(endDate.getDate() + 30)
        ).toISOString(),
        emailSent: 'NONE',
        quantity: 10,
        customerNote: 'note1',
        internalNote: 'note2',
        contractNumber: 'opportunityId',
      };

      const { body } = await createOrder(order);
      id = body.id;
    });

    afterEach(async () => {
      await cleanupResources();
    });

    test('returns 200 OK if the subscriptionStartDate is set to a past date.', async () => {
      const req = updateOrder.positiveTests.subscriptionStartDate.pastDate;
      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK and sets the optional field (customerNote in this case) to null', async () => {
      const req = updateOrder.positiveTests.optionalFieldToNull;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
      expect(res.body.customerNote).toBe(null);
    });

    test('returns 200 OK if the subscriptionStartDate is set to a future date, less than expirationDate.', async () => {
      const req = updateOrder.positiveTests.subscriptionStartDate.futureDate;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the expirationDate is set to a past date, but greater than subscriptionStartDate.', async () => {
      const req = updateOrder.positiveTests.expirationDate.pastDate;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the order ID is changed', async () => {
      const orderId: any = 2;
      const req = {
        id: orderId,
        ...updateOrder.positiveTests.idChanged,
      };

      const res = await putOrder(id, req);

      delete req.id;

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the quantity is updated to a positive integer.', async () => {
      const req = updateOrder.positiveTests.quantity;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the contractNumber is updated.', async () => {
      const req = updateOrder.positiveTests.contractNumber;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the order note is updated.', async () => {
      const req = updateOrder.positiveTests.note;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the emailSent is updated to a valid value.', async () => {
      const req = updateOrder.positiveTests.emailSent;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 400 if the id is an invalid number.', async () => {
      const invalidId = -1;
      const req = updateOrder.negativeTests.invalidId;

      const res = await putOrder(invalidId, req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual('Invalid order id.');
    });

    test('returns 400 if the id is a string.', async () => {
      const invalidId = 'invalidId';
      const req = updateOrder.negativeTests.invalidId;

      const res = await putOrder(invalidId, req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual('Invalid order id.');
    });

    test('returns 404 if the order id does not exist.', async () => {
      const invalidId = 2;
      const req = updateOrder.negativeTests.invalidId;

      const res = await putOrder(invalidId, req);

      expect(res.statusCode).toEqual(404);
      expect(res.body.httpStatusCode).toEqual(404);
      expect(res.body.messages[0]).toEqual('Order not found.');
    });

    test('returns 400 if the orgId is changed.', async () => {
      const req = updateOrder.negativeTests.orgIdChanged;

      const res = await putOrder(id, req);

      const fetchedOrder = await getOrder(orgId);
      const isOrgIdUnchanged = await getOrder(req.orgId);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual('Cannot change orgId');
      expect(fetchedOrder.statusCode).toEqual(200);
      expect(fetchedOrder.body.length).toEqual(1);
      expect(fetchedOrder.body[0].orgId).toEqual(orgId);
      expect(isOrgIdUnchanged.body.messages[0]).toEqual('Order Not Found');
    });

    test('returns 400 if the expirationDate is updated so it is before subscriptionStartDate.', async () => {
      const req = updateOrder.negativeTests.invalidExpirationDate;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual(
        'Expiration date should be greater than Start date'
      );
    });

    test('returns 400 if the quantity is a negative number.', async () => {
      const req = updateOrder.negativeTests.invalidQuantityNegativeNumber;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual(
        'Quantity should be a positive integer'
      );
    });

    test('returns 200 if the quantity is zero.', async () => {
      const req = updateOrder.positiveTests.validQuantityZero;

      const res = await putOrder(id, req);
      expect(res.statusCode).toEqual(200);
      expect(res.body).toMatchObject(req);
    });

    test('returns 400 if the quantity is a string.', async () => {
      const req = updateOrder.negativeTests.invalidQuantityString;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual(
        'Quantity should be a positive integer'
      );
    });

    test('returns 400 if the emailSent value is invalid.', async () => {
      const req = updateOrder.negativeTests.invalidEmailSent;

      const res = await putOrder(id, req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual(
        `emailSent must be one of ${Object.values(EmailSentEnum).join('|')}`
      );
    });

    test.each([
      {
        orgId: 5,
        emailSent: 'NONE',
        quantity: 50,
        customerNote: 'note1',
        internalNote: 'note2',
        contractNumber: 'opportunityId',
      },
    ])('Validating Subscription value on Update Order', async (order) => {
      const today = new Date();
      const activeOrder = {
        ...order,
        subscriptionStartDate: daysBefore(today, 2),
        expirationDate: daysBefore(today, -2),
      };
      const createOrderResponse = await createOrder(activeOrder); // create order

      const createOrderId = createOrderResponse.body.id;
      expect(createOrderResponse.statusCode).toBe(200);

      // Check subscription
      let getSubscriptionResponse = await getSubscription(activeOrder.orgId);

      expect(getSubscriptionResponse.statusCode).toBe(200);

      // Checking if the order quantity is counted towards OrgId Subscription Total Count
      expect(getSubscriptionResponse.body.subscription).toBe(
        activeOrder.quantity
      );

      // make subscription expired
      let putOrderResponse = await putOrder(createOrderId, {
        ...activeOrder,
        expirationDate: daysBefore(today, 1),
      });

      expect(putOrderResponse.statusCode).toBe(200);
      // Check subscription
      getSubscriptionResponse = await getSubscription(activeOrder.orgId);

      expect(getSubscriptionResponse.statusCode).toBe(200);

      // Checking if the order quantity is not counted towards OrgId Subscription Total Count
      expect(getSubscriptionResponse.body.subscription).toBe(0);

      // update the subscription to not yet started state
      putOrderResponse = await putOrder(createOrderId, {
        ...activeOrder,
        subscriptionStartDate: daysBefore(today, -2),
        expirationDate: daysBefore(today, -5),
      });
      expect(putOrderResponse.statusCode).toBe(200);

      // Check subscription
      getSubscriptionResponse = await getSubscription(activeOrder.orgId);
      expect(getSubscriptionResponse.statusCode).toBe(200);

      // Checking if the order quantity is not counted towards OrgId Subscription Total Count
      expect(getSubscriptionResponse.body.subscription).toBe(0);
    });
  });

  describe('GET /api/order/{orgId}', () => {
    beforeAll(async () => {
      await cleanupResources();
      const { positiveCase } = mockedData;
      const data = positiveCase.default;
      const data2 = positiveCase.valid1;
      data2.orgId = 6;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      data2.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();
      data2.expirationDate = today.toDateString();
      await createOrder(data);
      await createOrder(data);
      await createOrder(data2);
    });

    afterAll(async () => {
      await cleanupResources();
    });

    test('return success 200 and verify orders', async () => {
      const { positiveCase } = mockedData;
      const data = positiveCase.valid1;
      data.orgId = 150;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      const resOrder = await createOrder(data);
      const res = await getOrder(1);
      const resGetOrder = await getOrder(150);
      expect(res.statusCode).toBe(200);
      expect(res.body.length).toBe(2);
      expect(resOrder.body).toMatchObject(resGetOrder.body[0]);
    });

    test.each(invalidOrgId)(
      'return BAD Request 400 for invalid orgId %s',
      async (item) => {
        const res = await getOrder(item);
        expect(res.statusCode).toBe(400);
      }
    );

    test('return NOT_FOUND 404 for order not found', async () => {
      const res = await getOrder(5);
      expect(res.statusCode).toBe(404);
    });
  });

  describe('DELETE /api/order', () => {
    const { positiveCase } = mockedData;
    test('return 204 after successful deletion and not found when deleting the deleted order and verifying', async () => {
      const data = positiveCase.default;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();
      const res1 = await createOrder(data);
      await createOrder(data);
      const deleteResponse = await deleteByOrderId(res1.body.id);
      const notFoundDeleteResponse = await deleteByOrderId(res1.body.id);
      const getOrderRes = await getOrderByIdAndOrgId(
        res1.body.id,
        res1.body.orgId
      );
      expect(deleteResponse.statusCode).toBe(204);
      expect(notFoundDeleteResponse.statusCode).toBe(404);
      expect(getOrderRes).toBeUndefined();
    });

    test.each(invalidOrgId)(
      'test case for invalid order id %s',
      async (item) => {
        const badRequestResponse = await deleteByOrderId(item);
        expect(badRequestResponse.statusCode).toBe(400);
      }
    );

    test.each([
      {
        orgId: 5,
        emailSent: 'NONE',
        quantity: 50,
        customerNote: 'note1',
        internalNote: 'note2',
        contractNumber: 'opportunityId',
      },
    ])('Validating Subscription value on Delete order', async (order) => {
      const today = new Date();
      const activeOrder = {
        ...order,
        subscriptionStartDate: daysBefore(today, 2),
        expirationDate: daysBefore(today, -2),
      };
      const createOrderResponse = await createOrder(activeOrder); // create order

      const createOrderId = createOrderResponse.body.id;
      expect(createOrderResponse.statusCode).toBe(200);

      // Check subscription
      let getSubscriptionResponse = await getSubscription(activeOrder.orgId);

      expect(getSubscriptionResponse.statusCode).toBe(200);

      // Checking if the order quantity is counted towards OrgId Subscription Total Count
      expect(getSubscriptionResponse.body.subscription).toBe(
        activeOrder.quantity
      );

      // Delete the order
      const deleteOrderResponse = await deleteByOrderId(createOrderId);

      expect(deleteOrderResponse.statusCode).toBe(204);
      // Check subscription
      getSubscriptionResponse = await getSubscription(activeOrder.orgId);

      expect(getSubscriptionResponse.statusCode).toBe(200);

      // Checking if the order quantity is not counted towards OrgId Subscription Total Count
      expect(getSubscriptionResponse.body.subscription).toBe(0);
    });
  });

  describe('Order lifecycle management', () => {
    const { case1, case2, case3 } = orderLifecycle;

    beforeEach(async () => {
      await cleanupResources();
    });

    afterAll(async () => {
      await cleanupResources();
    });

    test('get count of subscriptions to be the sum of both the non-expired orders.', async () => {
      await createOrder(case1.order1);
      await createOrder(case1.order2);
      const totalSubscriptionCount =
        case1.order1.quantity + case1.order2.quantity;

      const { statusCode, body } = await getSubscription(case1.order1.orgId);

      expect(statusCode).toEqual(200);
      expect(body.subscription).toEqual(totalSubscriptionCount);
    });

    test('get count of subscriptions to be the sum of only the non-expired order when the order expired is within 0-90 days.', async () => {
      await createOrder(case2.order1);
      await createOrder(case2.order2);
      const totalSubscriptionCount = case1.order1.quantity;

      const { statusCode, body } = await getSubscription(case2.order1.orgId);

      expect(statusCode).toEqual(200);
      expect(body.subscription).toEqual(totalSubscriptionCount);
    });

    test('get count of subscriptions to be the sum of only the non-expired order when the order has expired past 0-90 days.', async () => {
      await createOrder(case3.order1);
      await createOrder(case3.order2);
      const totalSubscriptionCount = case3.order1.quantity;

      const { statusCode, body } = await getSubscription(case3.order1.orgId);

      const orders = await getOrder(case3.order1.orgId);

      expect(statusCode).toEqual(200);
      expect(body.subscription).toEqual(totalSubscriptionCount);
      expect(orders.body.length).toEqual(1);
    });
  });
});
