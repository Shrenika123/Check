import Router from '@koa/router';
import auth from 'koa-basic-auth';
import { dbErrorHandler, errorHandler } from './errors';
import { adminRouter } from './routes/admin';
import { mpLicenseRouter } from './routes/mpLicense';
import { subscriptionRouter } from './routes/subscription';
import { orderRouter } from './routes/order';

export const createApiRouter = (username, password) => {
  const apiRouter = new Router({
    prefix: '/api',
  });

  apiRouter.use(errorHandler).use(dbErrorHandler);

  // healthcheck endpoint doesn't require basic auth
  apiRouter.use(adminRouter.routes()).use(adminRouter.allowedMethods());

  apiRouter.use(auth({ name: username, pass: password }));

  // all other endpoints that require auth
  apiRouter.use(mpLicenseRouter.routes()).use(mpLicenseRouter.allowedMethods());
  apiRouter
    .use(subscriptionRouter.routes())
    .use(subscriptionRouter.allowedMethods());
  apiRouter.use(orderRouter.routes()).use(orderRouter.allowedMethods());

  return apiRouter;
};
