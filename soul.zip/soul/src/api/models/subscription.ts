import { Subscription } from '../../store/models/subscription';

export class SubscriptionModel {
  orgId!: number;
  subscription?: number;
  consumption?: number;
}

export const fromObjectionModel = (
  subscription: Subscription
): SubscriptionModel => {
  const subscriptionModel = new SubscriptionModel();

  subscriptionModel.orgId = subscription.orgId;
  subscriptionModel.subscription = subscription.subscription;
  subscriptionModel.consumption = subscription.consumption;

  return subscriptionModel;
};

export const toObjectionModel = (
  subscriptionModel: SubscriptionModel
): Subscription => {
  const subscription = new Subscription();

  subscription.orgId = subscriptionModel.orgId;
  subscription.subscription = subscriptionModel.subscription;
  subscription.consumption = subscriptionModel.consumption;

  return subscription;
};
