import { MpLicense } from '../../store/models/mpLicense';

export class MpLicenseModel {
  orgId!: number;
  mpName!: string;
  mpType!: string;
  parentOrgId!: number;
  consumptionBase?: number;
  consumptionAddon?: number;
}

export const fromObjectionModel = (mpLicense: MpLicense): MpLicenseModel => {
  const mpLicenseModel = new MpLicenseModel();

  mpLicenseModel.orgId = mpLicense.orgId;
  mpLicenseModel.parentOrgId = mpLicense.parentOrgId;
  mpLicenseModel.mpName = mpLicense.mpName;
  mpLicenseModel.mpType = mpLicense.mpType;
  mpLicenseModel.consumptionBase = mpLicense.consumptionBase;
  mpLicenseModel.consumptionAddon = mpLicense.consumptionAddon;

  return mpLicenseModel;
};

export const toObjectionModel = (mpLicenseModel: MpLicenseModel): MpLicense => {
  const mpLicense = new MpLicense();

  mpLicense.orgId = mpLicenseModel.orgId;
  mpLicense.parentOrgId = mpLicenseModel.parentOrgId;
  mpLicense.mpName = mpLicenseModel.mpName;
  mpLicense.mpType = mpLicenseModel.mpType;
  mpLicense.consumptionBase = mpLicenseModel.consumptionBase;
  mpLicense.consumptionAddon = mpLicenseModel.consumptionAddon;
  return mpLicense;
};
