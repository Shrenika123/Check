import { Order } from '../../store/models/order';

export class OrderModel {
  id?: number;
  orgId!: number;
  subscriptionStartDate!: Date;
  expirationDate!: Date;
  quantity!: number;
  emailSent!: string;
  customerNote?: string;
  internalNote?: string;
  contractNumber?: string;
}

export const fromObjectionModel = (order: Order): OrderModel => {
  const orderModel = new OrderModel();

  orderModel.id = order.id;
  orderModel.subscriptionStartDate = order.subscriptionStartDate;
  orderModel.orgId = order.orgId;
  orderModel.expirationDate = order.expirationDate;
  orderModel.quantity = order.quantity;
  orderModel.emailSent = order.emailSent;
  orderModel.customerNote = order.customerNote;
  orderModel.internalNote = order.internalNote;
  orderModel.contractNumber = order.contractNumber;

  return orderModel;
};

export const toObjectionModel = (orderModel: OrderModel): Order => {
  const order = new Order();

  // Keep the id unset for inserts.
  if (orderModel.id != null) {
    order.id = orderModel.id;
  }
  order.subscriptionStartDate = orderModel.subscriptionStartDate;
  order.orgId = orderModel.orgId;
  order.expirationDate = orderModel.expirationDate;
  order.quantity = orderModel.quantity;
  order.emailSent = orderModel.emailSent;
  order.customerNote = orderModel.customerNote ?? null;
  order.internalNote = orderModel.internalNote ?? null;
  order.contractNumber = orderModel.contractNumber ?? null;

  return order;
};
