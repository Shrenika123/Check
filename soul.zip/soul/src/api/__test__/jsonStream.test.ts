import { Readable } from 'stream';
import { jsonStream } from '../jsonStream';

const readStreamToString = (stream) => {
  let string = '';
  return new Promise((resolve, reject) => {
    stream.on('data', (data) => (string += data));
    stream.on('end', () => resolve(string));
    stream.on('error', (err) => reject(err));
  });
};

describe('jsonStream', () => {
  test('can convert a stream of objects to JSON', async () => {
    const objectStream = new Readable({ objectMode: true });
    const json = objectStream.pipe(jsonStream());
    objectStream.push({ id: 1, label: 'first' });
    objectStream.push({ id: 2, label: 'second' });
    objectStream.push(null);

    const jsonString = await readStreamToString(json);

    expect(jsonString).toEqual(
      '[{"id":1,"label":"first"},{"id":2,"label":"second"}]'
    );
  });
  test('can convert a stream with no objects to JSON', async () => {
    const objectStream = new Readable({ objectMode: true });
    const json = objectStream.pipe(jsonStream());
    objectStream.push(null);

    const jsonString = await readStreamToString(json);

    expect(jsonString).toEqual('[]');
  });
});
