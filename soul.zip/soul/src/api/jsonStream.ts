import { Transform } from 'stream';

const defaultEncoding = 'utf-8';

/**
 * @returns a stream transform that can transform an object stream to JSON output
 */
export const jsonStream = (encoding: BufferEncoding = defaultEncoding) => {
  let first = true;
  return new Transform({
    objectMode: true,
    highWaterMark: 16,
    transform(item, _, callback) {
      if (first) {
        this.push('[', encoding);
        first = false;
      } else {
        this.push(',', encoding);
      }
      callback(null, JSON.stringify(item));
    },
    flush(callback) {
      if (first) {
        this.push('[', encoding);
      }
      this.push(']', encoding);
      callback(null);
    },
  });
};
