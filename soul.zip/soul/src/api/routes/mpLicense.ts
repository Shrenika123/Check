import Router from '@koa/router';
import { HttpStatusError } from '../errors';
import * as mpLicenseService from '../../service/mpLicenseService';
import { validateMpLicences } from '../helper';

export const mpLicenseRouter = new Router();

mpLicenseRouter.get(
  '/mplicenses',
  // Query Parameter validation middleware
  async (ctx, next) => {
    let orgIds: number[];
    const ids: string | string[] = ctx.request.query.orgIds;

    if (Array.isArray(ids)) {
      if (ids.some((each) => isNaN(Number(each))))
        throw new HttpStatusError(400, 'OrgId should be an array of int');
      else orgIds = ids.map((each) => Number(each));
    } else {
      if (ids === undefined || isNaN(Number(ids)))
        throw new HttpStatusError(400, 'OrgId should be an array of int');
      else orgIds = [Number(ids)];
    }
    ctx.state.orgIds = orgIds;
    await next();
  },
  async (ctx) => {
    const orgIds = ctx.state.orgIds;

    ctx.body = await mpLicenseService.getByOrgIdOrParentOrgIds(orgIds);
    ctx.status = 200;
  }
);

mpLicenseRouter.post('/licenseReport', async (ctx) => {
  const requestBody = ctx.request.body;
  if (!validateMpLicences(requestBody)) {
    ctx.status = 400;
  } else {
    try {
      await mpLicenseService.licenseReport(requestBody);
      ctx.status = 200;
    } catch (e) {
      ctx.status = e.statusCode;
    }
  }
});
