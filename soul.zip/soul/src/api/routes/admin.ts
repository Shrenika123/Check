import Router from '@koa/router';
import { checkDbConnection } from '../../store/store';

export const adminRouter = new Router({
  prefix: '/admin',
});

adminRouter.get('/healthcheck', async (ctx) => {
  if (ctx.query.checkDb === 'true') {
    await checkDbConnection();
  }

  ctx.body = {
    result: 'ok',
  };
});
