import Router from '@koa/router';

import { fromObjectionModel } from '../models/subscription';
import { HttpStatusError } from '../errors';
import * as subscriptionService from '../../service/subscriptionService';

export const subscriptionRouter = new Router({
  prefix: '/subscription',
});

subscriptionRouter.get('/:orgId', async (ctx) => {
  const orgId = +ctx.params.orgId;

  if (!orgId) {
    throw new HttpStatusError(400, 'orgId is not a number.');
  }
  if (orgId < 0) {
    throw new HttpStatusError(400, 'orgId should be a positive integer.');
  }

  const subscription = await subscriptionService.retrieveCustomerSubscription(
    orgId
  );

  ctx.body = fromObjectionModel(subscription);
});
