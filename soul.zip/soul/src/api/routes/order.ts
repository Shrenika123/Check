import Router from '@koa/router';
import * as orderService from '../../service/orderService';
import { HttpStatusMessage, HttpStatusCode } from '../../types';
import { HttpStatusError } from '../errors';
import {
  validateBaseOrderPayload,
  validateOrgId,
  validateUpdateOrder,
} from '../helper';
import { OrderModel } from '../models/order';

export const orderRouter = new Router({ prefix: '/order' });

orderRouter.post(
  '/',
  /**
   * Middleware to validate request payloads
   *
   * @param ctx
   * @param next
   * @throws {HttpStatusError}
   * @return {Promise<any>}
   */
  async (ctx, next) => {
    const { result, errors } = validateBaseOrderPayload(ctx.request.body);
    if (!result) throw new HttpStatusError(HttpStatusCode.BAD_REQUEST, errors);
    else await next();
  },
  async (ctx) => {
    const {
      orgId,
      subscriptionStartDate,
      expirationDate,
      quantity,
      customerNote,
      internalNote,
      contractNumber,
    } = ctx.request.body;
    const order: OrderModel = {
      orgId,
      subscriptionStartDate: new Date(subscriptionStartDate),
      expirationDate: new Date(expirationDate),
      quantity: Number(quantity),
      customerNote,
      internalNote,
      contractNumber,
      emailSent: null,
    };

    ctx.body = await orderService.create(order);
    ctx.status = HttpStatusCode.OK;
  }
);

orderRouter.delete('/:id', async (ctx) => {
  const orderId = +ctx.params.id;
  if (!validateOrgId(orderId)) {
    throw new HttpStatusError(
      HttpStatusCode.BAD_REQUEST,
      HttpStatusMessage.BAD_REQUEST
    );
  } else {
    await orderService.deleteByOrderId(orderId);
    ctx.status = HttpStatusCode.OK_NO_CONTENT;
    ctx.message = HttpStatusMessage.ORDER_DELETE_SUCCESS;
  }
});

orderRouter.get('/:orgId', async (ctx) => {
  const orgId = +ctx.params.orgId;
  if (!validateOrgId(orgId)) {
    throw new HttpStatusError(
      HttpStatusCode.BAD_REQUEST,
      HttpStatusMessage.BAD_REQUEST
    );
  } else {
    const order = await orderService.get(orgId);
    ctx.body = order;
  }
});

orderRouter.put(
  '/:id',
  async (ctx, next) => {
    const { result, errors } = validateUpdateOrder(
      ctx.params.id,
      ctx.request.body
    );
    if (!result) throw new HttpStatusError(HttpStatusCode.BAD_REQUEST, errors);
    else await next();
  },
  async (ctx) => {
    const {
      id,
      orgId,
      subscriptionStartDate,
      expirationDate,
      quantity,
      emailSent,
      customerNote,
      internalNote,
      contractNumber,
    } = ctx.request.body;

    const orderId = ctx.params.id;

    const orderModel: OrderModel = {
      id,
      orgId,
      expirationDate: new Date(expirationDate),
      quantity: Number(quantity),
      emailSent,
      customerNote,
      internalNote,
      contractNumber,
      subscriptionStartDate: new Date(subscriptionStartDate),
    };

    ctx.body = await orderService.updateOrderAndSubscription(
      +orderId,
      orderModel
    );
  }
);
