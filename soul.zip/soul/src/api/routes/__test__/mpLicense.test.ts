// import { server } from "./app";
import { getServer, default as initServer } from '../../../index';
import supertest from 'supertest';
import { MpLicense } from '../../../store/models/mpLicense';
import mpLicenseData from './data/mpLicense.json';
import { MpLicenseModel } from '../../models/mpLicense';
import { systemSettings } from '../../../config';

let request: supertest.SuperTest<supertest.Test>;
const orgIds = [1, 2];
describe('Test cases for Mp license Routes', () => {
  // setup
  beforeAll(async () => {
    await initServer;

    request = supertest(getServer());
    console.log('Connection established');
  });
  // tear down
  afterAll((done) => {
    getServer().close((err) => {
      if (err) throw err;
      done();
    });
  });

  describe('GET /api/mplicenses', () => {
    beforeAll(async () => {
      await MpLicense.query().delete();
      await MpLicense.query().insert(mpLicenseData);
    });
    afterAll(async () => {
      await MpLicense.query().delete();
    });

    test('returns 200 for valid query params', async () => {
      const res = await request
        .get(`/api/mplicenses?orgIds=1&orgIds=2`)
        .auth(systemSettings.user, systemSettings.password);

      expect(res.statusCode).toBe(200);
    });
    test('all entries should have valid data', async () => {
      const queryParam = orgIds.map((each) => `orgIds=${each}`).join('&');

      const expectedData = mpLicenseData.filter(
        (each) =>
          orgIds.includes(each.orgId) || orgIds.includes(each.parentOrgId)
      );

      const res = await request
        .get(`/api/mplicenses?${queryParam}`)
        .auth(systemSettings.user, systemSettings.password);

      const actual = res.body;
      expect(res.statusCode).toBe(200);

      actual.forEach((each: MpLicenseModel) => {
        expect(
          orgIds.includes(each.orgId) || orgIds.includes(each.parentOrgId)
        ).toBeTruthy();
      });

      expect(actual).toStrictEqual(expectedData);
    });
    test("returns empty list if org ids doesn't match", async () => {
      const res = await request
        .get(`/api/mplicenses?orgIds=100`)
        .auth(systemSettings.user, systemSettings.password);

      expect(res.statusCode).toBe(200);
      expect(res.body).toEqual([]);
    });

    test('returns 400 if invalid query params (anything other than Array<int> ) are sent', async () => {
      const res = await request
        .get(`/api/mplicenses`)
        .auth(systemSettings.user, systemSettings.password);

      expect(res.statusCode).toBe(400);
      expect(res.body.httpStatusCode).toBe(400);
    });
    test('returns 400 if invalid query params (anything other than Array<int> ) are sent', async () => {
      const invalidOrgs = ['abs', '123'];
      const queryP = invalidOrgs.map((each) => `orgIds=${each}`).join('&');

      const res = await request
        .get(`/api/mplicenses?${queryP}`)
        .auth(systemSettings.user, systemSettings.password);

      expect(res.statusCode).toBe(400);
      expect(res.body.httpStatusCode).toBe(400);
    });
  });
});
