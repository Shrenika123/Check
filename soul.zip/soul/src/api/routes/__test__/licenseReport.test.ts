import { getServer, default as initServer } from '../../../index';
import supertest from 'supertest';
import { MpLicense } from '../../../store/models/mpLicense';
import mpLicenseData from './data/mpLicense.json';
import * as subscriptionRepository from '../../../store/repositories/subscriptionRepository';
import { systemSettings } from '../../../config';
import { Subscription } from '../../../store/models/subscription';
import { MpLicenseTableKeys } from '../../../types';

let request: supertest.SuperTest<supertest.Test>;

const mockRequest = {
  positive: {
    parentOrgId: 1,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 15,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
      {
        mpName: 'router1',
        applications: 200,
        orgId: 16,
        mpType: 'appliance-r1000',
      },
    ],
  },
  positive2: {
    parentOrgId: 1,
    monitoringPoints: [],
  },
  positive3: {
    parentOrgId: 1,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 15,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  negative: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
      {
        mpName: 'router1',
        applications: 200,
        orgId: 28,
        mpType: 'appliance-r1000',
      },
    ],
  },
  invalid: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: -4,
        orgId: 4,
        mpType: 'appliance',
      },
    ],
  },
};

describe('Test cases for licenseReport in MpLicense Route', () => {
  // setup
  beforeAll(async () => {
    await initServer;
    request = supertest(getServer());
  });

  afterAll((done) => {
    getServer().close((err) => {
      if (err) throw err;
      done();
    });
  });

  describe('POST /api/licenseReport', () => {
    beforeEach(async () => {
      await MpLicense.query().insert(mpLicenseData);
      await subscriptionRepository.upsert(1, 20);
    });
    // tear down
    afterEach(async () => {
      await MpLicense.query().delete();
    });

    afterAll(async () => {
      await Subscription.query().delete();
    });
    test('returns 200 for valid data with no monitoring points', async () => {
      const res = await request
        .post(`/api/licenseReport`)
        .send(mockRequest.positive2)
        .auth(systemSettings.user, systemSettings.password);
      expect(res.statusCode).toBe(200);
    });

    test('returns 200 for valid data and check with db,mps to be reduced ', async () => {
      const mpLicenseCountBefore = await MpLicense.query().whereComposite(
        MpLicenseTableKeys.PARENT_ORG_ID,
        mockRequest.positive.parentOrgId
      );
      const res = await request
        .post(`/api/licenseReport`)
        .send(mockRequest.positive)
        .auth(systemSettings.user, systemSettings.password);
      const mpLicenseCountAfter = await MpLicense.query().whereComposite(
        MpLicenseTableKeys.PARENT_ORG_ID,
        mockRequest.positive.parentOrgId
      );
      const subscription = await subscriptionRepository.get(1);

      expect(res.statusCode).toBe(200);
      expect(mpLicenseCountBefore.length).toBe(7);
      expect(mpLicenseCountAfter.length).toBe(2);
      expect(subscription.consumption).toBe(25.333);
    });

    test('returns 200 for valid data and check with db', async () => {
      await request
        .post(`/api/licenseReport`)
        .send(mockRequest.positive)
        .auth(systemSettings.user, systemSettings.password);
      const res = await request
        .post(`/api/licenseReport`)
        .send(mockRequest.positive3)
        .auth(systemSettings.user, systemSettings.password);
      const res1 = await MpLicense.query().whereComposite(
        MpLicenseTableKeys.PARENT_ORG_ID,
        mockRequest.positive.parentOrgId
      );
      const subscription = await subscriptionRepository.get(1);

      expect(res.statusCode).toBe(200);
      expect(res1.length).toBe(1);
      expect(subscription.consumption).toBe(12);
    });

    test('update subscription table if parentOrgId not present', async () => {
      await request
        .post(`/api/licenseReport`)
        .send(mockRequest.negative)
        .auth(systemSettings.user, systemSettings.password);
      const res1 = await MpLicense.query().whereComposite(
        MpLicenseTableKeys.PARENT_ORG_ID,
        mockRequest.negative.parentOrgId
      );
      const subscription = await subscriptionRepository.get(2);
      expect(res1.length).toBe(2);
      expect(subscription.consumption).toBe(25.333);
    });

    test('returns 400 bad request with invalid applications', async () => {
      const res = await request
        .post(`/api/licenseReport`)
        .send(mockRequest.invalid)
        .auth(systemSettings.user, systemSettings.password);
      expect(res.statusCode).toBe(400);
    });
  });
});
