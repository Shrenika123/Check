import { getServer, default as initServer } from '../../../index';
import * as subscriptionRepository from '../../../store/repositories/subscriptionRepository';
import { systemSettings } from '../../../config';
import supertest from 'supertest';
import { Subscription } from '../../../store/models/subscription';

let request: supertest.SuperTest<supertest.Test>;

describe('GET /api/subscription/:id', () => {
  let orgId: number | string;
  let subscription: number;

  beforeAll(async () => {
    await initServer;

    request = supertest(getServer());

    orgId = 1;
    subscription = 10;
    await subscriptionRepository.upsert(orgId, subscription);
  });

  afterAll((done) => {
    Subscription.query()
      .truncate()
      .then(() => {
        getServer().close((err) => {
          if (err) throw err;
          done();
        });
      });
  });

  test('returns 200 OK and the subscription object if it is a valid orgId', async () => {
    const res = await request
      .get(`/api/subscription/${orgId}`)
      .auth(systemSettings.user, systemSettings.password);

    expect(res.statusCode).toEqual(200);
    expect(res.body.orgId).toEqual(orgId);
    expect(res.body.subscription).toEqual(subscription);
    expect(res.body.consumption).toEqual(0);
  });

  test('returns 404 when the orgId does not exist', async () => {
    const randomOrgId = 2;

    const res = await request
      .get(`/api/subscription/${randomOrgId}`)
      .auth(systemSettings.user, systemSettings.password);

    expect(res.statusCode).toEqual(404);
    expect(res.body.httpStatusCode).toEqual(404);
    expect(res.body.messages[0]).toEqual(
      `No records found for orgId: ${randomOrgId}`
    );
  });

  test('returns 400 if orgId < 0', async () => {
    const invalidOrgId = -1;

    const res = await request
      .get(`/api/subscription/${invalidOrgId}`)
      .auth(systemSettings.user, systemSettings.password);

    expect(res.statusCode).toEqual(400);
    expect(res.body.httpStatusCode).toEqual(400);
    expect(res.body.messages[0]).toEqual('orgId should be a positive integer.');
  });

  test('returns 400 if orgId is not a number', async () => {
    const invalidOrgId = 'abc';

    const res = await request
      .get(`/api/subscription/${invalidOrgId}`)
      .auth(systemSettings.user, systemSettings.password);

    expect(res.statusCode).toEqual(400);
    expect(res.body.httpStatusCode).toEqual(400);
    expect(res.body.messages[0]).toEqual('orgId is not a number.');
  });
});
