import supertest from 'supertest';
import mockedData from './data/createOrder.json';
import { systemSettings } from '../../../config';
import { Order } from '../../../store/models/order';
import { OrderModel, toObjectionModel } from '../../models/order';
import { getServer, default as initServer } from '../../../index';
import { HttpStatusCode } from '../../../types';
import { Subscription } from '../../../store/models/subscription';
import * as subscriptionRepository from '../../../store/repositories/subscriptionRepository';
import updateOrder from './data/updateOrder.json';
import { EmailSentEnum } from '../../../types';

let request: supertest.SuperTest<supertest.Test>;

describe('Test cases for Order Apis', () => {
  // setup
  beforeAll(async () => {
    await initServer;

    request = supertest(getServer());
  });
  // tear down
  afterAll((done) => {
    getServer().close((err) => {
      if (err) {
        console.log(err.message);
      }
      done();
    });
  });

  describe('POST /api/order', () => {
    const { positiveCase, negativeCase } = mockedData;

    afterAll(async () => {
      await Order.query().delete();
    });

    test('Returns 200 : creating order with default values', async () => {
      const data = positiveCase.default;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();

      const resp = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);

      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      const insertedData = await Order.query().findById(newData.id);

      expect(insertedData?.contractNumber).toBeNull();
      expect(insertedData?.customerNote).toBeNull();
      expect(insertedData?.internalNote).toBeNull();
      expect(insertedData?.emailSent).toBe('NONE');
    });

    test('Returns 200 : create order with past dates', async () => {
      const data = positiveCase.pastDate;
      const resp = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);
      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      expect(newData.id).not.toBeNull();
    });

    test('Returns 200 : create order with future dates', async () => {
      const data = positiveCase.futureDate;
      const resp = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);
      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      expect(newData.id).not.toBeNull();
    });

    test('Returns 200 : create order with valid quantity, contractNumber, customerNote, internalNote', async () => {
      const data = positiveCase.valid1;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();

      const resp = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);
      const newData = resp.body;
      expect(resp.statusCode).toBe(200);
      const insertedData = await Order.query().findById(newData.id);
      expect(insertedData?.quantity).toBe(data.quantity);
      expect(insertedData?.contractNumber).toBe(data.contractNumber);
      expect(insertedData?.customerNote).toBe(data.customerNote);
      expect(insertedData?.internalNote).toBe(data.internalNote);
    });

    test('Returns 200 : create order with given email sent ', async () => {
      const data = negativeCase.withEmailSent;

      const resp = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);

      expect(resp.statusCode).toBe(200);
      expect(resp.body.emailSent).toBe('NONE');
      const insertedData = await Order.query().findById(resp.body.id);
      expect(insertedData?.emailSent).toBe('NONE');
    });

    test('Returns 400 : create order with invalid Dates', async () => {
      const data = {
        orgId: 1,
        subscriptionStartDate: '2022/10/10T12:00:00',
        expirationDate: '2022/11/10T13:00:00Z',
        quantity: 1,
      };

      const resp = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);

      expect(resp.statusCode).toBe(400);
      expect(resp.body.messages).toContain(
        'Subscription start date is not valid'
      );
      expect(resp.body.messages).toContain('Expiration date is not valid');
    });

    test.each(negativeCase.invalidOrgIds)(
      'Returns 400 : create order with invalid OrgId : $orgId',
      async (item) => {
        const resp = await request
          .post('/api/order')
          .send(item)
          .auth(systemSettings.user, systemSettings.password);

        expect(resp.statusCode).toBe(400);
        expect(resp.body.messages).toContain('OrgId should be an integer');
      }
    );

    test('Returns 400 : create order with expiration date before start date', async () => {
      const data = negativeCase.invalidStartAndEndDate;

      const resp = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);

      expect(resp.statusCode).toBe(400);
      expect(resp.body.messages).toContain(
        'Expiration date should be greater than Start date'
      );
    });

    test.each(negativeCase.invalidQuantity)(
      'Returns 400 : create order with invalid quantity : $quantity',
      async (item) => {
        const resp = await request
          .post('/api/order')
          .send(item)
          .auth(systemSettings.user, systemSettings.password);

        expect(resp.statusCode).toBe(400);
        expect(resp.body.messages).toContain(
          'Quantity should be a positive integer'
        );
      }
    );
  });
  describe('DELETE /api/order/:id', () => {
    afterAll(async () => {
      await Order.query().delete();
    });
    test('return 204 after successful deletion and not found when deleting the deleted order', async () => {
      const { positiveCase } = mockedData;
      const data = positiveCase.default;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();
      const res1 = await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);
      const deleteResponse = await request
        .delete(`/api/order/${res1.body.id}`)
        .auth(systemSettings.user, systemSettings.password);
      const notFoundDeleteResponse = await request
        .delete(`/api/order/${res1.body.id}`)
        .auth(systemSettings.user, systemSettings.password);
      expect(deleteResponse.statusCode).toBe(HttpStatusCode.OK_NO_CONTENT);
      expect(notFoundDeleteResponse.statusCode).toBe(HttpStatusCode.NOT_FOUND);
    });
    test('test case for invalid id', async () => {
      const badRequestResponse = await request
        .delete(`/api/order/abc`)
        .auth(systemSettings.user, systemSettings.password);
      expect(badRequestResponse.statusCode).toBe(HttpStatusCode.BAD_REQUEST);
    });
  });

  describe('GET /api/order/{orgId}', () => {
    beforeAll(async () => {
      await Order.query().delete();
      const { positiveCase } = mockedData;
      const data = positiveCase.default;
      const today = new Date();
      data.subscriptionStartDate = today.toDateString();
      today.setDate(today.getDate() + 2);
      data.expirationDate = today.toDateString();
      await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);
      await request
        .post('/api/order')
        .send(data)
        .auth(systemSettings.user, systemSettings.password);
    });

    afterAll(async () => {
      await Order.query().delete();
    });

    test('return success 200', async () => {
      const res = await request
        .get('/api/order/1')
        .auth(systemSettings.user, systemSettings.password);
      expect(res.statusCode).toBe(HttpStatusCode.OK);
      expect(res.body.length).toBe(2);
    });
    test('return BAD Request 400', async () => {
      const res = await request
        .get('/api/order/1.009')
        .auth(systemSettings.user, systemSettings.password);
      expect(res.statusCode).toBe(HttpStatusCode.BAD_REQUEST);
    });
    test('return NOT_FOUND 404', async () => {
      const res = await request
        .get('/api/order/5')
        .auth(systemSettings.user, systemSettings.password);
      expect(res.statusCode).toBe(HttpStatusCode.NOT_FOUND);
    });
  });

  describe('PUT /api/order/:id', () => {
    let orgId: number;
    let id: number;
    let order: OrderModel;

    const createOrder = async (orderModel: OrderModel): Promise<void> => {
      await Order.query().insert(toObjectionModel(orderModel));
    };

    const createSubscription = async (
      orgId: number,
      subscription: number
    ): Promise<void> => {
      await subscriptionRepository.upsert(orgId, subscription);
    };

    beforeAll(async () => {
      await Order.query().truncate();
      await Subscription.query().truncate();
    });

    beforeEach(async () => {
      const endDate = new Date();
      id = 1;
      orgId = 1;
      order = {
        orgId,
        subscriptionStartDate: new Date(),
        expirationDate: new Date(endDate.setDate(endDate.getDate() + 30)),
        emailSent: 'NONE',
        quantity: 1,
        customerNote: 'note1',
        internalNote: 'note2',
        contractNumber: 'opportunityId',
      };

      await createOrder(order);

      const subscription = 10;
      await createSubscription(orgId, subscription);
    });

    afterEach(async () => {
      await Order.query().truncate();
      await Subscription.query().truncate();
    });

    test('returns 200 OK if the subscriptionStartDate is set to a past date.', async () => {
      const req = updateOrder.positiveTests.subscriptionStartDate.pastDate;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK and sets the optional field (customerNote in this case) to null', async () => {
      const req = updateOrder.positiveTests.optionalFieldToNull;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
      expect(res.body.customerNote).toBe(null);
    });

    test('returns 200 OK if the subscriptionStartDate is set to a future date, less than expirationDate.', async () => {
      const req = updateOrder.positiveTests.subscriptionStartDate.futureDate;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the expirationDate is set to a past date, but greater than subscriptionStartDate.', async () => {
      const req = updateOrder.positiveTests.expirationDate.pastDate;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the quantity is updated to a positive integer.', async () => {
      const req = updateOrder.positiveTests.quantity;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the contractNumber is updated.', async () => {
      const req = updateOrder.positiveTests.contractNumber;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the order customer note and internal note is updated.', async () => {
      const req = updateOrder.positiveTests.note;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the emailSent is updated to a valid value.', async () => {
      const req = updateOrder.positiveTests.emailSent;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 200 OK if the order ID is changed', async () => {
      const orderId: any = 2;
      const req = {
        id: orderId,
        ...updateOrder.positiveTests.idChanged,
      };

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      delete req.id;

      expect(res.statusCode).toEqual(200);
      expect(res.body.id).toEqual(id);
      expect(res.body).toMatchObject(req);
    });

    test('returns 400 if the id is invalid.', async () => {
      const invalidId = -1;
      const req = updateOrder.negativeTests.invalidId;

      const res = await request
        .put(`/api/order/${invalidId}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual('Invalid order id.');
    });

    test('returns 400 if the order id does not exist.', async () => {
      const invalidId = 2;
      const req = updateOrder.negativeTests.invalidId;

      const res = await request
        .put(`/api/order/${invalidId}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(404);
      expect(res.body.httpStatusCode).toEqual(404);
      expect(res.body.messages[0]).toEqual('Order not found.');
    });

    test('returns 400 if the ordId is changed.', async () => {
      const req = updateOrder.negativeTests.orgIdChanged;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual('Cannot change orgId');
    });

    test('returns 400 if the expirationDate is updated so it is before subscriptionStartDate.', async () => {
      const req = updateOrder.negativeTests.invalidExpirationDate;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual(
        'Expiration date should be greater than Start date'
      );
    });

    test('returns 400 if the quantity is invalid.', async () => {
      const req = updateOrder.negativeTests.invalidQuantity;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual(
        'Quantity should be a positive integer'
      );
    });

    test('returns 400 if the emailSent value is invalid.', async () => {
      const req = updateOrder.negativeTests.invalidEmailSent;

      const res = await request
        .put(`/api/order/${id}`)
        .auth(systemSettings.user, systemSettings.password)
        .send(req);

      expect(res.statusCode).toEqual(400);
      expect(res.body.httpStatusCode).toEqual(400);
      expect(res.body.messages[0]).toEqual(
        `emailSent must be one of ${Object.values(EmailSentEnum).join('|')}`
      );
    });
  });
});
