import {
  isInteger,
  isValidDate,
  validateApplications,
  validateBaseOrderPayload,
  validateMpLicences,
  validateMpName,
  validateOrgId,
  validateUpdateOrder,
} from '../index';

const today = new Date();
const tomorrow = new Date();
tomorrow.setDate(today.getDate() + 1);

export const mockData = {
  invalid1: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: 4,
        mpType: 'appliance',
      },
    ],
  },
  invalid2: {
    parentOrgId: -2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  invalid3: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: -1,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  invalid4: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: -4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  invalid5: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: '',
        applications: 1,
        orgId: -4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  valid3: {
    parentOrgId: 99999999,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  valid: {
    parentOrgId: 2,
    monitoringPoints: [
      {
        mpName: 'router',
        applications: 1,
        orgId: 4,
        mpType: 'appliance-r1000',
      },
    ],
  },
  valid2: {
    parentOrgId: 2,
    monitoringPoints: [],
  },
  invalidApplication: [-1, 1.01, 'abc'],
  invalidOrgId: [0, 'abc', 1.01],
  invalidMpName: ['', null],
  invalidInteger: [1.01, 'abc'],
  invalidDate: ['abc', '1:03'],
  validDate: ['1', '2000-12-31T18:30:00.000Z'],
  invalidCreateOrder: [
    {
      orgId: 1,
      subscriptionStartDate: '2022-10-10T12:00:00.000Z',
      expirationDate: '2022-08-10T13:00:00.000Z',
      quantity: 1,
    },
    {
      orgId: 1,
      subscriptionStartDate: '',
      expirationDate: '2022-08-10T13:00:00.000Z',
      quantity: 1,
    },
    {
      orgId: 1,
      subscriptionStartDate: '2022-10-10T12:00:00.000Z',
      expirationDate: '',
      quantity: 1,
    },
    {
      orgId: -1,
      subscriptionStartDate: '2022-10-10T12:00:00.000Z',
      expirationDate: '',
      quantity: 1,
    },
    {
      orgId: 1,
      subscriptionStartDate: '2022-10-10T12:00:00.000Z',
      expirationDate: '',
      quantity: -1,
    },
  ],
  validCreateOrder: {
    orgId: 1,
    subscriptionStartDate: today,
    expirationDate: tomorrow,
    quantity: 1,
  },
  invalidUpdateOrder: [
    {
      orgId: 1,
      subscriptionStartDate: '',
      expirationDate: '2022-09-17T12:34:04.014Z',
      emailSent: 'NONE',
      quantity: 1,
    },
    {
      orgId: 1,
      subscriptionStartDate: today,
      expirationDate: tomorrow,
      emailSent: '',
      quantity: 1,
    },
  ],
  validUpdateOrder: {
    orgId: 1,
    subscriptionStartDate: today,
    expirationDate: tomorrow,
    emailSent: 'NONE',
    quantity: 1,
  },
};

describe('Test case for mpLicense request validation', () => {
  test('when mpType not in soul mp_definition', () => {
    expect(validateMpLicences(mockData.invalid1)).toBe(true);
  });
  test('when invalid parentId', () => {
    expect(validateMpLicences(mockData.invalid2)).toBe(false);
  });
  test('when invalid application', () => {
    expect(validateMpLicences(mockData.invalid3)).toBe(false);
  });
  test('when invalid orgId', () => {
    expect(validateMpLicences(mockData.invalid4)).toBe(false);
  });
  test.each([mockData.valid, mockData.valid3])('when valid orgId', () => {
    expect(validateMpLicences(mockData.valid3)).toBe(true);
  });
  test('when valid mps', () => {
    expect(validateMpLicences(mockData.valid2)).toBe(true);
  });
  test('when invalid mpName', () => {
    expect(validateMpLicences(mockData.invalid5)).toBe(false);
  });
});

describe('TestCase for validateApplications,isValidDate,validateOrgId,isInteger functions', () => {
  test.each(mockData.invalidApplication)(
    'Invalid applications %s',
    (application) => {
      expect(validateApplications(application)).toBe(false);
    }
  );
  test.each(mockData.invalidOrgId)('Invalid orgId %s', (orgIds) => {
    expect(validateOrgId(orgIds)).toBe(false);
  });
  test.each(mockData.invalidMpName)('Invalid mpName %s', (mpName) => {
    expect(validateMpName(mpName)).toBe(false);
  });
  test.each(mockData.invalidDate)('Invalid date %s', (dateData) => {
    expect(isValidDate(dateData)).toBe(false);
  });
  test.each(mockData.invalidInteger)('Not Integer %s', (integerData) => {
    expect(isInteger(integerData)).toBe(false);
  });

  test.each(mockData.validDate)('Valid date %s', (dateData) => {
    expect(isValidDate(dateData)).toBeInstanceOf(Date);
  });
});

describe('TestCase for validateBaseOrderPayload & validateUpdateOrder', () => {
  test.each`
    data                              | expectedValue
    ${mockData.invalidCreateOrder[0]} | ${'Expiration date should be greater than Start date'}
    ${mockData.invalidCreateOrder[1]} | ${'Subscription start date is not valid'}
    ${mockData.invalidCreateOrder[2]} | ${'Expiration date is not valid'}
    ${mockData.invalidCreateOrder[3]} | ${'OrgId should be an integer'}
    ${mockData.invalidCreateOrder[4]} | ${'Quantity should be a positive integer'}
  `(
    'invalid testCases for validateBaseOrderPayload function',
    async ({ data, expectedValue }) => {
      const error = validateBaseOrderPayload(data);
      expect(error.errors[0]).toBe(expectedValue);
    }
  );
  test('valid TestCase for validateBaseOrderPayload', () => {
    expect(validateBaseOrderPayload(mockData.validCreateOrder).result).toBe(
      true
    );
  });
  test.each`
    data                                                      | expectedValue
    ${{ id: '1', dataValue: mockData.invalidUpdateOrder[0] }} | ${'Subscription start date is not valid'}
    ${{ id: '1', dataValue: mockData.invalidUpdateOrder[1] }} | ${'emailSent must be one of NONE|EXPIRING_SOON|EXPIRED'}
    ${{ id: '-1', dataValue: mockData.validUpdateOrder }}     | ${'Invalid order id.'}
  `(
    'invalid testCases for validateUpdateOrder function',
    async ({ data, expectedValue }) => {
      const error = validateUpdateOrder(data.id, data.dataValue);
      expect(error.errors[0]).toBe(expectedValue);
    }
  );
  test('valid testCase for validateUpdateOrder', () => {
    expect(validateUpdateOrder('1', mockData.validUpdateOrder).result).toBe(
      true
    );
  });
});
