import { EmailSentEnum, IMpLicenseRequestBody } from '../../types';

export const validateOrgId = (orgId: any) => {
  if (typeof orgId !== 'number' || orgId < 1 || orgId % 1 !== 0) {
    return false;
  }
  return true;
};

export const validateApplications = (applicationCount: any) => {
  if (
    typeof applicationCount !== 'number' ||
    applicationCount < 0 ||
    applicationCount % 1 !== 0
  ) {
    return false;
  }
  return true;
};

export const validateMpName = (mpName: any) => {
  return typeof mpName === 'string' && mpName.length > 0;
};

export const validateMpLicences = (
  mpRecords: IMpLicenseRequestBody
): boolean => {
  const { parentOrgId, monitoringPoints } = mpRecords;
  if (!validateOrgId(parentOrgId)) {
    return false;
  } else {
    for (const { applications, orgId, mpName } of monitoringPoints) {
      if (
        !(
          validateApplications(applications) &&
          validateOrgId(orgId) &&
          validateMpName(mpName)
        )
      ) {
        return false;
      }
    }
  }
  return true;
};

/**
 * Checks if a supplied value can be parsed as integer
 *
 * @param {string|number}value
 * @returns boolean
 */
export const isInteger = (value: string | number) => {
  const data = +value;

  return !isNaN(data) && data % 1 === 0;
};

/**
 * Checks if a supplied string is a valid date string
 *
 * @param {integer} value
 * @return {Date|boolean} Date instance if valid date; otherwise false
 */
export const isValidDate = (value: string): boolean | Date => {
  const dateNumber = Date.parse(value);
  if (isNaN(dateNumber)) return false;
  else return new Date(dateNumber);
};

/**
 * Validation Function for Basic Order payload
 *
 * @param { orgId: number, subscriptionStartDate: string, expirationDate: string, quantity: number }
 * @returns { result : boolean, errors: string[] }
 */
export const validateBaseOrderPayload = ({
  orgId,
  subscriptionStartDate,
  expirationDate,
  quantity,
}): { result: boolean; errors: string[] } => {
  const errors: string[] = [];
  if (!validateOrgId(orgId)) {
    errors.push('OrgId should be an integer');
  }
  if (!isInteger(quantity) || Number(quantity) < 0) {
    errors.push('Quantity should be a positive integer');
  }
  let correctDate = true;
  const start = isValidDate(subscriptionStartDate);
  const end = isValidDate(expirationDate);
  if (!start) {
    correctDate = false;
    errors.push('Subscription start date is not valid');
  }
  if (!end) {
    correctDate = false;
    errors.push('Expiration date is not valid');
  }
  if (correctDate && start >= end) {
    errors.push('Expiration date should be greater than Start date');
  }

  return { result: errors.length === 0, errors };
};

/**
 * Validation Function for Update Order payload
 *
 * @param { id: number, orgId: number, subscriptionStartDate: string, expirationDate: string, quantity: number, emailSent: string }
 * @returns { result : boolean, errors: string[] }
 */
export const validateUpdateOrder = (
  id: string,
  { orgId, subscriptionStartDate, expirationDate, quantity, emailSent }
): { result: boolean; errors: string[] } => {
  const { errors } = validateBaseOrderPayload({
    orgId,
    subscriptionStartDate,
    expirationDate,
    quantity,
  });

  if (!isInteger(id) || Number(id) < 0) {
    errors.push('Invalid order id.');
  }

  if (!Object.values(EmailSentEnum).includes(emailSent)) {
    errors.push(
      `emailSent must be one of ${Object.values(EmailSentEnum).join('|')}`
    );
  }

  return { result: errors.length === 0, errors };
};
