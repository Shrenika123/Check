import { DefaultContext, DefaultState, ParameterizedContext } from 'koa';
import { DBError, NotFoundError, UniqueViolationError } from 'objection';
import { getLogger } from '../logger';

export class HttpStatusError extends Error {
  httpStatusCode: number;
  messages: string[];
  logLevel: string;

  constructor(
    httpStatusCode: number,
    message: string | string[],
    logLevel?: string
  ) {
    super(message.toString());
    this.httpStatusCode = httpStatusCode;
    this.messages = Array.isArray(message) ? message : [message];
    this.logLevel = logLevel || (this.httpStatusCode >= 500 ? 'error' : 'warn');
  }

  toResponse() {
    return {
      httpStatusCode: this.httpStatusCode,
      messages: this.messages,
    };
  }
}

export class DuplicateError extends Error {
  messages: string[];

  constructor(message: string) {
    super(message);
    this.messages = [message];
  }

  toResponse() {
    return {
      messages: this.messages,
    };
  }
}

export const withStatusCode = (err: Error, statusCode: number) =>
  new HttpStatusError(statusCode, err.message);

export const dbErrorHandler = async (
  ctx: ParameterizedContext<DefaultState, DefaultContext>,
  next: () => Promise<void>
) => {
  try {
    await next();
  } catch (err) {
    if (err instanceof NotFoundError) {
      throw withStatusCode(err, 404);
    } else if (err instanceof UniqueViolationError) {
      throw withStatusCode(
        new Error(
          `An entry with the same (${err.columns.join(', ')}) already exists`
        ),
        409
      );
    } else if (err instanceof DBError) {
      throw withStatusCode(err, 400);
    } else if (err instanceof DuplicateError) {
      throw withStatusCode(err, 409);
    } else {
      throw err;
    }
  }
};

/**
 * The final handler for all uncaught errors. Creates an appropriate HTTP response in the format expected by APM.
 * @param ctx
 * @param next
 */
export const errorHandler = async (
  ctx: ParameterizedContext<DefaultState, DefaultContext>,
  next: () => Promise<void>
) => {
  try {
    await next();
  } catch (err) {
    const errmsg = `[${ctx.method}] ${ctx.path}: ${err.message}`;
    if (err instanceof HttpStatusError) {
      getLogger().log(err.logLevel, errmsg);
      ctx.body = err.toResponse();
      ctx.status = err.httpStatusCode;
    } else if (err.name === 'UnauthorizedError') {
      getLogger().error(errmsg);
      // Basic auth failure.
      throw err;
    } else {
      getLogger().error(errmsg);
      getLogger().error(err.stack);
      ctx.body = {
        httpStatusCode: 500,
        messages: ['Internal Error'],
      };
      ctx.status = 500;
    }
  }
};
