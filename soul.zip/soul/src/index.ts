import Koa from 'koa';
import bodyParser from 'koa-bodyparser';

import { createApiRouter } from './api/router';
import { establishDbConnection } from './store/store';
import { initLoggers, getLogger, auditLog } from './logger';
import { startBackgroundTasks } from './background/backgroundTasks';
import { systemSettings } from './config';
import { Server } from 'http';
import { koaSwagger } from 'koa2-swagger-ui';
import swagger from './swagger.json';
import { default as cors } from '@koa/cors';

// to allow ctrl-c to kill the docker container
process.on('SIGINT', function () {
  process.exit();
});

let server: Server;

async function initialize(): Promise<Server> {
  initLoggers();
  getLogger().info('SOUL Startup...');

  await establishDbConnection();

  const app = new Koa();
  app.use(bodyParser());
  app.use(auditLog());
  app.use(cors());

  app.use(
    koaSwagger({
      swaggerOptions: {
        spec: swagger,
      },
    })
  );

  const apiRouter = createApiRouter(
    systemSettings.user,
    systemSettings.password
  );
  app.use(apiRouter.routes()).use(apiRouter.allowedMethods());

  const port = systemSettings.port;
  server = app.listen(port, () => {
    getLogger().info(
      `SOUL Startup Complete. Server is listening on port ${port}.`
    );
    startBackgroundTasks();
  });

  return server;
}

export const getServer = (): Server => server;

export default initialize();
