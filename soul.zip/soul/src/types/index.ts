import { MpLicenseModel } from '../api/models/mpLicense';

export enum EmailSentEnum {
  NONE = 'NONE',
  EXPIRING_SOON = 'EXPIRING_SOON',
  EXPIRED = 'EXPIRED',
}
export interface IMpLicenseRequestBody {
  parentOrgId: number;
  monitoringPoints?: IMonitoringPointsEntity[] | null;
}
export interface IMonitoringPointsEntity {
  mpName: string;
  applications: number;
  orgId: number;
  mpType: string;
}

export enum OrderTableKeys {
  ORG_ID = 'orgId',
}

export enum MpLicenseTableKeys {
  ORG_ID = 'orgId',
  MP_NAME = 'mpName',
  MP_TYPE = 'mpType',
  PARENT_ORG_ID = 'parentOrgId',
  CONSUMPTION_BASE = 'consumptionBase',
  CONSUMPTION_ADDON = 'consumptionAddon',
}

export enum AULCosts {
  SINGLE_APP = 1,
  SINGLE_AUL_APPS = 15,
}
export interface IMpDefinitionObject {
  aulCost: number;
  applicationCount: number;
}

export interface IMpReportsAndConsumption {
  consumption: number;
  mpReports: MpLicenseModel[];
}

export enum HttpStatusCode {
  'OK' = 200,
  'NOT_FOUND' = 404,
  'OK_NO_CONTENT' = 204,
  'BAD_REQUEST' = 400,
  'SERVER_ERROR' = 500,
}

export enum HttpStatusMessage {
  'OK' = 'OK',
  'BAD_REQUEST' = 'Bad Request',
  'ORDER_DELETE_SUCCESS' = 'Order Deleted Successfully',
  'ORDER_NOT_FOUND' = 'Order Not Found',
}
