import dotenv from 'dotenv';

dotenv.config();

const getNumber = (name: string, defaultValue?: number) => {
  if (process.env[name]) {
    return parseInt(process.env[name], 10);
  } else {
    return defaultValue;
  }
};

export const databaseSettings = {
  dbUser: process.env.DB_USER || 'soul_rw',
  dbPassword: process.env.DB_PASSWORD,
  dbHost: process.env.DB_HOST || 'localhost',
  dbPort: getNumber('DB_PORT', 5432),
  dbName: process.env.DB_NAME || 'souldb',
  dbSsl: process.env.DB_SSL === 'true',
  dbCert: process.env.DB_CERT,
  dbRetrySec: getNumber('DB_RETRY_SEC', 10),
};

export const systemSettings = {
  user: process.env.TRUSTED_API_USER || 'pvc',
  password: process.env.TRUSTED_API_PASSWORD || 'pass',
  port: getNumber('PORT', 8080),
  pca: process.env.PCA === 'true',
};

export const backgroundTaskSettings = {
  updateSubscriptionsAndDeleteOldOrders: {
    periodInMinutes: getNumber(
      process.env.UPDATE_SUBS_PERIOD_IN_MINUTES,
      24 * 60
    ),
  },
};

export const statsdSettings = {
  host: process.env.STATSD_HOST || 'mon.pm-dev.appneta.com',
  port: getNumber('STATSD_PORT', 8125),
  prefix: process.env.STATSD_PREFIX || 'soul-dev',
};

export const debugSettings = {
  debugKnex: process.env.DEBUG_KNEX,
  logLevel: process.env.LOG_LEVEL || 'info',
  logLocation: process.env.LOG_LOCATION || 'logs/soul.log',
  auditLogLocation: process.env.AUDIT_LOG_LOCATION || 'logs/soul-audit.log',
};

export const sessionSettings = {
  ttlInMs: getNumber('SESSION_TTL_MS', 1200000),
  cleanupIntervalInMs: getNumber('SESSION_CLEANUP_INTERVAL', 60000),
};
