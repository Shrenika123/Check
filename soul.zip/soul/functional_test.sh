#!/bin/bash

DOCKER_PROJECT_NAME=soul_functional_tests

docker-compose -p $DOCKER_PROJECT_NAME up --detach --build

SECONDS=0
until curl -s http://localhost:8080/api/admin/healthCheck > /dev/null
do
  if (( SECONDS > 60 ))
  then
    echo "Giving up..."
    exit 1
  fi

  echo "Waiting for SOUL to start up..."
  sleep 2
done

# Set environment variables for npm run functional-tests.
export SOUL_HOST=http://localhost:8080
export TRUSTED_API_USER=pvc
export TRUSTED_API_PASSWORD=pass

KEEP_RUNNING=""
if [ "$1" == "--keep-running" ]
then
  KEEP_RUNNING="$1"
  shift
fi

npm run functional-tests -- "$@"

if [ "$KEEP_RUNNING" != "--keep-running" ]
then
  docker-compose -p $DOCKER_PROJECT_NAME down -v
fi
