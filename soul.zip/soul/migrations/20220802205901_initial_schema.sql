DO $$
BEGIN

IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name='orders') THEN

    -- Table: orders

    CREATE TABLE orders
    (
        id serial,
        org_id integer NOT NULL,
        subscription_start_date timestamp without time zone NOT NULL,
        expiration_date timestamp without time zone NOT NULL,
        quantity integer NOT NULL,
        email_sent text NOT NULL,
        customer_note text,
        internal_note text,
        contract_number text,
        CONSTRAINT orders_pk PRIMARY KEY (id)
    );

    -- Table: subscriptions

    CREATE TABLE subscriptions
    (
        org_id integer NOT NULL,
        subscription integer,
        consumption decimal,
        CONSTRAINT subscriptions_pk PRIMARY KEY (org_id)
    );

    -- Table: mp_licenses

    CREATE TABLE mp_licenses
    (
        mp_name text NOT NULL,
        mp_type text NOT NULL,
        org_id integer NOT NULL,
        parent_org_id integer NOT NULL,
        consumption_base decimal,
        consumption_addon decimal,
        CONSTRAINT mp_licenses_pk PRIMARY KEY (mp_name, mp_type, org_id, parent_org_id)
    );

END IF;

END
$$ LANGUAGE 'plpgsql';