import { Knex } from 'knex';
import fs from 'fs';

export async function up(knex: Knex): Promise<void> {
  const script = fs
    .readFileSync('migrations/20220802205901_initial_schema.sql')
    .toString();
  await knex.raw(script);
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema
    .dropTableIfExists('orders')
    .dropTableIfExists('subscriptions')
    .dropTableIfExists('mp_licenses');
}
