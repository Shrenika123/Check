import { getLogger, initLoggers } from './src/logger';
import { establishDbConnection, getDbConfig } from './src/store/store';

const checkDbConnection = async () => {
  initLoggers();
  getLogger().info('Checking connection to DB before running migrations...');
  await establishDbConnection();
  getLogger().info(
    'Connection to DB established, proceeding to run migrations.'
  );
  return getDbConfig();
};

module.exports = checkDbConnection();
