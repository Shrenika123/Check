# Scale Optimized Universal Licensing (SOUL) Service

A dockerized NodeJS service for calculating and managing license orders.

## Dev Env Requirements

* Docker
* Node v16.13.0 (e.g. use `nvm install 16.13.0`)
* Postgres (running locally - with SOUL DB)

Create an `.env` file in this folder with at least the following environment variables:

```
DB_PASSWORD=<pw for the DB_USER>
```

### Debugging in VS Code

* use the "Launch Service" launch configuration


### Running in docker

```
docker build -t soul:latest .
docker run --rm -it --env-file .env -p 8080:8080 soul:latest
```

To connect to a DB running on `localhost`:

* add `--network=host` to the `docker run` command _or_
* when running on Mac: add `-e DB_HOST=host.docker.internal` to the `docker run` command


### Running on the host

Install dependencies:

```
npm i
```

Start the app:
```
npm start
```

### Running database migrations

If working with a PCA database, be sure to set:
```
PCA=true
```

```
npm run migrate
```

Generating a new migration file template:
```
npm run new-migration <migration_name>
```

### Running linting & tests

```
npm run lint
npm run test
```

### Running functional tests

Requirements: 
* `docker-compose` needs to be installed.
* Node version as specified above
* `nmp i` has been run

Running the tests:
```
./functional_test.sh [--keep-running] [<jest-args>]
```

**Options:**

* `--keep-running`: this prevents the docker containers from being stopped after the tests complete, 
  this can be useful to inspect the logs or the database (optional, needs to be provided as the first arg to the script).
* `<jest-args>`: any additional arguments are passed in to the `jest` command. Use this to e.g. only run a specific
  test (e.g. `-t "oranization"` will only run any tests / suites containing the word `organization`)

### Docker Compose

To run both the postgres DB and SOUL service using `docker-compose`:

Create a `.env` file with at least:

```
DB_PASSWORD=<secret-db-password>
```

then run:


```
docker-compose up --build --force-recreate
```

